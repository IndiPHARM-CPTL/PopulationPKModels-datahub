library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

felodipine_code <- '
$PROB
- Ref: Blychert E, Edgar B, Elmfeldt D, Hedner T.
- A population study of the pharmacokinetics of felodipine.
- Br J Clin Pharmacol. 1991;31(1):15-24.

$PARAM @annotated
KA        : 0.60   : 1/h      First-order absorption rate constant
FABS      : 0.145  : --       Oral bioavailability, mean 14.5%

TVCL      : 39.3   : L/h      Clearance at AGE = 43 years; 655 mL/min
AGE       : 43     : years    Age
AGE_REF   : 43     : years    Reference age
TH_AGE_CL : 0.521  : L/h/year Age effect on CL; approximately 8.68 mL/min/year decrease

VC        : 54     : L        Central volume
Q         : 27     : L/h      Intercompartmental clearance
VP        : 507    : L        Peripheral volume

PROP_SD   : 0.20   : --       Proportional residual SD, assumed

$CMT @annotated
DEPOT  : Oral absorption compartment
CENT   : Central compartment
PERIPH : Peripheral compartment

$OMEGA @diag @labels ETA_F ETA_CL ETA_VC
0.239 0.177 0.115

$SIGMA
1

$GLOBAL
double Fi;
double CLcov;
double KAi;
double CLi;
double VCi;
double Qi;
double VPi;
double K10i;
double K12i;
double K21i;

$MAIN

Fi = FABS * exp(ETA(1));

if(Fi > 1.0) {
  Fi = 1.0;
} else {
  Fi = Fi;
}

F_DEPOT = Fi;

CLcov = TVCL - TH_AGE_CL * (AGE - AGE_REF);

if(CLcov < 5.0) {
  CLcov = 5.0;
} else {
  CLcov = CLcov;
}

KAi = KA;
CLi = CLcov * exp(ETA(2));
VCi = VC * exp(ETA(3));
Qi  = Q;
VPi = VP;

K10i = CLi / VCi;
K12i = Qi  / VCi;
K21i = Qi  / VPi;

$ODE
dxdt_DEPOT  = -KAi * DEPOT;

dxdt_CENT   =  KAi * DEPOT
             - K10i * CENT
             - K12i * CENT
             + K21i * PERIPH;

dxdt_PERIPH =  K12i * CENT
             - K21i * PERIPH;

$TABLE
double FEL_mgL  = CENT / VCi;
double FEL_ngmL = FEL_mgL * 1000.0;

double DV_ngmL = FEL_ngmL * exp(PROP_SD * EPS(1));

$CAPTURE
FEL_ngmL DV_ngmL
Fi KAi CLi VCi Qi VPi K10i K12i K21i AGE
'

mod <- mcode("felodipine_blychert1991_ngmL", felodipine_code)

set.seed(123)

dose_mg <- c(5, 10)

N        <- 1000
tau_h    <- 12
n_days   <- 10
n_doses  <- n_days * 2
addl_md  <- n_doses - 1

t_end_sd <- 72
t_end_md <- n_days * 24

delta_sd <- 0.1
delta_md <- 0.1

last_dose_h <- (n_doses - 1) * tau_h

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q12h x", n_days, " days")

mod_typ <- zero_re(mod)

idata_typ <- tibble(
  ID  = 1,
  AGE = 43
)

idata_pop <- tibble(
  ID  = 1:N,
  AGE = pmin(pmax(rnorm(N, mean = 43, sd = 5), 30), 70)
)


fig1_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT"
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = FEL_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Felodipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Felodipine twice daily (5 mg/10mg), single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax_ng_mL = max(CP, na.rm = TRUE),
    Tmax_h     = time[which.max(CP)],
    C12_ng_mL  = CP[which.min(abs(time - 12))],
    C24_ng_mL  = CP[which.min(abs(time - 24))],
    C72_ng_mL  = CP[which.min(abs(time - 72))],
    .groups = "drop"
  )


fig2_list <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = FEL_ngmL,
      Dose = paste0(d, " mg q12h x", n_days, " days")
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Felodipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Felodipine twice daily (5 mg/10mg), multi-dose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= last_dose_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day10_ng_mL = max(CP, na.rm = TRUE),
    Tmax_day10_h     = time[which.max(CP)] - last_dose_h,
    Ctrough_ng_mL    = CP[which.min(abs(time - t_end_md))],
    .groups = "drop"
  )



fig3_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT"
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, seed = 123 + d) %>%
    as_tibble() %>%
    mutate(
      CP = FEL_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Felodipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Felodipine twice daily (5 mg/10mg), single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_ng_mL = max(CP, na.rm = TRUE),
    Tmax_h     = time[which.max(CP)],
    C12_ng_mL  = CP[which.min(abs(time - 12))],
    C24_ng_mL  = CP[which.min(abs(time - 24))],
    C72_ng_mL  = CP[which.min(abs(time - 72))],
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax_ng_mL, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax_ng_mL, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax_ng_mL, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax_h, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax_h, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax_h, 0.95, na.rm = TRUE),
    
    C12_med = median(C12_ng_mL, na.rm = TRUE),
    C12_p05 = quantile(C12_ng_mL, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12_ng_mL, 0.95, na.rm = TRUE),
    
    C24_med = median(C24_ng_mL, na.rm = TRUE),
    C24_p05 = quantile(C24_ng_mL, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24_ng_mL, 0.95, na.rm = TRUE),
    
    C72_med = median(C72_ng_mL, na.rm = TRUE),
    C72_p05 = quantile(C72_ng_mL, 0.05, na.rm = TRUE),
    C72_p95 = quantile(C72_ng_mL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


fig4_list <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md, seed = 456 + d) %>%
    as_tibble() %>%
    mutate(
      CP = FEL_ngmL,
      time_day = time / 24,
      Dose = paste0(d, " mg q12h x", n_days, " days")
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time, time_day) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time_day, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.12,
    colour = NA
  ) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Felodipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Felodipine twice daily (5 mg/10mg), multi-dose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= last_dose_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_day10_ng_mL = max(CP, na.rm = TRUE),
    Tmax_day10_h     = time[which.max(CP)] - last_dose_h,
    C4_day10_ng_mL   = CP[which.min(abs(time - (last_dose_h + 4)))],
    C8_day10_ng_mL   = CP[which.min(abs(time - (last_dose_h + 8)))],
    Ctrough_ng_mL    = CP[which.min(abs(time - t_end_md))],
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day10_med = median(Cmax_day10_ng_mL, na.rm = TRUE),
    Cmax_day10_p05 = quantile(Cmax_day10_ng_mL, 0.05, na.rm = TRUE),
    Cmax_day10_p95 = quantile(Cmax_day10_ng_mL, 0.95, na.rm = TRUE),
    
    Tmax_day10_med = median(Tmax_day10_h, na.rm = TRUE),
    Tmax_day10_p05 = quantile(Tmax_day10_h, 0.05, na.rm = TRUE),
    Tmax_day10_p95 = quantile(Tmax_day10_h, 0.95, na.rm = TRUE),
    
    C4_day10_med = median(C4_day10_ng_mL, na.rm = TRUE),
    C4_day10_p05 = quantile(C4_day10_ng_mL, 0.05, na.rm = TRUE),
    C4_day10_p95 = quantile(C4_day10_ng_mL, 0.95, na.rm = TRUE),
    
    C8_day10_med = median(C8_day10_ng_mL, na.rm = TRUE),
    C8_day10_p05 = quantile(C8_day10_ng_mL, 0.05, na.rm = TRUE),
    C8_day10_p95 = quantile(C8_day10_ng_mL, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough_ng_mL, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough_ng_mL, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough_ng_mL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


p1
p2
p3
p4


fig1_summary
fig2_summary
fig3_summary
fig4_summary