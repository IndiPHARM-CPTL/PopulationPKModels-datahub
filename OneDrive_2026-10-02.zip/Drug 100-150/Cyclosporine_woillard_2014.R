library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

ciclosporin_code <- '
$PROB
Ciclosporin population PK model

- Ref:
  Woillard JB, Lebreton V, Neely M, et al.
  Pharmacokinetic tools for the dose adjustment of ciclosporin
  in haematopoietic stem cell transplant patients.
  Br J Clin Pharmacol. 2014;78(4):836-846.
  doi:10.1111/bcp.12394

- Adult HSCT recipients
- Oral ciclosporin
- Two-compartment disposition
- Erlang absorption with 5 sequential delay compartments
- First-order elimination

IMPORTANT:
CL, Q, VC, and VP are apparent oral parameters (CL/F, Q/F, VC/F, VP/F).
Therefore no additional oral bioavailability term is applied.

$PARAM @annotated
KTR      : 5.72    : 1/h     Erlang transit absorption rate constant
CL       : 41.2    : L/h     Apparent oral clearance (CL/F)
VC       : 222     : L       Apparent central volume (Vc/F)
Q        : 33.7    : L/h     Apparent intercompartmental clearance (Q/F)
VP       : 500     : L       Apparent peripheral volume (Vp/F), fixed
PROP_SD  : 0.1253  : --      Proportional residual SD
ADD_SD   : 23      : ng/mL   Additive residual SD (0.023 mg/L)

$CMT @annotated
DEPOT  : Delay compartment 1 / dosing compartment (mg)
TRANS1 : Delay compartment 2 (mg)
TRANS2 : Delay compartment 3 (mg)
TRANS3 : Delay compartment 4 (mg)
TRANS4 : Delay compartment 5 (mg)
CENT   : Central compartment (mg)
PERIPH : Peripheral compartment (mg)

$OMEGA @labels ETA_KTR ETA_Q ETA_VC ETA_CL
0.22314
0.41759
0.28140
0.14842

$SIGMA
1
1

$GLOBAL
double KTRi;
double Qi;
double VCi;
double CLi;
double VPi;

$MAIN

KTRi = KTR * exp(ETA(1));
Qi   = Q   * exp(ETA(2));
VCi  = VC  * exp(ETA(3));
CLi  = CL  * exp(ETA(4));

VPi  = VP;


$ODE

// Five sequential Erlang delay stages:
// DEPOT -> TRANS1 -> TRANS2 -> TRANS3 -> TRANS4 -> CENT

dxdt_DEPOT =
  - KTRi * DEPOT;

dxdt_TRANS1 =
    KTRi * DEPOT
  - KTRi * TRANS1;

dxdt_TRANS2 =
    KTRi * TRANS1
  - KTRi * TRANS2;

dxdt_TRANS3 =
    KTRi * TRANS2
  - KTRi * TRANS3;

dxdt_TRANS4 =
    KTRi * TRANS3
  - KTRi * TRANS4;


// Two-compartment disposition

dxdt_CENT =
    KTRi * TRANS4
  - (CLi / VCi) * CENT
  - (Qi  / VCi) * CENT
  + (Qi  / VPi) * PERIPH;

dxdt_PERIPH =
    (Qi / VCi) * CENT
  - (Qi / VPi) * PERIPH;


$TABLE

// CENT / VC = mg/L
// x1000 converts mg/L -> ng/mL

double CP_ngmL = 1000.0 * CENT / VCi;

double DV_PK =
    CP_ngmL * (1.0 + PROP_SD * EPS(1))
  + ADD_SD * EPS(2);


$CAPTURE
CP_ngmL DV_PK
KTRi CLi VCi Qi VPi
'


mod_csa <- mcode(
  "ciclosporin_woillard2014",
  ciclosporin_code
)



# ============================================================
# SIMULATION SETTINGS
# ============================================================

N <- 1000

# Woillard cohort median body weight
WT_typ <- 71

# Published starting regimen = 3 mg/kg BID
doses_mgkg <- c(3)

dose_levels <- paste0(
  doses_mgkg,
  " mg/kg (",
  round(doses_mgkg * WT_typ),
  " mg)"
)

tau <- 12

# Paper / nlmixr2 reconstruction used 10 doses = 5 days BID
n_dose <- 10

last_dose <- tau * (n_dose - 1)

t_end_sd <- 24
t_end_md <- last_dose + tau

# Finer sampling is useful because absorption is rapid
delta_sd <- 0.05
delta_md <- 0.05


at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}


auc_trap <- function(time, conc) {
  sum(
    diff(time) *
      (head(conc, -1) + tail(conc, -1)) / 2
  )
}


# Remove all IIV and residual variability
mod_typ <- zero_re(mod_csa)



# ============================================================
# FIGURE 1
# TYPICAL PATIENT — SINGLE DOSE
# ============================================================

fig1_list <- lapply(doses_mgkg, function(d_mgkg) {
  
  dose_mg <- round(d_mgkg * WT_typ)
  
  idata_typ <- tibble(
    ID = 1
  )
  
  ev_sd <- ev(
    time = 0,
    amt = dose_mg,
    cmt = 1
  )
  
  mod_typ %>%
    ev(ev_sd) %>%
    mrgsim(
      idata = idata_typ,
      end = t_end_sd,
      delta = delta_sd
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(
        d_mgkg,
        " mg/kg (",
        dose_mg,
        " mg)"
      )
    )
})


fig1_out <- bind_rows(fig1_list) %>%
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )


p1_csa <- ggplot(
  fig1_out,
  aes(
    time,
    CP_ngmL,
    color = Dose
  )
) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Ciclosporin concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Ciclosporin single dose"
  )

p1_csa



# -----------------------------
# Figure 1 summary
# first 12-h interval
# -----------------------------

fig1_summary <- fig1_out %>%
  filter(time <= tau) %>%
  group_by(Dose) %>%
  summarise(
    
    Cmax = max(CP_ngmL),
    
    Tmax_h =
      time[which.max(CP_ngmL)],
    
    C12 =
      at_time(
        time,
        CP_ngmL,
        tau
      ),
    
    AUC0_12 =
      auc_trap(
        time,
        CP_ngmL
      ),
    
    .groups = "drop"
  )


fig1_summary





# ============================================================
# FIGURE 2
# TYPICAL PATIENT — MULTIPLE DOSE / STEADY STATE
# ============================================================

fig2_list <- lapply(doses_mgkg, function(d_mgkg) {
  
  dose_mg <- round(d_mgkg * WT_typ)
  
  idata_typ <- tibble(
    ID = 1
  )
  
  ev_md <- ev(
    time = 0,
    amt = dose_mg,
    cmt = 1,
    ii = tau,
    addl = n_dose - 1
  )
  
  mod_typ %>%
    ev(ev_md) %>%
    mrgsim(
      idata = idata_typ,
      end = t_end_md,
      delta = delta_md
    ) %>%
    as_tibble() %>%
    mutate(
      
      Dose = paste0(
        d_mgkg,
        " mg/kg (",
        dose_mg,
        " mg)"
      ),
      
      time_day = time / 24
    )
})


fig2_out <- bind_rows(fig2_list) %>%
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )


p2_csa <- ggplot(
  fig2_out,
  aes(
    time_day,
    CP_ngmL,
    color = Dose
  )
) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Ciclosporin concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Ciclosporin BID for 5 days"
  )

p2_csa



# -----------------------------
# Figure 2 steady-state summary
# Last 12-h dosing interval
# -----------------------------

fig2_summary <- fig2_out %>%
  
  filter(
    time >= last_dose,
    time <= last_dose + tau
  ) %>%
  
  mutate(
    t_rel = time - last_dose
  ) %>%
  
  group_by(Dose) %>%
  
  summarise(
    
    Cmax_ss =
      max(CP_ngmL),
    
    Tmax_ss_h =
      t_rel[which.max(CP_ngmL)],
    
    Ctrough_ss =
      at_time(
        t_rel,
        CP_ngmL,
        tau
      ),
    
    AUCtau_ss =
      auc_trap(
        t_rel,
        CP_ngmL
      ),
    
    .groups = "drop"
  )


fig2_summary





# ============================================================
# FIGURE 3
# POPULATION — SINGLE DOSE
# ============================================================

set.seed(123)


fig3_list <- lapply(doses_mgkg, function(d_mgkg) {
  
  dose_mg <- round(d_mgkg * WT_typ)
  
  idata_pop <- tibble(
    ID = 1:N
  )
  
  ev_sd <- ev(
    time = 0,
    amt = dose_mg,
    cmt = 1
  )
  
  mod_csa %>%
    ev(ev_sd) %>%
    mrgsim(
      idata = idata_pop,
      end = t_end_sd,
      delta = delta_sd
    ) %>%
    as_tibble() %>%
    mutate(
      
      Dose = paste0(
        d_mgkg,
        " mg/kg (",
        dose_mg,
        " mg)"
      )
    )
})


fig3_raw <- bind_rows(fig3_list) %>%
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )



# -----------------------------
# Population concentration ribbon
# -----------------------------

fig3_sum <- fig3_raw %>%
  
  group_by(
    Dose,
    time
  ) %>%
  
  summarise(
    
    CP_med =
      median(CP_ngmL),
    
    CP_p05 =
      quantile(
        CP_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_ngmL,
        0.95
      ),
    
    .groups = "drop"
  )



p3_csa <- ggplot(
  fig3_sum,
  aes(
    time,
    CP_med,
    color = Dose,
    fill = Dose
  )
) +
  
  geom_ribbon(
    aes(
      ymin = CP_p05,
      ymax = CP_p95
    ),
    alpha = 0.25,
    colour = NA
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (h)",
    y = "Ciclosporin concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Ciclosporin single dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )


p3_csa



# -----------------------------
# Individual PK metrics
# -----------------------------

fig3_ind <- fig3_raw %>%
  
  filter(
    time <= tau
  ) %>%
  
  arrange(
    Dose,
    ID,
    time
  ) %>%
  
  group_by(
    Dose,
    ID
  ) %>%
  
  summarise(
    
    Cmax =
      max(CP_ngmL),
    
    Tmax_h =
      time[which.max(CP_ngmL)],
    
    C12 =
      at_time(
        time,
        CP_ngmL,
        tau
      ),
    
    AUC0_12 =
      auc_trap(
        time,
        CP_ngmL
      ),
    
    .groups = "drop"
  )



fig3_summary <- fig3_ind %>%
  
  group_by(Dose) %>%
  
  summarise(
    
    Cmax_med =
      median(Cmax),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(Tmax_h),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    C12_med =
      median(C12),
    
    C12_p05 =
      quantile(
        C12,
        0.05
      ),
    
    C12_p95 =
      quantile(
        C12,
        0.95
      ),
    
    
    AUC0_12_med =
      median(AUC0_12),
    
    AUC0_12_p05 =
      quantile(
        AUC0_12,
        0.05
      ),
    
    AUC0_12_p95 =
      quantile(
        AUC0_12,
        0.95
      ),
    
    .groups = "drop"
  )


fig3_summary





# ============================================================
# FIGURE 4
# POPULATION — MULTIPLE DOSE / STEADY STATE
# ============================================================

set.seed(123)


fig4_list <- lapply(doses_mgkg, function(d_mgkg) {
  
  dose_mg <- round(d_mgkg * WT_typ)
  
  idata_pop <- tibble(
    ID = 1:N
  )
  
  ev_md <- ev(
    time = 0,
    amt = dose_mg,
    cmt = 1,
    ii = tau,
    addl = n_dose - 1
  )
  
  mod_csa %>%
    ev(ev_md) %>%
    mrgsim(
      idata = idata_pop,
      end = t_end_md,
      delta = delta_md
    ) %>%
    as_tibble() %>%
    mutate(
      
      Dose = paste0(
        d_mgkg,
        " mg/kg (",
        dose_mg,
        " mg)"
      ),
      
      time_day = time / 24
    )
})


fig4_raw <- bind_rows(fig4_list) %>%
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )



# -----------------------------
# Population ribbon
# -----------------------------

fig4_sum <- fig4_raw %>%
  
  group_by(
    Dose,
    time,
    time_day
  ) %>%
  
  summarise(
    
    CP_med =
      median(CP_ngmL),
    
    CP_p05 =
      quantile(
        CP_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_ngmL,
        0.95
      ),
    
    .groups = "drop"
  )



p4_csa <- ggplot(
  fig4_sum,
  aes(
    time_day,
    CP_med,
    color = Dose,
    fill = Dose
  )
) +
  
  geom_ribbon(
    aes(
      ymin = CP_p05,
      ymax = CP_p95
    ),
    alpha = 0.25,
    colour = NA
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (days)",
    y = "Ciclosporin concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Ciclosporin BID for 5 days, population",
    subtitle = "Median with 5th–95th percentiles"
  )


p4_csa





# ============================================================
# FIGURE 4 INDIVIDUAL STEADY-STATE PK PARAMETERS
# ============================================================

fig4_ind <- fig4_raw %>%
  
  filter(
    time >= last_dose,
    time <= last_dose + tau
  ) %>%
  
  mutate(
    t_rel = time - last_dose
  ) %>%
  
  arrange(
    Dose,
    ID,
    t_rel
  ) %>%
  
  group_by(
    Dose,
    ID
  ) %>%
  
  summarise(
    
    Cmax =
      max(CP_ngmL),
    
    Tmax_h =
      t_rel[which.max(CP_ngmL)],
    
    Ctrough =
      at_time(
        t_rel,
        CP_ngmL,
        tau
      ),
    
    AUCtau =
      auc_trap(
        t_rel,
        CP_ngmL
      ),
    
    .groups = "drop"
  )



fig4_summary <- fig4_ind %>%
  
  group_by(Dose) %>%
  
  summarise(
    
    Cmax_med =
      median(Cmax),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(Tmax_h),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    Ctrough_med =
      median(Ctrough),
    
    Ctrough_p05 =
      quantile(
        Ctrough,
        0.05
      ),
    
    Ctrough_p95 =
      quantile(
        Ctrough,
        0.95
      ),
    
    
    AUCtau_med =
      median(AUCtau),
    
    AUCtau_p05 =
      quantile(
        AUCtau,
        0.05
      ),
    
    AUCtau_p95 =
      quantile(
        AUCtau,
        0.95
      ),
    
    .groups = "drop"
  )


fig4_summary