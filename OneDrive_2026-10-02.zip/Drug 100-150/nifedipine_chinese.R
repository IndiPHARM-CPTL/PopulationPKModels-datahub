library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)
nifedipine_code <- '
$PROB
- Ref: Li Y, Mu S, Huang Q, et al. Population Pharmacokinetics of Nifedipine in High-Altitude and Plain Patients with Hypertension. J Clin Pharmacol. 2025;65(12):1757-1766. doi:10.1002/jcph.70087
- US version: extended release; Chinese study: Germany - controlled-released - 30 mg;
- 60 mg QD simulation: be aware of zero-order absorption, first-order elimination
$PARAM @annotated
TVV        : 103.88 : L       Apparent volume of distribution
TVCL       : 18.74  : L/h     Apparent clearance in high-altitude group
TVK0       : 2.06   : mg/h    Zero-order absorption rate
AREA       : 0      : --      0 = high-altitude; 1 = plain
TH_AREA_CL : -0.30  : --      Plain-area effect on CL
ADD_SD     : 10.06  : ng/mL   Additive residual SD

$CMT @annotated
CENT : Central compartment

$OMEGA @diag @labels ETA_V ETA_CL ETA_K0
0.05 0.10 0.02

$SIGMA
1

$GLOBAL
double AREA_CL;
double Vi;
double CLi;
double K0i;
double KEi;

$MAIN

if(AREA == 1) {
  AREA_CL = exp(TH_AREA_CL);
} else {
  AREA_CL = 1.0;
}

Vi  = TVV  * exp(ETA(1));
CLi = TVCL * AREA_CL * exp(ETA(2));
K0i = TVK0 * exp(ETA(3));

KEi = CLi / Vi;
R_CENT = K0i;

$ODE
dxdt_CENT = -KEi * CENT;

$TABLE
double NIF_mgL  = CENT / Vi;
double NIF_ngmL = NIF_mgL * 1000.0;

double DV_ngmL = NIF_ngmL + ADD_SD * EPS(1);

$CAPTURE
NIF_ngmL DV_ngmL
Vi CLi K0i KEi AREA AREA_CL
'
mod <- mcode("nifedipine_li2025", nifedipine_code)

set.seed(123)

dose_mg <- c(30)

N        <- 1000
tau_h    <- 24
n_doses  <- 10
addl_md  <- n_doses - 1

t_end_sd <- 48
t_end_md <- 240

delta_sd <- 0.1
delta_md <- 0.1

AREA_SIM <- 0

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(
  ID = 1,
  AREA = AREA_SIM
)

idata_pop <- tibble(
  ID = 1:N,
  AREA = AREA_SIM
)



fig1_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- ev(
    time = 0,
    amt  = d,
    cmt  = "CENT",
    rate = -1
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = NIF_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Nifedipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Nifedipine controlled-release 30 mg once daily, single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C24  = get_nearest(time, CP, 24),
    C48  = get_nearest(time, CP, 48),
    C72  = get_nearest(time, CP, 72),
    .groups = "drop"
  )



fig2_list <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "CENT",
    rate = -1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = NIF_ngmL,
      Dose = paste0(d, " mg q24h x", n_doses)
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Nifedipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Nifedipine controlled-release 30 mg once daily, multi-dose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day6 = max(CP, na.rm = TRUE),
    Tmax_day6 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    C11_day6  = get_nearest(time, CP, (n_doses - 1) * tau_h + 11),
    C12_day6  = get_nearest(time, CP, (n_doses - 1) * tau_h + 12),
    C14_day6  = get_nearest(time, CP, (n_doses - 1) * tau_h + 14),
    Ctrough_day6 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

set.seed(123)

fig3_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- ev(
    time = 0,
    amt  = d,
    cmt  = "CENT",
    rate = -1
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = NIF_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Nifedipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Nifedipine controlled-release 30 mg once daily, single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C24  = get_nearest(time, CP, 24),
    C48  = get_nearest(time, CP, 48),
    C72  = get_nearest(time, CP, 72),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    C48_med = median(C48, na.rm = TRUE),
    C48_p05 = quantile(C48, 0.05, na.rm = TRUE),
    C48_p95 = quantile(C48, 0.95, na.rm = TRUE),
    
    C72_med = median(C72, na.rm = TRUE),
    C72_p05 = quantile(C72, 0.05, na.rm = TRUE),
    C72_p95 = quantile(C72, 0.95, na.rm = TRUE),
    .groups = "drop"
  )



set.seed(123)

fig4_list <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "CENT",
    rate = -1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = NIF_ngmL,
      Dose = paste0(d, " mg q24h x", n_doses)
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Nifedipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Nifedipine controlled-release 30 mg once daily, multi-dose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_day6 = max(CP, na.rm = TRUE),
    Tmax_day6 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    C11_day6  = get_nearest(time, CP, (n_doses - 1) * tau_h + 11),
    C12_day6  = get_nearest(time, CP, (n_doses - 1) * tau_h + 12),
    C14_day6  = get_nearest(time, CP, (n_doses - 1) * tau_h + 14),
    Ctrough_day6 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day6_med = median(Cmax_day6, na.rm = TRUE),
    Cmax_day6_p05 = quantile(Cmax_day6, 0.05, na.rm = TRUE),
    Cmax_day6_p95 = quantile(Cmax_day6, 0.95, na.rm = TRUE),
    
    Tmax_day6_med = median(Tmax_day6, na.rm = TRUE),
    Tmax_day6_p05 = quantile(Tmax_day6, 0.05, na.rm = TRUE),
    Tmax_day6_p95 = quantile(Tmax_day6, 0.95, na.rm = TRUE),
    
    C11_day6_med = median(C11_day6, na.rm = TRUE),
    C11_day6_p05 = quantile(C11_day6, 0.05, na.rm = TRUE),
    C11_day6_p95 = quantile(C11_day6, 0.95, na.rm = TRUE),
    
    C12_day6_med = median(C12_day6, na.rm = TRUE),
    C12_day6_p05 = quantile(C12_day6, 0.05, na.rm = TRUE),
    C12_day6_p95 = quantile(C12_day6, 0.95, na.rm = TRUE),
    
    C14_day6_med = median(C14_day6, na.rm = TRUE),
    C14_day6_p05 = quantile(C14_day6, 0.05, na.rm = TRUE),
    C14_day6_p95 = quantile(C14_day6, 0.95, na.rm = TRUE),
    
    Ctrough_day6_med = median(Ctrough_day6, na.rm = TRUE),
    Ctrough_day6_p05 = quantile(Ctrough_day6, 0.05, na.rm = TRUE),
    Ctrough_day6_p95 = quantile(Ctrough_day6, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary





