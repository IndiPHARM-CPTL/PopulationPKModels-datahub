library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

methotrexate_code <- '

$PROB
High-dose methotrexate population PK model

- Ref: Blackman MH, Yelvington B, Beck C,
  Cortez M, Choi L.
  Development and validation of high-dose
  methotrexate population pharmacokinetic models
  to inform clinical decisions on dosing.
  Eur J Clin Pharmacol. 2026;82:156.
  doi:10.1007/s00228-026-04080-0


$PARAM @annotated
CL       : 9.41  : L/h    Population clearance
V1       : 30.67 : L      Central volume
Q2       : 0.87  : L/h    First intercompartmental clearance
V2       : 5.62  : L      First peripheral volume
Q3       : 0.14  : L/h    Second intercompartmental clearance
V3       : 10.60 : L      Second peripheral volume

TH_BSA_CL : 0.61  : --   BSA exponent on clearance
TH_SCR_CL : -0.56 : --   Creatinine exponent on clearance
TH_SEX_CL : 0.01  : --   Female sex effect on clearance
TH_BSA    : 1.0   : --   BSA exponent on other PK parameters

BSA       : 1.97  : m2      Body surface area
CREAT     : 68.08 : umol/L  Serum creatinine
SEXF      : 0     : --      Female sex indicator

CYCLEH    : 504   : h       Time between cycles

PROP_SD   : 0.25  : --      Proportional residual SD


$CMT @annotated
CENT   : Central compartment (mg)
PERIPH : First peripheral compartment (mg)
DEEP   : Second peripheral compartment (mg)


$OMEGA @labels ETA_CL ETA_V1 ETA_Q2 ETA_V2 ETA_Q3 ETA_V3
0.0576
0.0841
0.1444
0.0900
0.2209
0.1156

$OMEGA @labels ETA_IOV1 ETA_IOV2 ETA_IOV3 ETA_IOV4
0.0196
0.0196
0.0196
0.0196


$SIGMA
1


$GLOBAL
double CLbase;
double V1i;
double Q2i;
double V2i;
double Q3i;
double V3i;

double CLi;

double CLocc1;
double CLocc2;
double CLocc3;
double CLocc4;


$MAIN

CLocc1 = CLbase * exp(ETA(7));
CLocc2 = CLbase * exp(ETA(8));
CLocc3 = CLbase * exp(ETA(9));
CLocc4 = CLbase * exp(ETA(10));

CLbase = CL
  * pow(BSA / 1.97, TH_BSA_CL)
  * pow(CREAT / 68.08, TH_SCR_CL)
  * exp(TH_SEX_CL * SEXF)
  * exp(ETA(1));

V1i = V1
  * pow(BSA / 1.97, TH_BSA)
  * exp(ETA(2));

Q2i = Q2
  * pow(BSA / 1.97, TH_BSA)
  * exp(ETA(3));

V2i = V2
  * pow(BSA / 1.97, TH_BSA)
  * exp(ETA(4));

Q3i = Q3
  * pow(BSA / 1.97, TH_BSA)
  * exp(ETA(5));

V3i = V3
  * pow(BSA / 1.97, TH_BSA)
  * exp(ETA(6));


$ODE

double CLode = CLocc1;

if (SOLVERTIME >= CYCLEH &&
    SOLVERTIME < 2.0 * CYCLEH) {

  CLode = CLocc2;
}

if (SOLVERTIME >= 2.0 * CYCLEH &&
    SOLVERTIME < 3.0 * CYCLEH) {

  CLode = CLocc3;
}

if (SOLVERTIME >= 3.0 * CYCLEH) {

  CLode = CLocc4;
}



dxdt_CENT =
    -(CLode / V1i) * CENT
    -(Q2i / V1i) * CENT
    +(Q2i / V2i) * PERIPH
    -(Q3i / V1i) * CENT
    +(Q3i / V3i) * DEEP;

dxdt_PERIPH =
     (Q2i / V1i) * CENT
    -(Q2i / V2i) * PERIPH;

dxdt_DEEP =
     (Q3i / V1i) * CENT
    -(Q3i / V3i) * DEEP;

$TABLE
double CP_mgL = CENT / V1i;
double CP_ngmL = CP_mgL * 1000.0;
double DV_PK =
    CP_mgL * (1.0 + PROP_SD * EPS(1));
CLi = CLbase * exp(ETA(7));

if(TIME >= CYCLEH && TIME < 2.0 * CYCLEH) {
  CLi = CLbase * exp(ETA(8));
}

if(TIME >= 2.0 * CYCLEH &&
   TIME < 3.0 * CYCLEH) {
  CLi = CLbase * exp(ETA(9));
}

if(TIME >= 3.0 * CYCLEH) {
  CLi = CLbase * exp(ETA(10));
}


$CAPTURE
CP_mgL CP_ngmL DV_PK
CLbase CLi V1i Q2i V2i Q3i V3i
BSA CREAT SEXF

'

mod_mtx <- mcode("methotrexate_blackman_2026", methotrexate_code)

N <- 1000

dose_g_m2 <- 3.5
BSA_ref <- 1.97

dose_mg <- dose_g_m2 * BSA_ref * 1000

infusion_h <- 4.7

tau <- 21 * 24
n_dose <- 4

dose_times <- (0:(n_dose - 1)) * tau

t_end_sd <- 96
t_end_md <- tau * n_dose

last_dose <- max(dose_times)

delta_typ <- 0.1
delta_pop <- 2


# Reference patient

idata_typ <- tibble(
  ID = 1,
  BSA = 1.97,
  CREAT = 68.08,
  SEXF = 0
)


idata_pop <- tibble(
  ID = seq_len(N),
  BSA = 1.97,
  CREAT = 68.08,
  SEXF = 0
)


mod_typ <- zero_re(mod_mtx)


ev_sd <- ev(
  time = 0,
  amt = dose_mg,
  rate = dose_mg / infusion_h,
  cmt = 1
)

ev_md <- ev(
  time = dose_times,
  amt = dose_mg,
  rate = dose_mg / infusion_h,
  cmt = 1
)

at_time <- function(time, value, target) {
  
  value[which.min(abs(time - target))]
}


auc_trap <- function(time, conc) {
  
  o <- order(time)
  
  time <- time[o]
  conc <- conc[o]
  
  sum(
    diff(time) *
      (head(conc, -1) + tail(conc, -1)) / 2
  )
}


population_curve <- function(dat) {
  
  dat %>%
    group_by(time, time_day) %>%
    summarise(
      CP_med = median(CP_mgL),
      CP_p05 = quantile(CP_mgL, 0.05),
      CP_p95 = quantile(CP_mgL, 0.95),
      
      DV_med = median(DV_PK),
      DV_p05 = quantile(DV_PK, 0.05),
      DV_p95 = quantile(DV_PK, 0.95),
      
      .groups = "drop"
    )
}


summarise_pk <- function(dat) {
  
  dat %>%
    summarise(
      Cmax_med = median(Cmax),
      Cmax_p05 = quantile(Cmax, 0.05),
      Cmax_p95 = quantile(Cmax, 0.95),
      
      Tmax_med_h = median(Tmax_h),
      Tmax_p05_h = quantile(Tmax_h, 0.05),
      Tmax_p95_h = quantile(Tmax_h, 0.95),
      
      Ctrough_med = median(Ctrough),
      Ctrough_p05 = quantile(Ctrough, 0.05),
      Ctrough_p95 = quantile(Ctrough, 0.95),
      
      AUC_med = median(AUC),
      AUC_p05 = quantile(AUC, 0.05),
      AUC_p95 = quantile(AUC, 0.95),
      
      .groups = "drop"
    )
}


fig1_out <- mod_typ %>%
  ev(ev_sd) %>%
  mrgsim(
    idata = idata_typ,
    end = t_end_sd,
    delta = delta_typ
  ) %>%
  as_tibble() %>%
  mutate(time_day = time / 24)


p1_mtx <- ggplot(
  fig1_out,
  aes(time_day, CP_mgL)
) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Methotrexate concentration (mg/L)",
    title = "Figure 1. Methotrexate single dose",
    subtitle = "3.5 g/m2 IV over 4.7 hours"
  )

p1_mtx


fig1_summary <- fig1_out %>%
  summarise(
    Cmax = max(CP_mgL),
    
    Tmax_h = time[which.max(CP_mgL)],
    
    C24 = at_time(time, CP_mgL, 24),
    C48 = at_time(time, CP_mgL, 48),
    C72 = at_time(time, CP_mgL, 72),
    
    AUC0_24 = auc_trap(
      time[time <= 24],
      CP_mgL[time <= 24]
    ),
    
    AUC0_96 = auc_trap(time, CP_mgL)
  )

fig1_summary



fig2_out <- mod_typ %>%
  ev(ev_md) %>%
  mrgsim(
    idata = idata_typ,
    end = t_end_md,
    delta = delta_typ
  ) %>%
  as_tibble() %>%
  mutate(time_day = time / 24)


p2_mtx <- ggplot(
  fig2_out,
  aes(time_day, CP_mgL)
) +
  geom_line(linewidth = 1) +
  geom_vline(
    xintercept = dose_times / 24,
    linetype = "dashed",
    alpha = 0.35
  ) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Methotrexate concentration (mg/L)",
    title = "Figure 2. Methotrexate multiple dose",
    subtitle = "Four cycles, 3.5 g/m2 every 21 days"
  )

p2_mtx


fig2_last <- fig2_out %>%
  filter(
    time >= last_dose,
    time <= last_dose + 96
  ) %>%
  mutate(t_rel = time - last_dose)


fig2_summary <- fig2_last %>%
  summarise(
    Cmax_last = max(CP_mgL),
    
    Tmax_last_h = t_rel[which.max(CP_mgL)],
    
    C24_last = at_time(t_rel, CP_mgL, 24),
    C48_last = at_time(t_rel, CP_mgL, 48),
    C72_last = at_time(t_rel, CP_mgL, 72),
    
    AUC0_96_last = auc_trap(t_rel, CP_mgL)
  )

fig2_summary



set.seed(123)

fig3_raw <- mod_mtx %>%
  ev(ev_sd) %>%
  mrgsim(
    idata = idata_pop,
    end = t_end_sd,
    delta = delta_pop
  ) %>%
  as_tibble() %>%
  mutate(time_day = time / 24)


fig3_sum <- population_curve(fig3_raw)


p3_mtx <- ggplot(
  fig3_sum,
  aes(time_day, CP_med)
) +
  geom_ribbon(
    aes(ymin = CP_p05, ymax = CP_p95),
    alpha = 0.25
  ) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Methotrexate concentration (mg/L)",
    title = "Figure 3. Methotrexate single dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p3_mtx


fig3_ind <- fig3_raw %>%
  arrange(ID, time) %>%
  group_by(ID) %>%
  summarise(
    Cmax = max(CP_mgL),
    
    Tmax_h = time[which.max(CP_mgL)],
    
    Ctrough = at_time(time, CP_mgL, 96),
    
    AUC = auc_trap(time, CP_mgL),
    
    C24 = at_time(time, CP_mgL, 24),
    C48 = at_time(time, CP_mgL, 48),
    C72 = at_time(time, CP_mgL, 72),
    
    .groups = "drop"
  )


fig3_summary <- summarise_pk(fig3_ind)

fig3_summary


fig3_monitoring <- fig3_ind %>%
  summarise(
    C24_med = median(C24),
    C24_p05 = quantile(C24, 0.05),
    C24_p95 = quantile(C24, 0.95),
    
    C48_med = median(C48),
    C48_p05 = quantile(C48, 0.05),
    C48_p95 = quantile(C48, 0.95),
    
    C72_med = median(C72),
    C72_p05 = quantile(C72, 0.05),
    C72_p95 = quantile(C72, 0.95)
  )

fig3_monitoring


set.seed(123)

fig4_raw <- mod_mtx %>%
  ev(ev_md) %>%
  mrgsim(
    idata = idata_pop,
    end = t_end_md,
    delta = delta_pop
  ) %>%
  as_tibble() %>%
  mutate(time_day = time / 24)


fig4_sum <- population_curve(fig4_raw)


p4_mtx <- ggplot(
  fig4_sum,
  aes(time_day, CP_med)
) +
  geom_ribbon(
    aes(ymin = CP_p05, ymax = CP_p95),
    alpha = 0.25
  ) +
  geom_line(linewidth = 1) +
  geom_vline(
    xintercept = dose_times / 24,
    linetype = "dashed",
    alpha = 0.35
  ) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Methotrexate concentration (mg/L)",
    title = "Figure 4. Methotrexate multiple dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p4_mtx


fig4_last <- fig4_raw %>%
  filter(
    time >= last_dose,
    time <= last_dose + 96
  ) %>%
  mutate(t_rel = time - last_dose)


fig4_ind <- fig4_last %>%
  arrange(ID, t_rel) %>%
  group_by(ID) %>%
  summarise(
    Cmax = max(CP_mgL),
    
    Tmax_h = t_rel[which.max(CP_mgL)],
    
    Ctrough = at_time(t_rel, CP_mgL, 96),
    
    AUC = auc_trap(t_rel, CP_mgL),
    
    C24 = at_time(t_rel, CP_mgL, 24),
    C48 = at_time(t_rel, CP_mgL, 48),
    C72 = at_time(t_rel, CP_mgL, 72),
    
    .groups = "drop"
  )


fig4_summary <- summarise_pk(fig4_ind)

fig4_summary


fig4_monitoring <- fig4_ind %>%
  summarise(
    C24_med = median(C24),
    C24_p05 = quantile(C24, 0.05),
    C24_p95 = quantile(C24, 0.95),
    
    C48_med = median(C48),
    C48_p05 = quantile(C48, 0.05),
    C48_p95 = quantile(C48, 0.95),
    
    C72_med = median(C72),
    C72_p05 = quantile(C72, 0.05),
    C72_p95 = quantile(C72, 0.95)
  )

fig4_monitoring