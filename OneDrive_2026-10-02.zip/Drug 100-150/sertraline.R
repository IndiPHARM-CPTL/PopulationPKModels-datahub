library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

sertraline_code <- '
$PROB
Sertraline population PK model in overdose
- Ref: Cooper JM, Duffull SB, Saiao AS, Isbister GK.
  The pharmacokinetics of sertraline in overdose and the effect of
  activated charcoal.
  Br J Clin Pharmacol. 2015;79(5):307-315.
  doi:10.1111/bcp.12500

$PARAM @annotated
KA          : 0.895  : 1/h    First-order absorption rate constant
CLF         : 130    : L/h    Apparent clearance (no SDAC)
VF          : 5340   : L      Apparent volume of distribution
TLAG        : 1      : h      Shifted lag time (fixed)
FDEPOT      : 1      : --     Relative bioavailability (fixed)

CHARCOAL    : 0      : --     0 = no SDAC, 1 = single-dose activated charcoal

TH_CL_CHAR  : 1.92   : --     SDAC multiplier on CL/F

PROP_SD     : 0.117  : --     Proportional residual SD

$CMT @annotated
DEPOT : Oral dosing/absorption compartment (mg)
CENT  : Central compartment (mg)

$OMEGA @labels ETA_TLAG ETA_KA ETA_V ETA_CL ETA_F
0.922 1.02 0.085 0.126 0.303

$SIGMA
1

$GLOBAL
double KAi;
double CLFi;
double VFi;
double TLAGi;
double Fi;

$MAIN
KAi   = KA * exp(ETA_KA);

CLFi  = CLF *
        (1.0 + (TH_CL_CHAR - 1.0) * CHARCOAL) *
        exp(ETA_CL);

VFi   = VF * exp(ETA_V);

TLAGi = TLAG * exp(ETA_TLAG);
Fi    = FDEPOT * exp(ETA_F);

ALAG_DEPOT = TLAGi;
F_DEPOT    = Fi;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT =
    KAi * DEPOT
  - (CLFi / VFi) * CENT;

$TABLE
double CP_mgL = CENT / VFi;

double DV_PK =
  CP_mgL * (1.0 + PROP_SD * EPS(1));

double THALF = log(2.0) * VFi / CLFi;

$CAPTURE
CP_mgL DV_PK THALF
KAi CLFi VFi TLAGi Fi
CHARCOAL
'
mod_sert <- mcode("sertraline_pk", sertraline_code)


N <- 1000                          # per arm

# Overdose amounts (Cooper 2015 Table 1: range 250-5000 mg, median 1550 mg)
doses_mg <- c(500, 1500, 5000)
dose_levels <- c("500 mg", "1500 mg", "5000 mg")

dose_ref <- 1500                   # median overdose used for the SDAC comparison
arm_levels <- c("No SDAC", "SDAC")

t_end <- 96                        # typical t1/2 ~28 h without SDAC
delta <- 0.1


at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

auc_trap <- function(time, conc) {
  sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2)
}

add_arm <- function(df) {
  df %>% mutate(Arm = factor(ifelse(CHARCOAL == 1, "SDAC", "No SDAC"),
                             levels = arm_levels))
}

# Per-subject NCA-style metrics. AUC0-inf = AUC0-last + Clast / kel,
# with kel = CL/V (exact for a one-compartment model).
nca_metrics <- function(df) {
  df %>%
    summarise(
      Cmax = max(CP_mgL),
      Tmax_h = time[which.max(CP_mgL)],
      C24 = at_time(time, CP_mgL, 24),
      AUC0_last = auc_trap(time, CP_mgL),
      AUC0_inf = AUC0_last + last(CP_mgL) / (first(CLFi) / first(VFi)),
      THALF_h = first(THALF),
      .groups = "drop"
    )
}




idata_typ <- tibble(
  ID = 1:2,
  CHARCOAL = c(0, 1)
)

idata_pop <- tibble(
  ID = 1:(2 * N),
  CHARCOAL = rep(c(0, 1), each = N)
)

mod_typ <- zero_re(mod_sert)


# Note: the model was fitted to overdose data only. Multiple therapeutic
# dosing is not simulated here; the F and lag-time BSV encode uncertainty in
# the reported overdose amount and time, not therapeutic-dose variability.


# ---------------------------------------------------------------------------
# Figure 1. Typical subject, single overdose by amount (no SDAC)
# ---------------------------------------------------------------------------

fig1_list <- lapply(doses_mg, function(d) {
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    ev(ev_sd) %>%
    mrgsim(idata = filter(idata_typ, CHARCOAL == 0),
           end = t_end, delta = delta, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = paste0(d, " mg"))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


p1_sert <- ggplot(fig1_out, aes(time, CP_mgL, color = Dose)) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, t_end, 12), limits = c(0, t_end)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time post-reported overdose (h)",
    y = "Sertraline concentration (mg/L)",
    color = "Overdose",
    title = "Figure 1. Sertraline single overdose, no SDAC"
  )

p1_sert


fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  nca_metrics()

fig1_summary


# Structural check: AUC0-inf = F * Dose / CL (F = 1 for the typical subject)
fig1_check <- fig1_summary %>%
  mutate(
    dose = as.numeric(sub(" mg", "", as.character(Dose))),
    AUC_expected = dose / 130,
    pct_diff = 100 * (AUC0_inf / AUC_expected - 1)
  ) %>%
  select(Dose, AUC0_inf, AUC_expected, pct_diff)

fig1_check





# ---------------------------------------------------------------------------
# Figure 2. Typical subject, 1500 mg overdose, with vs without SDAC
#           (replicates Cooper 2015 Figure 3A)
# ---------------------------------------------------------------------------

ev_ref <- ev(time = 0, amt = dose_ref, cmt = "DEPOT")

fig2_out <- mod_typ %>%
  ev(ev_ref) %>%
  mrgsim(idata = idata_typ, end = t_end, delta = delta, obsonly = TRUE) %>%
  as_tibble() %>%
  add_arm()


p2_sert <- ggplot(filter(fig2_out, CP_mgL > 0), aes(time, CP_mgL, color = Arm)) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, t_end, 12), limits = c(0, t_end)) +
  scale_y_log10() +
  theme_bw() +
  labs(
    x = "Time post-reported overdose (h)",
    y = "Sertraline concentration (mg/L, log scale)",
    color = NULL,
    title = "Figure 2. Sertraline 1500 mg overdose, with vs without SDAC"
  )

p2_sert


fig2_summary <- fig2_out %>%
  group_by(Arm) %>%
  nca_metrics()

fig2_summary





# ---------------------------------------------------------------------------
# Figure 3. Population, single overdose by amount (no SDAC)
# ---------------------------------------------------------------------------

fig3_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_sert %>%
    ev(ev_sd) %>%
    mrgsim(idata = filter(idata_pop, CHARCOAL == 0),
           end = t_end, delta = delta, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = paste0(d, " mg"))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    CP_med = median(CP_mgL),
    CP_p05 = quantile(CP_mgL, 0.05),
    CP_p95 = quantile(CP_mgL, 0.95),
    .groups = "drop"
  )


p3_sert <- ggplot(fig3_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, t_end, 12), limits = c(0, t_end)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time post-reported overdose (h)",
    y = "Sertraline concentration (mg/L)",
    color = "Overdose",
    fill = "Overdose",
    title = "Figure 3. Sertraline single overdose, population, no SDAC",
    subtitle = "Median with 5th–95th percentiles"
  )

p3_sert


fig3_ind <- fig3_raw %>%
  arrange(Dose, ID, time) %>%
  group_by(Dose, ID) %>%
  nca_metrics()


fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    AUC0_inf_med = median(AUC0_inf),
    AUC0_inf_p05 = quantile(AUC0_inf, 0.05),
    AUC0_inf_p95 = quantile(AUC0_inf, 0.95),
    
    THALF_med_h = median(THALF_h),
    THALF_p05_h = quantile(THALF_h, 0.05),
    THALF_p95_h = quantile(THALF_h, 0.95),
    
    .groups = "drop"
  )

fig3_summary




# ---------------------------------------------------------------------------
# Figure 4. Population, 1500 mg overdose, with vs without SDAC
# ---------------------------------------------------------------------------

set.seed(123)

fig4_raw <- mod_sert %>%
  ev(ev_ref) %>%
  mrgsim(idata = idata_pop, end = t_end, delta = delta, obsonly = TRUE) %>%
  as_tibble() %>%
  add_arm()


fig4_sum <- fig4_raw %>%
  group_by(Arm, time) %>%
  summarise(
    CP_med = median(CP_mgL),
    CP_p05 = quantile(CP_mgL, 0.05),
    CP_p95 = quantile(CP_mgL, 0.95),
    .groups = "drop"
  )


p4_sert <- ggplot(fig4_sum, aes(time, CP_med, color = Arm, fill = Arm)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, t_end, 12), limits = c(0, t_end)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time post-reported overdose (h)",
    y = "Sertraline concentration (mg/L)",
    color = NULL,
    fill = NULL,
    title = "Figure 4. Sertraline 1500 mg overdose, population, SDAC vs no SDAC",
    subtitle = "Median with 5th–95th percentiles"
  )

p4_sert


fig4_ind <- fig4_raw %>%
  arrange(Arm, ID, time) %>%
  group_by(Arm, ID) %>%
  nca_metrics()


fig4_summary <- fig4_ind %>%
  group_by(Arm) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    AUC0_inf_med = median(AUC0_inf),
    AUC0_inf_p05 = quantile(AUC0_inf, 0.05),
    AUC0_inf_p95 = quantile(AUC0_inf, 0.95),
    
    THALF_med_h = median(THALF_h),
    THALF_p05_h = quantile(THALF_h, 0.05),
    THALF_p95_h = quantile(THALF_h, 0.95),
    
    .groups = "drop"
  )

fig4_summary

