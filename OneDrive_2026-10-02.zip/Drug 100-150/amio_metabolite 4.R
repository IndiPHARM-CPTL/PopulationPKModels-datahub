library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

amiodarone_code <- '
$PROB
Amiodarone and desethylamiodarone PopPK model
- Ref: Pollak PT, Bouillon T, Shafer SL. Population pharmacokinetics of long-term oral amiodarone therapy. Clin Pharmacol Ther. 2000;67(6):642-652. doi:10.1067/mcp.2000.107047

$PARAM @annotated
V1A   : 882   : L      Amiodarone central volume, V1/F
V2A   : 12700 : L      Amiodarone peripheral volume, V2/F
CL1A  : 229   : L/day  Amiodarone elimination clearance, CL1/F
QA    : 588   : L/day  Amiodarone intercompartmental clearance

V1M   : 2790  : L      Desethylamiodarone central volume
V2M   : 7830  : L      Desethylamiodarone peripheral volume
CL1M  : 254   : L/day  Desethylamiodarone elimination clearance
QM    : 151   : L/day  Desethylamiodarone intercompartmental clearance

FMET  : 1     : --     Apparent parent-to-metabolite formation fraction

$CMT @annotated
AMI_CENT   : Amiodarone central compartment
AMI_PERIPH : Amiodarone peripheral compartment
DEA_CENT   : Desethylamiodarone central compartment
DEA_PERIPH : Desethylamiodarone peripheral compartment

$OMEGA @diag @labels ETA_V2A ETA_CL1A ETA_QA ETA_V1M ETA_V2M ETA_CL1M ETA_QM
0.294 0.0929 0.274 0.0439 0.779 0.0884 0.180

$MAIN
double V1Ai = V1A;
double V2Ai = V2A * exp(ETA_V2A);
double CL1Ai = CL1A * exp(ETA_CL1A);
double QAi = QA * exp(ETA_QA);

double V1Mi = V1M * exp(ETA_V1M);
double V2Mi = V2M * exp(ETA_V2M);
double CL1Mi = CL1M * exp(ETA_CL1M);
double QMi = QM * exp(ETA_QM);

double K10A = CL1Ai / V1Ai;
double K12A = QAi / V1Ai;
double K21A = QAi / V2Ai;

double K10M = CL1Mi / V1Mi;
double K12M = QMi / V1Mi;
double K21M = QMi / V2Mi;

$ODE
dxdt_AMI_CENT = -K10A * AMI_CENT
                 -K12A * AMI_CENT
                 +K21A * AMI_PERIPH;

dxdt_AMI_PERIPH = K12A * AMI_CENT
                  -K21A * AMI_PERIPH;

dxdt_DEA_CENT = FMET * K10A * AMI_CENT
                -K10M * DEA_CENT
                -K12M * DEA_CENT
                +K21M * DEA_PERIPH;

dxdt_DEA_PERIPH = K12M * DEA_CENT
                  -K21M * DEA_PERIPH;

$TABLE
double C_AMI_ngmL = (AMI_CENT / V1Ai) * 1000.0;
double C_DEA_ngmL = (DEA_CENT / V1Mi) * 1000.0;

$CAPTURE C_AMI_ngmL C_DEA_ngmL
'

mod <- mcode("amiodarone_pollak2000", amiodarone_code)

N <- 1000

n_days_treat <- 90
n_days_wash <- 275
t_end <- 365

delta_day <- 0.05

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:N)

mod_typ <- zero_re(mod)

usual_schedule <- tibble(
  start_day = c(0, 2, 7, 14, 21, 28),
  dose_mg_day = c(1600, 1200, 1000, 800, 600, 400),
  n_days = c(2, 5, 7, 7, 7, 62)
)

usual_schedule

make_schedule_events <- function(schedule) {
  schedule %>%
    filter(n_days > 0) %>%
    transmute(
      time = start_day,
      amt = dose_mg_day,
      cmt = 1,
      evid = 1,
      ii = 1,
      addl = n_days - 1
    ) %>%
    as.ev()
}

ev_usual <- make_schedule_events(usual_schedule)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

therapeutic_lines <- tibble(
  Analyte = "Amiodarone",
  yintercept = c(1000, 1500, 2500)
)




fig1_out <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_usual) %>%
  mrgsim(end = t_end, delta = delta_day, obsonly = TRUE) %>%
  as_tibble() %>%
  transmute(
    ID,
    time,
    AMI = pmax(C_AMI_ngmL, 0),
    DEA = pmax(C_DEA_ngmL, 0),
    Phase = if_else(time < n_days_treat, "Treatment", "Washout")
  )

fig1_plot <- bind_rows(
  fig1_out %>%
    transmute(time, Phase, Analyte = "Amiodarone", CP = AMI),
  
  fig1_out %>%
    transmute(time, Phase, Analyte = "Desethylamiodarone", CP = DEA)
)

p1 <- ggplot(fig1_plot, aes(time, CP, color = Analyte)) +
  geom_line(linewidth = 1) +
  geom_vline(xintercept = n_days_treat, linetype = "dashed") +
  geom_hline(
    data = therapeutic_lines,
    aes(yintercept = yintercept),
    linetype = "dashed",
    inherit.aes = FALSE
  ) +
  facet_wrap(~Analyte, scales = "free_y") +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Serum concentration (ng/mL)",
    color = "Analyte",
    title = "Figure 1. Amiodarone loading, maintenance, and washout"
  )

fig1_summary <- bind_rows(
  fig1_out %>%
    summarise(
      Analyte = "Amiodarone",
      Cmax_treatment_ng_mL = max(AMI[time <= n_days_treat], na.rm = TRUE),
      Tmax_treatment_day = time[
        which.max(ifelse(time <= n_days_treat, AMI, -Inf))
      ],
      C_day7_ng_mL = get_nearest(time, AMI, 7),
      C_day14_ng_mL = get_nearest(time, AMI, 14),
      C_day28_ng_mL = get_nearest(time, AMI, 28),
      C_day35_ng_mL = get_nearest(time, AMI, 35),
      C_day90_ng_mL = get_nearest(time, AMI, 90),
      C_day180_ng_mL = get_nearest(time, AMI, 180),
      C_day365_ng_mL = get_nearest(time, AMI, 365),
    ),
  
  fig1_out %>%
    summarise(
      Analyte = "Desethylamiodarone",
      Cmax_treatment_ng_mL = max(DEA[time <= n_days_treat], na.rm = TRUE),
      Tmax_treatment_day = time[
        which.max(ifelse(time <= n_days_treat, DEA, -Inf))
      ],
      C_day7_ng_mL = get_nearest(time, DEA, 7),
      C_day14_ng_mL = get_nearest(time, DEA, 14),
      C_day28_ng_mL = get_nearest(time, DEA, 28),
      C_day35_ng_mL = get_nearest(time, DEA, 35),
      C_day90_ng_mL = get_nearest(time, DEA, 90),
      C_day180_ng_mL = get_nearest(time, DEA, 180),
      C_day365_ng_mL = get_nearest(time, DEA, 365),
    )
)




set.seed(123)

fig2_raw <- mod %>%
  idata_set(idata_pop) %>%
  ev(ev_usual) %>%
  mrgsim(end = t_end, delta = delta_day, obsonly = TRUE) %>%
  as_tibble() %>%
  transmute(
    ID,
    time,
    AMI = pmax(C_AMI_ngmL, 0),
    DEA = pmax(C_DEA_ngmL, 0)
  )

fig2_sum <- bind_rows(
  fig2_raw %>%
    group_by(time) %>%
    summarise(
      C_med = median(AMI, na.rm = TRUE),
      C_p05 = quantile(AMI, 0.05, na.rm = TRUE),
      C_p95 = quantile(AMI, 0.95, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "Amiodarone"),
  
  fig2_raw %>%
    group_by(time) %>%
    summarise(
      C_med = median(DEA, na.rm = TRUE),
      C_p05 = quantile(DEA, 0.05, na.rm = TRUE),
      C_p95 = quantile(DEA, 0.95, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "Desethylamiodarone")
)

p2 <- ggplot(fig2_sum, aes(time, C_med, color = Analyte, fill = Analyte)) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.20,
    colour = NA
  ) +
  geom_line(linewidth = 1) +
  geom_vline(xintercept = n_days_treat, linetype = "dashed") +
  geom_hline(
    data = therapeutic_lines,
    aes(yintercept = yintercept),
    linetype = "dashed",
    inherit.aes = FALSE
  ) +
  facet_wrap(~Analyte, scales = "free_y") +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Serum concentration (ng/mL)",
    color = "Analyte",
    fill = "Analyte",
    title = "Figure 2. Amiodarone loading, maintenance, and washout: population"
  )


fig2_ind <- bind_rows(
  fig2_raw %>%
    group_by(ID) %>%
    summarise(
      Analyte = "Amiodarone",
      Cmax_treatment = max(AMI[time <= n_days_treat], na.rm = TRUE),
      Tmax_treatment = time[
        which.max(ifelse(time <= n_days_treat, AMI, -Inf))
      ],
      C_day7 = get_nearest(time, AMI, 7),
      C_day14 = get_nearest(time, AMI, 14),
      C_day28 = get_nearest(time, AMI, 28),
      C_day35 = get_nearest(time, AMI, 35),
      C_day90 = get_nearest(time, AMI, 90),
      C_day180 = get_nearest(time, AMI, 180),
      C_day365 = get_nearest(time, AMI, 365),
      .groups = "drop"
    ),
  
  fig2_raw %>%
    group_by(ID) %>%
    summarise(
      Analyte = "Desethylamiodarone",
      Cmax_treatment = max(DEA[time <= n_days_treat], na.rm = TRUE),
      Tmax_treatment = time[
        which.max(ifelse(time <= n_days_treat, DEA, -Inf))
      ],
      C_day7 = get_nearest(time, DEA, 7),
      C_day14 = get_nearest(time, DEA, 14),
      C_day28 = get_nearest(time, DEA, 28),
      C_day35 = get_nearest(time, DEA, 35),
      C_day90 = get_nearest(time, DEA, 90),
      C_day180 = get_nearest(time, DEA, 180),
      C_day365 = get_nearest(time, DEA, 365),
      .groups = "drop"
    )
)

fig2_summary <- fig2_ind %>%
  group_by(Analyte) %>%
  summarise(
    Cmax_med_ng_mL = median(Cmax_treatment, na.rm = TRUE),
    Cmax_p05_ng_mL = quantile(Cmax_treatment, 0.05, na.rm = TRUE),
    Cmax_p95_ng_mL = quantile(Cmax_treatment, 0.95, na.rm = TRUE),
    
    Tmax_med_day = median(Tmax_treatment, na.rm = TRUE),
    Tmax_p05_day = quantile(Tmax_treatment, 0.05, na.rm = TRUE),
    Tmax_p95_day = quantile(Tmax_treatment, 0.95, na.rm = TRUE),
    
    C_day7_med_ng_mL = median(C_day7, na.rm = TRUE),
    C_day7_p05_ng_mL = quantile(C_day7, 0.05, na.rm = TRUE),
    C_day7_p95_ng_mL = quantile(C_day7, 0.95, na.rm = TRUE),
    
    C_day14_med_ng_mL = median(C_day14, na.rm = TRUE),
    C_day14_p05_ng_mL = quantile(C_day14, 0.05, na.rm = TRUE),
    C_day14_p95_ng_mL = quantile(C_day14, 0.95, na.rm = TRUE),
    
    C_day28_med_ng_mL = median(C_day28, na.rm = TRUE),
    C_day28_p05_ng_mL = quantile(C_day28, 0.05, na.rm = TRUE),
    C_day28_p95_ng_mL = quantile(C_day28, 0.95, na.rm = TRUE),
    
    C_day35_med_ng_mL = median(C_day35, na.rm = TRUE),
    C_day35_p05_ng_mL = quantile(C_day35, 0.05, na.rm = TRUE),
    C_day35_p95_ng_mL = quantile(C_day35, 0.95, na.rm = TRUE),
    
    C_day90_med_ng_mL = median(C_day90, na.rm = TRUE),
    C_day90_p05_ng_mL = quantile(C_day90, 0.05, na.rm = TRUE),
    C_day90_p95_ng_mL = quantile(C_day90, 0.95, na.rm = TRUE),
    
    C_day180_med_ng_mL = median(C_day180, na.rm = TRUE),
    C_day180_p05_ng_mL = quantile(C_day180, 0.05, na.rm = TRUE),
    C_day180_p95_ng_mL = quantile(C_day180, 0.95, na.rm = TRUE),
    
    C_day365_med_ng_mL = median(C_day365, na.rm = TRUE),
    C_day365_p05_ng_mL = quantile(C_day365, 0.05, na.rm = TRUE),
    C_day365_p95_ng_mL = quantile(C_day365, 0.95, na.rm = TRUE),
    .groups = "drop"
  )



p1
p2

usual_schedule
fig1_summary
fig2_summary
