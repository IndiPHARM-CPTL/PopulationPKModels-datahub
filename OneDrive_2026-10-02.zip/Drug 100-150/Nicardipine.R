library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

nicardipine_code <- '
$PROB
- Ref:Modi NB, Veng-Pedersen P, Graham DJ, Dow RJ. Application of a system analysis approach to population pharmacokinetics and pharmacodynamics of nicardipine hydrochloride in healthy males. J Pharm Sci. 1993;82(7):705-713. doi:10.1002/jps.2600820707

$PARAM @annotated
TVCL    : 0.920 : L/h/kg   Plasma clearance per kg
TVVC    : 0.291 : L/kg     Central/sampling volume per kg
TVQ     : 0.826 : L/h/kg   Distribution clearance per kg
TVVP    : 0.839 : L/kg     Peripheral volume per kg; Vdss - Vc

WT      : 74.0  : kg       Body weight
PROP_SD : 0.20  : --       Proportional residual SD; assumed

$CMT @annotated
CENT   : Central plasma compartment
PERIPH : Peripheral compartment

$OMEGA @diag @labels ETA_CL ETA_VC ETA_Q ETA_VP
0.0263 0.0894 0.0747 0.243

$SIGMA
1

$GLOBAL
double CLi;
double VCi;
double Qi;
double VPi;
double K10i;
double K12i;
double K21i;

$MAIN
CLi = TVCL * WT * exp(ETA(1));
VCi = TVVC * WT * exp(ETA(2));
Qi  = TVQ  * WT * exp(ETA(3));
VPi = TVVP * WT * exp(ETA(4));

K10i = CLi / VCi;
K12i = Qi  / VCi;
K21i = Qi  / VPi;

$ODE
dxdt_CENT   = -K10i * CENT
              -K12i * CENT
              +K21i * PERIPH;

dxdt_PERIPH =  K12i * CENT
              -K21i * PERIPH;

$TABLE
double NIC_mgL  = CENT / VCi;
double NIC_ngmL = NIC_mgL * 1000.0;

double DV_ngmL = NIC_ngmL * exp(PROP_SD * EPS(1));

$CAPTURE
NIC_ngmL DV_ngmL
CLi VCi Qi VPi K10i K12i K21i WT
'
mod <- mcode("nicardipine_mod", nicardipine_code)

set.seed(123)

dose_ugkg <- c(70, 140, 210, 280)

N          <- 1000
WT_FIXED   <- 74.0
infusion_h <- 0.5
tau_h      <- 8
n_doses_md <- 4
addl_md    <- n_doses_md - 1

t_end_sd <- 8
t_end_md <- (n_doses_md - 1) * tau_h + 8

delta_sd <- 0.05
delta_md <- 0.05

dose_levels_sd <- paste0(dose_ugkg, " ug/kg IV infusion x1")
dose_levels_md <- paste0(dose_ugkg, " ug/kg IV infusion q8h x", n_doses_md)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(
  ID = 1,
  WT = WT_FIXED
)

idata_pop <- tibble(
  ID = 1:N,
  WT = WT_FIXED
)

fig1_list <- lapply(dose_ugkg, function(d) {
  
  amt_mg    <- d * WT_FIXED / 1000
  rate_mg_h <- amt_mg / infusion_h
  
  ev_sd <- ev(
    time = 0,
    amt  = amt_mg,
    rate = rate_mg_h,
    cmt  = "CENT"
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = NIC_ngmL,
      Dose = paste0(d, " ug/kg IV infusion x1")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Nicardipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Nicardipine IV infusion - intermittent, single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C0_5 = get_nearest(time, CP, 0.5),
    C1   = get_nearest(time, CP, 1),
    C2   = get_nearest(time, CP, 2),
    C4_5 = get_nearest(time, CP, 4.5),
    C8_5 = get_nearest(time, CP, 8.5),
    C12_5 = get_nearest(time, CP, 12.5),
    C24_5 = get_nearest(time, CP, 24.5),
    .groups = "drop"
  )



fig2_list <- lapply(dose_ugkg, function(d) {
  
  amt_mg    <- d * WT_FIXED / 1000
  rate_mg_h <- amt_mg / infusion_h
  
  ev_md <- ev(
    time = 0,
    amt  = amt_mg,
    rate = rate_mg_h,
    cmt  = "CENT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = NIC_ngmL,
      Dose = paste0(d, " ug/kg IV infusion q8h x", n_doses_md)
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Nicardipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Nicardipine IV infusion - intermittent, multi-dose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= (n_doses_md - 1) * tau_h) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_after_dose4 = max(CP, na.rm = TRUE),
    Tmax_after_dose4 = time[which.max(CP)] - (n_doses_md - 1) * tau_h,
    C8_after_dose4   = get_nearest(time, CP, (n_doses_md - 1) * tau_h + 8),
    C24_5_after_dose4 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )


set.seed(123)

fig3_list <- lapply(dose_ugkg, function(d) {
  
  amt_mg    <- d * WT_FIXED / 1000
  rate_mg_h <- amt_mg / infusion_h
  
  ev_sd <- ev(
    time = 0,
    amt  = amt_mg,
    rate = rate_mg_h,
    cmt  = "CENT"
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = NIC_ngmL,
      Dose = paste0(d, " ug/kg IV infusion x1")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Nicardipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Nicardipine IV infusion - intermittent, single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C0_5 = get_nearest(time, CP, 0.5),
    C1   = get_nearest(time, CP, 1),
    C2   = get_nearest(time, CP, 2),
    C4_5 = get_nearest(time, CP, 4.5),
    C8_5 = get_nearest(time, CP, 8.5),
    C12_5 = get_nearest(time, CP, 12.5),
    C24_5 = get_nearest(time, CP, 24.5),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C0_5_med = median(C0_5, na.rm = TRUE),
    C0_5_p05 = quantile(C0_5, 0.05, na.rm = TRUE),
    C0_5_p95 = quantile(C0_5, 0.95, na.rm = TRUE),
    
    C1_med = median(C1, na.rm = TRUE),
    C1_p05 = quantile(C1, 0.05, na.rm = TRUE),
    C1_p95 = quantile(C1, 0.95, na.rm = TRUE),
    
    C2_med = median(C2, na.rm = TRUE),
    C2_p05 = quantile(C2, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2, 0.95, na.rm = TRUE),
    
    C4_5_med = median(C4_5, na.rm = TRUE),
    C4_5_p05 = quantile(C4_5, 0.05, na.rm = TRUE),
    C4_5_p95 = quantile(C4_5, 0.95, na.rm = TRUE),
    
    C8_5_med = median(C8_5, na.rm = TRUE),
    C8_5_p05 = quantile(C8_5, 0.05, na.rm = TRUE),
    C8_5_p95 = quantile(C8_5, 0.95, na.rm = TRUE),
    
    C12_5_med = median(C12_5, na.rm = TRUE),
    C12_5_p05 = quantile(C12_5, 0.05, na.rm = TRUE),
    C12_5_p95 = quantile(C12_5, 0.95, na.rm = TRUE),
    
    C24_5_med = median(C24_5, na.rm = TRUE),
    C24_5_p05 = quantile(C24_5, 0.05, na.rm = TRUE),
    C24_5_p95 = quantile(C24_5, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


set.seed(123)

fig4_list <- lapply(dose_ugkg, function(d) {
  
  amt_mg    <- d * WT_FIXED / 1000
  rate_mg_h <- amt_mg / infusion_h
  
  ev_md <- ev(
    time = 0,
    amt  = amt_mg,
    rate = rate_mg_h,
    cmt  = "CENT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = NIC_ngmL,
      Dose = paste0(d, " ug/kg IV infusion q8h x", n_doses_md)
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Nicardipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Nicardipine IV infusion - intermittent, multi-dose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= (n_doses_md - 1) * tau_h) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_after_dose4 = max(CP, na.rm = TRUE),
    Tmax_after_dose4 = time[which.max(CP)] - (n_doses_md - 1) * tau_h,
    C8_after_dose4   = get_nearest(time, CP, (n_doses_md - 1) * tau_h + 8),
    C24_5_after_dose4 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_after_dose4_med = median(Cmax_after_dose4, na.rm = TRUE),
    Cmax_after_dose4_p05 = quantile(Cmax_after_dose4, 0.05, na.rm = TRUE),
    Cmax_after_dose4_p95 = quantile(Cmax_after_dose4, 0.95, na.rm = TRUE),
    
    Tmax_after_dose4_med = median(Tmax_after_dose4, na.rm = TRUE),
    Tmax_after_dose4_p05 = quantile(Tmax_after_dose4, 0.05, na.rm = TRUE),
    Tmax_after_dose4_p95 = quantile(Tmax_after_dose4, 0.95, na.rm = TRUE),
    
    C8_after_dose4_med = median(C8_after_dose4, na.rm = TRUE),
    C8_after_dose4_p05 = quantile(C8_after_dose4, 0.05, na.rm = TRUE),
    C8_after_dose4_p95 = quantile(C8_after_dose4, 0.95, na.rm = TRUE),
    
    C24_5_after_dose4_med = median(C24_5_after_dose4, na.rm = TRUE),
    C24_5_after_dose4_p05 = quantile(C24_5_after_dose4, 0.05, na.rm = TRUE),
    C24_5_after_dose4_p95 = quantile(C24_5_after_dose4, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary

