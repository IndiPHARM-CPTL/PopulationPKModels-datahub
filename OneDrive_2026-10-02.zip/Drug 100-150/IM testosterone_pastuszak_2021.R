library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)
testosterone_code <- '
$PROB
Intramuscular testosterone undecanoate population PK model

- Ref: Pastuszak AW, et al.
  Population Pharmacokinetic Modeling and Simulations
  to Evaluate a Potential Dose Regimen of Testosterone
  Undecanoate in Hypogonadal Males.
  J Clin Pharmacol. 2021.
  doi:10.1002/jcph.1939
-  Intramuscular testosterone undecanoate 750 mg is approved to be administered at initiation and at 4 weeks, followedby a maintenance dose every 10 weeks
-  Simulated Cmax is 20% lower than reported cmax in original study, but tmax, cmin, and auc are comparable
$PARAM @annotated
KA        : 0.001    : 1/h    First-order absorption constant
CL        : 197      : L/h    Apparent clearance
V         : 12300    : L      Apparent volume
RB        : 0.445    : mg/h   Baseline endogenous production
RSS       : 0.572    : mg/h   Recovered endogenous production
K1        : 10       : 1/h    Acute suppression rate
K2        : 0.000727 : 1/h    Recovery rate

WTKG      : 101      : kg     Body weight
SHBG      : 20       : nmol/L SHBG concentration

TH_WT_CL  : 0.75     : --     Weight exponent on CL
TH_SHBG   : -0.219   : --     SHBG exponent on CL
TH_WT_KA  : -1.83    : --     Weight exponent on KA
TH_WT_V   : 1.0      : --     Weight exponent on V

PROP_SD   : 0.188    : --     Proportional residual SD
ADD_SD    : 56.8     : ng/dL  Additive residual SD

$CMT @annotated
DEPOT : Intramuscular depot (mg)
CENT  : Central compartment (mg)

$OMEGA @labels ETA_CL ETA_KA
0.04
0.2

$SIGMA @labels EPS_PROP EPS_ADD
1
1

$GLOBAL
double CLi;
double Vi;
double KAi;

$MAIN

CLi = CL
      * pow(WTKG / 101.0, TH_WT_CL)
      * pow(SHBG / 20.0, TH_SHBG)
      * exp(ETA(1));

Vi = V
     * pow(WTKG / 101.0, TH_WT_V);

KAi = KA
      * pow(WTKG / 101.0, TH_WT_KA)
      * exp(ETA(2));

CENT_0 = RB * Vi / CLi;

$ODE
double R_t =
    RB * exp(-K1 * SOLVERTIME)
    + RSS * (1.0 - exp(-K2 * SOLVERTIME));

dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT =
    KAi * DEPOT
    + R_t
    - (CLi / Vi) * CENT;

$TABLE
double CP_ngdL = 100000.0 * CENT / Vi;

double DV_PK =
    CP_ngdL * (1.0 + PROP_SD * EPS(1))
    + ADD_SD * EPS(2);

$CAPTURE
CP_ngdL DV_PK CLi Vi KAi
WTKG SHBG
'

mod_test <- mcode(
  "testosterone_undecanoate_pk",
  testosterone_code
)


N <- 1000
dose_mg <- 750

week_h <- 168

dose_weeks <- c(0, 4, 14, 24)
dose_times <- dose_weeks * week_h

t_end_sd <- 10 * week_h
t_end_md <- 34 * week_h

last_dose <- 24 * week_h
tau_last <- 10 * week_h

delta_typ <- 2
delta_pop <- 6

idata_typ <- tibble(
  ID = 1,
  WTKG = 101,
  SHBG = 20
)

idata_pop <- tibble(
  ID = 1:N,
  WTKG = 101,
  SHBG = 20
)

mod_typ <- zero_re(mod_test)

ev_sd <- ev(
  time = 0,
  amt = dose_mg,
  cmt = 1
)

ev_md <- ev(
  time = dose_times,
  amt = dose_mg,
  cmt = 1
)

auc_trap <- function(time, conc) {
  sum(
    diff(time) *
      (head(conc, -1) + tail(conc, -1)) / 2
  )
}

at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

summarise_pk <- function(dat, conc_col = "CP_ngdL") {
  
  dat %>%
    arrange(ID, time) %>%
    group_by(ID) %>%
    summarise(
      Cmax = max(.data[[conc_col]]),
      Tmax_h = time[which.max(.data[[conc_col]])],
      Ctrough = last(.data[[conc_col]]),
      AUC = auc_trap(time, .data[[conc_col]]),
      .groups = "drop"
    ) %>%
    summarise(
      Cmax_med = median(Cmax),
      Cmax_p05 = quantile(Cmax, 0.05),
      Cmax_p95 = quantile(Cmax, 0.95),
      
      Tmax_med_h = median(Tmax_h),
      Tmax_p05_h = quantile(Tmax_h, 0.05),
      Tmax_p95_h = quantile(Tmax_h, 0.95),
      
      Ctrough_med = median(Ctrough),
      Ctrough_p05 = quantile(Ctrough, 0.05),
      Ctrough_p95 = quantile(Ctrough, 0.95),
      
      AUC_med = median(AUC),
      AUC_p05 = quantile(AUC, 0.05),
      AUC_p95 = quantile(AUC, 0.95)
    )
}

population_curve <- function(dat) {
  dat %>%
    group_by(time, time_wk) %>%
    summarise(
      CP_med = median(CP_ngdL),
      CP_p05 = quantile(CP_ngdL, 0.05),
      CP_p95 = quantile(CP_ngdL, 0.95),
      .groups = "drop"
    )
}





fig1_out <- mod_typ %>%
  ev(ev_sd) %>%
  mrgsim(
    idata = idata_typ,
    end = t_end_sd,
    delta = delta_typ
  ) %>%
  as_tibble() %>%
  mutate(time_wk = time / week_h)

p1_test <- ggplot(
  fig1_out,
  aes(time_wk, CP_ngdL)
) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (weeks)",
    y = "Total testosterone (ng/dL)",
    title = "Figure 1. Testosterone undecanoate 750 mg IM",
    subtitle = "Typical single-dose profile"
  )

p1_test

fig1_summary <- fig1_out %>%
  summarise(
    Cmax = max(CP_ngdL),
    Tmax_h = time[which.max(CP_ngdL)],
    Tmax_day = Tmax_h / 24,
    C168 = at_time(time, CP_ngdL, 168),
    AUC0_168 = auc_trap(
      time[time <= 168],
      CP_ngdL[time <= 168]
    ),
    AUC0_10wk = auc_trap(time, CP_ngdL)
  )

fig1_summary


fig2_out <- mod_typ %>%
  ev(ev_md) %>%
  mrgsim(
    idata = idata_typ,
    end = t_end_md,
    delta = delta_typ
  ) %>%
  as_tibble() %>%
  mutate(time_wk = time / week_h)

p2_test <- ggplot(
  fig2_out,
  aes(time_wk, CP_ngdL)
) +
  geom_line(linewidth = 1) +
  geom_vline(
    xintercept = dose_weeks,
    linetype = "dashed",
    alpha = 0.35
  ) +
  theme_bw() +
  labs(
    x = "Time (weeks)",
    y = "Total testosterone (ng/dL)",
    title = "Figure 2. Testosterone undecanoate multiple dose",
    subtitle = "750 mg IM at weeks 0, 4, 14 and 24"
  )

p2_test

fig2_last <- fig2_out %>%
  filter(
    time >= last_dose,
    time <= t_end_md
  ) %>%
  mutate(t_rel = time - last_dose)

fig2_summary <- fig2_last %>%
  summarise(
    Cmax_last = max(CP_ngdL),
    Tmax_last_h = t_rel[which.max(CP_ngdL)],
    Tmax_last_day = Tmax_last_h / 24,
    Ctrough_last = at_time(
      t_rel, CP_ngdL, tau_last
    ),
    AUCtau_last = auc_trap(t_rel, CP_ngdL),
    Cavg_last = AUCtau_last / tau_last
  )

fig2_summary




set.seed(123)

fig3_raw <- mod_test %>%
  ev(ev_sd) %>%
  mrgsim(
    idata = idata_pop,
    end = t_end_sd,
    delta = delta_pop
  ) %>%
  as_tibble() %>%
  mutate(time_wk = time / week_h)

fig3_sum <- population_curve(fig3_raw)

p3_test <- ggplot(
  fig3_sum,
  aes(time_wk, CP_med)
) +
  geom_ribbon(
    aes(ymin = CP_p05, ymax = CP_p95),
    alpha = 0.25
  ) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (weeks)",
    y = "Total testosterone (ng/dL)",
    title = "Figure 3. Testosterone undecanoate single dose",
    subtitle = "Population median and 5th–95th percentiles"
  )

p3_test

fig3_ind <- fig3_raw %>%
  filter(time <= t_end_sd)

fig3_summary <- summarise_pk(fig3_ind)

fig3_summary



set.seed(123)

fig4_raw <- mod_test %>%
  ev(ev_md) %>%
  mrgsim(
    idata = idata_pop,
    end = t_end_md,
    delta = delta_pop
  ) %>%
  as_tibble() %>%
  mutate(time_wk = time / week_h)

fig4_sum <- population_curve(fig4_raw)

p4_test <- ggplot(
  fig4_sum,
  aes(time_wk, CP_med)
) +
  geom_ribbon(
    aes(ymin = CP_p05, ymax = CP_p95),
    alpha = 0.25
  ) +
  geom_line(linewidth = 1) +
  geom_vline(
    xintercept = dose_weeks,
    linetype = "dashed",
    alpha = 0.35
  ) +
  theme_bw() +
  labs(
    x = "Time (weeks)",
    y = "Total testosterone (ng/dL)",
    title = "Figure 4. Testosterone undecanoate multiple dose",
    subtitle = "750 mg IM; median with 5th–95th percentiles"
  )

p4_test

fig4_last <- fig4_raw %>%
  filter(
    time >= last_dose,
    time <= t_end_md
  ) %>%
  mutate(t_rel = time - last_dose)

fig4_ind <- fig4_last %>%
  arrange(ID, t_rel) %>%
  group_by(ID) %>%
  summarise(
    Cmax = max(CP_ngdL),
    Tmax_h = t_rel[which.max(CP_ngdL)],
    Ctrough = at_time(
      t_rel, CP_ngdL, tau_last
    ),
    AUCtau = auc_trap(t_rel, CP_ngdL),
    Cavg = AUCtau / tau_last,
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    Ctrough_med = median(Ctrough),
    Ctrough_p05 = quantile(Ctrough, 0.05),
    Ctrough_p95 = quantile(Ctrough, 0.95),
    
    AUCtau_med = median(AUCtau),
    AUCtau_p05 = quantile(AUCtau, 0.05),
    AUCtau_p95 = quantile(AUCtau, 0.95),
    
    Cavg_med = median(Cavg),
    Cavg_p05 = quantile(Cavg, 0.05),
    Cavg_p95 = quantile(Cavg, 0.95)
  )

fig4_summary