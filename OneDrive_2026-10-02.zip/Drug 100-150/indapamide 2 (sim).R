library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

indapamide_code <- '
$PROB
- Ref: Grebow PE, Treitman JA, Barry EP, Blasucci DJ, Portelli ST, Tantillo NC, Vukovich RA, Neiss ES.
  Pharmacokinetics and bioavailability of indapamide: a new antihypertensive drug.
  Eur J Clin Pharmacol. 1982;22:295-299.

$PARAM @annotated
CL  : 1.20  : L/h   Systemic clearance
VC  : 12.0  : L     Central volume
K12 : 0.100 : 1/h   Central-to-peripheral rate constant
K21 : 0.132 : 1/h   Peripheral-to-central rate constant
KA  : 0.75  : 1/h   Absorption rate constant
F1  : 1.00  : --    Relative oral bioavailability

$CMT @annotated
GUT    : Oral depot compartment
CENT   : Central compartment
PERIPH : Peripheral compartment

$OMEGA @diag @labels ETA_KA ETA_CL ETA_VC ETA_K12 ETA_K21
0.160 0.090 0.090 0.090 0.090

$MAIN
double KAi  = KA  * exp(ETA_KA);
double CLi  = CL  * exp(ETA_CL);
double VCi  = VC  * exp(ETA_VC);
double K12i = K12 * exp(ETA_K12);
double K21i = K21 * exp(ETA_K21);
double K10i = CLi / VCi;

F_GUT = F1;

$ODE
dxdt_GUT = -KAi * GUT;

dxdt_CENT =
    KAi * GUT
  - K10i * CENT
  - K12i * CENT
  + K21i * PERIPH;

dxdt_PERIPH =
    K12i * CENT
  - K21i * PERIPH;

$TABLE
double IND_mgL  = CENT / VCi;
double IND_ngmL = IND_mgL * 1000.0;

$CAPTURE IND_ngmL
'

mod <- mcode("indapamide_grebow1982", indapamide_code)

set.seed(123)

dose_mg <- c(2.5, 5)

N        <- 1000
tau_h    <- 24
n_doses  <- 10
addl_md  <- n_doses - 1

t_end_sd <- 96
t_end_md <- n_doses * tau_h

delta_sd <- 0.01
delta_md <- 0.01

last_dose_h <- (n_doses - 1) * tau_h

dose_levels_sd <- paste0(dose_mg," mg single dose")
dose_levels_md <- paste0(dose_mg," mg q24h x", n_doses)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:N)



fig1_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- ev(time = 0, amt  = d, cmt  = "GUT")
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(
      end   = t_end_sd,
      delta = delta_sd
    ) %>%
    as_tibble() %>%
    mutate(
      CP   = IND_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(
  fig1_out,
  aes(time, CP, color = Dose)
) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Indapamide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Indapamide once-daily single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C2   = get_nearest(time, CP, 2),
    C4   = get_nearest(time, CP, 4),
    C8   = get_nearest(time, CP, 8),
    C12  = get_nearest(time, CP, 12),
    C24  = get_nearest(time, CP, 24),
    C48  = get_nearest(time, CP, 48),
    .groups = "drop"
  )



fig2_list <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "GUT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(
      end   = t_end_md,
      delta = delta_md
    ) %>%
    as_tibble() %>%
    mutate(
      CP   = IND_ngmL,
      Dose = paste0(
        d,
        " mg q24h x",
        n_doses
      )
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(
    Dose = factor(Dose, levels = dose_levels_md)
  )

p2 <- ggplot(
  fig2_out,
  aes(time / 24, CP, color = Dose)
) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Indapamide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Indapamide once-daily, multidose"
  )

fig2_summary <- fig2_out %>%
  filter(
    time >= last_dose_h,
    time <= t_end_md
  ) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day10 = max(CP, na.rm = TRUE),
    Tmax_day10 = time[which.max(CP)] - last_dose_h,
    
    C2_day10 = get_nearest(time, CP, last_dose_h + 2),
    C4_day10 = get_nearest(time, CP, last_dose_h + 4),
    C8_day10 = get_nearest(time, CP, last_dose_h + 8),
    C12_day10 = get_nearest(time, CP, last_dose_h + 12),
    Ctrough_day10 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )



set.seed(123)
fig3_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- ev(time = 0, amt  = d, cmt  = "GUT")
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(
      end   = t_end_sd,
      delta = delta_sd
    ) %>%
    as_tibble() %>%
    mutate(
      CP   = IND_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(
    Dose = factor(Dose, levels = dose_levels_sd)
  )

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(
  fig3_sum,
  aes(time, C_med, color = Dose, fill = Dose)
) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Indapamide concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Indapamide once-daily single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C2   = get_nearest(time, CP, 2),
    C4   = get_nearest(time, CP, 4),
    C8   = get_nearest(time, CP, 8),
    C12  = get_nearest(time, CP, 12),
    C24  = get_nearest(time, CP, 24),
    C48  = get_nearest(time, CP, 48),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C2_med = median(C2, na.rm = TRUE),
    C2_p05 = quantile(C2, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2, 0.95, na.rm = TRUE),
    
    C4_med = median(C4, na.rm = TRUE),
    C4_p05 = quantile(C4, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )



set.seed(123)
fig4_list <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "GUT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(
      end   = t_end_md,
      delta = delta_md
    ) %>%
    as_tibble() %>%
    mutate(
      CP   = IND_ngmL,
      Dose = paste0(
        d,
        " mg q24h x",
        n_doses
      )
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(
    Dose = factor(Dose, levels = dose_levels_md)
  )

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(
  fig4_sum,
  aes(time / 24, C_med, color = Dose, fill = Dose)
) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Indapamide concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Indapamide once-daily multidose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(
    time >= last_dose_h,
    time <= t_end_md
  ) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_day10 = max(CP, na.rm = TRUE),
    Tmax_day10 = time[which.max(CP)] - last_dose_h,
    C2_day10 = get_nearest(time, CP, last_dose_h + 2),
    C4_day10 = get_nearest(time, CP, last_dose_h + 4),
    C8_day10 = get_nearest(time, CP, last_dose_h + 8),
    C12_day10 = get_nearest(time,CP,last_dose_h + 12),
    Ctrough_day10 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day10_med = median(Cmax_day10, na.rm = TRUE),
    Cmax_day10_p05 = quantile(Cmax_day10, 0.05, na.rm = TRUE),
    Cmax_day10_p95 = quantile(Cmax_day10, 0.95, na.rm = TRUE),
    
    Tmax_day10_med = median(Tmax_day10, na.rm = TRUE),
    Tmax_day10_p05 = quantile(Tmax_day10, 0.05, na.rm = TRUE),
    Tmax_day10_p95 = quantile(Tmax_day10, 0.95, na.rm = TRUE),
    
    C2_day10_med = median(C2_day10, na.rm = TRUE),
    C2_day10_p05 = quantile(C2_day10, 0.05, na.rm = TRUE),
    C2_day10_p95 = quantile(C2_day10, 0.95, na.rm = TRUE),
    
    C4_day10_med = median(C4_day10, na.rm = TRUE),
    C4_day10_p05 = quantile(C4_day10, 0.05, na.rm = TRUE),
    C4_day10_p95 = quantile(C4_day10, 0.95, na.rm = TRUE),
    
    C8_day10_med = median(C8_day10, na.rm = TRUE),
    C8_day10_p05 = quantile(C8_day10, 0.05, na.rm = TRUE),
    C8_day10_p95 = quantile(C8_day10, 0.95, na.rm = TRUE),
    
    C12_day10_med = median(C12_day10, na.rm = TRUE),
    C12_day10_p05 = quantile(C12_day10, 0.05, na.rm = TRUE),
    C12_day10_p95 = quantile(C12_day10, 0.95, na.rm = TRUE),
    
    Ctrough_day10_med = median(Ctrough_day10, na.rm = TRUE),
    Ctrough_day10_p05 = quantile(Ctrough_day10, 0.05, na.rm = TRUE),
    Ctrough_day10_p95 = quantile(Ctrough_day10, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary