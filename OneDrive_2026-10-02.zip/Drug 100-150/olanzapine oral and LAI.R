library(mrgsolve) 
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

olz_lai_code <- '
$PROB
Olanzapine TV-44749 (SC long-acting injectable) population PK/D2RO model
- Ref: Perlstein I, Cherniakov I, Elgart A, Gomeni R, Gutman D,
  Merenlender Wagner A, Singh R.
  Population Pharmacokinetic Model-Based Dose Selection of Extended-Release
  Injectable Olanzapine (TV-44749) for Subcutaneous Use in Phase 3 Clinical
  Trial in Adults with Schizophrenia.
  J Clin Pharmacol. 2026;66(1):e70144. doi:10.1002/jcph.70144
  
  

$PARAM @annotated
TD        : 117     : h      First release process, Weibull time scale
SS        : 1.4     : --     First release process, Weibull shape
TD1_0     : 323     : h      Second release process, time scale intercept
TD1_DOSE  : 0.0939  : h/mg   Dose effect on second-process time scale
SS1       : 3.25    : --     Second release process, Weibull shape
FF        : 0.236   : --     Fraction of dose in first release process

CLF       : 16.6    : L/h    Apparent clearance (70 kg)
VF        : 15.4    : L      Apparent central volume (70 kg)
K12       : 1.61    : 1/h    Central -> peripheral rate constant
K21       : 0.00313 : 1/h    Peripheral -> central rate constant

WT        : 70      : kg     Body weight
WT_REF    : 70      : kg     Reference weight
DOSE_MG   : 425     : mg     TV-44749 dose (for the TD1 dose effect)

TH_CL_WT  : 0.31    : --     Weight exponent on CL/F
TH_V_WT   : 0.364   : --     Weight exponent on V/F

ADD_SD    : 0.632   : ng/mL  Additive residual SD
PROP_SD   : 0.233   : --     Proportional residual SD

ROMAX     : 100     : %      Maximum D2 receptor occupancy (fixed, Mamo 2008)
EC50      : 11      : ng/mL  Concentration for 50% D2RO (fixed, Mamo 2008)

$CMT @annotated
DEPOT  : First (rapid) release depot (mg)
DEPOT2 : Second (sustained) release depot (mg)
CENT   : Central compartment (mg)
PERIPH : Peripheral compartment (mg)

$OMEGA @labels ETA_TD ETA_SS ETA_TD1 ETA_SS1 ETA_FF ETA_CL ETA_V ETA_K12 ETA_K21
0.0038 0 0 0 0.0669 0 0 0 0.445

$SIGMA
1 1

$GLOBAL
double TDOSE = -1.0;
double TDi;
double SSi;
double TD1i;
double SS1i;
double FFi;
double CLFi;
double VFi;
double K12i;
double K21i;

$MAIN
if (NEWIND <= 1) TDOSE = -1.0;
if (EVID == 1 && (CMT == 1 || CMT == 2)) TDOSE = TIME;

TDi  = TD  * exp(ETA_TD);
SSi  = SS  * exp(ETA_SS);
TD1i = (TD1_0 + TD1_DOSE * DOSE_MG) * exp(ETA_TD1);
SS1i = SS1 * exp(ETA_SS1);

double LOGIT_FF = log(FF / (1.0 - FF)) + ETA_FF;
FFi = 1.0 / (1.0 + exp(-LOGIT_FF));

CLFi = CLF * pow(WT / WT_REF, TH_CL_WT) * exp(ETA_CL);
VFi  = VF  * pow(WT / WT_REF, TH_V_WT)  * exp(ETA_V);
K12i = K12 * exp(ETA_K12);
K21i = K21 * exp(ETA_K21);

F_DEPOT  = FFi;
F_DEPOT2 = 1.0 - FFi;

$ODE
double TAD = SOLVERTIME - TDOSE;
double H1 = 0.0;
double H2 = 0.0;
if (TDOSE >= 0.0 && TAD > 0.0) {
  H1 = (SSi  / TDi)  * pow(TAD / TDi,  SSi  - 1.0);
  H2 = (SS1i / TD1i) * pow(TAD / TD1i, SS1i - 1.0);
}

dxdt_DEPOT  = -H1 * DEPOT;
dxdt_DEPOT2 = -H2 * DEPOT2;

dxdt_CENT =
    H1 * DEPOT
  + H2 * DEPOT2
  - (CLFi / VFi) * CENT
  - K12i * CENT
  + K21i * PERIPH;

dxdt_PERIPH =
    K12i * CENT
  - K21i * PERIPH;

$TABLE
double CP_ngmL = 1000.0 * CENT / VFi;
if (CP_ngmL < 0) CP_ngmL = 0;

double DV_PK =
  CP_ngmL * (1.0 + PROP_SD * EPS(1)) + ADD_SD * EPS(2);

double D2RO = ROMAX * CP_ngmL / (EC50 + CP_ngmL);

$CAPTURE
CP_ngmL DV_PK D2RO
TDi SSi TD1i SS1i FFi CLFi VFi K12i K21i
WT DOSE_MG
'
mod_lai <- mcode("olanzapine_lai", olz_lai_code)


olz_oral_code <- '
$PROB
Oral olanzapine population PK/D2RO model (Perlstein 2026, Supplemental Table 2)


$PARAM @annotated
KA        : 0.0292  : 1/h    First-order absorption rate constant
VF        : 9.61    : L      Apparent central volume
CLF       : 22.6    : L/h    Apparent clearance
K12       : 0.254   : 1/h    Central -> peripheral rate constant
K21       : 0.015   : 1/h    Peripheral -> central rate constant
TLAG      : 0.937   : h      Absorption lag time

ADD_SD    : 0.0001  : ng/mL  Additive residual SD (fixed)
PROP_SD   : 0.147   : --     Proportional residual SD

ROMAX     : 100     : %      Maximum D2 receptor occupancy (fixed)
EC50      : 11      : ng/mL  Concentration for 50% D2RO (fixed)

$CMT @annotated
DEPOT  : Oral dosing/absorption compartment (mg)
CENT   : Central compartment (mg)
PERIPH : Peripheral compartment (mg)

$OMEGA @labels ETA_KA ETA_V ETA_CL
0.0444 0.897 0.227

$SIGMA
1 1

$GLOBAL
double KAi;
double VFi;
double CLFi;

$MAIN
KAi  = KA  * exp(ETA_KA);
VFi  = VF  * exp(ETA_V);
CLFi = CLF * exp(ETA_CL);

ALAG_DEPOT = TLAG;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT =
    KAi * DEPOT
  - (CLFi / VFi) * CENT
  - K12 * CENT
  + K21 * PERIPH;

dxdt_PERIPH =
    K12 * CENT
  - K21 * PERIPH;

$TABLE
double CP_ngmL = 1000.0 * CENT / VFi;
if (CP_ngmL < 0) CP_ngmL = 0;

double DV_PK =
  CP_ngmL * (1.0 + PROP_SD * EPS(1)) + ADD_SD * EPS(2);

double D2RO = ROMAX * CP_ngmL / (EC50 + CP_ngmL);

$CAPTURE
CP_ngmL DV_PK D2RO
KAi VFi CLFi
'
mod_oral <- mcode("olanzapine_oral", olz_oral_code)
