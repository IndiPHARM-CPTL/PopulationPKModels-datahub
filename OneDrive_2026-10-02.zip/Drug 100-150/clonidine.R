library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

clonidine_code <- '
$PROB
- Ref: Anavekar SN, Howes LG, Jarrott B, Syrjanen M, Conway EL, Louis WJ.
  Pharmacokinetics and antihypertensive effects of low dose clonidine during chronic therapy.
  J Clin Pharmacol. 1989;29:321-326.

$PARAM @annotated
KA      : 0.85  : 1/h   First-order absorption rate constant; selected to approximate Tmax ~3.6 h after first dose
CL      : 12.3  : L/h   Apparent oral clearance; derived from 75 mcg / AUC ~6.1 ng*h/mL
VAPP    : 268   : L     Apparent volume; derived from CL / KEL with t1/2 ~15.1 h

$CMT 
GUT CENT

$OMEGA @annotated
EKA     : 0.160 : IIV on KA
ECL     : 0.200 : IIV on CL
EVAPP   : 0.250 : IIV on VAPP

$MAIN
double KAi   = KA   * exp(EKA);
double CLi   = CL   * exp(ECL);
double VAPPi = VAPP * exp(EVAPP);

double KELi  = CLi / VAPPi;

$ODE
dxdt_GUT  = -KAi * GUT;

dxdt_CENT =  KAi * GUT
             -KELi * CENT;

$TABLE
double C_CLON_ngmL = CENT / VAPPi;


$CAPTURE C_CLON_ngmL
'
mod <- mcode("clonidine_anavekar_1989_1c", clonidine_code)



dose_mcg <- c(37.5, 75, 150)

n_pop <- 1000
set.seed(123)

tau_h    <- 12
n_doses  <- 10       
addl_md  <- n_doses - 1

t_end_sd <- 24
t_end_md <- 120

delta_sd <- 0.05
delta_md <- 0.10

last_dose_h <- (n_doses - 1) * tau_h
final_interval_end_h <- last_dose_h + tau_h

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:n_pop)

mod_typ <- zero_re(mod)


get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  
  df$conc[which.min(abs(df$time - t))]
}


make_long_primary <- function(x) {
  x %>%
    pivot_longer(
      cols = c(C_CLON_ngmL),
      names_to = "analyte",
      values_to = "conc_ngmL"
    ) %>%
    mutate(
      analyte = recode(
        analyte,
        C_CLON_ngmL = "Clonidine"
      )
    )
}


fig1_raw <- lapply(dose_mcg, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(dose = paste0(d, " mcg"))
}) %>%
  bind_rows() %>%
  mutate(dose = factor(dose, levels = paste0(dose_mcg, " mcg")))

fig1 <- make_long_primary(fig1_raw)

p1 <- ggplot(fig1, aes(x = time, y = conc_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after oral dose (h)",
    y = "Plasma clonidine concentration (ng/mL)",
    title = "Figure 1. Clonidine single-dose typical simulation",
    subtitle = "Oral one-compartment model",
    color = "Dose"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_ngmL, na.rm = TRUE),
    Tmax = time[which.max(conc_ngmL)],
    C0_5 = get_conc_at(time, conc_ngmL, 0.5),
    C1   = get_conc_at(time, conc_ngmL, 1),
    C2   = get_conc_at(time, conc_ngmL, 2),
    C3   = get_conc_at(time, conc_ngmL, 3),
    C4   = get_conc_at(time, conc_ngmL, 4),
    C6   = get_conc_at(time, conc_ngmL, 6),
    C8   = get_conc_at(time, conc_ngmL, 8),
    C12  = get_conc_at(time, conc_ngmL, 12),
    C24  = get_conc_at(time, conc_ngmL, 24),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_ng_mL = median(Cmax, na.rm = TRUE),
    Tmax_h     = median(Tmax, na.rm = TRUE),
    C0_5_ng_mL = median(C0_5, na.rm = TRUE),
    C1_ng_mL   = median(C1, na.rm = TRUE),
    C2_ng_mL   = median(C2, na.rm = TRUE),
    C3_ng_mL   = median(C3, na.rm = TRUE),
    C4_ng_mL   = median(C4, na.rm = TRUE),
    C6_ng_mL   = median(C6, na.rm = TRUE),
    C8_ng_mL   = median(C8, na.rm = TRUE),
    C12_ng_mL  = median(C12, na.rm = TRUE),
    C24_ng_mL  = median(C24, na.rm = TRUE),
    .groups = "drop"
  )

p1
fig1_summary


fig2_raw <- lapply(dose_mcg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(dose = paste0(d, " mcg q12h x", n_doses))
}) %>%
  bind_rows() %>%
  mutate(dose = factor(dose, levels = paste0(dose_mcg, " mcg q12h x", n_doses)))

fig2 <- make_long_primary(fig2_raw)

p2 <- ggplot(fig2, aes(x = time, y = conc_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Plasma clonidine concentration (ng/mL)",
    title = "Figure 2. Clonidine q12h multiple-dose typical simulation",
    subtitle = "Approximate chronic day-5 condition",
    color = "Dose"
  ) +
  theme_bw()

fig2_ind <- fig2 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_ngmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ngmL, -Inf))
    ] - last_dose_h,
    C12_after_last = get_conc_at(time, conc_ngmL, final_interval_end_h),
    C12_day1       = get_conc_at(time, conc_ngmL, tau_h),
    C24            = get_conc_at(time, conc_ngmL, 24),
    C48            = get_conc_at(time, conc_ngmL, 48),
    C72            = get_conc_at(time, conc_ngmL, 72),
    C108           = get_conc_at(time, conc_ngmL, 108),
    C120           = get_conc_at(time, conc_ngmL, 120),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_ng_mL = median(Cmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_h     = median(Tmax_final_interval, na.rm = TRUE),
    C12_after_last_ng_mL      = median(C12_after_last, na.rm = TRUE),
    C12_day1_ng_mL            = median(C12_day1, na.rm = TRUE),
    C24_ng_mL                 = median(C24, na.rm = TRUE),
    C48_ng_mL                 = median(C48, na.rm = TRUE),
    C72_ng_mL                 = median(C72, na.rm = TRUE),
    C108_ng_mL                = median(C108, na.rm = TRUE),
    C120_ng_mL                = median(C120, na.rm = TRUE),
    .groups = "drop"
  )

p2
fig2_summary


fig3_raw <- lapply(dose_mcg, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(dose = paste0(d, " mcg"))
}) %>%
  bind_rows() %>%
  mutate(dose = factor(dose, levels = paste0(dose_mcg, " mcg")))

fig3 <- make_long_primary(fig3_raw)

fig3_sum <- fig3 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_ngmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after oral dose (h)",
    y = "Plasma clonidine concentration (ng/mL)",
    title = "Figure 3. Clonidine single-dose population simulation",
    subtitle = "Line = median; ribbon = 5th-95th percentile",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig3_ind <- fig3 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_ngmL, na.rm = TRUE),
    Tmax = time[which.max(conc_ngmL)],
    C0_5 = get_conc_at(time, conc_ngmL, 0.5),
    C1   = get_conc_at(time, conc_ngmL, 1),
    C2   = get_conc_at(time, conc_ngmL, 2),
    C3   = get_conc_at(time, conc_ngmL, 3),
    C4   = get_conc_at(time, conc_ngmL, 4),
    C6   = get_conc_at(time, conc_ngmL, 6),
    C8   = get_conc_at(time, conc_ngmL, 8),
    C12  = get_conc_at(time, conc_ngmL, 12),
    C24  = get_conc_at(time, conc_ngmL, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C2_med = median(C2, na.rm = TRUE),
    C2_p05 = quantile(C2, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2, 0.95, na.rm = TRUE),
    
    C4_med = median(C4, na.rm = TRUE),
    C4_p05 = quantile(C4, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3
fig3_summary



fig4_raw <- lapply(dose_mcg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(dose = paste0(d, " mcg q12h x", n_doses))
}) %>%
  bind_rows() %>%
  mutate(dose = factor(dose, levels = paste0(dose_mcg, " mcg q12h x", n_doses)))

fig4 <- make_long_primary(fig4_raw)

fig4_sum <- fig4 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_ngmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Plasma clonidine concentration (ng/mL)",
    title = "Figure 4. Clonidine q12h population simulation",
    subtitle = "Line = median; ribbon = 5th-95th percentile",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig4_ind <- fig4 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_ngmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ngmL, -Inf))
    ] - last_dose_h,
    C12_after_last = get_conc_at(time, conc_ngmL, final_interval_end_h),
    C12_day1       = get_conc_at(time, conc_ngmL, tau_h),
    C24            = get_conc_at(time, conc_ngmL, 24),
    C48            = get_conc_at(time, conc_ngmL, 48),
    C72            = get_conc_at(time, conc_ngmL, 72),
    C108           = get_conc_at(time, conc_ngmL, 108),
    C120           = get_conc_at(time, conc_ngmL, 120),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_final_interval_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_final_interval_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_final_interval_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_final_interval_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C12_after_last_med = median(C12_after_last, na.rm = TRUE),
    C12_after_last_p05 = quantile(C12_after_last, 0.05, na.rm = TRUE),
    C12_after_last_p95 = quantile(C12_after_last, 0.95, na.rm = TRUE),
    
    C12_day1_med = median(C12_day1, na.rm = TRUE),
    C12_day1_p05 = quantile(C12_day1, 0.05, na.rm = TRUE),
    C12_day1_p95 = quantile(C12_day1, 0.95, na.rm = TRUE),
    
    C72_med = median(C72, na.rm = TRUE),
    C72_p05 = quantile(C72, 0.05, na.rm = TRUE),
    C72_p95 = quantile(C72, 0.95, na.rm = TRUE),
    
    C120_med = median(C120, na.rm = TRUE),
    C120_p05 = quantile(C120, 0.05, na.rm = TRUE),
    C120_p95 = quantile(C120, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4
fig4_summary

