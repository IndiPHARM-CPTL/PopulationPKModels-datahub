library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

desacetyl_deflazacort_code <- '
$PROB
21-Desacetyldeflazacort PK after oral deflazacort

- Ref: Möllmann H, Hochhaus G, Rohatagi S, Barth J, Derendorf H. Pharmacokinetic/pharmacodynamic evaluation of deflazacort in comparison to methylprednisolone and prednisolone. Pharm Res. 1995;12(7):1096-1100. doi:10.1023/a:1016287104656

$PARAM @annotated
KA       : 1.22  : 1/h    First-order appearance rate constant
CL       : 114   : L/h    Apparent oral clearance
V        : 204   : L      Apparent volume of distribution
PROP_ERR : 0.10  : --     Assumed proportional residual error SD

$OMEGA @labels ETA_CL ETA_V
0.0546
0.1566

$SIGMA
1

$CMT
DEPOT CENT

$GLOBAL
double KAi, CLi, Vi, KEi;

$MAIN
KAi = KA;
CLi = CL * exp(ETA(1));
Vi  = V  * exp(ETA(2));
KEi = CLi / Vi;

F_DEPOT = 1.0;

$ODE
dxdt_DEPOT = -KAi * DEPOT;
dxdt_CENT  =  KAi * DEPOT
             - (CLi / Vi) * CENT;

$TABLE
double CP = (CENT / Vi) * 1000.0;
double DV = CP * (1.0 + PROP_ERR * EPS(1));

$CAPTURE CP KAi CLi Vi KEi
'
mod_dfd <- mcode("desacetyl_deflazacort_pk",desacetyl_deflazacort_code)

doses_mg <- c(30)
dose_levels <- paste0(doses_mg, " mg")

tau_h    <- 24
n_doses  <- 7
addl_md  <- n_doses - 1

t_end_sd <- 24
delta_sd <- 0.05

t_end_md <- n_doses * tau_h
delta_md <- 0.10

last_dose_time_h <- (n_doses - 1) * tau_h

mod_typ <- zero_re(mod_dfd)
idata_typ <- tibble(ID = 1)

make_idata_pop <- function(N) {
  tibble(
    ID = seq_len(N)
  )
}

at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}


fig1_list <- lapply(doses_mg, function(d) {
  ev_sd <- ev(
    amt = d,
    cmt = 1,
    time = 0
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd
    ) %>%
    as_tibble() %>%
    mutate(group = paste0(d, " mg"))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(group = factor(group, levels = dose_levels))

p1 <- ggplot(
  fig1_out,
  aes(time, CP, color = group)
) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Unbound 21-desacetyldeflazacort concentration (ng/mL)",
    color = "Deflazacort dose",
    title = "Figure 1. Deflazacort single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(group) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C2h = at_time(time, CP, 2),
    C4h = at_time(time, CP, 4),
    C8h = at_time(time, CP, 8),
    C12h = at_time(time, CP, 12),
    C24h = at_time(time, CP, 24),
    .groups = "drop"
  )


fig2_list <- lapply(doses_mg, function(d) {
  ev_md <- ev(
    amt = d,
    ii = tau_h,
    addl = addl_md,
    cmt = 1
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md
    ) %>%
    as_tibble() %>%
    mutate(group = paste0(d, " mg"))
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(group = factor(group, levels = dose_levels))

p2 <- ggplot(
  fig2_out,
  aes(time / 24, CP, color = group)
) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Unbound 21-desacetyldeflazacort concentration (ng/mL)",
    color = "Deflazacort dose",
    title = "Figure 2. Deflazacort once daily for 7 days"
  )

fig2_summary <- fig2_out %>%
  group_by(group) %>%
  summarise(
    Cmax_ss = max(CP[time >= last_dose_time_h]),
    
    Tmax_ss_h =
      time[time >= last_dose_time_h][
        which.max(CP[time >= last_dose_time_h])
      ] -
      last_dose_time_h,
    
    Ctrough_ss = at_time(time, CP, t_end_md),
    
    Cday1 = at_time(time, CP, 24),
    Cday2 = at_time(time, CP, 48),
    Cday3 = at_time(time, CP, 72),
    Cday4 = at_time(time, CP, 96),
    Cday5 = at_time(time, CP, 120),
    Cday6 = at_time(time, CP, 144),
    Cday7 = at_time(time, CP, 168),
    
    .groups = "drop"
  )

N <- 1000
idata_pop <- make_idata_pop(N)
set.seed(123)

fig3_list <- lapply(doses_mg, function(d) {
  ev_sd <- ev(
    amt = d,
    cmt = 1,
    time = 0
  )
  
  mod_dfd %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd
    ) %>%
    as_tibble() %>%
    mutate(group = paste0(d, " mg"))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(group = factor(group, levels = dose_levels))

fig3_sum <- fig3_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP),
    C_p05 = quantile(CP, 0.05),
    C_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p3 <- ggplot(
  fig3_sum,
  aes(
    time,
    C_med,
    color = group,
    fill = group
  )
) +
  geom_ribbon(
    aes(
      ymin = C_p05,
      ymax = C_p95
    ),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Unbound 21-desacetyldeflazacort concentration (ng/mL)",
    color = "Deflazacort dose",
    fill = "Deflazacort dose",
    title = "Figure 3. Deflazacort single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C2h = at_time(time, CP, 2),
    C4h = at_time(time, CP, 4),
    C8h = at_time(time, CP, 8),
    C12h = at_time(time, CP, 12),
    C24h = at_time(time, CP, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med = median(Tmax_h),
    Tmax_p05 = quantile(Tmax_h, 0.05),
    Tmax_p95 = quantile(Tmax_h, 0.95),
    
    C2h_med = median(C2h),
    C2h_p05 = quantile(C2h, 0.05),
    C2h_p95 = quantile(C2h, 0.95),
    
    C4h_med = median(C4h),
    C4h_p05 = quantile(C4h, 0.05),
    C4h_p95 = quantile(C4h, 0.95),
    
    C8h_med = median(C8h),
    C8h_p05 = quantile(C8h, 0.05),
    C8h_p95 = quantile(C8h, 0.95),
    
    C12h_med = median(C12h),
    C12h_p05 = quantile(C12h, 0.05),
    C12h_p95 = quantile(C12h, 0.95),
    
    C24h_med = median(C24h),
    C24h_p05 = quantile(C24h, 0.05),
    C24h_p95 = quantile(C24h, 0.95),
    
    .groups = "drop"
  )


set.seed(123)
fig4_list <- lapply(doses_mg, function(d) {
  ev_md <- ev(
    amt = d,
    ii = tau_h,
    addl = addl_md,
    cmt = 1
  )
  
  mod_dfd %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md
    ) %>%
    as_tibble() %>%
    mutate(group = paste0(d, " mg"))
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(group = factor(group, levels = dose_levels))

fig4_sum <- fig4_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP),
    C_p05 = quantile(CP, 0.05),
    C_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p4 <- ggplot(
  fig4_sum,
  aes(
    time / 24,
    C_med,
    color = group,
    fill = group
  )
) +
  geom_ribbon(
    aes(
      ymin = C_p05,
      ymax = C_p95
    ),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Unbound 21-desacetyldeflazacort concentration (ng/mL)",
    color = "Deflazacort dose",
    fill = "Deflazacort dose",
    title = "Figure 4. Deflazacort once daily for 7 days, population"
  )

fig4_daily <- fig4_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cday1 = at_time(time, CP, 24),
    Cday2 = at_time(time, CP, 48),
    Cday3 = at_time(time, CP, 72),
    Cday4 = at_time(time, CP, 96),
    Cday5 = at_time(time, CP, 120),
    Cday6 = at_time(time, CP, 144),
    Cday7 = at_time(time, CP, 168),
    .groups = "drop"
  )

fig4_last_interval <- fig4_raw %>%
  filter(
    time >= last_dose_time_h,
    time <= t_end_md
  ) %>%
  group_by(group, ID) %>%
  summarise(
    Cmax_ss = max(CP),
    Tmax_ss_h = time[which.max(CP)] - last_dose_time_h,
    Ctrough_ss = at_time(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_ind <- fig4_last_interval %>%
  left_join(
    fig4_daily,
    by = c("group", "ID")
  )

fig4_summary <- fig4_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax_ss),
    Cmax_p05 = quantile(Cmax_ss, 0.05),
    Cmax_p95 = quantile(Cmax_ss, 0.95),
    
    Tmax_med = median(Tmax_ss_h),
    Tmax_p05 = quantile(Tmax_ss_h, 0.05),
    Tmax_p95 = quantile(Tmax_ss_h, 0.95),
    
    Ctrough_med = median(Ctrough_ss),
    Ctrough_p05 = quantile(Ctrough_ss, 0.05),
    Ctrough_p95 = quantile(Ctrough_ss, 0.95),
    
    Cday1_med = median(Cday1),
    Cday1_p05 = quantile(Cday1, 0.05),
    Cday1_p95 = quantile(Cday1, 0.95),
    
    Cday2_med = median(Cday2),
    Cday2_p05 = quantile(Cday2, 0.05),
    Cday2_p95 = quantile(Cday2, 0.95),
    
    Cday3_med = median(Cday3),
    Cday3_p05 = quantile(Cday3, 0.05),
    Cday3_p95 = quantile(Cday3, 0.95),
    
    Cday4_med = median(Cday4),
    Cday4_p05 = quantile(Cday4, 0.05),
    Cday4_p95 = quantile(Cday4, 0.95),
    
    Cday5_med = median(Cday5),
    Cday5_p05 = quantile(Cday5, 0.05),
    Cday5_p95 = quantile(Cday5, 0.95),
    
    Cday6_med = median(Cday6),
    Cday6_p05 = quantile(Cday6, 0.05),
    Cday6_p95 = quantile(Cday6, 0.95),
    
    Cday7_med = median(Cday7),
    Cday7_p05 = quantile(Cday7, 0.05),
    Cday7_p95 = quantile(Cday7, 0.95),
    
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary

