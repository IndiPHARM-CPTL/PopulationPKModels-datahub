library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

amiloride_code <- '
$PROB
- Ref: Spahn H, Reuter K, Mutschler E, Gerok W, Knauf H.
  Pharmacokinetics of Amiloride in Renal and Hepatic Disease.
  Eur J Clin Pharmacol. 1987;33:493-498.

$PARAM @annotated
KA : 0.78889 : 1/h   First-order absorption rate constant
CL : 39.5257 : L/h   Apparent oral clearance, CL/F
V  : 436.583 : L     Apparent volume of distribution, V/F

$CMT @annotated
GUT  : Oral depot compartment
CENT : Central compartment

$OMEGA @diag @labels ETA_KA ETA_CL ETA_V
0.220 0.029 0.240

$MAIN
double KAi = KA * exp(ETA_KA);
double CLi = CL * exp(ETA_CL);
double Vi = V * exp(ETA_V);
double KELi = CLi / Vi;

$ODE
dxdt_GUT = -KAi * GUT;
dxdt_CENT = KAi * GUT - KELi * CENT;

$TABLE
double AMI_ngmL = (CENT / Vi) * 1000.0;

$CAPTURE AMI_ngmL
'

mod <- mcode("amiloride_spahn1987_1cpt", amiloride_code)

set.seed(123)

dose_mg <- c(5, 10, 20)

N <- 1000
tau_h <- 24
n_doses <- 7
addl_md <- n_doses - 1

t_end_sd <- tau_h
t_end_md <- n_doses * tau_h

delta_sd <- 0.1
delta_md <- 0.1

last_dose_h <- (n_doses - 1) * tau_h

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:N)


fig1_out <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT")) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(
      ID,
      time,
      CP = pmax(AMI_ngmL, 0),
      Dose = paste0(d, " mg single dose")
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Amiloride concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Amiloride once-daily single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    Ctrough = get_nearest(time, CP, tau_h),
    .groups = "drop"
  )



fig2_out <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(
      time = 0,
      amt = d,
      cmt = "GUT",
      ii = tau_h,
      addl = addl_md
    )) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(
      ID,
      time,
      CP = pmax(AMI_ngmL, 0),
      Dose = paste0(d, " mg q24h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Amiloride concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Amiloride once-daily multidose for 7 days"
  )

fig2_summary <- fig2_out %>%
  filter(time >= last_dose_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_final_interval = max(CP, na.rm = TRUE),
    Tmax_final_interval = time[which.max(CP)] - last_dose_h,
    Ctrough_final_interval = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )


fig3_raw <- lapply(dose_mg, function(d) {
  set.seed(123)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT")) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(
      ID,
      time,
      CP = pmax(AMI_ngmL, 0),
      Dose = paste0(d, " mg single dose")
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Amiloride concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Amiloride once-daily single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    Ctrough = get_nearest(time, CP, tau_h),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )




fig4_raw <- lapply(dose_mg, function(d) {
  set.seed(123)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(
      time = 0,
      amt = d,
      cmt = "GUT",
      ii = tau_h,
      addl = addl_md
    )) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(
      ID,
      time,
      CP = pmax(AMI_ngmL, 0),
      Dose = paste0(d, " mg q24h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Amiloride concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Amiloride once-daily multi-dose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= last_dose_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_final_interval = max(CP, na.rm = TRUE),
    Tmax_final_interval = time[which.max(CP)] - last_dose_h,
    Ctrough_final_interval = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough_final_interval, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough_final_interval, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough_final_interval, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )

p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary