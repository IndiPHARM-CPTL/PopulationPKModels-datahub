library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

torsemide_code <- '
$PROB
Torsemide oral PopPK model
- Ref: Jeong SH, Jang JH, Cho HY, Lee YB. Population Pharmacokinetic (Pop-PK) Analysis of Torsemide in Healthy Korean Males Considering CYP2C9 and OATP1B1 Genetic Polymorphisms. Pharmaceutics. 2022;14(4):771. Published 2022 Apr 1. doi:10.3390/pharmaceutics14040771

$PARAM @annotated
KA       : 0.861 : 1/h     First-order absorption rate constant
V1       : 1.027 : L       Apparent central volume
V2       : 3.914 : L       Apparent peripheral volume, V2/F
CL       : 1.740 : L/h     Apparent clearance
Q        : 0.828 : L/h     Apparent intercompartmental clearance
TLAG     : 0.274 : h       lag time

DV_IT    : -0.410 : --     OATP1B1 IT effect on V/F
DV_PT    : -0.646 : --     OATP1B1 PT effect on V/F
DCL_EM   :  0.510 : --     CYP2C9 EM effect on CL/F
DQ_EM    :  0.365 : --     CYP2C9 EM effect on Q/F

CYP_EM   : 1 : --          CYP2C9 phenotype flag; 1 = EM, 0 = IM
OATP_IT  : 0 : --          OATP1B1 intermediate transporter flag
OATP_PT  : 0 : --          OATP1B1 poor transporter flag
COV_ON   : 1 : --          0 = no covariate effect; 1 = apply CYP2C9/OATP1B1 effects

$CMT 
GUT CENT PERIPH

$OMEGA @annotated
EV1    : 0.562 : IIV on V1/F
ECL    : 0.029 : IIV on CL/F
EV2    : 0.036 : IIV on V2/F
EQ     : 0.022 : IIV on Q/F
ETLAG  : 0.341 : IIV on TLAG

$MAIN
double v1_eff = 1.0;
double cl_eff = 1.0;
double q_eff  = 1.0;

if(COV_ON == 1) {
  v1_eff = 1.0 + DV_IT*OATP_IT + DV_PT*OATP_PT;
  cl_eff = 1.0 + DCL_EM*CYP_EM;
  q_eff  = 1.0 + DQ_EM*CYP_EM;
}

double KAi    = KA;
double V1i    = V1   * v1_eff * exp(EV1);
double V2i    = V2            * exp(EV2);
double CLi    = CL   * cl_eff * exp(ECL);
double Qi     = Q    * q_eff  * exp(EQ);
double TLAGi  = TLAG          * exp(ETLAG);

ALAG_GUT = TLAGi;

$ODE
dxdt_GUT    = -KAi * GUT;

dxdt_CENT   =  KAi * GUT
             - (CLi / V1i) * CENT
             - (Qi  / V1i) * CENT
             + (Qi  / V2i) * PERIPH;

dxdt_PERIPH =  (Qi / V1i) * CENT
             - (Qi / V2i) * PERIPH;

$TABLE
double CP_mgL  = CENT / V1i;
double CP_ngmL = CP_mgL * 1000.0;

$CAPTURE CP_mgL  CP_ngmL
'
mod <- mcode("torsemide_oral_jeong_2022", torsemide_code)

dose_mg <- c(5, 10, 20)
n_pop <- 1000
set.seed(123)

phenotype_tbl <- tibble(
  phenotype = c("ET_EM", "ET_IM", "IT_EM", "IT_IM", "PT_EM", "PT_IM"),
  prob      = c(0.7143, 0.0536, 0.1518, 0.0536, 0.0000, 0.0268)
)

idata_pop <- tibble(
  ID = 1:n_pop,
  phenotype = sample(
    phenotype_tbl$phenotype,
    size = n_pop,
    replace = TRUE,
    prob = phenotype_tbl$prob
  )
) %>%
  mutate(
    CYP_EM  = if_else(grepl("_EM$", phenotype), 1, 0),
    OATP_IT = if_else(grepl("^IT_", phenotype), 1, 0),
    OATP_PT = if_else(grepl("^PT_", phenotype), 1, 0),
    COV_ON  = 1
  )

idata_mrg <- idata_pop %>%
  select(ID, CYP_EM, OATP_IT, OATP_PT, COV_ON)

get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  
  df$conc[which.min(abs(df$time - t))]
}

tau_h <- 24
n_doses <- 3
last_dose_h <- (n_doses - 1) * tau_h   # 48 h
t_end_sd <- 24
t_end_md <- 72

fig1 <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(time = 0, amt = d, cmt = 1)
  
  mod %>%
    zero_re() %>%
    param(
      COV_ON = 0,
      CYP_EM = 1,
      OATP_IT = 0,
      OATP_PT = 0
    ) %>%
    ev(ev_one) %>%
    mrgsim(end = 24, delta = 0.02) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

p1 <- ggplot(fig1, aes(x = time, y = CP_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after dose (h)",
    y = "Torsemide concentration (ng/mL)",
    title = "Figure 1. Torsemide single-dose typical simulation",
    color = "Dose"
  ) +
  theme_bw()

p1


fig2 <- lapply(dose_mg, function(d) {
  
  ev_qd_3d <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = 24,
    addl = 2
  )
  
  mod %>%
    zero_re() %>%
    param(
      COV_ON = 0,
      CYP_EM = 1,
      OATP_IT = 0,
      OATP_PT = 0
    ) %>%
    ev(ev_qd_3d) %>%
    mrgsim(end = 72, delta = 0.02) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

p2 <- ggplot(fig2, aes(x = time, y = CP_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Torsemide concentration (ng/mL)",
    title = "Figure 2. Torsemide once-daily single dose",
    color = "Dose"
  ) +
  theme_bw()

p2



fig3_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(time = 0, amt = d, cmt = 1)
  
  mod %>%
    ev(ev_one) %>%
    mrgsim(
      idata = idata_mrg,
      end = 24,
      delta = 0.02,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig3_sum <- fig3_raw %>%
  group_by(dose, time) %>%
  summarise(
    CP_med = median(CP_ngmL, na.rm = TRUE),
    CP_p05 = quantile(CP_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after dose (h)",
    y = "Torsemide concentration (ng/mL)",
    title = "Figure 3. Torsemide once-daily single dose, population",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

p3


fig4_raw <- lapply(dose_mg, function(d) {
  
  ev_qd_3d <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = 24,
    addl = 2
  )
  
  mod %>%
    ev(ev_qd_3d) %>%
    mrgsim(
      idata = idata_mrg,
      end = 72,
      delta = 0.02,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig4_sum <- fig4_raw %>%
  group_by(dose, time) %>%
  summarise(
    CP_med = median(CP_ngmL, na.rm = TRUE),
    CP_p05 = quantile(CP_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Torsemide concentration (ng/mL)",
    title = "Figure 4. Torsemide once-daily multi-dose, population",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

p4




























dose_mg <- c(5, 10, 20)

n_pop <- 1000
set.seed(123)

tau_h    <- 24
n_doses  <- 3
addl_md  <- n_doses - 1

t_end_sd <- 24
t_end_md <- 72

delta_sd <- 0.02
delta_md <- 0.02

last_dose_h <- (n_doses - 1) * tau_h   

get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  
  df$conc[which.min(abs(df$time - t))]
}


phenotype_tbl <- tibble(
  phenotype = c("ET_EM", "ET_IM", "IT_EM", "IT_IM", "PT_EM", "PT_IM"),
  prob      = c(0.7143, 0.0536, 0.1518, 0.0536, 0.0000, 0.0268)
)

idata_pop <- tibble(
  ID = 1:n_pop,
  phenotype = sample(
    phenotype_tbl$phenotype,
    size = n_pop,
    replace = TRUE,
    prob = phenotype_tbl$prob
  )
) %>%
  mutate(
    CYP_EM  = if_else(grepl("_EM$", phenotype), 1, 0),
    OATP_IT = if_else(grepl("^IT_", phenotype), 1, 0),
    OATP_PT = if_else(grepl("^PT_", phenotype), 1, 0),
    COV_ON  = 1
  )

idata_mrg <- idata_pop %>%
  select(ID, CYP_EM, OATP_IT, OATP_PT, COV_ON)

idata_typ <- tibble(
  ID = 1,
  CYP_EM = 1,
  OATP_IT = 0,
  OATP_PT = 0,
  COV_ON = 0
)
mod_typ <- zero_re(mod)


fig1 <- lapply(dose_mg, function(d) {
  ev_one <- ev(time = 0, amt = d, cmt = 1)
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

p1 <- ggplot(fig1, aes(x = time, y = CP_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after dose (h)",
    y = "Torsemide concentration (ng/mL)",
    title = "Figure 1. Torsemide once-daily single-dose",
    color = "Dose"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(dose, ID) %>%
  summarise(
    Cmax  = max(CP_ngmL, na.rm = TRUE),
    Tmax  = time[which.max(CP_ngmL)],
    C6    = get_conc_at(time, CP_ngmL, 6),
    C12   = get_conc_at(time, CP_ngmL, 12),
    C24   = get_conc_at(time, CP_ngmL, 24),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(dose) %>%
  summarise(
    Cmax_ng_mL = median(Cmax, na.rm = TRUE),
    Tmax_h     = median(Tmax, na.rm = TRUE),
    C6_ng_mL   = median(C6, na.rm = TRUE),
    C12_ng_mL  = median(C12, na.rm = TRUE),
    C24_ng_mL  = median(C24, na.rm = TRUE),
    .groups = "drop"
  )

p1
fig1_summary


fig2 <- lapply(dose_mg, function(d) {
  
  ev_qd_3d <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_qd_3d) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q24h")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q24h"))
  )

p2 <- ggplot(fig2, aes(x = time, y = CP_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Torsemide concentration (ng/mL)",
    title = "Figure 2. Torsemide once-daily multi-dose",
    color = "Dose"
  ) +
  theme_bw()

fig2_ind <- fig2 %>%
  group_by(dose, ID) %>%
  summarise(
    Cmax_final_interval = {
      idx <- time >= last_dose_h & time <= t_end_md
      max(CP_ngmL[idx], na.rm = TRUE)
    },
    Tmax_final_interval = {
      idx <- time >= last_dose_h & time <= t_end_md
      time[idx][which.max(CP_ngmL[idx])] - last_dose_h
    },
    C24_after_last = get_conc_at(time, CP_ngmL, t_end_md),
    C24_day1       = get_conc_at(time, CP_ngmL, 24),
    C48            = get_conc_at(time, CP_ngmL, 48),
    C72            = get_conc_at(time, CP_ngmL, 72),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(dose) %>%
  summarise(
    Cmax_final_interval_ng_mL = median(Cmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_h     = median(Tmax_final_interval, na.rm = TRUE),
    C24_after_last_ng_mL      = median(C24_after_last, na.rm = TRUE),
    C24_day1_ng_mL            = median(C24_day1, na.rm = TRUE),
    C48_ng_mL                 = median(C48, na.rm = TRUE),
    C72_ng_mL                 = median(C72, na.rm = TRUE),
    .groups = "drop"
  )

p2
fig2_summary




fig3_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(time = 0, amt = d, cmt = 1)
  
  mod %>%
    idata_set(idata_mrg) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig3_sum <- fig3_raw %>%
  group_by(dose, time) %>%
  summarise(
    CP_med = median(CP_ngmL, na.rm = TRUE),
    CP_p05 = quantile(CP_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after dose (h)",
    y = "Torsemide concentration (ng/mL)",
    title = "Figure 3. Torsemide once-daily single-dose, population",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig3_ind <- fig3_raw %>%
  group_by(dose, ID) %>%
  summarise(
    Cmax  = max(CP_ngmL, na.rm = TRUE),
    Tmax  = time[which.max(CP_ngmL)],
    C6    = get_conc_at(time, CP_ngmL, 6),
    C12   = get_conc_at(time, CP_ngmL, 12),
    C24   = get_conc_at(time, CP_ngmL, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C6_med = median(C6, na.rm = TRUE),
    C6_p05 = quantile(C6, 0.05, na.rm = TRUE),
    C6_p95 = quantile(C6, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3
fig3_summary


fig4_raw <- lapply(dose_mg, function(d) {
  
  ev_qd_3d <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_mrg) %>%
    ev(ev_qd_3d) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q24h")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q24h"))
  )

fig4_sum <- fig4_raw %>%
  group_by(dose, time) %>%
  summarise(
    CP_med = median(CP_ngmL, na.rm = TRUE),
    CP_p05 = quantile(CP_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Torsemide concentration (ng/mL)",
    title = "Figure 4. Torsemide once-daily multi-dose, population",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig4_ind <- fig4_raw %>%
  group_by(dose, ID) %>%
  summarise(
    Cmax_final_interval = {
      idx <- time >= last_dose_h & time <= t_end_md
      max(CP_ngmL[idx], na.rm = TRUE)
    },
    Tmax_final_interval = {
      idx <- time >= last_dose_h & time <= t_end_md
      time[idx][which.max(CP_ngmL[idx])] - last_dose_h
    },
    C24_after_last = get_conc_at(time, CP_ngmL, t_end_md),
    C24_day1       = get_conc_at(time, CP_ngmL, 24),
    C48            = get_conc_at(time, CP_ngmL, 48),
    C72            = get_conc_at(time, CP_ngmL, 72),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(dose) %>%
  summarise(
    Cmax_final_interval_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_final_interval_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_final_interval_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_final_interval_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_final_interval_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C24_after_last_med = median(C24_after_last, na.rm = TRUE),
    C24_after_last_p05 = quantile(C24_after_last, 0.05, na.rm = TRUE),
    C24_after_last_p95 = quantile(C24_after_last, 0.95, na.rm = TRUE),
    
    C24_day1_med = median(C24_day1, na.rm = TRUE),
    C24_day1_p05 = quantile(C24_day1, 0.05, na.rm = TRUE),
    C24_day1_p95 = quantile(C24_day1, 0.95, na.rm = TRUE),
    
    C48_med = median(C48, na.rm = TRUE),
    C48_p05 = quantile(C48, 0.05, na.rm = TRUE),
    C48_p95 = quantile(C48, 0.95, na.rm = TRUE),
    
    C72_med = median(C72, na.rm = TRUE),
    C72_p05 = quantile(C72, 0.05, na.rm = TRUE),
    C72_p95 = quantile(C72, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4
fig4_summary
