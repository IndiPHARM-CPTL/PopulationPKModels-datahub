library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

betamethasone_code <- '
$PROB
Betamethasone population pharmacokinetic model

$PARAM @annotated
CL       : 5.95    : L/h    Apparent clearance, CL/FIM
VP       : 67.5    : L      Apparent central volume, Vp/FIM
Q        : 0.173   : L/h    Apparent distributional clearance, CLD/FIM
VT       : 4.94    : L      Apparent peripheral volume, VT/FIM

KA_IM    : 0.971   : 1/h    BET phosphate IM absorption rate
KA_PO    : 1.21    : 1/h    BET phosphate PO absorption rate
KA_AC    : 0.00638 : 1/h    BET acetate IM absorption rate

FR       : 0.935   : --     Relative PO bioavailability, FPO/FIM
FRA      : 0.819   : --     Relative acetate bioavailability, FIMa/FIM

$OMEGA @block @labels ETA_CL ETA_VP
0.0210
0.0155 0.0188

$OMEGA @labels ETA_KA_IM ETA_KA_AC ETA_KA_PO ETA_FR ETA_FRA
0.0441
0.147
0.241
0.0182
0.00773

$SIGMA
0.0211

$CMT
DEPOT_IM DEPOT_PO DEPOT_AC CENT PERIPH

$GLOBAL
double CLi, VPi, KAIMi, KAPOi, KAACi, FRi, FRAi;

$MAIN
CLi   = CL * exp(ETA(1));
VPi   = VP * exp(ETA(2));

KAIMi = KA_IM * exp(ETA(3));
KAACi = KA_AC * exp(ETA(4));
KAPOi = KA_PO * exp(ETA(5));

FRi   = FR * exp(ETA(6));
FRAi  = FRA * exp(ETA(7));

F_DEPOT_IM = 1.0;
F_DEPOT_PO = FRi;
F_DEPOT_AC = FRAi;

$ODE
dxdt_DEPOT_IM = -KAIMi * DEPOT_IM;
dxdt_DEPOT_PO = -KAPOi * DEPOT_PO;
dxdt_DEPOT_AC = -KAACi * DEPOT_AC;

dxdt_CENT = KAIMi * DEPOT_IM
            + KAPOi * DEPOT_PO
            + KAACi * DEPOT_AC
            - (CLi / VPi) * CENT
            - (Q / VPi) * CENT
            + (Q / VT) * PERIPH;

dxdt_PERIPH = (Q / VPi) * CENT
              - (Q / VT) * PERIPH;

$TABLE
double CP_ngmL = (CENT / VPi) * 1000.0;
double DV_ngmL = CP_ngmL * exp(EPS(1));

$CAPTURE CP_ngmL
'

mod_bet <- mcode("betamethasone_popPK", betamethasone_code)


N <- 1000

t_end_sd <- 96
delta_sd <- 0.1

tau_h <- 24
n_doses_md <- 14
addl_md <- n_doses_md - 1

last_dose_h <- 312
final_interval_end_h <- 336

t_end_md <- 360
delta_md <- 0.1

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:N)

mod_typ <- zero_re(mod_bet)

at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}



ev_betp_im_6 <- ev(time = 0, amt = 6, cmt = 1)

ev_betp_po_6 <- ev(time = 0, amt = 6, cmt = 2)

ev_betpa_im_6 <- c(
  ev(time = 0, amt = 3, cmt = 1),
  ev(time = 0, amt = 3, cmt = 3)
)




ev_betp_6_md <- ev(time = 0, amt = 6, cmt = 1, ii = 24, addl = 13)

ev_betp_12_md <- ev(time = 0, amt = 12, cmt = 1, ii = 24, addl = 13)

ev_betpa_6_md <- c(
  ev(time = 0, amt = 3, cmt = 1, ii = 24, addl = 13),
  ev(time = 0, amt = 3, cmt = 3, ii = 24, addl = 13)
)

ev_betpa_12_md <- c(
  ev(time = 0, amt = 6, cmt = 1, ii = 24, addl = 13),
  ev(time = 0, amt = 6, cmt = 3, ii = 24, addl = 13)
)


fig1_betp_im <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_betp_im_6) %>%
  mrgsim(end = t_end_sd, delta = delta_sd) %>%
  as_tibble() %>%
  mutate(group = "BET-P 6 mg IM")

fig1_betp_po <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_betp_po_6) %>%
  mrgsim(end = t_end_sd, delta = delta_sd) %>%
  as_tibble() %>%
  mutate(group = "BET-P 6 mg PO")

fig1_betpa_im <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_betpa_im_6) %>%
  mrgsim(end = t_end_sd, delta = delta_sd) %>%
  as_tibble() %>%
  mutate(group = "BET-PA 6 mg IM")

fig1_out <- bind_rows(
  fig1_betp_im,
  fig1_betp_po,
  fig1_betpa_im
)

p1 <- ggplot(fig1_out, aes(time, CP_ngmL, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time after dose (hours)",
    y = "Betamethasone concentration (ng/mL)",
    color = "Formulation",
    title = "Figure 1. Betamethasone single-dose"
  )

fig1_summary <- fig1_out %>%
  group_by(group) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = time[which.max(CP_ngmL)],
    C6h = at_time(time, CP_ngmL, 6),
    C12h = at_time(time, CP_ngmL, 12),
    C24h = at_time(time, CP_ngmL, 24),
    C48h = at_time(time, CP_ngmL, 48),
    C72h = at_time(time, CP_ngmL, 72),
    C96h = at_time(time, CP_ngmL, 96),
    .groups = "drop"
  )


fig2_betp_6 <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_betp_6_md) %>%
  mrgsim(end = t_end_md, delta = delta_md) %>%
  as_tibble() %>%
  mutate(group = "BET-P 6 mg IM q24h x14")

fig2_betp_12 <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_betp_12_md) %>%
  mrgsim(end = t_end_md, delta = delta_md) %>%
  as_tibble() %>%
  mutate(group = "BET-P 12 mg IM q24h x14")

fig2_betpa_6 <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_betpa_6_md) %>%
  mrgsim(end = t_end_md, delta = delta_md) %>%
  as_tibble() %>%
  mutate(group = "BET-PA 6 mg IM q24h x14")

fig2_betpa_12 <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_betpa_12_md) %>%
  mrgsim(end = t_end_md, delta = delta_md) %>%
  as_tibble() %>%
  mutate(group = "BET-PA 12 mg IM q24h x14")

fig2_out <- bind_rows(
  fig2_betp_6,
  fig2_betp_12,
  fig2_betpa_6,
  fig2_betpa_12
) %>%
  mutate(
    group = factor(
      group,
      levels = c(
        "BET-P 6 mg IM q24h x14",
        "BET-P 12 mg IM q24h x14",
        "BET-PA 6 mg IM q24h x14",
        "BET-PA 12 mg IM q24h x14"
      )
    )
  )

p2 <- ggplot(fig2_out, aes(time, CP_ngmL, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time after first dose (hours)",
    y = "Betamethasone concentration (ng/mL)",
    color = "Regimen",
    title = "Figure 2. Betamethasone q24h x14"
  )

fig2_summary <- fig2_out %>%
  group_by(group) %>%
  summarise(
    Cmax_day1 = max(CP_ngmL[time >= 0 & time < 24]),
    Tmax_day1_h = time[time >= 0 & time < 24][which.max(CP_ngmL[time >= 0 & time < 24])],
    Ctrough_day1 = at_time(time, CP_ngmL, 24),
    
    Cmax_final = max(CP_ngmL[time >= 312 & time < 336]),
    Tmax_final_h = time[time >= 312 & time < 336][which.max(CP_ngmL[time >= 312 & time < 336])] - 312,
    Ctrough_final = at_time(time, CP_ngmL, 336),
    
    C48h = at_time(time, CP_ngmL, 48),
    C96h = at_time(time, CP_ngmL, 96),
    C168h = at_time(time, CP_ngmL, 168),
    C240h = at_time(time, CP_ngmL, 240),
    C312h = at_time(time, CP_ngmL, 312),
    C336h = at_time(time, CP_ngmL, 336),
    C360h = at_time(time, CP_ngmL, 360),
    
    .groups = "drop"
  )


set.seed(123)

fig3_betp_im <- mod_bet %>%
  idata_set(idata_pop) %>%
  ev(ev_betp_im_6) %>%
  mrgsim(end = t_end_sd, delta = delta_sd) %>%
  as_tibble() %>%
  mutate(group = "BET-P 6 mg IM")

set.seed(123)

fig3_betp_po <- mod_bet %>%
  idata_set(idata_pop) %>%
  ev(ev_betp_po_6) %>%
  mrgsim(end = t_end_sd, delta = delta_sd) %>%
  as_tibble() %>%
  mutate(group = "BET-P 6 mg PO")

set.seed(123)

fig3_betpa_im <- mod_bet %>%
  idata_set(idata_pop) %>%
  ev(ev_betpa_im_6) %>%
  mrgsim(end = t_end_sd, delta = delta_sd) %>%
  as_tibble() %>%
  mutate(group = "BET-PA 6 mg IM")

fig3_raw <- bind_rows(
  fig3_betp_im,
  fig3_betp_po,
  fig3_betpa_im
)

fig3_sum <- fig3_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP_ngmL),
    C_p05 = quantile(CP_ngmL, 0.05),
    C_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = group, fill = group)) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.15,
    colour = NA
  ) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time after dose (hours)",
    y = "Betamethasone concentration (ng/mL)",
    color = "Formulation",
    fill = "Formulation",
    title = "Figure 3. Betamethasone single-dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = time[which.max(CP_ngmL)],
    C6h = at_time(time, CP_ngmL, 6),
    C12h = at_time(time, CP_ngmL, 12),
    C24h = at_time(time, CP_ngmL, 24),
    C48h = at_time(time, CP_ngmL, 48),
    C72h = at_time(time, CP_ngmL, 72),
    C96h = at_time(time, CP_ngmL, 96),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med = median(Tmax_h),
    Tmax_p05 = quantile(Tmax_h, 0.05),
    Tmax_p95 = quantile(Tmax_h, 0.95),
    
    C6h_med = median(C6h),
    C6h_p05 = quantile(C6h, 0.05),
    C6h_p95 = quantile(C6h, 0.95),
    
    C12h_med = median(C12h),
    C12h_p05 = quantile(C12h, 0.05),
    C12h_p95 = quantile(C12h, 0.95),
    
    C24h_med = median(C24h),
    C24h_p05 = quantile(C24h, 0.05),
    C24h_p95 = quantile(C24h, 0.95),
    
    C48h_med = median(C48h),
    C48h_p05 = quantile(C48h, 0.05),
    C48h_p95 = quantile(C48h, 0.95),
    
    C72h_med = median(C72h),
    C72h_p05 = quantile(C72h, 0.05),
    C72h_p95 = quantile(C72h, 0.95),
    
    C96h_med = median(C96h),
    C96h_p05 = quantile(C96h, 0.05),
    C96h_p95 = quantile(C96h, 0.95),
    
    .groups = "drop"
  )



set.seed(123)

fig4_betp_6 <- mod_bet %>%
  idata_set(idata_pop) %>%
  ev(ev_betp_6_md) %>%
  mrgsim(end = t_end_md, delta = delta_md) %>%
  as_tibble() %>%
  mutate(group = "BET-P 6 mg IM q24h x14")

set.seed(123)

fig4_betp_12 <- mod_bet %>%
  idata_set(idata_pop) %>%
  ev(ev_betp_12_md) %>%
  mrgsim(end = t_end_md, delta = delta_md) %>%
  as_tibble() %>%
  mutate(group = "BET-P 12 mg IM q24h x14")

set.seed(123)

fig4_betpa_6 <- mod_bet %>%
  idata_set(idata_pop) %>%
  ev(ev_betpa_6_md) %>%
  mrgsim(end = t_end_md, delta = delta_md) %>%
  as_tibble() %>%
  mutate(group = "BET-PA 6 mg IM q24h x14")

set.seed(123)

fig4_betpa_12 <- mod_bet %>%
  idata_set(idata_pop) %>%
  ev(ev_betpa_12_md) %>%
  mrgsim(end = t_end_md, delta = delta_md) %>%
  as_tibble() %>%
  mutate(group = "BET-PA 12 mg IM q24h x14")

fig4_raw <- bind_rows(
  fig4_betp_6,
  fig4_betp_12,
  fig4_betpa_6,
  fig4_betpa_12
) %>%
  mutate(
    group = factor(
      group,
      levels = c(
        "BET-P 6 mg IM q24h x14",
        "BET-P 12 mg IM q24h x14",
        "BET-PA 6 mg IM q24h x14",
        "BET-PA 12 mg IM q24h x14"
      )
    )
  )

fig4_sum <- fig4_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP_ngmL),
    C_p05 = quantile(CP_ngmL, 0.05),
    C_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time, C_med, color = group, fill = group)) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.15,
    colour = NA
  ) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time after first dose (hours)",
    y = "Betamethasone concentration (ng/mL)",
    color = "Regimen",
    fill = "Regimen",
    title = "Figure 4. Betamethasone q24h x14, population"
  )

fig4_ind <- fig4_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax_day1 = max(CP_ngmL[time >= 0 & time < 24]),
    Tmax_day1_h = time[time >= 0 & time < 24][which.max(CP_ngmL[time >= 0 & time < 24])],
    Ctrough_day1 = at_time(time, CP_ngmL, 24),
    
    Cmax_final = max(CP_ngmL[time >= 312 & time < 336]),
    Tmax_final_h = time[time >= 312 & time < 336][which.max(CP_ngmL[time >= 312 & time < 336])] - 312,
    Ctrough_final = at_time(time, CP_ngmL, 336),
    
    C48h = at_time(time, CP_ngmL, 48),
    C96h = at_time(time, CP_ngmL, 96),
    C168h = at_time(time, CP_ngmL, 168),
    C240h = at_time(time, CP_ngmL, 240),
    C312h = at_time(time, CP_ngmL, 312),
    C336h = at_time(time, CP_ngmL, 336),
    C360h = at_time(time, CP_ngmL, 360),
    
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_day1_med = median(Cmax_day1),
    Cmax_day1_p05 = quantile(Cmax_day1, 0.05),
    Cmax_day1_p95 = quantile(Cmax_day1, 0.95),
    
    Tmax_day1_med = median(Tmax_day1_h),
    Tmax_day1_p05 = quantile(Tmax_day1_h, 0.05),
    Tmax_day1_p95 = quantile(Tmax_day1_h, 0.95),
    
    Ctrough_day1_med = median(Ctrough_day1),
    Ctrough_day1_p05 = quantile(Ctrough_day1, 0.05),
    Ctrough_day1_p95 = quantile(Ctrough_day1, 0.95),
    
    Cmax_final_med = median(Cmax_final),
    Cmax_final_p05 = quantile(Cmax_final, 0.05),
    Cmax_final_p95 = quantile(Cmax_final, 0.95),
    
    Tmax_final_med = median(Tmax_final_h),
    Tmax_final_p05 = quantile(Tmax_final_h, 0.05),
    Tmax_final_p95 = quantile(Tmax_final_h, 0.95),
    
    Ctrough_final_med = median(Ctrough_final),
    Ctrough_final_p05 = quantile(Ctrough_final, 0.05),
    Ctrough_final_p95 = quantile(Ctrough_final, 0.95),
    
    C48h_med = median(C48h),
    C48h_p05 = quantile(C48h, 0.05),
    C48h_p95 = quantile(C48h, 0.95),
    
    C96h_med = median(C96h),
    C96h_p05 = quantile(C96h, 0.05),
    C96h_p95 = quantile(C96h, 0.95),
    
    C168h_med = median(C168h),
    C168h_p05 = quantile(C168h, 0.05),
    C168h_p95 = quantile(C168h, 0.95),
    
    C240h_med = median(C240h),
    C240h_p05 = quantile(C240h, 0.05),
    C240h_p95 = quantile(C240h, 0.95),
    
    C312h_med = median(C312h),
    C312h_p05 = quantile(C312h, 0.05),
    C312h_p95 = quantile(C312h, 0.95),
    
    C336h_med = median(C336h),
    C336h_p05 = quantile(C336h, 0.05),
    C336h_p95 = quantile(C336h, 0.95),
    
    C360h_med = median(C360h),
    C360h_p05 = quantile(C360h, 0.05),
    C360h_p95 = quantile(C360h, 0.95),
    
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary