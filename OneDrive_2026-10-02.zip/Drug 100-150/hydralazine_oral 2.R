library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

hydralazine_code <- '
$PROB
Oral hydralazine parent-only empirical PK model
- Ref: Hanson A, Johansson BW, Wernersson B, Wahlander LA.
  Pharmacokinetics of oral hydralazine in chronic heart failure.
  Eur J Clin Pharmacol. 1983;25:467-473.

$PARAM @annotated
KA      : 2.33    : 1/h       First-order absorption rate constant
CL      : 79.17   : L/h       Apparent oral clearance
VAPP    : 227.5   : L         Apparent volume of distribution
MW_HYD  : 160.18  : g/mol     Molecular weight of hydralazine free base
MG_PER_UMOL_HCL : 0.19664 : mg/umol  Hydralazine HCl conversion

$CMT @annotated
GUT  : Oral depot compartment
CENT : Central compartment

$OMEGA @annotated
EKA   : 0.160 : IIV variance on KA
ECL   : 0.250 : IIV variance on CL
EVAPP : 0.120 : IIV variance on VAPP

$MAIN
double KAi = KA * exp(EKA);
double CLi = CL * exp(ECL);
double VAPPi = VAPP * exp(EVAPP);
double KELi = CLi / VAPPi;

$ODE
dxdt_GUT = -KAi * GUT;
dxdt_CENT = KAi * GUT / MG_PER_UMOL_HCL - KELi * CENT;

$TABLE
double C_HYD_nmolmL = CENT / VAPPi;
double C_HYD_ngmL = C_HYD_nmolmL * MW_HYD;

$CAPTURE C_HYD_ngmL
'

mod <- mcode("hydralazine_hanson_1983_parent_only", hydralazine_code)

dose_mg <- c(25, 50, 100)
n_pop <- 1000

tau_h <- 8
n_doses <- 12
addl_md <- n_doses - 1

t_end_sd <- 12
last_dose_h <- (n_doses - 1) * tau_h
final_interval_end_h <- last_dose_h + tau_h
t_end_md <- final_interval_end_h

delta_sd <- 0.1
delta_md <- 0.1

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:n_pop)
mod_typ <- zero_re(mod)

dose_levels_sd <- paste0(dose_mg, " mg")
dose_levels_md <- paste0(dose_mg, " mg q8h x", n_doses)

get_nearest <- function(time, conc, target_time) conc[which.min(abs(time - target_time))]






fig1_raw <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT")) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(ID, time, CP = pmax(C_HYD_ngmL, 0), Dose = paste0(d, " mg"))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_raw, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(x = "Time after oral dose (h)", y = "Hydralazine concentration (ng/mL)", color = "Dose",
       title = "Figure 1. Hydralazine single-dose")

fig1_ind <- fig1_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C8 = get_nearest(time, CP, 8),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_ng_mL = median(Cmax, na.rm = TRUE),
    Tmax_h = median(Tmax, na.rm = TRUE),
    C8_ng_mL = median(C8, na.rm = TRUE),
    .groups = "drop"
  )





fig2_raw <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT", ii = tau_h, addl = addl_md)) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(ID, time, CP = pmax(C_HYD_ngmL, 0), Dose = paste0(d, " mg q8h x", n_doses))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_raw, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(x = "Time (h)", y = "Hydralazine concentration (ng/mL)", color = "Dose",
       title = "Figure 2. Hydralazine q8h multidose for 4 days")

fig2_ind <- fig2_raw %>%
  filter(time >= last_dose_h, time <= final_interval_end_h) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_final_interval = max(CP, na.rm = TRUE),
    Tmax_final_interval = time[which.max(CP)] - last_dose_h,
    Ctrough_final_interval = get_nearest(time, CP, final_interval_end_h),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_ng_mL = median(Cmax_final_interval, na.rm = TRUE),
    Tmax_h = median(Tmax_final_interval, na.rm = TRUE),
    Ctrough_ng_mL = median(Ctrough_final_interval, na.rm = TRUE),
    .groups = "drop"
  )





fig3_raw <- lapply(dose_mg, function(d) {
  set.seed(123)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT")) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(ID, time, CP = pmax(C_HYD_ngmL, 0), Dose = paste0(d, " mg"))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    CP_med = median(CP, na.rm = TRUE),
    CP_p05 = quantile(CP, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(x = "Time after oral dose (h)", y = "Hydralazine concentration (ng/mL)", color = "Dose", fill = "Dose",
       title = "Figure 3. Hydralazine single-dose, population")

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C8 = get_nearest(time, CP, 8),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )






fig4_raw <- lapply(dose_mg, function(d) {
  set.seed(123)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT", ii = tau_h, addl = addl_md)) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(ID, time, CP = pmax(C_HYD_ngmL, 0), Dose = paste0(d, " mg q8h x", n_doses))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    CP_med = median(CP, na.rm = TRUE),
    CP_p05 = quantile(CP, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(x = "Time (h)", y = "Hydralazine concentration (ng/mL)", color = "Dose", fill = "Dose",
       title = "Figure 4. Hydralazine q8h for 4 days, population")


fig4_ind <- fig4_raw %>%
  filter(time >= last_dose_h, time <= final_interval_end_h) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_final_interval = max(CP, na.rm = TRUE),
    Tmax_final_interval = time[which.max(CP)] - last_dose_h,
    Ctrough_final_interval = get_nearest(time, CP, final_interval_end_h),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough_final_interval, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough_final_interval, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough_final_interval, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary