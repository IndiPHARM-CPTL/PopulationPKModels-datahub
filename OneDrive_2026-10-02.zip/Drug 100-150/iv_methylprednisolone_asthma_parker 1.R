library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

methylprednisolone_code <- '
$PROB
Methylprednisolone IV population PK model

- Ref: Parker TJ, Daley-Yates PT, Wood SA. A comparative population pharmacokinetic analysis for methylprednisolone following multiple dosing of two prodrugs in patients with acute asthma. Br J Clin Pharmacol. 1997;43(6):589-592. doi:10.1046/j.1365-2125.1997.00599.x

$PARAM @annotated
CL       : 19.0 : L/h     Population clearance
V        : 76.7 : L       Volume of distribution
KA_SUCC  : 5.5  : 1/h     MP formation rate from succinate
KA_SUL   : 66.0 : 1/h     MP formation rate from suleptanate
F_SUL    : 0.94 : --      Relative bioavailability of suleptanate
FORM     : 0    : --      0 = succinate; 1 = suleptanate

$CMT PRO CENT

$OMEGA @annotated
ECL : 0.1065 : IIV on CL
EV  : 0.2148 : IIV on V
EKA : 0.3247 : IIV on KA

$SIGMA @annotated
ADD : 6670.0 : Additive residual variance

$MAIN
double CLi = CL * exp(ECL);
double Vi  = V  * exp(EV);

double KAi = KA_SUCC;
double Fi  = 1.0;

if(FORM == 1) {
  KAi = KA_SUL;
  Fi  = F_SUL;
}

KAi = KAi * exp(EKA);

F_PRO = Fi;

double KE = CLi / Vi;

$ODE
dxdt_PRO  = -KAi * PRO;
dxdt_CENT =  KAi * PRO - KE * CENT;

$TABLE
double CP = CENT / Vi * 1000.0;
double DV = CP + ADD;

$CAPTURE CP DV CLi Vi KAi KE
'
mod_methylprednisolone <- mcode("methylprednisolone", methylprednisolone_code)

mod_typ <- zero_re(mod_methylprednisolone)
fig1 <- mod_typ %>%
  ev(amt = 40, cmt = 1) %>%
  mrgsim(start = 0, end = 24, delta = 0.01) %>%
  as_tibble()

p1 <- ggplot(fig1, aes(time, CP)) +
  geom_line(linewidth = 0.9) +
  labs(
    x = "Time (h)",
    y = "Methylprednisolone concentration (ng/mL)",
    title = "Figure 1. Single 40 mg IV dose"
  ) +
  theme_bw()
p1


fig2_all <- mod_typ %>%
  ev(amt = 40, cmt = 1, ii = 6, addl = 7) %>%
  mrgsim(start = 0, end = 48, delta = 0.01) %>%
  as_tibble()

fig2 <- fig2_all %>%
  filter(time >= 24) %>%
  mutate(time_plot = time - 24)

p2 <- ggplot(fig2, aes(time_plot, CP)) +
  geom_line(linewidth = 0.9) +
  labs(
    x = "Time in last 24 h (h)",
    y = "Methylprednisolone concentration (ng/mL)",
    title = "Figure 2. 40 mg IV q6h, last 24 h"
  ) +
  theme_bw()

p2

set.seed(1234)

idata <- tibble(ID = 1:1000)

fig3_raw <- mod_methylprednisolone %>%
  idata_set(idata) %>%
  ev(amt = 40, cmt = 1) %>%
  mrgsim(start = 0, end = 12, delta = 0.05) %>%
  as_tibble()

fig3 <- fig3_raw %>%
  group_by(time) %>%
  summarise(
    med = median(CP),
    p05 = quantile(CP, 0.05),
    p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p3 <- ggplot(fig3, aes(time, med)) +
  geom_ribbon(aes(ymin = p05, ymax = p95), alpha = 0.2) +
  geom_line(linewidth = 0.9) +
  labs(
    x = "Time (h)",
    y = "Methylprednisolone concentration (ng/mL)",
    title = "Figure 3. Single 40 mg IV dose, N=1000"
  ) +
  theme_bw()

p3

set.seed(1234)
fig4_raw <- mod_methylprednisolone %>%
  idata_set(idata) %>%
  ev(amt = 40, cmt = 1, ii = 6, addl = 7) %>%
  mrgsim(start = 0, end = 48, delta = 0.05) %>%
  as_tibble()

fig4 <- fig4_raw %>%
  filter(time >= 24) %>%
  mutate(time_plot = time - 24) %>%
  group_by(time_plot) %>%
  summarise(
    med = median(CP),
    p05 = quantile(CP, 0.05),
    p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p4 <- ggplot(fig4, aes(time_plot, med)) +
  geom_ribbon(aes(ymin = p05, ymax = p95), alpha = 0.2) +
  geom_line(linewidth = 0.9) +
  labs(
    x = "Time in last 24 h (h)",
    y = "Methylprednisolone concentration (ng/mL)",
    title = "Figure 4. 40 mg IV q6h, N=1000, last 24 h"
  ) +
  theme_bw()

p4


