library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

torsemide_code <- '
$PROB
Torsemide oral PopPK model

- Ref: Jeong SH, Jang JH, Cho HY, Lee YB.
  Population Pharmacokinetic (Pop-PK) Analysis of Torsemide in Healthy
  Korean Males Considering CYP2C9 and OATP1B1 Genetic Polymorphisms.
  Pharmaceutics. 2022;14(4):771.
  doi:10.3390/pharmaceutics14040771

$PARAM @annotated
KA       : 0.861 : 1/h   First-order absorption rate constant
V1       : 1.027 : L     Apparent central volume
V2       : 3.914 : L     Apparent peripheral volume
CL       : 1.740 : L/h   Apparent clearance
Q        : 0.828 : L/h   Apparent intercompartmental clearance
TLAG     : 0.274 : h     Absorption lag time

DV_IT    : -0.410 : --   OATP1B1 intermediate-transporter effect on V1/F
DV_PT    : -0.646 : --   OATP1B1 poor-transporter effect on V1/F
DCL_EM   :  0.510 : --   CYP2C9 extensive-metabolizer effect on CL/F
DQ_EM    :  0.365 : --   CYP2C9 extensive-metabolizer effect on Q/F

CYP_EM   : 1 : --        CYP2C9 phenotype: 1 = EM, 0 = IM
OATP_IT  : 0 : --        OATP1B1 intermediate-transporter flag
OATP_PT  : 0 : --        OATP1B1 poor-transporter flag
COV_ON   : 1 : --        Apply phenotype covariate effects

$CMT @annotated
GUT    : Oral depot compartment
CENT   : Central compartment
PERIPH : Peripheral compartment

$OMEGA @annotated
EV1   : 0.562 : IIV on V1/F
ECL   : 0.029 : IIV on CL/F
EV2   : 0.036 : IIV on V2/F
EQ    : 0.022 : IIV on Q/F
ETLAG : 0.341 : IIV on TLAG

$MAIN
double v1_eff = 1.0;
double cl_eff = 1.0;
double q_eff = 1.0;

if(COV_ON == 1) {
  v1_eff = 1.0 + DV_IT * OATP_IT + DV_PT * OATP_PT;
  cl_eff = 1.0 + DCL_EM * CYP_EM;
  q_eff = 1.0 + DQ_EM * CYP_EM;
}

double V1i = V1 * v1_eff * exp(EV1);
double V2i = V2 * exp(EV2);
double CLi = CL * cl_eff * exp(ECL);
double Qi = Q * q_eff * exp(EQ);
double TLAGi = TLAG * exp(ETLAG);

ALAG_GUT = TLAGi;

$ODE
dxdt_GUT = -KA * GUT;

dxdt_CENT = KA * GUT
            - (CLi / V1i) * CENT
            - (Qi / V1i) * CENT
            + (Qi / V2i) * PERIPH;

dxdt_PERIPH = (Qi / V1i) * CENT
              - (Qi / V2i) * PERIPH;

$TABLE
double CP_ngmL = CENT / V1i * 1000.0;

$CAPTURE CP_ngmL
'

mod <- mcode("torsemide_jeong2022", torsemide_code)



set.seed(123)

dose_mg <- c(5, 10, 20)

N <- 1000
tau_h <- 24
n_doses <- 10
addl_md <- n_doses - 1

t_end_sd <- tau_h
t_end_md <- n_doses * tau_h

delta_sd <- 0.01
delta_md <- 0.01

last_dose_h <- (n_doses - 1) * tau_h

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses)



phenotype_tbl <- tibble(
  phenotype = c("ET_EM", "ET_IM", "IT_EM", "IT_IM", "PT_EM", "PT_IM"),
  probability = c(0.7143, 0.0536, 0.1518, 0.0536, 0, 0.0268)
)

idata_pop <- tibble(
  ID = 1:N,
  phenotype = sample(
    phenotype_tbl$phenotype,
    size = N,
    replace = TRUE,
    prob = phenotype_tbl$probability
  )
) %>%
  mutate(
    CYP_EM = as.numeric(grepl("_EM$", phenotype)),
    OATP_IT = as.numeric(grepl("^IT_", phenotype)),
    OATP_PT = as.numeric(grepl("^PT_", phenotype)),
    COV_ON = 1
  ) %>%
  select(ID, CYP_EM, OATP_IT, OATP_PT, COV_ON)

idata_typ <- tibble(
  ID = 1,
  CYP_EM = 1,
  OATP_IT = 0,
  OATP_PT = 0,
  COV_ON = 0
)

mod_typ <- zero_re(mod)



get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

simulate_profiles <- function(
    model,
    idata,
    doses,
    end_time,
    delta,
    ii = 0,
    addl = 0,
    population = FALSE) {
  
  output <- lapply(doses, function(d) {
    
    if(population) {
      set.seed(123)
    }
    
    dose_event <- if(ii > 0) {
      ev(time = 0, amt = d, cmt = "GUT", ii = ii, addl = addl)
    } else {
      ev(time = 0, amt = d, cmt = "GUT")
    }
    
    dose_label <- if(ii > 0) {
      paste0(d, " mg q", ii, "h x", addl + 1)
    } else {
      paste0(d, " mg single dose")
    }
    
    model %>%
      idata_set(idata) %>%
      ev(dose_event) %>%
      mrgsim(end = end_time, delta = delta, obsonly = TRUE) %>%
      as_tibble() %>%
      transmute(
        ID,
        time,
        CP = pmax(CP_ngmL, 0),
        Dose = dose_label
      )
  })
  
  bind_rows(output)
}

summarise_population_pk <- function(data) {
  data %>%
    group_by(Dose) %>%
    summarise(
      across(
        c(Cmax, Tmax, C1, C2, C4, C8, C12, Ctrough),
        list(
          med = ~median(.x, na.rm = TRUE),
          p05 = ~quantile(.x, 0.05, na.rm = TRUE),
          p95 = ~quantile(.x, 0.95, na.rm = TRUE)
        ),
        .names = "{.col}_{.fn}"
      ),
      .groups = "drop"
    )
}




fig1_out <- simulate_profiles(
  model = mod_typ,
  idata = idata_typ,
  doses = dose_mg,
  end_time = t_end_sd,
  delta = delta_sd
) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time after dose (h)",
    y = "Torsemide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Torsemide once daily single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C1 = get_nearest(time, CP, 1),
    C2 = get_nearest(time, CP, 2),
    C4 = get_nearest(time, CP, 4),
    C8 = get_nearest(time, CP, 8),
    C12 = get_nearest(time, CP, 12),
    Ctrough = get_nearest(time, CP, tau_h),
    .groups = "drop"
  )




fig2_out <- simulate_profiles(
  model = mod_typ,
  idata = idata_typ,
  doses = dose_mg,
  end_time = t_end_md,
  delta = delta_md,
  ii = tau_h,
  addl = addl_md
) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Torsemide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Torsemide once daily multidose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= last_dose_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)] - last_dose_h,
    C1 = get_nearest(time, CP, last_dose_h + 1),
    C2 = get_nearest(time, CP, last_dose_h + 2),
    C4 = get_nearest(time, CP, last_dose_h + 4),
    C8 = get_nearest(time, CP, last_dose_h + 8),
    C12 = get_nearest(time, CP, last_dose_h + 12),
    Ctrough = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )



fig3_raw <- simulate_profiles(
  model = mod,
  idata = idata_pop,
  doses = dose_mg,
  end_time = t_end_sd,
  delta = delta_sd,
  population = TRUE
) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.15,
    colour = NA
  ) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time after dose (h)",
    y = "Torsemide concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Torsemide once daily single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C1 = get_nearest(time, CP, 1),
    C2 = get_nearest(time, CP, 2),
    C4 = get_nearest(time, CP, 4),
    C8 = get_nearest(time, CP, 8),
    C12 = get_nearest(time, CP, 12),
    Ctrough = get_nearest(time, CP, tau_h),
    .groups = "drop"
  )

fig3_summary <- summarise_population_pk(fig3_ind)





fig4_raw <- simulate_profiles(
  model = mod,
  idata = idata_pop,
  doses = dose_mg,
  end_time = t_end_md,
  delta = delta_md,
  ii = tau_h,
  addl = addl_md,
  population = TRUE
) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.15,
    colour = NA
  ) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Torsemide concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Torsemide once daily multidose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= last_dose_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)] - last_dose_h,
    C1 = get_nearest(time, CP, last_dose_h + 1),
    C2 = get_nearest(time, CP, last_dose_h + 2),
    C4 = get_nearest(time, CP, last_dose_h + 4),
    C8 = get_nearest(time, CP, last_dose_h + 8),
    C12 = get_nearest(time, CP, last_dose_h + 12),
    Ctrough = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- summarise_population_pk(fig4_ind)



p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary