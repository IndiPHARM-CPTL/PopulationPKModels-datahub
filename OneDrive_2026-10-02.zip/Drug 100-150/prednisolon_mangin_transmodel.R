library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

prednisolone_mangin_code <- '
$PROB
Prednisolone oral population PK model after prednisone administration

- Ref: Mangin O, Zheng Y, Bouazza N, et al. Free prednisolone
  pharmacokinetics predicted from total concentrations in patients with
  inflammatory-immunologic conditions. Fundam Clin Pharmacol.
  2020;34(2):270-278. doi:10.1111/fcp.12515

$PARAM @annotated
KTR      : 6.41    : 1/h       Transit and absorption/formation rate constant
CL_U     : 26.7    : L/h       Apparent unbound clearance at 50 kg LBW
V_U      : 94.3    : L         Apparent unbound volume at 50 kg LBW
LBW      : 50      : kg        Lean body weight calculated with Boer equation
BMAX     : 6.77    : --        CBG saturable-binding coefficient; fixed
K1       : 9.5     : L/umol    CBG affinity/saturation constant; fixed
KNS      : 0.8     : --        Nonsaturable albumin-binding coefficient; fixed
IOV_KTR  : 0       : --        Occasion ETA on KTR; SD = 0.990
IOV_VU   : 0       : --        Occasion ETA on V_U; SD = 0.213
MW_PSL   : 360.44  : mg/mmol   Molecular weight of prednisolone

$CMT 
TRANS1 TRANS2 TRANS3 DEPOT CENT

$OMEGA @annotated
ECL_U  : 0.039601 : IIV variance on CL_U; omega SD = 0.199
EBMAX  : 0.083521 : IIV variance on BMAX; omega SD = 0.289

$SIGMA @annotated
ADD    : 18.66 : Additive residual variance
PROP   : 0.038 : Proportional residual variance

$MAIN
double CLUi = CL_U * pow(LBW / 50.0, 0.75) * exp(ECL_U);
double VUi = V_U * pow(LBW / 50.0, 1.00) * exp(IOV_VU);
double KTRi = KTR * exp(IOV_KTR);
double BMAXi = BMAX * exp(EBMAX);
double KEL = CLUi / VUi;

$ODE
dxdt_TRANS1 = -KTRi * TRANS1;
dxdt_TRANS2 =  KTRi * TRANS1 - KTRi * TRANS2;
dxdt_TRANS3 =  KTRi * TRANS2 - KTRi * TRANS3;
dxdt_DEPOT  =  KTRi * TRANS3 - KTRi * DEPOT;
dxdt_CENT   =  KTRi * DEPOT  - KEL * CENT;

$TABLE
double CU_MG_L = CENT / VUi;
double CU_UMOL_L = CU_MG_L * 1000.0 / MW_PSL;
double CTOT_UMOL_L = CU_UMOL_L *
  (1.0 + BMAXi / (1.0 + K1 * CU_UMOL_L) + KNS);

double CU = CU_MG_L * 1000.0;
double CP = CTOT_UMOL_L * MW_PSL;
double DV = CP + ADD + CP * PROP;

$CAPTURE CP CU DV CU_UMOL_L CTOT_UMOL_L CLUi VUi KTRi BMAXi KEL
'

mod_prednisolone_mangin <- mcode("prednisolone_mangin_2020", prednisolone_mangin_code)
boer_lbw <- function(SEX, WT, HT) {
  ifelse(
    SEX == 1,
    0.407 * WT + 0.267 * HT - 19.2,
    0.252 * WT + 0.473 * HT - 48.3
  )
}

dose_mg <- 10
lbw_kg <- 50
sd_iov_ktr <- 0.990
sd_iov_vu <- 0.213

mod_typ <- mod_prednisolone_mangin %>%
  zero_re() %>%
  param(LBW = lbw_kg, IOV_KTR = 0, IOV_VU = 0)

fig1 <- mod_typ %>%
  ev(amt = dose_mg, cmt = 1) %>%
  mrgsim(start = 0, end = 24, delta = 0.01) %>%
  as_tibble()

p1 <- ggplot(fig1, aes(time, CP)) +
  geom_line(linewidth = 0.9) +
  labs(
    x = "Time (h)",
    y = "Total prednisolone concentration (ng/mL)",
    title = paste0("Figure 1. Single ", dose_mg, " mg oral prednisone dose")
  ) +
  theme_bw()

p1

# Figure 2: typical subject, Day 7
fig2_all <- mod_typ %>%
  ev(amt = dose_mg, cmt = 1, ii = 24, addl = 6) %>%
  mrgsim(start = 0, end = 168, delta = 0.01) %>%
  as_tibble()

fig2 <- fig2_all %>%
  filter(time >= 144) %>%
  mutate(time_plot = time - 144)

p2 <- ggplot(fig2, aes(time_plot, CP)) +
  geom_line(linewidth = 0.9) +
  labs(
    x = "Time after Day 7 dose (h)",
    y = "Total prednisolone concentration (ng/mL)",
    title = paste0("Figure 2. ", dose_mg, " mg oral prednisone QD, Day 7")
  ) +
  theme_bw()

p2

set.seed(1234)
idata_single <- tibble(
  ID = 1:1000,
  LBW = lbw_kg,
  IOV_KTR = rnorm(1000, 0, sd_iov_ktr),
  IOV_VU = rnorm(1000, 0, sd_iov_vu)
)

fig3_raw <- mod_prednisolone_mangin %>%
  idata_set(idata_single) %>%
  ev(amt = dose_mg, cmt = 1) %>%
  mrgsim(start = 0, end = 24, delta = 0.05) %>%
  as_tibble()

fig3 <- fig3_raw %>%
  group_by(time) %>%
  summarise(
    med = median(CP),
    p05 = quantile(CP, 0.05),
    p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p3 <- ggplot(fig3, aes(time, med)) +
  geom_ribbon(aes(ymin = p05, ymax = p95), alpha = 0.2) +
  geom_line(linewidth = 0.9) +
  labs(
    x = "Time (h)",
    y = "Total prednisolone concentration (ng/mL)",
    title = paste0(
      "Figure 3. Single ", dose_mg,
      " mg oral prednisone dose, N=1000"
    )
  ) +
  theme_bw()

p3



set.seed(1234)

idata_multi <- tibble(
  ID = 1:1000,
  LBW = lbw_kg
)

fig4_doses <- tibble(
  ID = rep(1:1000, each = 7),
  time = rep(seq(0, 144, by = 24), times = 1000),
  amt = dose_mg,
  cmt = 1,
  evid = 1,
  IOV_KTR = rnorm(7000, 0, sd_iov_ktr),
  IOV_VU = rnorm(7000, 0, sd_iov_vu)
)

fig4_raw <- mod_prednisolone_mangin %>%
  idata_set(idata_multi) %>%
  data_set(fig4_doses) %>%
  mrgsim(
    tgrid = seq(144, 168, by = 0.05),
    obsaug = TRUE,
    obsonly = TRUE,
    recsort = 3,
    nocb = FALSE
  ) %>%
  as_tibble()

fig4 <- fig4_raw %>%
  mutate(time_plot = time - 144) %>%
  group_by(time_plot) %>%
  summarise(
    med = median(CP),
    p05 = quantile(CP, 0.05),
    p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p4 <- ggplot(fig4, aes(time_plot, med)) +
  geom_ribbon(aes(ymin = p05, ymax = p95), alpha = 0.2) +
  geom_line(linewidth = 0.9) +
  labs(
    x = "Time after Day 7 dose (h)",
    y = "Total prednisolone concentration (ng/mL)",
    title = paste0(
      "Figure 4. ", dose_mg,
      " mg oral prednisone QD, Day 7, N=1000"
    )
  ) +
  theme_bw()

p4

auc_trap <- function(time, conc) {
  sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2)
}

fig1_summary <- fig1 %>%
  summarise(
    Dose = paste0(dose_mg, " mg single dose"),
    Cmax_ng_mL = max(CP),
    Tmax_h = time[which.max(CP)],
    C24_ng_mL = CP[which.max(time)],
    AUC0_24_ng_h_mL = auc_trap(time, CP)
  )

fig2_summary <- fig2 %>%
  summarise(
    Dose = paste0(dose_mg, " mg QD, Day 7"),
    Cmax_day7_ng_mL = max(CP),
    Tmax_day7_h = time_plot[which.max(CP)],
    Ctrough_day7_ng_mL = CP[which.max(time_plot)],
    AUCtau_day7_ng_h_mL = auc_trap(time_plot, CP)
  )

fig3_individual <- fig3_raw %>%
  group_by(ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax = time[which.max(CP)],
    C24 = CP[which.max(time)],
    AUC0_24 = auc_trap(time, CP),
    .groups = "drop"
  )

fig3_summary <- fig3_individual %>%
  summarise(
    Dose = paste0(dose_mg, " mg single dose"),
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    Tmax_med = median(Tmax),
    Tmax_p05 = quantile(Tmax, 0.05),
    Tmax_p95 = quantile(Tmax, 0.95),
    C24_med = median(C24),
    C24_p05 = quantile(C24, 0.05),
    C24_p95 = quantile(C24, 0.95),
    AUC0_24_med = median(AUC0_24),
    AUC0_24_p05 = quantile(AUC0_24, 0.05),
    AUC0_24_p95 = quantile(AUC0_24, 0.95)
  )

fig4_individual <- fig4_raw %>%
  mutate(time_plot = time - 144) %>%
  group_by(ID) %>%
  summarise(
    Cmax_day7 = max(CP),
    Tmax_day7 = time_plot[which.max(CP)],
    Ctrough_day7 = CP[which.max(time_plot)],
    AUCtau_day7 = auc_trap(time_plot, CP),
    .groups = "drop"
  )

fig4_summary <- fig4_individual %>%
  summarise(
    Dose = paste0(dose_mg, " mg QD, Day 7"),
    Cmax_day7_med = median(Cmax_day7),
    Cmax_day7_p05 = quantile(Cmax_day7, 0.05),
    Cmax_day7_p95 = quantile(Cmax_day7, 0.95),
    Tmax_day7_med = median(Tmax_day7),
    Tmax_day7_p05 = quantile(Tmax_day7, 0.05),
    Tmax_day7_p95 = quantile(Tmax_day7, 0.95),
    Ctrough_day7_med = median(Ctrough_day7),
    Ctrough_day7_p05 = quantile(Ctrough_day7, 0.05),
    Ctrough_day7_p95 = quantile(Ctrough_day7, 0.95),
    AUCtau_day7_med = median(AUCtau_day7),
    AUCtau_day7_p05 = quantile(AUCtau_day7, 0.05),
    AUCtau_day7_p95 = quantile(AUCtau_day7, 0.95)
  )

fig1_summary
fig2_summary
fig3_summary
fig4_summary