library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

bempedoic_code <- '
$PROB
Bempedoic acid oral PopPK model
- Ref: Jadhav SB, Amore BM, Bockbrader H, Crass RL, Chapel S, Sasiela WJ, Emery MG.
  Population pharmacokinetic and pharmacokinetic-pharmacodynamic modeling of bempedoic acid
  and low-density lipoprotein cholesterol in healthy subjects and patients with dyslipidemia.
  J Pharmacokinet Pharmacodyn. 2023;50:351-364.

$PARAM @annotated
CL      : 0.755 : L/h     Apparent systemic clearance, CL/F
VC      : 19.1  : L       Apparent central volume, Vc/F
KA      : 1.41  : 1/h     Absorption / transit rate constant
K23     : 0.184 : 1/h     Distribution rate constant, central to peripheral
K32     : 0.156 : 1/h     Distribution rate constant, peripheral to central

FED     : 0     : --      Food ; 0 = fasted, 1 = fed
FEMALE  : 0     : --      Sex ; 0 = male, 1 = female
BLACK   : 0     : --      Race ; 0 = non-Black/reference, 1 = Black
HYPERLIP: 1     : --      Hyperlipidemia 
T2DM    : 0     : --      Type 2 diabetes 
EZET    : 0     : --      Concomitant ezetimibe 
ATORVA  : 0     : --      Concomitant atorvastatin 
SIMVA   : 0     : --      Concomitant simvastatin 

WT      : 85.1  : kg      Body weight
AGE     : 60.5  : year    Age
EGFR    : 91.4  : mL/min  Estimated glomerular filtration rate

REF_WT  : 85.1  : kg       body weight
REF_AGE : 60.5  : year     age
REF_EGFR: 91.4  : mL/min   eGFR

COV_ON  : 1     : --      0 = no covariates; 1 = apply covariates

$CMT 
TRANSIT ABS CENT PERIPH

$OMEGA @annotated
ECL  : 0.0845 : IIV variance on CL/F; 29.7%
EVC  : 0.6931 : IIV variance on Vc/F; 100%
EKA  : 0.4364 : IIV variance on KA;   73.9%

$MAIN
double food_eff = 1.0;
double cl_eff   = 1.0;
double vc_eff   = 1.0;
double f1_eff   = 1.0;

if(COV_ON ==  1) {
  food_eff = 1.0 - 0.777 * FED;
  
  cl_eff =
    (1.0 - 0.127  * FEMALE) *
    (1.0 - 0.143  * BLACK) *
    (1.0 - 0.0945 * HYPERLIP) *
    (1.0 - 0.177  * T2DM) *
    (1.0 - 0.0934 * EZET) *
    pow(WT   / REF_WT,   0.61) *
    pow(EGFR / REF_EGFR, 0.574);
  
  vc_eff =
    (1.0 - 0.0895 * FEMALE) *
    (1.0 - 0.154  * SIMVA) *
    pow(WT  / REF_WT,  0.94) *
    pow(AGE / REF_AGE, 0.743);
  
  f1_eff = 1.0 + 0.142 * ATORVA;
}

if(food_eff < 0.05) food_eff = 0.05;
if(cl_eff   < 0.05) cl_eff   = 0.05;
if(vc_eff   < 0.05) vc_eff   = 0.05;
if(f1_eff   < 0.05) f1_eff   = 0.05;

double CLi = CL * cl_eff * exp(ECL);
double VCi = VC * vc_eff * exp(EVC);
double KAi = KA * food_eff * exp(EKA);

double K10i = CLi / VCi;
double K23i = K23;
double K32i = K32;

F_TRANSIT = f1_eff;

$ODE
dxdt_TRANSIT = -KAi * TRANSIT;

dxdt_ABS     =  KAi * TRANSIT
               -KAi * ABS;

dxdt_CENT    =  KAi  * ABS
               -K10i * CENT
               -K23i * CENT
               +K32i * PERIPH;

dxdt_PERIPH  =  K23i * CENT
               -K32i * PERIPH;

$TABLE
double CP_mgL  = CENT / VCi;
double CP_ugmL = CP_mgL;
double CP_ngmL = CP_ugmL * 1000.0;

double VPi = (K23i * VCi) / K32i;

$CAPTURE CP_mgL CP_ugmL CP_ngmL
'

mod <- mcode("bempedoic_jadhav_2023", bempedoic_code)


dose_mg <- c(60, 120, 180, 240)

n_pop <- 1000
set.seed(123)

tau_h    <- 24
n_doses  <- 10
addl_md  <- n_doses - 1

t_end_sd <- 240
t_end_md <- 240

delta_sd <- 0.2
delta_md <- 0.2

last_dose_h <- (n_doses - 1) * tau_h
final_interval_end_h <- last_dose_h + tau_h

idata_typ <- tibble(
  ID = 1,
  FED = 0,
  FEMALE = 0,
  BLACK = 0,
  HYPERLIP = 1,
  T2DM = 0,
  EZET = 0,
  ATORVA = 0,
  SIMVA = 0,
  WT = 85.1,
  AGE = 60.5,
  EGFR = 91.4,
  REF_WT = 85.1,
  REF_AGE = 60.5,
  REF_EGFR = 91.4,
  COV_ON = 0
)

idata_pop <- tibble(
  ID = 1:n_pop,
  FED = 0,
  FEMALE = rbinom(n_pop, 1, 0.406),
  BLACK = rbinom(n_pop, 1, 0.092),
  HYPERLIP = rbinom(n_pop, 1, 0.896),
  T2DM = rbinom(n_pop, 1, 0.161),
  EZET = 0,
  ATORVA = 0,
  SIMVA = 0,
  WT = pmin(pmax(rnorm(n_pop, mean = 85.1, sd = 17.3), 42.5), 160),
  AGE = pmin(pmax(rnorm(n_pop, mean = 60.5, sd = 12.3), 18), 90),
  EGFR = pmin(pmax(rnorm(n_pop, mean = 91.4, sd = 24.5), 30), 180),
  REF_WT = 85.1,
  REF_AGE = 60.5,
  REF_EGFR = 91.4,
  COV_ON = 1
)

mod_typ <- zero_re(mod)



get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  
  df$conc[which.min(abs(df$time - t))]
}


make_long_primary <- function(x) {
  x %>%
    pivot_longer(
      cols = c(CP_ugmL),
      names_to = "analyte",
      values_to = "conc_ugmL"
    ) %>%
    mutate(
      analyte = recode(
        analyte,
        CP_ugmL = "Bempedoic acid"
      )
    )
}


fig1_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig1 <- make_long_primary(fig1_raw)

p1 <- ggplot(fig1, aes(x = time, y = conc_ugmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after dose (h)",
    y = "Plasma concentration (ug/mL)",
    title = "Figure 1. Bempedoic acid single-dose typical simulation",
    color = "Dose"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_ugmL, na.rm = TRUE),
    Tmax = time[which.max(conc_ugmL)],
    C2   = get_conc_at(time, conc_ugmL, 2),
    C4   = get_conc_at(time, conc_ugmL, 4),
    C8   = get_conc_at(time, conc_ugmL, 8),
    C12  = get_conc_at(time, conc_ugmL, 12),
    C24  = get_conc_at(time, conc_ugmL, 24),
    C48  = get_conc_at(time, conc_ugmL, 48),
    C72  = get_conc_at(time, conc_ugmL, 72),
    C120 = get_conc_at(time, conc_ugmL, 120),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_ug_mL = median(Cmax, na.rm = TRUE),
    Tmax_h     = median(Tmax, na.rm = TRUE),
    C2_ug_mL   = median(C2, na.rm = TRUE),
    C4_ug_mL   = median(C4, na.rm = TRUE),
    C8_ug_mL   = median(C8, na.rm = TRUE),
    C12_ug_mL  = median(C12, na.rm = TRUE),
    C24_ug_mL  = median(C24, na.rm = TRUE),
    C48_ug_mL  = median(C48, na.rm = TRUE),
    C72_ug_mL  = median(C72, na.rm = TRUE),
    C120_ug_mL = median(C120, na.rm = TRUE),
    .groups = "drop"
  )

p1
fig1_summary



fig2_raw <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q24h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q24h x", n_doses))
  )

fig2 <- make_long_primary(fig2_raw)

p2 <- ggplot(fig2, aes(x = time, y = conc_ugmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Plasma concentration (ug/mL)",
    title = "Figure 2. Bempedoic acid q24h multiple-dose typical simulation",
    color = "Dose"
  ) +
  theme_bw()

fig2_ind <- fig2 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_ugmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ugmL, -Inf))
    ] - last_dose_h,
    C24_after_last = get_conc_at(time, conc_ugmL, final_interval_end_h),
    C24_day1       = get_conc_at(time, conc_ugmL, 24),
    C48            = get_conc_at(time, conc_ugmL, 48),
    C96            = get_conc_at(time, conc_ugmL, 96),
    C168           = get_conc_at(time, conc_ugmL, 168),
    C216           = get_conc_at(time, conc_ugmL, 216),
    C240           = get_conc_at(time, conc_ugmL, 240),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_ug_mL = median(Cmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_h     = median(Tmax_final_interval, na.rm = TRUE),
    C24_after_last_ug_mL      = median(C24_after_last, na.rm = TRUE),
    C24_day1_ug_mL            = median(C24_day1, na.rm = TRUE),
    C48_ug_mL                 = median(C48, na.rm = TRUE),
    C96_ug_mL                 = median(C96, na.rm = TRUE),
    C168_ug_mL                = median(C168, na.rm = TRUE),
    C216_ug_mL                = median(C216, na.rm = TRUE),
    C240_ug_mL                = median(C240, na.rm = TRUE),
    .groups = "drop"
  )

p2
fig2_summary



fig3_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig3 <- make_long_primary(fig3_raw)

fig3_sum <- fig3 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_ugmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ugmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ugmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after dose (h)",
    y = "Plasma concentration (ug/mL)",
    title = "Figure 3. Bempedoic acid single-dose population simulation",
    subtitle = "Line = median; ribbon = 5th-95th percentile",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig3_ind <- fig3 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_ugmL, na.rm = TRUE),
    Tmax = time[which.max(conc_ugmL)],
    C2   = get_conc_at(time, conc_ugmL, 2),
    C4   = get_conc_at(time, conc_ugmL, 4),
    C8   = get_conc_at(time, conc_ugmL, 8),
    C12  = get_conc_at(time, conc_ugmL, 12),
    C24  = get_conc_at(time, conc_ugmL, 24),
    C48  = get_conc_at(time, conc_ugmL, 48),
    C72  = get_conc_at(time, conc_ugmL, 72),
    C120 = get_conc_at(time, conc_ugmL, 120),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C4_med = median(C4, na.rm = TRUE),
    C4_p05 = quantile(C4, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    C72_med = median(C72, na.rm = TRUE),
    C72_p05 = quantile(C72, 0.05, na.rm = TRUE),
    C72_p95 = quantile(C72, 0.95, na.rm = TRUE),

    .groups = "drop"
  )

p3
fig3_summary




fig4_raw <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q24h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q24h x", n_doses))
  )

fig4 <- make_long_primary(fig4_raw)

fig4_sum <- fig4 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_ugmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ugmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ugmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Plasma concentration (ug/mL)",
    title = "Figure 4. Bempedoic acid q24h multiple-dose population simulation",
    subtitle = "Line = median; ribbon = 5th-95th percentile",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig4_ind <- fig4 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_ugmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ugmL, -Inf))
    ] - last_dose_h,
    C24_after_last = get_conc_at(time, conc_ugmL, final_interval_end_h),
    C24_day1       = get_conc_at(time, conc_ugmL, 24),
    C48            = get_conc_at(time, conc_ugmL, 48),
    C96            = get_conc_at(time, conc_ugmL, 96),
    C168           = get_conc_at(time, conc_ugmL, 168),
    C216           = get_conc_at(time, conc_ugmL, 216),
    C240           = get_conc_at(time, conc_ugmL, 240),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_final_interval_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_final_interval_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_final_interval_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_final_interval_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C24_after_last_med = median(C24_after_last, na.rm = TRUE),
    C24_after_last_p05 = quantile(C24_after_last, 0.05, na.rm = TRUE),
    C24_after_last_p95 = quantile(C24_after_last, 0.95, na.rm = TRUE),
    
    C24_day1_med = median(C24_day1, na.rm = TRUE),
    C24_day1_p05 = quantile(C24_day1, 0.05, na.rm = TRUE),
    C24_day1_p95 = quantile(C24_day1, 0.95, na.rm = TRUE),
    
    C168_med = median(C168, na.rm = TRUE),
    C168_p05 = quantile(C168, 0.05, na.rm = TRUE),
    C168_p95 = quantile(C168, 0.95, na.rm = TRUE),
    
    C216_med = median(C216, na.rm = TRUE),
    C216_p05 = quantile(C216, 0.05, na.rm = TRUE),
    C216_p95 = quantile(C216, 0.95, na.rm = TRUE),
    
    C240_med = median(C240, na.rm = TRUE),
    C240_p05 = quantile(C240, 0.05, na.rm = TRUE),
    C240_p95 = quantile(C240, 0.95, na.rm = TRUE),
     .groups = "drop"
  )

p4
fig4_summary