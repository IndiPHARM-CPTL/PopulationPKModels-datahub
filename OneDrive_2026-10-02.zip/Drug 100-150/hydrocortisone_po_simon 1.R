library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

hydrocortisone_oral_code <- '
$PROB
Adult oral hydrocortisone population PK model

- Ref: Simon N, Castinetti F, Ouliac F, Lesavre N,
  Brue T, Oliver C. Pharmacokinetic evidence for
  suboptimal treatment of adrenal insufficiency with
  currently available hydrocortisone tablets.
  Clin Pharmacokinet. 2010;49(7):455-463.
- calculation -> peak of 10 mg dose is around 230 ng/ml --> 634 nmol/L (matched around 600 nmol/L), cortisol molar mass is 362.4 g/mol

$PARAM @annotated
D1       : 0.54   : h      Duration of zero-order oral absorption
CL       : 12.1   : L/h    Apparent oral clearance
V        : 38.7   : L      Apparent volume of distribution
F1       : 1.00   : --     Relative oral bioavailability


$OMEGA @labels ETA_CL ETA_V
0.1296
0.1296


$SIGMA
0.1043

$CMT
CENT

$GLOBAL
double CLi, Vi;

$MAIN
CLi = CL * exp(ETA(1));
Vi  = V  * exp(ETA(2));

F_CENT = F1;
D_CENT = D1;

$ODE
dxdt_CENT = -(CLi / Vi) * CENT;

$TABLE
double CP = (CENT / Vi) * 1000.0;   // ng/mL
double CORT_NMOL = CP * 2.759;      // nmol/L
double DV = CP * (1.0 + EPS(1));

$CAPTURE CP CORT_NMOL
'

mod_hc_oral <- mcode("hydrocortisone_oral_popPK", hydrocortisone_oral_code)

single_dose_mg <- 10
dose_times_h <- c(0, 4.5, 9)
dose_amts_mg <- c(10, 5, 5)

t_end_sd <- 24
delta_sd <- 0.02

t_end_md <- 24
delta_md <- 0.02

mod_typ <- zero_re(mod_hc_oral)
idata_typ <- tibble(ID = 1)

N <- 1000
idata_pop <- tibble(ID = 1:N)

at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}


ev_sd <- ev(
  amt = single_dose_mg,
  cmt = 1,
  time = 0,
  rate = -2
)

ev_md <- ev(
  time = dose_times_h,
  amt = dose_amts_mg,
  cmt = c(1, 1, 1),
  rate = c(-2, -2, -2)
)

fig1_out <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_sd) %>%
  mrgsim(end = t_end_sd, delta = delta_sd) %>%
  as_tibble() %>%
  mutate(group = "10 mg PO")

p1 <- ggplot(fig1_out, aes(time, CP, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time after dose (hours)",
    y = "Hydrocortisone concentration (ng/mL)",
    color = "Regimen",
    title = "Figure 1. Hydrocortisone single oral dose"
  )

fig1_summary <- fig1_out %>%
  group_by(group) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C2h = at_time(time, CP, 2),
    C4h = at_time(time, CP, 4),
    C8h = at_time(time, CP, 8),
    C12h = at_time(time, CP, 12),
    Cmin_24h = at_time(time, CP, 24),
    .groups = "drop"
  )


fig2_out <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_md) %>%
  mrgsim(end = t_end_md, delta = delta_md) %>%
  as_tibble() %>%
  mutate(group = "10 + 5 + 5 mg PO")

p2 <- ggplot(fig2_out, aes(time, CP, color = group)) +
  geom_line(linewidth = 1) +
  geom_vline(
    xintercept = dose_times_h,
    linetype = "dotted",
    linewidth = 0.4
  ) +
  theme_bw() +
  labs(
    x = "Time after 07:30 dose (hours)",
    y = "Hydrocortisone concentration (ng/mL)",
    color = "Regimen",
    title = paste0(
      "Figure 2. Hydrocortisone 10 mg at 07:30, ",
      "5 mg at 12:00 and 5 mg at 16:30"
    )
  )

fig2_summary <- fig2_out %>%
  group_by(group) %>%
  summarise(
    Cmax_overall = max(CP),
    Tmax_overall_h = time[which.max(CP)],
    
    Cmax_morning = max(CP[time >= 0 & time < 4.5]),
    Cmax_midday = max(CP[time >= 4.5 & time < 9]),
    Cmax_afternoon = max(CP[time >= 9 & time <= 24]),
    
    Cmin_24h = at_time(time, CP, 24),

    C0800_nmol_L = at_time(time, CORT_NMOL, 0.5),
    C1600_nmol_L = at_time(time, CORT_NMOL, 8.5),
    C2400_nmol_L = at_time(time, CORT_NMOL, 16.5),
    
    .groups = "drop"
  )


set.seed(123)

fig3_raw <- mod_hc_oral %>%
  idata_set(idata_pop) %>%
  ev(ev_sd) %>%
  mrgsim(end = t_end_sd, delta = delta_sd) %>%
  as_tibble() %>%
  mutate(group = "10 mg PO")

fig3_sum <- fig3_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP),
    C_p05 = quantile(CP, 0.05),
    C_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = group, fill = group)) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time after dose (hours)",
    y = "Hydrocortisone concentration (ng/mL)",
    color = "Regimen",
    fill = "Regimen",
    title = "Figure 3. Hydrocortisone single oral dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C2h = at_time(time, CP, 2),
    C4h = at_time(time, CP, 4),
    C8h = at_time(time, CP, 8),
    C12h = at_time(time, CP, 12),
    Cmin_24h = at_time(time, CP, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med = median(Tmax_h),
    Tmax_p05 = quantile(Tmax_h, 0.05),
    Tmax_p95 = quantile(Tmax_h, 0.95),
 
    C2h_med = median(C2h),
    C2h_p05 = quantile(C2h, 0.05),
    C2h_p95 = quantile(C2h, 0.95),
    
    C4h_med = median(C4h),
    C4h_p05 = quantile(C4h, 0.05),
    C4h_p95 = quantile(C4h, 0.95),
    
    C8h_med = median(C8h),
    C8h_p05 = quantile(C8h, 0.05),
    C8h_p95 = quantile(C8h, 0.95),
    
    C12h_med = median(C12h),
    C12h_p05 = quantile(C12h, 0.05),
    C12h_p95 = quantile(C12h, 0.95),
    
    Cmin_24h_med = median(Cmin_24h),
    Cmin_24h_p05 = quantile(Cmin_24h, 0.05),
    Cmin_24h_p95 = quantile(Cmin_24h, 0.95),
    
    .groups = "drop"
  )

set.seed(123)

fig4_raw <- mod_hc_oral %>%
  idata_set(idata_pop) %>%
  ev(ev_md) %>%
  mrgsim(end = t_end_md, delta = delta_md) %>%
  as_tibble() %>%
  mutate(group = "10 + 5 + 5 mg PO")

fig4_sum <- fig4_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP),
    C_p05 = quantile(CP, 0.05),
    C_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time, C_med, color = group, fill = group)) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(linewidth = 1.1) +
  geom_vline(
    xintercept = dose_times_h,
    linetype = "dotted",
    linewidth = 0.4
  ) +
  theme_bw() +
  labs(
    x = "Time after 07:30 dose (hours)",
    y = "Hydrocortisone concentration (ng/mL)",
    color = "Regimen",
    fill = "Regimen",
    title = paste0(
      "Figure 4. Hydrocortisone 10 + 5 + 5 mg, ",
      "population"
    )
  )

fig4_ind <- fig4_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax_overall = max(CP),
    Tmax_overall_h = time[which.max(CP)],
    
    Cmax_morning = max(CP[time >= 0 & time < 4.5]),
    Cmax_midday = max(CP[time >= 4.5 & time < 9]),
    Cmax_afternoon = max(CP[time >= 9 & time <= 24]),
    
    Cmin_24h = at_time(time, CP, 24),

    C0800_nmol_L = at_time(time, CORT_NMOL, 0.5),
    C1600_nmol_L = at_time(time, CORT_NMOL, 8.5),
    C2400_nmol_L = at_time(time, CORT_NMOL, 16.5),
    
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax_overall),
    Cmax_p05 = quantile(Cmax_overall, 0.05),
    Cmax_p95 = quantile(Cmax_overall, 0.95),
    
    Tmax_med = median(Tmax_overall_h),
    Tmax_p05 = quantile(Tmax_overall_h, 0.05),
    Tmax_p95 = quantile(Tmax_overall_h, 0.95),
    
    Cmax_morning_med = median(Cmax_morning),
    Cmax_morning_p05 = quantile(Cmax_morning, 0.05),
    Cmax_morning_p95 = quantile(Cmax_morning, 0.95),
    
    Cmax_midday_med = median(Cmax_midday),
    Cmax_midday_p05 = quantile(Cmax_midday, 0.05),
    Cmax_midday_p95 = quantile(Cmax_midday, 0.95),
    
    Cmax_afternoon_med = median(Cmax_afternoon),
    Cmax_afternoon_p05 = quantile(Cmax_afternoon, 0.05),
    Cmax_afternoon_p95 = quantile(Cmax_afternoon, 0.95),
    
    Cmin_24h_med = median(Cmin_24h),
    Cmin_24h_p05 = quantile(Cmin_24h, 0.05),
    Cmin_24h_p95 = quantile(Cmin_24h, 0.95),
    
    C0800_med = median(C0800_nmol_L),
    C0800_p05 = quantile(C0800_nmol_L, 0.05),
    C0800_p95 = quantile(C0800_nmol_L, 0.95),
    
    C1600_med = median(C1600_nmol_L),
    C1600_p05 = quantile(C1600_nmol_L, 0.05),
    C1600_p95 = quantile(C1600_nmol_L, 0.95),
    
    C2400_med = median(C2400_nmol_L),
    C2400_p05 = quantile(C2400_nmol_L, 0.05),
    C2400_p95 = quantile(C2400_nmol_L, 0.95),
    
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary
