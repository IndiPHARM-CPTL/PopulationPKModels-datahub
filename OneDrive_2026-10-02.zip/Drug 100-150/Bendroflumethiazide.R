library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

bendroflumethiazide_code <- '
$PROB
- Ref:Beermann B, Groschinsky-Grind M, Lindström B, Wikland B. Pharmacokinetics of bendroflumenthiazide in hypertensive patients. Eur J Clin Pharmacol. 1978;13(2):119-124. doi:10.1007/BF00609755

$PARAM @annotated
DOSEMG   : 5.0  : mg       Nominal dose; use 2.5 or 5

KA       : 0.90 : 1/h      First-order absorption rate constant; chosen for Tmax around 2-3 h
WT       : 80   : kg       Body weight

VKG      : 1.18 : L/kg     Apparent volume of distribution
CLNR     : 12.0 : L/h      Nonrenal clearance; 200 mL/min

CLR_LOW  : 5.58 : L/h      Renal clearance after 2.5 mg; 93 mL/min
CLR_HIGH : 2.88 : L/h      Renal clearance after 5 mg; 48 mL/min

PROP_SD  : 0.20 : --       Proportional residual SD; assumed

$CMT @annotated
DEPOT : Oral absorption compartment
CENT  : Central compartment

$OMEGA @diag @labels ETA_CL ETA_V ETA_KA
0.0253 0.0654 0.1000

$SIGMA
1

$GLOBAL
double KAi;
double CLNRi;
double CLRi;
double CLi;
double Vi;
double KEi;
double KRi;
double T12i;

$MAIN

KAi = KA * exp(ETA(3));

Vi = VKG * WT * exp(ETA(2));

if(DOSEMG <= 2.5) {
  CLRi = CLR_LOW;
} else {
  CLRi = CLR_HIGH;
}

CLi = (CLNRi + CLRi) * exp(ETA(1));

KEi = CLi / Vi;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT  =  KAi * DEPOT-KEi * CENT;

$TABLE
double BFT_mgL  = CENT / Vi;
double BFT_ngmL = BFT_mgL * 1000.0;

double DV_ngmL = BFT_ngmL * exp(PROP_SD * EPS(1));

$CAPTURE
BFT_ngmL DV_ngmL
'
mod <- mcode("bendroflumethiazide_beermann1978", bendroflumethiazide_code)

set.seed(123)

dose_mg <- c(2.5, 5)

N        <- 1000
tau_h    <- 24
n_doses  <- 14
addl_md  <- n_doses - 1

t_end_sd <- 24
t_end_md <- 336

delta_sd <- 0.05
delta_md <- 0.05

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses, " days")

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(
  ID = 1,
  WT = 80
)

idata_pop <- tibble(
  ID = 1:N,
  WT = pmin(pmax(rnorm(N, mean = 80, sd = 14), 50), 110)
)



fig1_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT"
  )
  
  mod_typ %>%
    param(DOSEMG = d) %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = BFT_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Bendroflumethiazide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Bendroflumethiazide single dose, typical profile"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C2   = get_nearest(time, CP, 2),
    C4   = get_nearest(time, CP, 4),
    C8   = get_nearest(time, CP, 8),
    C12  = get_nearest(time, CP, 12),
    C24  = get_nearest(time, CP, 24),
    .groups = "drop"
  )



fig2_list <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    param(DOSEMG = d) %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = BFT_ngmL,
      Dose = paste0(d, " mg q24h x", n_doses, " days"),
      time_day = time / 24
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time_day, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Bendroflumethiazide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Bendroflumethiazide q24h x14 days, typical profile"
  )

fig2_summary <- fig2_out %>%
  filter(time >= (n_doses - 1) * tau_h,
         time <= n_doses * tau_h) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day14 = max(CP, na.rm = TRUE),
    Tmax_day14 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    C2_day14   = get_nearest(time, CP, (n_doses - 1) * tau_h + 2),
    C4_day14   = get_nearest(time, CP, (n_doses - 1) * tau_h + 4),
    C8_day14   = get_nearest(time, CP, (n_doses - 1) * tau_h + 8),
    C12_day14  = get_nearest(time, CP, (n_doses - 1) * tau_h + 12),
    Ctrough_day14 = get_nearest(time, CP, n_doses * tau_h),
    .groups = "drop"
  )


set.seed(123)

fig3_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT"
  )
  
  mod %>%
    param(DOSEMG = d) %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = BFT_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Bendroflumethiazide concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Bendroflumethiazide single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C2   = get_nearest(time, CP, 2),
    C4   = get_nearest(time, CP, 4),
    C8   = get_nearest(time, CP, 8),
    C12  = get_nearest(time, CP, 12),
    C24  = get_nearest(time, CP, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C2_med = median(C2, na.rm = TRUE),
    C2_p05 = quantile(C2, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2, 0.95, na.rm = TRUE),
    
    C4_med = median(C4, na.rm = TRUE),
    C4_p05 = quantile(C4, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    .groups = "drop"
  )



set.seed(123)

fig4_list <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    param(DOSEMG = d) %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = BFT_ngmL,
      Dose = paste0(d, " mg q24h x", n_doses, " days"),
      time_day = time / 24
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Bendroflumethiazide concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Bendroflumethiazide q24h x14 days, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= (n_doses - 1) * tau_h,
         time <= n_doses * tau_h) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_day14 = max(CP, na.rm = TRUE),
    Tmax_day14 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    C2_day14   = get_nearest(time, CP, (n_doses - 1) * tau_h + 2),
    C4_day14   = get_nearest(time, CP, (n_doses - 1) * tau_h + 4),
    C8_day14   = get_nearest(time, CP, (n_doses - 1) * tau_h + 8),
    C12_day14  = get_nearest(time, CP, (n_doses - 1) * tau_h + 12),
    Ctrough_day14 = get_nearest(time, CP, n_doses * tau_h),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day14_med = median(Cmax_day14, na.rm = TRUE),
    Cmax_day14_p05 = quantile(Cmax_day14, 0.05, na.rm = TRUE),
    Cmax_day14_p95 = quantile(Cmax_day14, 0.95, na.rm = TRUE),
    
    Tmax_day14_med = median(Tmax_day14, na.rm = TRUE),
    Tmax_day14_p05 = quantile(Tmax_day14, 0.05, na.rm = TRUE),
    Tmax_day14_p95 = quantile(Tmax_day14, 0.95, na.rm = TRUE),
    
    C2_day14_med = median(C2_day14, na.rm = TRUE),
    C2_day14_p05 = quantile(C2_day14, 0.05, na.rm = TRUE),
    C2_day14_p95 = quantile(C2_day14, 0.95, na.rm = TRUE),
    
    C4_day14_med = median(C4_day14, na.rm = TRUE),
    C4_day14_p05 = quantile(C4_day14, 0.05, na.rm = TRUE),
    C4_day14_p95 = quantile(C4_day14, 0.95, na.rm = TRUE),
    
    C8_day14_med = median(C8_day14, na.rm = TRUE),
    C8_day14_p05 = quantile(C8_day14, 0.05, na.rm = TRUE),
    C8_day14_p95 = quantile(C8_day14, 0.95, na.rm = TRUE),
    
    Ctrough_day14_med = median(Ctrough_day14, na.rm = TRUE),
    Ctrough_day14_p05 = quantile(Ctrough_day14, 0.05, na.rm = TRUE),
    Ctrough_day14_p95 = quantile(Ctrough_day14, 0.95, na.rm = TRUE),
     .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary

