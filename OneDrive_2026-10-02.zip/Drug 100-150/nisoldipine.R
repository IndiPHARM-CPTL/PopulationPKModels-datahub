library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

nisoldipine_code <- '
$PROB
- Nisoldipine coat-core - 20%/80%
- Ref: Heinig R. Clinical pharmacokinetics of nisoldipine coat-core. Clin Pharmacokinet. 1998;35(3):191-208. doi:10.2165/00003088-199835030-00003
- Covariate: Fasting, age, liver function, CYP3A4

$PARAM @annotated
DOSEMG    : 20   : mg      Nominal dose, used only for annotation

TVCL      : 680  : L/h     Apparent oral clearance, CL/F
TVV       : 8500 : L       Apparent volume, V/F
KA        : 1.20 : 1/h     First-order absorption from GI depot

DUR_FASTED : 16.0 : h      Controlled-release duration under fasting
DUR_FED    : 4.0  : h      Shorter apparent release duration with high-fat food
FREL_FAST  : 1.00 : --     Relative bioavailability fasting
FREL_FED   : 0.75 : --     Relative bioavailability with high-fat food; AUC tends to decrease

AGE        : 50   : years   Age
AGE_REF    : 50   : years   Reference age
THETA_AGE  : 0.18 : --      Fractional CL decrease per decade above/below AGE_REF on log scale

HEPATIC    : 0    : --      1 = liver cirrhosis / severe hepatic impairment
TH_HEP_CL  : 0.25 : --      CL multiplier in hepatic cirrhosis

RENAL      : 0    : --      1 = renal impairment; no PK effect applied

FOOD       : 0    : --      0 = fasted; 1 = high-fat food
GFJ        : 0    : --      1 = grapefruit juice
CIMET      : 0    : --      1 = cimetidine
INDUCER    : 0    : --      1 = strong CYP3A4 inducer

TH_GFJ_CL   : 0.50 : --     Grapefruit juice decreases apparent CL/F
TH_CIM_CL   : 0.75 : --     Cimetidine decreases CL/F 
TH_IND_CL   : 8.00 : --     Strong inducer increases apparent CL/F 

PROP_SD     : 0.25 : --     Proportional residual SD; assumed

$CMT @annotated
DEPOT : GI absorption depot
CENT  : Central compartment

$OMEGA @diag @labels ETA_CL ETA_V ETA_DUR
0.176 0.150 0.100

$SIGMA
1

$GLOBAL
double AGE_CL;
double HEP_CL;
double GFJ_CL;
double CIM_CL;
double IND_CL;

double CLi;
double Vi;
double KAi;
double KEi;

double DURi;
double FRELi;

$MAIN
AGE_CL = exp(-THETA_AGE * ((AGE - AGE_REF) / 10.0));

if(HEPATIC == 1) {
  HEP_CL = TH_HEP_CL;
} else {
  HEP_CL = 1.0;
}

if(GFJ == 1) {
  GFJ_CL = TH_GFJ_CL;
} else {
  GFJ_CL = 1.0;
}

if(CIMET == 1) {
  CIM_CL = TH_CIM_CL;
} else {
  CIM_CL = 1.0;
}

if(INDUCER == 1) {
  IND_CL = TH_IND_CL;
} else {
  IND_CL = 1.0;
}

if(FOOD == 1) {
  DURi  = DUR_FED * exp(ETA(3));
  FRELi = FREL_FED;
} else {
  DURi  = DUR_FASTED * exp(ETA(3));
  FRELi = FREL_FAST;
}

CLi = TVCL *
      AGE_CL *
      HEP_CL *
      GFJ_CL *
      CIM_CL *
      IND_CL *
      exp(ETA(1));

Vi  = TVV * exp(ETA(2));

KAi = KA;
KEi = CLi / Vi;
D_DEPOT = DURi;
F_DEPOT = FRELi;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT  =  KAi * DEPOT
             -KEi * CENT;

$TABLE
double NIS_mgL  = CENT / Vi;
double NIS_ngmL = NIS_mgL * 1000.0;

double DV_ngmL = NIS_ngmL * exp(PROP_SD * EPS(1));

$CAPTURE
NIS_ngmL DV_ngmL
CLi Vi KAi KEi DURi FRELi
AGE FOOD HEPATIC RENAL GFJ CIMET INDUCER
'

mod <- mcode("nisoldipine_popPK", nisoldipine_code)


set.seed(123)

dose_mg <- c(10, 20, 30, 40)

N        <- 1000
tau_h    <- 24
n_doses  <- 7
addl_md  <- n_doses - 1

t_end_sd <- 48
t_end_md <- 168

delta_sd <- 0.1
delta_md <- 0.1

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses)


make_nisoldipine_cc_ev <- function(dose_mg,
                                   ii = NULL,
                                   addl = NULL) {
  
  repeat_args <- if(!is.null(ii)) {
    list(ii = ii, addl = addl)
  } else {
    list()
  }
  
  ev_coat <- do.call(
    ev,
    c(
      list(
        time = 0,
        amt  = dose_mg * 0.20,
        cmt  = "DEPOT"
      ),
      repeat_args
    )
  )
  
  ev_core <- do.call(
    ev,
    c(
      list(
        time = 0,
        amt  = dose_mg * 0.80,
        cmt  = "DEPOT",
        rate = -2
      ),
      repeat_args
    )
  )
  
  c(ev_coat, ev_core)
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(
  ID      = 1,
  AGE     = 50,
  FOOD    = 0,
  HEPATIC = 0,
  RENAL   = 0,
  GFJ     = 0,
  CIMET   = 0,
  INDUCER = 0
)

idata_pop <- tibble(
  ID      = 1:N,
  AGE     = pmin(pmax(rnorm(N, mean = 50, sd = 10), 20), 85),
  FOOD    = 0,
  HEPATIC = 0,
  RENAL   = 0,
  GFJ     = 0,
  CIMET   = 0,
  INDUCER = 0
)


fig1_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- make_nisoldipine_cc_ev(dose_mg = d)
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = NIS_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Nisoldipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Nisoldipine Coat-Core (10/20/30/40 mg) once daily, single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C12  = get_nearest(time, CP, 12),
    C24  = get_nearest(time, CP, 24),
    .groups = "drop"
  )



fig2_list <- lapply(dose_mg, function(d) {
  
  ev_md <- make_nisoldipine_cc_ev(
    dose_mg = d,
    ii      = tau_h,
    addl    = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = NIS_ngmL,
      time_day = time / 24,
      Dose = paste0(d, " mg q24h x", n_doses)
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time_day, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Nisoldipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Nisoldipine Coat-Core (10/20/30/40 mg) once daily, multi-dose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= (n_doses - 1) * tau_h,
         time <= n_doses * tau_h) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day7 = max(CP, na.rm = TRUE),
    Tmax_day7 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    Ctrough_day7 = get_nearest(time, CP, n_doses * tau_h),
    .groups = "drop"
  )



set.seed(123)

fig3_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- make_nisoldipine_cc_ev(dose_mg = d)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = NIS_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Nisoldipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Nisoldipine Coat-Core (10/20/30/40 mg) once daily, single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C12  = get_nearest(time, CP, 12),
    C24  = get_nearest(time, CP, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),

    .groups = "drop"
  )



set.seed(123)

fig4_list <- lapply(dose_mg, function(d) {
  
  ev_md <- make_nisoldipine_cc_ev(
    dose_mg = d,
    ii      = tau_h,
    addl    = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = NIS_ngmL,
      time_day = time / 24,
      Dose = paste0(d, " mg q24h x", n_doses)
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Nisoldipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Nisoldipine Coat-Core (10/20/30/40 mg) once daily, multi-dose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= (n_doses - 1) * tau_h,
         time <= n_doses * tau_h) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_day7 = max(CP, na.rm = TRUE),
    Tmax_day7 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    Ctrough_day7 = get_nearest(time, CP, n_doses * tau_h),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day7_med = median(Cmax_day7, na.rm = TRUE),
    Cmax_day7_p05 = quantile(Cmax_day7, 0.05, na.rm = TRUE),
    Cmax_day7_p95 = quantile(Cmax_day7, 0.95, na.rm = TRUE),
    
    Tmax_day7_med = median(Tmax_day7, na.rm = TRUE),
    Tmax_day7_p05 = quantile(Tmax_day7, 0.05, na.rm = TRUE),
    Tmax_day7_p95 = quantile(Tmax_day7, 0.95, na.rm = TRUE),
    
    Ctrough_day7_med = median(Ctrough_day7, na.rm = TRUE),
    Ctrough_day7_p05 = quantile(Ctrough_day7, 0.05, na.rm = TRUE),
    Ctrough_day7_p95 = quantile(Ctrough_day7, 0.95, na.rm = TRUE),

    .groups = "drop"
  )



p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary

