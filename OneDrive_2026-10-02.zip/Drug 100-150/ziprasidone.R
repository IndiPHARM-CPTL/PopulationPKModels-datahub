library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

ziprasidone_code <- '
$PROB
Ziprasidone population PK model (CATIE)
- Ref: Wessels AM, Bies RR, Pollock BG, Schneider LS, Lieberman JA,
  Stroup S, et al.
  Population Pharmacokinetic Modeling of Ziprasidone in Patients With
  Schizophrenia From the CATIE Study.
  J Clin Pharmacol. 2011;51(11):1587-1591.
  doi:10.1177/0091270010387604

$PARAM @annotated
KA          : 0.5    : 1/h    First-order absorption rate constant (fixed)
CLF         : 122    : L/h    Apparent clearance
VF          : 1060   : L      Apparent volume of distribution

PROP_SD     : 0.655  : --     Proportional residual SD

$CMT @annotated
DEPOT : Oral dosing/absorption compartment (mg)
CENT  : Central compartment (mg)

$OMEGA @labels ETA_CL ETA_V
0.35061 0.73714

$SIGMA
1

$GLOBAL
double KAi;
double CLFi;
double VFi;

$MAIN
KAi = KA;

CLFi = CLF * exp(ETA_CL);

VFi = VF * exp(ETA_V);

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT =
    KAi * DEPOT
  - (CLFi / VFi) * CENT;

$TABLE
double CP_ngmL = 1000.0 * CENT / VFi;

double DV_PK =
  CP_ngmL * (1.0 + PROP_SD * EPS(1));

double THALF = log(2.0) * VFi / CLFi;

$CAPTURE
CP_ngmL DV_PK THALF
KAi CLFi VFi
'
mod_zip <- mcode("ziprasidone_pk", ziprasidone_code)


N <- 1000

# CATIE flexible dosing 40-160 mg/day (median 80), given twice daily
doses_mg <- c(20, 40, 80)                     # mg per dose, BID
dose_levels <- c("20 mg BID", "40 mg BID", "80 mg BID")

tau <- 12
n_dose <- 20                                  # 10 days BID

t_end_sd <- 48                                # typical t1/2 ~6 h
last_dose <- tau * (n_dose - 1)
t_end_md <- last_dose + tau

delta_sd <- 0.1
delta_md <- 0.25


at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

auc_trap <- function(time, conc) {
  sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2)
}

dose_label <- function(d) paste0(d, " mg BID")




# No covariates in the final model
idata_typ <- tibble(ID = 1)

idata_pop <- tibble(ID = 1:N)

mod_typ <- zero_re(mod_zip)





# ---------------------------------------------------------------------------
# Figure 1. Typical subject, single dose
# ---------------------------------------------------------------------------

fig1_list <- lapply(doses_mg, function(d) {
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_typ, end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = dose_label(d))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


p1_zip <- ggplot(fig1_out, aes(time, CP_ngmL, color = Dose)) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, t_end_sd, 6), limits = c(0, t_end_sd)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Ziprasidone concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Ziprasidone single dose"
  )

p1_zip


fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = time[which.max(CP_ngmL)],
    C12 = at_time(time, CP_ngmL, tau),
    AUC0_12 = auc_trap(time[time <= tau], CP_ngmL[time <= tau]),
    AUC0_48 = auc_trap(time, CP_ngmL),
    THALF_h = first(THALF),
    .groups = "drop"
  )

fig1_summary





# ---------------------------------------------------------------------------
# Figure 2. Typical subject, twice daily for 10 days
# ---------------------------------------------------------------------------

fig2_list <- lapply(doses_mg, function(d) {
  
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau, addl = n_dose - 1)
  
  mod_typ %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_typ, end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = dose_label(d),
      time_day = time / 24
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


p2_zip <- ggplot(fig2_out, aes(time_day, CP_ngmL, color = Dose)) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, 10, 1), limits = c(0, 10)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Ziprasidone concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Ziprasidone twice daily for 10 days"
  )

p2_zip


fig2_summary <- fig2_out %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_ss = max(CP_ngmL),
    Tmax_ss_h = t_rel[which.max(CP_ngmL)],
    Ctrough_ss = at_time(t_rel, CP_ngmL, tau),
    AUCtau_ss = auc_trap(t_rel, CP_ngmL),
    Cavg_ss = AUCtau_ss / tau,
    .groups = "drop"
  )

fig2_summary


# Structural check: AUCtau,ss = Dose / (CL/F)
fig2_check <- fig2_summary %>%
  mutate(
    dose = as.numeric(sub(" mg BID", "", as.character(Dose))),
    AUC_expected = 1000 * dose / 122,
    pct_diff = 100 * (AUCtau_ss / AUC_expected - 1)
  ) %>%
  select(Dose, AUCtau_ss, AUC_expected, pct_diff)

fig2_check





# ---------------------------------------------------------------------------
# Figure 3. Population, single dose
# ---------------------------------------------------------------------------

fig3_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_zip %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_pop, end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = dose_label(d))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    CP_med = median(CP_ngmL),
    CP_p05 = quantile(CP_ngmL, 0.05),
    CP_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )


p3_zip <- ggplot(fig3_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, t_end_sd, 6), limits = c(0, t_end_sd)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Ziprasidone concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Ziprasidone single dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p3_zip


fig3_ind <- fig3_raw %>%
  arrange(Dose, ID, time) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = time[which.max(CP_ngmL)],
    C12 = at_time(time, CP_ngmL, tau),
    AUC0_12 = auc_trap(time[time <= tau], CP_ngmL[time <= tau]),
    THALF = first(THALF),
    .groups = "drop"
  )


fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    C12_med = median(C12),
    C12_p05 = quantile(C12, 0.05),
    C12_p95 = quantile(C12, 0.95),
    
    AUC0_12_med = median(AUC0_12),
    AUC0_12_p05 = quantile(AUC0_12, 0.05),
    AUC0_12_p95 = quantile(AUC0_12, 0.95),
    
    THALF_med_h = median(THALF),
    THALF_p05_h = quantile(THALF, 0.05),
    THALF_p95_h = quantile(THALF, 0.95),
    
    .groups = "drop"
  )

fig3_summary




# ---------------------------------------------------------------------------
# Figure 4. Population, twice daily for 10 days
# ---------------------------------------------------------------------------

fig4_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau, addl = n_dose - 1)
  
  mod_zip %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_pop, end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = dose_label(d),
      time_day = time / 24
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


fig4_sum <- fig4_raw %>%
  group_by(Dose, time, time_day) %>%
  summarise(
    CP_med = median(CP_ngmL),
    CP_p05 = quantile(CP_ngmL, 0.05),
    CP_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )


p4_zip <- ggplot(fig4_sum, aes(time_day, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, 10, 1), limits = c(0, 10)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Ziprasidone concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Ziprasidone twice daily for 10 days, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p4_zip


fig4_ind <- fig4_raw %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  arrange(Dose, ID, t_rel) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = t_rel[which.max(CP_ngmL)],
    Ctrough = at_time(t_rel, CP_ngmL, tau),
    AUCtau = auc_trap(t_rel, CP_ngmL),
    .groups = "drop"
  )


fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    Ctrough_med = median(Ctrough),
    Ctrough_p05 = quantile(Ctrough, 0.05),
    Ctrough_p95 = quantile(Ctrough, 0.95),
    
    AUCtau_med = median(AUCtau),
    AUCtau_p05 = quantile(AUCtau, 0.05),
    AUCtau_p95 = quantile(AUCtau, 0.95),
    
    .groups = "drop"
  )

fig4_summary
