library(mrgsolve)
library(dplyr)
library(tibble)
library(tidyr)
library(ggplot2)


# ============================================================
# OMEPRAZOLE POPULATION PK MODEL
# Solana et al. 2014
# ============================================================

omeprazole_code <- '
$PROB
Omeprazole population PK model

- Ref:
  Solana MJ, Colom H, Lopez-Herce J, et al.
  Population pharmacokinetics of omeprazole in critically ill
  pediatric patients.
  Ther Drug Monit. 2014;36(4):519-527.
  doi:10.1097/FTD.0000000000000033

- Critically ill pediatric patients
- Intravenous omeprazole
- Two-compartment disposition
- First-order elimination
- Fixed allometric scaling by body weight
- IIV on clearance

IMPORTANT:
The source reports IV dosing but does not report infusion duration
in the available abstract.

A 15-minute IV infusion is assumed for simulation.

$PARAM @annotated
CL70     : 24.9   : L/h   Clearance at 70 kg
Q70      : 53.9   : L/h   Intercompartmental clearance at 70 kg
VC70     : 4.23   : L     Central volume at 70 kg
VP70     : 674    : L     Peripheral volume at 70 kg
WT       : 15     : kg    Body weight
PROP_SD  : 1.30   : --    Proportional residual SD

$CMT @annotated
CENT   : Central compartment (mg)
PERIPH : Peripheral compartment (mg)

$OMEGA @labels ETA_CL
0.45106

$SIGMA
1

$GLOBAL
double CLi;
double Qi;
double VCi;
double VPi;

$MAIN

CLi =
  CL70 *
  pow(WT / 70.0, 0.75) *
  exp(ETA(1));

Qi =
  Q70 *
  pow(WT / 70.0, 0.75);

VCi =
  VC70 *
  pow(WT / 70.0, 1.0);

VPi =
  VP70 *
  pow(WT / 70.0, 1.0);


$ODE

dxdt_CENT =
  - (CLi / VCi) * CENT
  - (Qi  / VCi) * CENT
  + (Qi  / VPi) * PERIPH;

dxdt_PERIPH =
    (Qi / VCi) * CENT
  - (Qi / VPi) * PERIPH;


$TABLE

double CP_mgL =
  CENT / VCi;

double CP_ngmL =
  1000.0 * CP_mgL;

double DV_PK =
  CP_ngmL *
  (1.0 + PROP_SD * EPS(1));


$CAPTURE
CP_mgL CP_ngmL DV_PK
CLi Qi VCi VPi WT
'


mod_omep <- mcode(
  "omeprazole_solana2014",
  omeprazole_code
)



# ============================================================
# SIMULATION SETTINGS
# ============================================================

N <- 1000


# Trial doses
doses_mgkg <- c(
  0.5,
  1
)

dose_levels <- c(
  "0.5 mg/kg",
  "1 mg/kg"
)


# ------------------------------------------------------------
# Typical pediatric subject
#
# The abstract does not report median weight.
# 15 kg is used as an illustrative reference because the
# source reconstruction centres the virtual cohort around 15 kg.
# ------------------------------------------------------------

WT_typ <- 15


# BID
tau <- 12


# 15-minute infusion
infdur_h <- 0.25


# Four doses:
# 0, 12, 24, 36 h
n_dose <- 4


last_dose <-
  tau *
  (n_dose - 1)


# Single-dose simulation
t_end_sd <- 24

# Multiple-dose simulation
t_end_md <- 48


delta_sd <- 0.05
delta_md <- 0.05



# ============================================================
# HELPER FUNCTIONS
# ============================================================

at_time <- function(
    time,
    value,
    target
) {
  
  value[
    which.min(
      abs(
        time - target
      )
    )
  ]
  
}



auc_trap <- function(
    time,
    conc
) {
  
  sum(
    diff(time) *
      (
        head(conc, -1) +
          tail(conc, -1)
      ) / 2
  )
  
}



# Typical-value model:
# zero IIV and residual error
mod_typ <- zero_re(
  mod_omep
)



# ============================================================
# FIGURE 1
# TYPICAL PATIENT — SINGLE IV INFUSION
# ============================================================

fig1_list <- lapply(
  doses_mgkg,
  function(d_mgkg) {
    
    dose_mg <-
      d_mgkg *
      WT_typ
    
    
    infusion_rate <-
      dose_mg /
      infdur_h
    
    
    idata_typ <- tibble(
      ID = 1,
      WT = WT_typ
    )
    
    
    ev_sd <- ev(
      time = 0,
      amt = dose_mg,
      cmt = 1,
      rate = infusion_rate
    )
    
    
    mod_typ %>%
      
      ev(ev_sd) %>%
      
      mrgsim(
        idata = idata_typ,
        end = t_end_sd,
        delta = delta_sd
      ) %>%
      
      as_tibble() %>%
      
      mutate(
        
        Dose =
          paste0(
            d_mgkg,
            " mg/kg"
          ),
        
        dose_mg =
          dose_mg
      )
    
  }
)



fig1_out <- bind_rows(
  fig1_list
) %>%
  
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )



p1_omep <- ggplot(
  fig1_out,
  aes(
    time,
    CP_ngmL,
    color = Dose
  )
) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (h)",
    y = "Omeprazole concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Omeprazole single IV infusion"
  )


p1_omep



# ============================================================
# FIGURE 1 SUMMARY
# FIRST 12-HOUR INTERVAL
# ============================================================

fig1_summary <- fig1_out %>%
  
  filter(
    time <= tau
  ) %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      time[
        which.max(
          CP_ngmL
        )
      ],
    
    C12 =
      at_time(
        time,
        CP_ngmL,
        tau
      ),
    
    AUC0_12 =
      auc_trap(
        time,
        CP_ngmL
      ),
    
    .groups = "drop"
  )


fig1_summary





# ============================================================
# FIGURE 2
# TYPICAL PATIENT
# IV BID FOR 48 HOURS
# ============================================================

fig2_list <- lapply(
  doses_mgkg,
  function(d_mgkg) {
    
    dose_mg <-
      d_mgkg *
      WT_typ
    
    
    infusion_rate <-
      dose_mg /
      infdur_h
    
    
    idata_typ <- tibble(
      ID = 1,
      WT = WT_typ
    )
    
    
    ev_md <- ev(
      time = 0,
      amt = dose_mg,
      cmt = 1,
      rate = infusion_rate,
      ii = tau,
      addl = n_dose - 1
    )
    
    
    mod_typ %>%
      
      ev(ev_md) %>%
      
      mrgsim(
        idata = idata_typ,
        end = t_end_md,
        delta = delta_md
      ) %>%
      
      as_tibble() %>%
      
      mutate(
        
        Dose =
          paste0(
            d_mgkg,
            " mg/kg"
          ),
        
        time_day =
          time / 24
      )
    
  }
)



fig2_out <- bind_rows(
  fig2_list
) %>%
  
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )



p2_omep <- ggplot(
  fig2_out,
  aes(
    time,
    CP_ngmL,
    color = Dose
  )
) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (h)",
    y = "Omeprazole concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Omeprazole IV twice daily for 48 h"
  )


p2_omep



# ============================================================
# FIGURE 2 SUMMARY
# FINAL OBSERVED DOSING INTERVAL: 36-48 h
#
# NOTE:
# This is deliberately not called steady state.
# ============================================================

fig2_summary <- fig2_out %>%
  
  filter(
    time >= last_dose,
    time <= last_dose + tau
  ) %>%
  
  mutate(
    t_rel =
      time - last_dose
  ) %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax_last =
      max(
        CP_ngmL
      ),
    
    Tmax_last_h =
      t_rel[
        which.max(
          CP_ngmL
        )
      ],
    
    Ctrough_last =
      at_time(
        t_rel,
        CP_ngmL,
        tau
      ),
    
    AUCtau_last =
      auc_trap(
        t_rel,
        CP_ngmL
      ),
    
    .groups = "drop"
  )


fig2_summary





# ============================================================
# POPULATION EVENT BUILDER
# ============================================================

make_omep_population <- function(
    dose_mgkg,
    multiple = FALSE,
    id_offset = 0,
    seed = NULL
) {
  
  if(!is.null(seed)) {
    
    set.seed(
      seed
    )
    
  }
  
  
  # ----------------------------------------------------------
  # Pediatric body-weight distribution
  #
  # Log-normal distribution centred near 15 kg,
  # truncated to approximately 4-50 kg.
  # ----------------------------------------------------------
  
  WT_i <-
    pmin(
      pmax(
        exp(
          rnorm(
            N,
            mean = log(15),
            sd = 0.7
          )
        ),
        4
      ),
      50
    )
  
  
  ids <-
    id_offset +
    seq_len(N)
  
  
  subjects <- tibble(
    
    ID = ids,
    
    WT = WT_i,
    
    dose_mg =
      dose_mgkg *
      WT_i,
    
    rate_mgh =
      (
        dose_mgkg *
          WT_i
      ) /
      infdur_h
    
  )
  
  
  # ==========================================================
  # SINGLE DOSE
  # ==========================================================
  
  if(!multiple) {
    
    dose_rows <- subjects %>%
      
      transmute(
        
        ID,
        
        time = 0,
        
        evid = 1,
        
        cmt = 1,
        
        amt =
          dose_mg,
        
        rate =
          rate_mgh,
        
        WT
      )
    
    
    obs_times <-
      sort(
        unique(
          c(
            
            seq(
              0,
              t_end_sd,
              by = delta_sd
            ),
            
            infdur_h
          )
        )
      )
    
    
    # ==========================================================
    # MULTIPLE DOSE
    # ==========================================================
    
  } else {
    
    
    dose_times <-
      seq(
        0,
        by = tau,
        length.out = n_dose
      )
    
    
    dose_rows <- crossing(
      
      subjects,
      
      time =
        dose_times
      
    ) %>%
      
      transmute(
        
        ID,
        
        time,
        
        evid = 1,
        
        cmt = 1,
        
        amt =
          dose_mg,
        
        rate =
          rate_mgh,
        
        WT
      )
    
    
    obs_times <-
      sort(
        unique(
          c(
            
            seq(
              0,
              t_end_md,
              by = delta_md
            ),
            
            dose_times,
            
            dose_times +
              infdur_h
          )
        )
      )
    
  }
  
  
  # ----------------------------------------------------------
  # Observation rows
  # ----------------------------------------------------------
  
  obs_rows <- crossing(
    
    subjects %>%
      select(
        ID,
        WT
      ),
    
    time =
      obs_times
    
  ) %>%
    
    mutate(
      
      evid = 0,
      
      cmt = 0,
      
      amt = 0,
      
      rate = 0
      
    )
  
  
  # ----------------------------------------------------------
  # Combine dosing and observation rows
  #
  # Dose rows are placed before observation rows
  # when they occur at the same nominal time.
  # ----------------------------------------------------------
  
  bind_rows(
    dose_rows,
    obs_rows
  ) %>%
    
    arrange(
      ID,
      time,
      desc(evid)
    )
  
}





# ============================================================
# FIGURE 3
# POPULATION — SINGLE IV INFUSION
# ============================================================

fig3_list <- lapply(
  seq_along(
    doses_mgkg
  ),
  function(i) {
    
    d <-
      doses_mgkg[i]
    
    
    data_i <-
      make_omep_population(
        
        dose_mgkg = d,
        
        multiple = FALSE,
        
        id_offset =
          (i - 1) *
          N,
        
        seed =
          100 + i
      )
    
    
    mod_omep %>%
      
      data_set(
        data_i
      ) %>%
      
      mrgsim(
        carry_out = "evid"
      ) %>%
      
      as_tibble() %>%
      
      filter(
        evid == 0
      ) %>%
      
      mutate(
        
        Dose =
          paste0(
            d,
            " mg/kg"
          )
        
      )
    
  }
)



fig3_raw <- bind_rows(
  fig3_list
) %>%
  
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )



# ============================================================
# FIGURE 3 POPULATION SUMMARY
# ============================================================

fig3_sum <- fig3_raw %>%
  
  group_by(
    Dose,
    time
  ) %>%
  
  summarise(
    
    CP_med =
      median(
        CP_ngmL
      ),
    
    CP_p05 =
      quantile(
        CP_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_ngmL,
        0.95
      ),
    
    .groups = "drop"
  )



p3_omep <- ggplot(
  fig3_sum,
  aes(
    time,
    CP_med,
    color = Dose,
    fill = Dose
  )
) +
  
  geom_ribbon(
    aes(
      ymin = CP_p05,
      ymax = CP_p95
    ),
    alpha = 0.25,
    colour = NA
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (h)",
    y = "Omeprazole concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Omeprazole single IV infusion, population",
    subtitle = "Median with 5th–95th percentiles"
  )


p3_omep



# ============================================================
# FIGURE 3 INDIVIDUAL PK METRICS
# ============================================================

fig3_ind <- fig3_raw %>%
  
  filter(
    time <= tau
  ) %>%
  
  arrange(
    Dose,
    ID,
    time
  ) %>%
  
  group_by(
    Dose,
    ID
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      time[
        which.max(
          CP_ngmL
        )
      ],
    
    C12 =
      at_time(
        time,
        CP_ngmL,
        tau
      ),
    
    AUC0_12 =
      auc_trap(
        time,
        CP_ngmL
      ),
    
    .groups = "drop"
  )



fig3_summary <- fig3_ind %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax_med =
      median(
        Cmax
      ),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(
        Tmax_h
      ),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    C12_med =
      median(
        C12
      ),
    
    C12_p05 =
      quantile(
        C12,
        0.05
      ),
    
    C12_p95 =
      quantile(
        C12,
        0.95
      ),
    
    
    AUC0_12_med =
      median(
        AUC0_12
      ),
    
    AUC0_12_p05 =
      quantile(
        AUC0_12,
        0.05
      ),
    
    AUC0_12_p95 =
      quantile(
        AUC0_12,
        0.95
      ),
    
    .groups = "drop"
  )


fig3_summary





# ============================================================
# FIGURE 4
# POPULATION — IV BID FOR 48 h
# ============================================================

fig4_list <- lapply(
  seq_along(
    doses_mgkg
  ),
  function(i) {
    
    d <-
      doses_mgkg[i]
    
    
    data_i <-
      make_omep_population(
        
        dose_mgkg = d,
        
        multiple = TRUE,
        
        id_offset =
          (i - 1) *
          N,
        
        seed =
          200 + i
      )
    
    
    mod_omep %>%
      
      data_set(
        data_i
      ) %>%
      
      mrgsim(
        carry_out = "evid"
      ) %>%
      
      as_tibble() %>%
      
      filter(
        evid == 0
      ) %>%
      
      mutate(
        
        Dose =
          paste0(
            d,
            " mg/kg"
          )
        
      )
    
  }
)



fig4_raw <- bind_rows(
  fig4_list
) %>%
  
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )



# ============================================================
# FIGURE 4 POPULATION SUMMARY
# ============================================================

fig4_sum <- fig4_raw %>%
  
  group_by(
    Dose,
    time
  ) %>%
  
  summarise(
    
    CP_med =
      median(
        CP_ngmL
      ),
    
    CP_p05 =
      quantile(
        CP_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_ngmL,
        0.95
      ),
    
    .groups = "drop"
  )



p4_omep <- ggplot(
  fig4_sum,
  aes(
    time,
    CP_med,
    color = Dose,
    fill = Dose
  )
) +
  
  geom_ribbon(
    aes(
      ymin = CP_p05,
      ymax = CP_p95
    ),
    alpha = 0.25,
    colour = NA
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (h)",
    y = "Omeprazole concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Omeprazole IV BID for 48 h, population",
    subtitle = "Median with 5th–95th percentiles"
  )


p4_omep



# ============================================================
# FIGURE 4
# INDIVIDUAL FINAL-DOSING-INTERVAL PK METRICS
# ============================================================

fig4_ind <- fig4_raw %>%
  
  filter(
    time >= last_dose,
    time <= last_dose + tau
  ) %>%
  
  mutate(
    t_rel =
      time - last_dose
  ) %>%
  
  arrange(
    Dose,
    ID,
    t_rel
  ) %>%
  
  group_by(
    Dose,
    ID
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      t_rel[
        which.max(
          CP_ngmL
        )
      ],
    
    Ctrough =
      at_time(
        t_rel,
        CP_ngmL,
        tau
      ),
    
    AUCtau =
      auc_trap(
        t_rel,
        CP_ngmL
      ),
    
    .groups = "drop"
  )



fig4_summary <- fig4_ind %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax_med =
      median(
        Cmax
      ),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(
        Tmax_h
      ),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    Ctrough_med =
      median(
        Ctrough
      ),
    
    Ctrough_p05 =
      quantile(
        Ctrough,
        0.05
      ),
    
    Ctrough_p95 =
      quantile(
        Ctrough,
        0.95
      ),
    
    
    AUCtau_med =
      median(
        AUCtau
      ),
    
    AUCtau_p05 =
      quantile(
        AUCtau,
        0.05
      ),
    
    AUCtau_p95 =
      quantile(
        AUCtau,
        0.95
      ),
    
    .groups = "drop"
  )


fig4_summary

