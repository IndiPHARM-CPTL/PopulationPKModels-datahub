library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

tacrolimus_lee2006_code <- '
$PROB
- Ref: Lee JY, Hahn HJ, Son IJ, et al. Factors Affecting the Apparent Clearance of Tacrolimus in Korean Adult Liver Transplant Recipients.Pharmacotherapy. 2006;26(8):1069-1077.

$PARAM @annotated
WT    : 60.0 : kg      Body weight
TBIL  : 1.0  : mg/dL   Total bilirubin
INR   : 1.0  : --      International normalized ratio
GRWR  : 1.50 : %       Graft-to-recipient weight ratio
POD0  : 15.0 : day     Postoperative day at start of simulation

$CMT 
CENT

$OMEGA @annotated
ECL : 0.13 : IIV variance on clearance
EV  : 0.46 : IIV variance on volume

$SIGMA
9.8596  

$MAIN

double POD = POD0 + TIME/24.0;
double TBIL_EFF = (TBIL <= 1.2) ? 1.0 : TBIL;
double LPOD_ADD = (POD > 35.0) ? 2.01/POD : 0.0;

double EPOD_F = (POD <= 3.0) ? 0.49 : 1.0;
double INR_F  = (INR > 1.4) ? 0.75 : 1.0;
double GRWR_F = (GRWR <= 1.25) ? 0.86 : 1.0;

double TVCL =
  (0.36 + LPOD_ADD) *
  pow(TBIL_EFF, -0.23) *
  EPOD_F *
  INR_F *
  GRWR_F *
  WT;

double TVV = 568.0;
double CL = TVCL * exp(ETA(1));
double V  = TVV  * exp(ETA(2));

$ODE

dxdt_CENT = -(CL/V) * CENT;

$TABLE
double CP = CENT/V * 1000.0;
double DV = CP + EPS(1);

$CAPTURE CP DV CL V TVCL TVV POD TBIL_EFF EPOD_F INR_F GRWR_F
'
mod_tac <- mcode("tacrolimus_lee2006", tacrolimus_lee2006_code)