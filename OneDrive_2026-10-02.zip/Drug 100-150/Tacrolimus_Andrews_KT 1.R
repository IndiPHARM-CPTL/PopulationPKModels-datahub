library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

tacrolimus_andrews2019_code <- '
$PROB
- Ref: Andrews LM, Hesselink DA, van Schaik RHN, et al. A population pharmacokinetic model to predict the individual starting dose of tacrolimus in adult renal transplant recipients. Br J Clin Pharmacol. 2019;85(3):601-615. doi:10.1111/bcp.13838

$PARAM @annotated
TLAG       : 0.38  : h         Absorption lag time
KA         : 3.58  : 1/h       First-order absorption rate constant
CL_REF     : 23.0  : L/h       Typical apparent clearance
V1_REF     : 692   : L         Typical apparent central volume
Q_REF      : 11.6  : L/h       Typical apparent intercompartmental clearance
V2_REF     : 5340  : L         Typical apparent peripheral volume

AGE        : 56    : year      Recipient age
ALB        : 42    : g/L       Serum albumin
BSA        : 1.93  : m2        Body surface area
CREAT      : 135   : umol/L    Serum creatinine
HCT        : 0.34  : L/L       Haematocrit
LBW        : 60    : kg        Lean body weight
LBW_REF    : 60    : kg        Reference lean body weight

CYP3A5_EXP : 0     : --        0 = CYP3A5 nonexpresser; 1 = expresser
CYP3A4_22  : 0     : --        0 = CYP3A4*1/unknown; 1 = CYP3A4*22 carrier
ASSAY      : 2     : --        1 = immunoassay; 2 = LC-MS/MS

$CMT @annotated
GUT    : Oral dosing/absorption compartment (mg)
CENT   : Central compartment (mg)
PERIPH : Peripheral compartment (mg)

$OMEGA @annotated
ECL : 0.14 : IIV variance on CL/F; IIV 38.6%
EV1 : 0.22 : IIV variance on V1/F; IIV 49.2%
EV2 : 0.25 : IIV variance on V2/F; IIV 53.0%
EQ  : 0.48 : IIV variance on Q/F;  IIV 78.7%

$SIGMA @labels PROP_IMM ADD_IMM PROP_LCMS
0.03
0.77
0.06

$MAIN

ALAG_GUT = TLAG;

double CYP3A5_F = 1.0;
if(CYP3A5_EXP == 1) {
  CYP3A5_F = 1.63;
}

double CYP3A4_F = 1.0;
if(CYP3A4_22 == 1) {
  CYP3A4_F = 0.80;
}

double TVCL =
  CL_REF *
  CYP3A5_F *
  CYP3A4_F *
  pow(AGE/56.0, -0.43) *
  pow(ALB/42.0, 0.43) *
  pow(BSA/1.93, 0.88) *
  pow(CREAT/135.0, -0.14) *
  pow(HCT/0.34, -0.76);

double TVV1 =
  V1_REF *
  pow(LBW/LBW_REF, 1.52);

double TVQ  = Q_REF;
double TVV2 = V2_REF;

double CLi = TVCL * exp(ETA(1));
double V1i = TVV1 * exp(ETA(2));
double V2i = TVV2 * exp(ETA(3));
double Qi  = TVQ  * exp(ETA(4));

$ODE
dxdt_GUT =
  -KA * GUT;

dxdt_CENT =
  KA * GUT
- (CLi/V1i) * CENT
- (Qi/V1i) * CENT
+ (Qi/V2i) * PERIPH;

dxdt_PERIPH =
  (Qi/V1i) * CENT
- (Qi/V2i) * PERIPH;

$TABLE

double CP = CENT/V1i * 1000.0;

double DV = CP;

if(ASSAY == 1) {
  DV = CP * (1.0 + EPS(1)) + EPS(2);
}

if(ASSAY == 2) {
  DV = CP * (1.0 + EPS(3));
}

$CAPTURE
CP DV
'
mod_tac_andrews <- mcode(  "tacrolimus_andrews2019",  tacrolimus_andrews2019_code)


N <- 1000

WT_typ <- 79.4
dose_mgkg <- 0.1
dose_mg <- dose_mgkg * WT_typ

t_end_sd <- 72
t_end_md <- 240

delta_sd <- 0.05
delta_md <- 0.05

mod_tac_typ <- zero_re(mod_tac_andrews)



idata_typ <- tibble(
  ID = 1,
  AGE = 56,
  ALB = 42,
  BSA = 1.93,
  CREAT = 135,
  HCT = 0.34,
  LBW = 60,
  CYP3A5_EXP = 0,
  CYP3A4_22 = 0,
  ASSAY = 2
)



ev_sd <- ev(
  time = 0,
  amt = dose_mg,
  cmt = 1
)



ev_md <- ev(
  time = 0,
  amt = dose_mg,
  cmt = 1,
  ii = 12,
  addl = 19
)



predose_value <- function(time, conc, target) {
  idx <- which(time < target)
  conc[idx[which.max(time[idx])]]
}

fig1_out <- mod_tac_typ %>%
  ev(ev_sd) %>%
  mrgsim(
    idata = idata_typ,
    end = t_end_sd,
    delta = delta_sd
  ) %>%
  as_tibble() %>%
  mutate(group = "Tacrolimus")


p1_tac <- ggplot(
  fig1_out,
  aes(time, CP, color = group)
) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Tacrolimus concentration (ng/mL)",
    color = "Group",
    title = "Figure 1. Tacrolimus 0.1 mg/kg single dose"
  )

p1_tac


fig1_summary <- fig1_out %>%
  group_by(group) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C12 = CP[which.min(abs(time - 12))],
    C24 = CP[which.min(abs(time - 24))],
    C48 = CP[which.min(abs(time - 48))],
    C72 = CP[which.min(abs(time - 72))],
    .groups = "drop"
  )

fig1_summary



fig2_out <- mod_tac_typ %>%
  ev(ev_md) %>%
  mrgsim(
    idata = idata_typ,
    end = t_end_md,
    delta = delta_md
  ) %>%
  as_tibble() %>%
  mutate(group = "Tacrolimus")


p2_tac <- ggplot(
  fig2_out,
  aes(time, CP, color = group)
) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Tacrolimus concentration (ng/mL)",
    color = "Group",
    title = "Figure 2. Tacrolimus 0.1 mg/kg q12h for 10 days"
  )

p2_tac


fig2_trough <- tibble(
  time = seq(12, 240, by = 12)
) %>%
  rowwise() %>%
  mutate(
    Ctrough = predose_value(
      fig2_out$time,
      fig2_out$CP,
      time
    )
  ) %>%
  ungroup()

fig2_trough



fig2_last <- fig2_out %>%
  filter(time >= 228, time <= 240)


fig2_summary <- fig2_last %>%
  group_by(group) %>%
  summarise(
    Cmax_last = max(CP),
    Tmax_last_h = time[which.max(CP)] - 228,
    Ctrough_240h = CP[which.min(abs(time - 240))],
    .groups = "drop"
  )

fig2_summary


set.seed(123)

idata_pop <- tibble(
  ID = 1:N,
  AGE = 56,
  ALB = 42,
  BSA = 1.93,
  CREAT = 135,
  HCT = 0.34,
  LBW = 60,
  CYP3A5_EXP = 0,
  CYP3A4_22 = 0,
  ASSAY = 2
)


fig3_raw <- mod_tac_andrews %>%
  ev(ev_sd) %>%
  mrgsim(
    idata = idata_pop,
    end = t_end_sd,
    delta = delta_sd
  ) %>%
  as_tibble() %>%
  mutate(group = "Tacrolimus")


fig3_sum <- fig3_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP),
    C_p05 = quantile(CP, 0.05),
    C_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )


p3_tac <- ggplot(
  fig3_sum,
  aes(time, C_med, color = group, fill = group)
) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.15,
    colour = NA
  ) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Tacrolimus concentration (ng/mL)",
    color = "Group",
    fill = "Group",
    title = "Figure 3. Tacrolimus 0.1 mg/kg single dose, population"
  )

p3_tac



fig3_ind <- fig3_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C12 = CP[which.min(abs(time - 12))],
    C24 = CP[which.min(abs(time - 24))],
    C48 = CP[which.min(abs(time - 48))],
    C72 = CP[which.min(abs(time - 72))],
    .groups = "drop"
  )


fig3_summary <- fig3_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    C12_med = median(C12),
    C12_p05 = quantile(C12, 0.05),
    C12_p95 = quantile(C12, 0.95),
    
    C24_med = median(C24),
    C24_p05 = quantile(C24, 0.05),
    C24_p95 = quantile(C24, 0.95),
    
    C48_med = median(C48),
    C48_p05 = quantile(C48, 0.05),
    C48_p95 = quantile(C48, 0.95),
    
    C72_med = median(C72),
    C72_p05 = quantile(C72, 0.05),
    C72_p95 = quantile(C72, 0.95),
    
    .groups = "drop"
  )

fig3_summary



fig4_raw <- mod_tac_andrews %>%
  ev(ev_md) %>%
  mrgsim(
    idata = idata_pop,
    end = t_end_md,
    delta = delta_md
  ) %>%
  as_tibble() %>%
  mutate(group = "Tacrolimus")


fig4_sum <- fig4_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP),
    C_p05 = quantile(CP, 0.05),
    C_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )


p4_tac <- ggplot(
  fig4_sum,
  aes(time, C_med, color = group, fill = group)
) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.15,
    colour = NA
  ) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Tacrolimus concentration (ng/mL)",
    color = "Group",
    fill = "Group",
    title = "Figure 4. Tacrolimus 0.1 mg/kg q12h for 10 days, population"
  )

p4_tac


trough_times <- seq(12, 240, by = 12)


fig4_trough_ind <- fig4_raw %>%
  group_by(group, ID) %>%
  group_modify(~{
    tibble(
      time = trough_times,
      Ctrough = sapply(
        trough_times,
        function(tt) {
          predose_value(.x$time, .x$CP, tt)
        }
      )
    )
  }) %>%
  ungroup()


fig4_last <- fig4_raw %>%
  filter(time >= 228, time <= 240) %>%
  group_by(group, ID) %>%
  summarise(
    Cmax_last = max(CP),
    Tmax_last_h = time[which.max(CP)] - 228,
    Ctrough_last = CP[which.min(abs(time - 240))],
    .groups = "drop"
  )


fig4_summary <- fig4_last %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax_last),
    Cmax_p05 = quantile(Cmax_last, 0.05),
    Cmax_p95 = quantile(Cmax_last, 0.95),
    
    Tmax_med_h = median(Tmax_last_h),
    Tmax_p05_h = quantile(Tmax_last_h, 0.05),
    Tmax_p95_h = quantile(Tmax_last_h, 0.95),
    
    Ctrough_med = median(Ctrough_last),
    Ctrough_p05 = quantile(Ctrough_last, 0.05),
    Ctrough_p95 = quantile(Ctrough_last, 0.95),
    
    .groups = "drop"
  )

fig4_summary

p1_tac
p2_tac
p3_tac
p4_tac


fig1_summary
fig2_summary
fig3_summary
fig4_summary