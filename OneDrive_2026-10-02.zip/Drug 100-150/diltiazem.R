library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

diltiazem_code <- '
$PROB
- Ref: Guan XF, Li DY, Yin WJ, et al. Population Pharmacokinetic Modeling of Diltiazem in Chinese Renal Transplant Recipients. Eur J Drug Metab Pharmacokinet. 2018;43(1):55-62. doi:10.1007/s13318-017-0425-y

$PARAM @annotated
KA      : 1.96  : 1/h      First-order absorption rate constant
CL      : 92.4  : L/h      Apparent oral clearance, CL/F
V       : 3550  : L        Apparent volume of distribution, V/F

PROP_SD : 0.326 : --       Proportional residual error SD

$CMT @annotated
DEPOT : Oral absorption compartment
CENT  : Central compartment

$OMEGA @diag @labels ETA_CL ETA_V
0.2803 0.6502

$SIGMA
1

$GLOBAL
double KAi;
double CLi;
double Vi;
double KEi;

$MAIN

KAi = KA;

CLi = CL * exp(ETA(1));
Vi  = V  * exp(ETA(2));

KEi = CLi / Vi;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT  =  KAi * DEPOT
             -KEi * CENT;

$TABLE
double DIL_mgL  = CENT / Vi;
double DIL_ngmL = DIL_mgL * 1000.0;

double DV_ngmL = DIL_ngmL * (1.0 + PROP_SD * EPS(1));

$CAPTURE
DIL_ngmL DV_ngmL
KAi CLi Vi KEi
'

mod <- mcode("diltiazem_guan2017", diltiazem_code)


set.seed(123)

dose_mg <- c(60, 90, 120)

N        <- 1000
tau_h    <- 12
n_days   <- 10
n_doses  <- n_days * 2
addl_md  <- n_doses - 1

t_end_sd <- 24
t_end_md <- 240

delta_sd <- 0.05
delta_md <- 0.05

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q12h x", n_days, " days")

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:N)



fig1_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT"
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = DIL_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Diltiazem concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Diltiazem (60/90/120) twice daily, single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C0_5 = get_nearest(time, CP, 0.5),
    C1   = get_nearest(time, CP, 1),
    C2   = get_nearest(time, CP, 2),
    C8   = get_nearest(time, CP, 8),
    C12  = get_nearest(time, CP, 12),
    C24  = get_nearest(time, CP, 24),
    .groups = "drop"
  )


fig2_list <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = DIL_ngmL,
      Dose = paste0(d, " mg q12h x", n_days, " days")
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Diltiazem concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Diltiazem (60/90/120) twice daily, multi-dose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day10 = max(CP, na.rm = TRUE),
    Tmax_day10 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    C0_5_day10 = get_nearest(time, CP, (n_doses - 1) * tau_h + 0.5),
    C1_day10   = get_nearest(time, CP, (n_doses - 1) * tau_h + 1),
    C2_day10   = get_nearest(time, CP, (n_doses - 1) * tau_h + 2),
    C8_day10   = get_nearest(time, CP, (n_doses - 1) * tau_h + 8),
    Ctrough_day10 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

set.seed(123)

fig3_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT"
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = DIL_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Diltiazem concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Diltiazem (60/90/120) twice daily, single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C0_5 = get_nearest(time, CP, 0.5),
    C1   = get_nearest(time, CP, 1),
    C2   = get_nearest(time, CP, 2),
    C8   = get_nearest(time, CP, 8),
    C12  = get_nearest(time, CP, 12),
    C24  = get_nearest(time, CP, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C0_5_med = median(C0_5, na.rm = TRUE),
    C0_5_p05 = quantile(C0_5, 0.05, na.rm = TRUE),
    C0_5_p95 = quantile(C0_5, 0.95, na.rm = TRUE),
    
    C1_med = median(C1, na.rm = TRUE),
    C1_p05 = quantile(C1, 0.05, na.rm = TRUE),
    C1_p95 = quantile(C1, 0.95, na.rm = TRUE),
    
    C2_med = median(C2, na.rm = TRUE),
    C2_p05 = quantile(C2, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


set.seed(123)

fig4_list <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = DIL_ngmL,
      Dose = paste0(d, " mg q12h x", n_days, " days")
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Diltiazem concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Diltiazem (60/90/120) twice daily, multi-dose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_day10 = max(CP, na.rm = TRUE),
    Tmax_day10 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    C0_5_day10 = get_nearest(time, CP, (n_doses - 1) * tau_h + 0.5),
    C1_day10   = get_nearest(time, CP, (n_doses - 1) * tau_h + 1),
    C2_day10   = get_nearest(time, CP, (n_doses - 1) * tau_h + 2),
    C8_day10   = get_nearest(time, CP, (n_doses - 1) * tau_h + 8),
    Ctrough_day10 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day10_med = median(Cmax_day10, na.rm = TRUE),
    Cmax_day10_p05 = quantile(Cmax_day10, 0.05, na.rm = TRUE),
    Cmax_day10_p95 = quantile(Cmax_day10, 0.95, na.rm = TRUE),
    
    Tmax_day10_med = median(Tmax_day10, na.rm = TRUE),
    Tmax_day10_p05 = quantile(Tmax_day10, 0.05, na.rm = TRUE),
    Tmax_day10_p95 = quantile(Tmax_day10, 0.95, na.rm = TRUE),
    
    C0_5_day10_med = median(C0_5_day10, na.rm = TRUE),
    C0_5_day10_p05 = quantile(C0_5_day10, 0.05, na.rm = TRUE),
    C0_5_day10_p95 = quantile(C0_5_day10, 0.95, na.rm = TRUE),
    
    C1_day10_med = median(C1_day10, na.rm = TRUE),
    C1_day10_p05 = quantile(C1_day10, 0.05, na.rm = TRUE),
    C1_day10_p95 = quantile(C1_day10, 0.95, na.rm = TRUE),
    
    C2_day10_med = median(C2_day10, na.rm = TRUE),
    C2_day10_p05 = quantile(C2_day10, 0.05, na.rm = TRUE),
    C2_day10_p95 = quantile(C2_day10, 0.95, na.rm = TRUE),
    
    C8_day10_med = median(C8_day10, na.rm = TRUE),
    C8_day10_p05 = quantile(C8_day10, 0.05, na.rm = TRUE),
    C8_day10_p95 = quantile(C8_day10, 0.95, na.rm = TRUE),
    
    Ctrough_day10_med = median(Ctrough_day10, na.rm = TRUE),
    Ctrough_day10_p05 = quantile(Ctrough_day10, 0.05, na.rm = TRUE),
    Ctrough_day10_p95 = quantile(Ctrough_day10, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary

