library(mrgsolve)
library(dplyr)
library(tidyr)
library(ggplot2)
library(tibble)

spir_can_code <- '
$PROB
- Ref:Tatipalli M, Siripuram VK, Long T, et al. Model-Informed Optimization of a Pediatric Clinical Pharmacokinetic Trial of a New Spironolactone Liquid Formulation. Pharmaceutics. 2021;13(6):849. Published 2021 Jun 8. doi:10.3390/pharmaceutics13060849

$PARAM @annotated
ALAG1   : 0.156 : h      Absorption lag time for SPIR
KA      : 5.22  : 1/h    SPIR absorption rate constant

CL      : 629   : L/h    SPIR apparent clearance from central compartment
V2      : 517   : L      SPIR central volume
Q       : 89.9  : L/h    SPIR intercompartmental clearance
V3      : 777   : L      SPIR peripheral volume

FM      : 0.7   : --     Fraction metabolized to CAN; fixed in source model
CLM1    : 217   : L/h    SPIR apparent metabolic clearance to CAN

CLM     : 17    : L/h    CAN apparent clearance
V4      : 189   : L      CAN central volume
Q1      : 60    : L/h    CAN intercompartmental clearance
V5      : 448   : L      CAN peripheral volume

WT      : 70    : kg     Body weight for optional allometric scaling
ALLO    : 0     : --     0 = adult parameters as published; 1 = apply allometric scaling

MW_CORR : 1.0   : --     Optional mass conversion factor from SPIR to CAN; default 1

$CMT @annotated
DEPOT  : SPIR absorption depot
SPIR_C : SPIR central compartment
SPIR_P : SPIR peripheral compartment
CAN_C  : CAN central compartment
CAN_P  : CAN peripheral compartment

$OMEGA @block @labels ETA_KA ETA_CL ETA_V2
0.900
0     0.166
0     0.112 0.118

$OMEGA @labels ETA_Q ETA_CLM1 ETA_CLM ETA_V4 ETA_Q1 ETA_V5
0.080 0.180 0.080 0.030 0.070 0.090

$SIGMA @diag
0.080 0.017

$GLOBAL
double KAi;
double CLi;
double V2i;
double Qi;
double V3i;
double CLM1i;
double CLMi;
double V4i;
double Q1i;
double V5i;
double ALAG1i;

double SC_CL;
double SC_V;

double K20_NONMET;
double K24_FORM;
double K23;
double K32;
double K40;
double K45;
double K54;

$MAIN
SC_CL = 1.0;
SC_V  = 1.0;

if(ALLO > 0.5) {
  SC_CL = pow(WT / 70.0, 0.75);
  SC_V  = WT / 70.0;
}

ALAG1i = ALAG1;

KAi   = KA   * exp(ETA(1));

CLi   = CL   * SC_CL * exp(ETA(2));
V2i   = V2   * SC_V  * exp(ETA(3));

Qi    = Q    * SC_CL * exp(ETA(4));
V3i   = V3   * SC_V;

CLM1i = CLM1 * SC_CL * exp(ETA(5));

CLMi  = CLM  * SC_CL * exp(ETA(6));
V4i   = V4   * SC_V  * exp(ETA(7));

Q1i   = Q1   * SC_CL * exp(ETA(8));
V5i   = V5   * SC_V  * exp(ETA(9));

ALAG_DEPOT = ALAG1i;
K20_NONMET = (CLi   * (1.0 - FM)) / V2i;
K24_FORM   = (CLM1i * FM)         / V2i;

K23 = Qi  / V2i;
K32 = Qi  / V3i;

K40 = CLMi / V4i;
K45 = Q1i  / V4i;
K54 = Q1i  / V5i;

$ODE
dxdt_DEPOT  = -KAi * DEPOT;

dxdt_SPIR_C =
    KAi * DEPOT
  - K20_NONMET * SPIR_C
  - K24_FORM   * SPIR_C
  - K23        * SPIR_C
  + K32        * SPIR_P;

dxdt_SPIR_P =
    K23 * SPIR_C
  - K32 * SPIR_P;

dxdt_CAN_C =
    K24_FORM * SPIR_C * MW_CORR
  - K40      * CAN_C
  - K45      * CAN_C
  + K54      * CAN_P;

dxdt_CAN_P =
    K45 * CAN_C
  - K54 * CAN_P;

$TABLE
double CP_SPIR_mgL  = SPIR_C / V2i;
double CP_SPIR_ngmL = CP_SPIR_mgL * 1000.0;

double CP_CAN_mgL   = CAN_C / V4i;
double CP_CAN_ngmL  = CP_CAN_mgL * 1000.0;

double DV_SPIR_ngmL = CP_SPIR_ngmL * (1.0 + EPS(1));
double DV_CAN_ngmL  = CP_CAN_ngmL  * (1.0 + EPS(2));

$CAPTURE
CP_SPIR_ngmL CP_CAN_ngmL
DV_SPIR_ngmL DV_CAN_ngmL
'

mod <- mcode("spironolactone_canrenone_tatipalli2021", spir_can_code)

doses_mg <- c(25, 50, 100)

tau_h    <- 24
n_doses  <- 14
addl_md  <- n_doses - 1

t_end_sd <- 72
t_end_md <- n_doses * tau_h

delta_sd <- 0.1
delta_md <- 0.25

last_dose_h <- (n_doses - 1) * tau_h

get_conc_at <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}
add_units <- function(df) {
  df %>% mutate(time_day = time / 24)}

to_long_analyte <- function(df) {
  df %>%
    pivot_longer(
      cols = c(CP_SPIR_ngmL, CP_CAN_ngmL),
      names_to = "analyte",
      values_to = "CP"
    ) %>%
    mutate(
      analyte = recode(
        analyte,
        CP_SPIR_ngmL = "Spironolactone",
        CP_CAN_ngmL  = "Canrenone"
      )
    )
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(
  ID = 1,
  WT = 70,
  ALLO = 0
)

make_idata_pop <- function(N, seed = 123, allo = 0) {
  set.seed(seed)
  
  tibble(
    ID = 1:N,
    WT = pmin(pmax(rnorm(N, mean = 64, sd = 6.4), 50), 85),
    ALLO = allo
  )
}


fig1_list <- lapply(doses_mg, function(d) {
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    add_units() %>%
    mutate(group = paste0(d, " mg"))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(group = factor(group, levels = paste0(doses_mg, " mg")))

fig1_long <- fig1_out %>%
  to_long_analyte()

p1 <- ggplot(fig1_long, aes(time, CP, color = group)) +
  geom_line(linewidth = 1) +
  facet_wrap(~analyte, scales = "free_y") +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Spironolactone (Canrenone) single dose"
  )

fig1_summary <- fig1_long %>%
  group_by(analyte, group) %>%
  summarise(
    Cmax_ng_mL      = max(CP, na.rm = TRUE),
    Tmax_h          = time[which.max(CP)],
    C12_ng_mL       = get_conc_at(time, CP, 12),
    C24_ng_mL       = get_conc_at(time, CP, 24),
    .groups = "drop"
  )


fig2_list <- lapply(doses_mg, function(d) {
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    add_units() %>%
    mutate(group = paste0(d, " mg QD"))
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(group = factor(group, levels = paste0(doses_mg, " mg QD")))

fig2_long <- fig2_out %>%
  to_long_analyte()

p2 <- ggplot(fig2_long, aes(time_day, CP, color = group)) +
  geom_line(linewidth = 1) +
  facet_wrap(~analyte, scales = "free_y") +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Spironolactone (Canrenone) multi-dose"
  )

fig2_summary <- fig2_long %>%
  group_by(analyte, group) %>%
  summarise(
    Cmax_ss_ng_mL = max(CP[time >= last_dose_h & time <= t_end_md], na.rm = TRUE),
    Tmax_ss_h     = time[which.max(ifelse(time >= last_dose_h & time <= t_end_md, CP, -Inf))] - last_dose_h,
    Cmin_day1     = get_conc_at(time, CP, 24),
    Cmin_day3     = get_conc_at(time, CP, 72),
    Cmin_day7     = get_conc_at(time, CP, 7 * 24),
    Cmin_day14    = get_conc_at(time, CP, 14 * 24),
    .groups = "drop"
  )


N <- 1000
idata_pop <- make_idata_pop(N, seed = 123, allo = 0)

fig3_list <- lapply(doses_mg, function(d) {
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    add_units() %>%
    mutate(group = paste0(d, " mg"))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(group = factor(group, levels = paste0(doses_mg, " mg")))

fig3_long <- fig3_raw %>%
  to_long_analyte()

fig3_sum <- fig3_long %>%
  group_by(group, analyte, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(time_day = time / 24)

p3 <- ggplot(fig3_sum, aes(time, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  facet_wrap(~analyte, scales = "free_y") +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Spironolactone (Canrenone) single dose, population",
  )

fig3_ind <- fig3_long %>%
  group_by(group, analyte, ID) %>%
  summarise(
    Cmax    = max(CP, na.rm = TRUE),
    Tmax    = time[which.max(CP)],
    C12     = get_conc_at(time, CP, 12),
    C24     = get_conc_at(time, CP, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(group, analyte) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


fig4_list <- lapply(doses_mg, function(d) {
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    add_units() %>%
    mutate(group = paste0(d, " mg QD"))
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(group = factor(group, levels = paste0(doses_mg, " mg QD")))

fig4_long <- fig4_raw %>%
  to_long_analyte()

fig4_sum <- fig4_long %>%
  group_by(group, analyte, time_day) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time_day, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  facet_wrap(~analyte, scales = "free_y") +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Spironolactone (Canrenone) multi-dose, population",
  )

fig4_ind <- fig4_long %>%
  group_by(group, analyte, ID) %>%
  summarise(
    Cmax_ss = max(CP[time >= last_dose_h & time <= t_end_md], na.rm = TRUE),
    Tmax_ss = time[which.max(ifelse(time >= last_dose_h & time <= t_end_md, CP, -Inf))] - last_dose_h,
    
    Cmin_day1  = get_conc_at(time, CP, 24),
    Cmin_day3  = get_conc_at(time, CP, 72),
    Cmin_day7  = get_conc_at(time, CP, 7 * 24),
    Cmin_day14 = get_conc_at(time, CP, 14 * 24),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(group, analyte) %>%
  summarise(
    Cmax_ss_med = median(Cmax_ss, na.rm = TRUE),
    Cmax_ss_p05 = quantile(Cmax_ss, 0.05, na.rm = TRUE),
    Cmax_ss_p95 = quantile(Cmax_ss, 0.95, na.rm = TRUE),
    
    Tmax_ss_med = median(Tmax_ss, na.rm = TRUE),
    Tmax_ss_p05 = quantile(Tmax_ss, 0.05, na.rm = TRUE),
    Tmax_ss_p95 = quantile(Tmax_ss, 0.95, na.rm = TRUE),
    
    Cmin_day1_med  = median(Cmin_day1, na.rm = TRUE),
    Cmin_day1_p05  = quantile(Cmin_day1, 0.05, na.rm = TRUE),
    Cmin_day1_p95  = quantile(Cmin_day1, 0.95, na.rm = TRUE),
    
    Cmin_day3_med  = median(Cmin_day3, na.rm = TRUE),
    Cmin_day3_p05  = quantile(Cmin_day3, 0.05, na.rm = TRUE),
    Cmin_day3_p95  = quantile(Cmin_day3, 0.95, na.rm = TRUE),
    
    Cmin_day7_med  = median(Cmin_day7, na.rm = TRUE),
    Cmin_day7_p05  = quantile(Cmin_day7, 0.05, na.rm = TRUE),
    Cmin_day7_p95  = quantile(Cmin_day7, 0.95, na.rm = TRUE),
    
    Cmin_day14_med = median(Cmin_day14, na.rm = TRUE),
    Cmin_day14_p05 = quantile(Cmin_day14, 0.05, na.rm = TRUE),
    Cmin_day14_p95 = quantile(Cmin_day14, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary
