library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

methotrexate_godfrey_code <- '

$PROB
Methotrexate population PK model in rheumatoid arthritis

- Ref: Godfrey C, Sweeney K, Miller K, Hamilton R, Kremer J.
  The population pharmacokinetics of long-term methotrexate
  in rheumatoid arthritis.
  Br J Clin Pharmacol. 1998;46(4):369-376.
  doi:10.1046/j.1365-2125.1998.t01-1-00790.x
  
$PARAM @annotated

TH_CL_WT    : 0.0810 : L/h/kg   Weight coefficient on CL
TH_CL_CRCL  : 0.257  : --       Creatinine clearance coefficient on CL
TH_CL_SEX   : 0.167  : --       Female effect on CL

TH_VC_WT    : 0.311  : L/kg     Weight coefficient on Vc

TH_VP_WT    : 0.469  : L/kg     Weight coefficient on Vp
TH_VP_AGE   : 0.169  : L/year   Age coefficient on Vp

TH_Q        : 4.27   : L/h      Typical Q in male
TH_Q_SEX    : 0.355  : --       Female effect on Q

TH_KA_PO_0  : 4.70   : 1/h      Oral Ka intercept
TH_KA_PO_D  : 0.0439 : --       Dose effect on oral Ka
TH_KA_FED   : 0.507  : --       Fed-state modification of dose effect

TH_KA_IM    : 0.122  : --       Dose coefficient on IM Ka

F_PO        : 0.934  : --       Relative oral bioavailability
LAG_PO      : 0.225  : h        Oral lag time (13.5 min)

WTKG        : 75.6   : kg        Body weight
AGE         : 60     : years     Age
CLCR        : 4.73   : L/h       Creatinine clearance
SEX         : 0      : --        0 male, 1 female
FED         : 0      : --        0 fasted, 1 fed

DOSE_UMOL   : 16.50  : umol      Methotrexate dose


$CMT @annotated
GUT    : Oral absorption compartment (mg)
IMDEP  : Intramuscular absorption compartment (mg)
CENT   : Central compartment (mg)
PERIPH : Peripheral compartment (mg)


$OMEGA @labels ETA_CL ETA_VC ETA_VP ETA_Q ETA_KAPO ETA_KAIM ETA_F
0.073984
0.077841
0.097344
0.164025
0.588289
0.193600
0.016900


$GLOBAL
double CLi;
double VCi;
double VPi;
double Qi;
double KAPOi;
double KAIMi;
double FPOi;


$MAIN
CLi =
  (TH_CL_WT * WTKG +
   TH_CL_CRCL * CLCR)
  * (1.0 - TH_CL_SEX * SEX)
  * exp(ETA(1));


VCi =
  (TH_VC_WT * WTKG)
  * exp(ETA(2));


VPi =
  (TH_VP_WT * WTKG -
   TH_VP_AGE * AGE)
  * exp(ETA(3));


Qi =
  TH_Q
  * (1.0 - TH_Q_SEX * SEX)
  * exp(ETA(4));

KAPOi =
  (TH_KA_PO_0 -
   TH_KA_PO_D * DOSE_UMOL *
   (1.0 - TH_KA_FED * FED))
  * exp(ETA(5));


KAIMi =
  (TH_KA_IM * DOSE_UMOL)
  * exp(ETA(6));



FPOi =
  F_PO * exp(ETA(7));


F_GUT = FPOi;
ALAG_GUT = LAG_PO;

F_IMDEP = 1.0;


$ODE

dxdt_GUT =
  -KAPOi * GUT;

dxdt_IMDEP =
  -KAIMi * IMDEP;

dxdt_CENT =
    KAPOi * GUT
  + KAIMi * IMDEP
  - (CLi / VCi) * CENT
  - (Qi / VCi) * CENT
  + (Qi / VPi) * PERIPH;

dxdt_PERIPH =
    (Qi / VCi) * CENT
  - (Qi / VPi) * PERIPH;


$TABLE
double CP_mgL =
  CENT / VCi;


double CP_uM =
  CP_mgL * 1000.0 / 454.44;

double CP_ngmL =
  CP_mgL;


$CAPTURE
CP_mgL CP_uM CP_ngmL
CLi VCi VPi Qi
KAPOi KAIMi FPOi
WTKG AGE CLCR SEX FED DOSE_UMOL
'

mod_mtx_godfrey <- mcode(
  "methotrexate_godfrey_1998",
  methotrexate_godfrey_code
)

set.seed(123)

N <- 1000

MW_MTX <- 454.44

doses_mg <- c(7.5)

dose_levels <- c("7.5 mg")

routes <- c("Oral", "IM")


mg_to_umol <- function(mg) {
  mg * 1000 / MW_MTX
}


tau <- 7 * 24

# 8 weekly doses
n_dose <- 8

t_end_sd <- 48
t_end_md <- tau * n_dose

last_dose <- (n_dose - 1) * tau

delta_sd <- 0.05
delta_md <- 0.25

idata_typ <- tibble(
  ID = 1,
  WTKG = 75.6,
  AGE = 60,
  CLCR = 4.73,
  SEX = 0,
  FED = 0
)


idata_pop <- tibble(
  ID = 1:N,
  WTKG = 75.6,
  AGE = 60,
  CLCR = 4.73,
  SEX = 0,
  FED = 0
)


mod_typ <- zero_re(mod_mtx_godfrey)

at_time <- function(time, value, target) {
  
  value[
    which.min(
      abs(time - target)
    )
  ]
}


auc_trap <- function(time, conc) {
  
  sum(
    diff(time) *
      (
        head(conc, -1) +
          tail(conc, -1)
      ) / 2
  )
}


fig1_list <- list()


for(d in doses_mg) {
  
  dose_umol <-
    mg_to_umol(d)
  
  
  ev_po <- ev(
    time = 0,
    amt = d,
    cmt = 1
  )
  
  
  po <- mod_typ %>%
    param(
      DOSE_UMOL = dose_umol
    ) %>%
    ev(ev_po) %>%
    mrgsim(
      idata = idata_typ,
      end = t_end_sd,
      delta = delta_sd
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      Route = "Oral",
      time_day = time / 24
    )
  
  
  ev_im <- ev(
    time = 0,
    amt = d,
    cmt = 2
  )
  
  
  im <- mod_typ %>%
    param(
      DOSE_UMOL = dose_umol
    ) %>%
    ev(ev_im) %>%
    mrgsim(
      idata = idata_typ,
      end = t_end_sd,
      delta = delta_sd
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      Route = "IM",
      time_day = time / 24
    )
  
  
  fig1_list[[paste0(d, "_PO")]] <- po
  fig1_list[[paste0(d, "_IM")]] <- im
}


fig1_out <-
  bind_rows(fig1_list) %>%
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    ),
    Route = factor(
      Route,
      levels = routes
    )
  )


p1_mtx <- ggplot(
  fig1_out,
  aes(
    time,
    CP_uM,
    color = Route
  )
) +
  geom_line(
    linewidth = 1
  ) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Methotrexate concentration (µM)",
    color = "Route",
    title =
      "Figure 1. Methotrexate single dose"
  )


p1_mtx


fig1_summary <-
  fig1_out %>%
  group_by(
    Dose,
    Route
  ) %>%
  summarise(
    
    Cmax_uM =
      max(CP_uM),
    
    Tmax_h =
      time[
        which.max(CP_uM)
      ],
    
    C24_uM =
      at_time(
        time,
        CP_uM,
        24
      ),
    
    AUC0_24_uMh =
      auc_trap(
        time[
          time <= 24
        ],
        CP_uM[
          time <= 24
        ]
      ),
    
    .groups = "drop"
  )


fig1_summary



fig2_list <- list()


for(d in doses_mg) {
  
  dose_umol <-
    mg_to_umol(d)
  
  
  ev_po_md <- ev(
    time = 0,
    amt = d,
    cmt = 1,
    ii = tau,
    addl = n_dose - 1
  )
  
  
  po <- mod_typ %>%
    param(
      DOSE_UMOL = dose_umol
    ) %>%
    ev(ev_po_md) %>%
    mrgsim(
      idata = idata_typ,
      end = t_end_md,
      delta = delta_md
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      Route = "Oral",
      time_day = time / 24
    )
  

  
  ev_im_md <- ev(
    time = 0,
    amt = d,
    cmt = 2,
    ii = tau,
    addl = n_dose - 1
  )
  
  
  im <- mod_typ %>%
    param(
      DOSE_UMOL = dose_umol
    ) %>%
    ev(ev_im_md) %>%
    mrgsim(
      idata = idata_typ,
      end = t_end_md,
      delta = delta_md
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      Route = "IM",
      time_day = time / 24
    )
  
  
  fig2_list[[paste0(d, "_PO")]] <- po
  fig2_list[[paste0(d, "_IM")]] <- im
}


fig2_out <-
  bind_rows(fig2_list) %>%
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    ),
    Route = factor(
      Route,
      levels = routes
    )
  )


p2_mtx <- ggplot(
  fig2_out,
  aes(
    time_day,
    CP_uM,
    color = Route
  )
) +
  geom_line(
    linewidth = 1
  ) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Methotrexate concentration (µM)",
    color = "Route",
    title =
      "Figure 2. Methotrexate 7.5 mg weekly for 8 weeks"
  )


p2_mtx


fig2_summary <-
  fig2_out %>%
  filter(
    time >= last_dose,
    time <= last_dose + tau
  ) %>%
  mutate(
    t_rel =
      time - last_dose
  ) %>%
  group_by(
    Dose,
    Route
  ) %>%
  summarise(
    
    Cmax_last =
      max(CP_uM),
    
    Tmax_last_h =
      t_rel[
        which.max(CP_uM)
      ],
    
    C24_last =
      at_time(
        t_rel,
        CP_uM,
        24
      ),
    
    Ctrough_last =
      at_time(
        t_rel,
        CP_uM,
        tau
      ),
    
    AUCtau_last =
      auc_trap(
        t_rel,
        CP_uM
      ),
    
    .groups = "drop"
  )


fig2_summary



set.seed(123)

fig3_list <- list()


for(d in doses_mg) {
  
  dose_umol <-
    mg_to_umol(d)
  
  ev_po <- ev(
    time = 0,
    amt = d,
    cmt = 1
  )
  
  
  po <- mod_mtx_godfrey %>%
    param(
      DOSE_UMOL = dose_umol
    ) %>%
    ev(ev_po) %>%
    mrgsim(
      idata = idata_pop,
      end = t_end_sd,
      delta = delta_sd
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      Route = "Oral",
      time_day = time / 24
    )
  
  ev_im <- ev(
    time = 0,
    amt = d,
    cmt = 2
  )
  
  
  im <- mod_mtx_godfrey %>%
    param(
      DOSE_UMOL = dose_umol
    ) %>%
    ev(ev_im) %>%
    mrgsim(
      idata = idata_pop,
      end = t_end_sd,
      delta = delta_sd
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      Route = "IM",
      time_day = time / 24
    )
  
  
  fig3_list[[paste0(d, "_PO")]] <- po
  fig3_list[[paste0(d, "_IM")]] <- im
}


fig3_raw <-
  bind_rows(fig3_list) %>%
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    ),
    Route = factor(
      Route,
      levels = routes
    )
  )


fig3_sum <-
  fig3_raw %>%
  group_by(
    Dose,
    Route,
    time,
    time_day
  ) %>%
  summarise(
    
    CP_med =
      median(CP_uM),
    
    CP_p05 =
      quantile(
        CP_uM,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_uM,
        0.95
      ),
    
    .groups = "drop"
  )


p3_mtx <- ggplot(
  fig3_sum,
  aes(
    time,
    CP_med,
    color = Route,
    fill = Route
  )
) +
  geom_ribbon(
    aes(
      ymin = CP_p05,
      ymax = CP_p95
    ),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(
    linewidth = 1
  ) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Methotrexate concentration (µM)",
    color = "Route",
    fill = "Route",
    title =
      "Figure 3. Methotrexate single dose, population",
    subtitle =
      "Median with 5th–95th percentiles"
  )


p3_mtx


fig3_ind <-
  fig3_raw %>%
  filter(
    time <= 24
  ) %>%
  arrange(
    Dose,
    Route,
    ID,
    time
  ) %>%
  group_by(
    Dose,
    Route,
    ID
  ) %>%
  summarise(
    
    Cmax =
      max(CP_uM),
    
    Tmax_h =
      time[
        which.max(CP_uM)
      ],
    
    C24 =
      at_time(
        time,
        CP_uM,
        24
      ),
    
    AUC0_24 =
      auc_trap(
        time,
        CP_uM
      ),
    
    .groups = "drop"
  )


fig3_summary <-
  fig3_ind %>%
  group_by(
    Dose,
    Route
  ) %>%
  summarise(
    
    Cmax_med =
      median(Cmax),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    Tmax_med_h =
      median(Tmax_h),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    C24_med =
      median(C24),
    
    C24_p05 =
      quantile(
        C24,
        0.05
      ),
    
    C24_p95 =
      quantile(
        C24,
        0.95
      ),
    
    AUC0_24_med =
      median(AUC0_24),
    
    AUC0_24_p05 =
      quantile(
        AUC0_24,
        0.05
      ),
    
    AUC0_24_p95 =
      quantile(
        AUC0_24,
        0.95
      ),
    
    .groups = "drop"
  )


fig3_summary



set.seed(123)

fig4_list <- list()


for(d in doses_mg) {
  
  dose_umol <-
    mg_to_umol(d)
  
  
  
  ev_po_md <- ev(
    time = 0,
    amt = d,
    cmt = 1,
    ii = tau,
    addl = n_dose - 1
  )
  
  
  po <- mod_mtx_godfrey %>%
    param(
      DOSE_UMOL = dose_umol
    ) %>%
    ev(ev_po_md) %>%
    mrgsim(
      idata = idata_pop,
      end = t_end_md,
      delta = delta_md
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      Route = "Oral",
      time_day = time / 24
    )
  
  
  ev_im_md <- ev(
    time = 0,
    amt = d,
    cmt = 2,
    ii = tau,
    addl = n_dose - 1
  )
  
  
  im <- mod_mtx_godfrey %>%
    param(
      DOSE_UMOL = dose_umol
    ) %>%
    ev(ev_im_md) %>%
    mrgsim(
      idata = idata_pop,
      end = t_end_md,
      delta = delta_md
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      Route = "IM",
      time_day = time / 24
    )
  
  
  fig4_list[[paste0(d, "_PO")]] <- po
  fig4_list[[paste0(d, "_IM")]] <- im
}


fig4_raw <-
  bind_rows(fig4_list) %>%
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    ),
    Route = factor(
      Route,
      levels = routes
    )
  )


fig4_sum <-
  fig4_raw %>%
  group_by(
    Dose,
    Route,
    time,
    time_day
  ) %>%
  summarise(
    
    CP_med =
      median(CP_uM),
    
    CP_p05 =
      quantile(
        CP_uM,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_uM,
        0.95
      ),
    
    .groups = "drop"
  )


p4_mtx <- ggplot(
  fig4_sum,
  aes(
    time_day,
    CP_med,
    color = Route,
    fill = Route
  )
) +
  geom_ribbon(
    aes(
      ymin = CP_p05,
      ymax = CP_p95
    ),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(
    linewidth = 1
  ) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Methotrexate concentration (µM)",
    color = "Route",
    fill = "Route",
    title =
      "Figure 4. Methotrexate 7.5 mg weekly, population",
    subtitle =
      "Median with 5th–95th percentiles"
  )


p4_mtx


fig4_ind <-
  fig4_raw %>%
  filter(
    time >= last_dose,
    time <= last_dose + tau
  ) %>%
  mutate(
    t_rel =
      time - last_dose
  ) %>%
  arrange(
    Dose,
    Route,
    ID,
    t_rel
  ) %>%
  group_by(
    Dose,
    Route,
    ID
  ) %>%
  summarise(
    
    Cmax =
      max(CP_uM),
    
    Tmax_h =
      t_rel[
        which.max(CP_uM)
      ],
    
    C24 =
      at_time(
        t_rel,
        CP_uM,
        24
      ),
    
    Ctrough =
      at_time(
        t_rel,
        CP_uM,
        tau
      ),
    
    AUCtau =
      auc_trap(
        t_rel,
        CP_uM
      ),
    
    .groups = "drop"
  )


fig4_summary <-
  fig4_ind %>%
  group_by(
    Dose,
    Route
  ) %>%
  summarise(
    
    Cmax_med =
      median(Cmax),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    Tmax_med_h =
      median(Tmax_h),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    C24_med =
      median(C24),
    
    C24_p05 =
      quantile(
        C24,
        0.05
      ),
    
    C24_p95 =
      quantile(
        C24,
        0.95
      ),
    
    Ctrough_med =
      median(Ctrough),
    
    Ctrough_p05 =
      quantile(
        Ctrough,
        0.05
      ),
    
    Ctrough_p95 =
      quantile(
        Ctrough,
        0.95
      ),
    
    AUCtau_med =
      median(AUCtau),
    
    AUCtau_p05 =
      quantile(
        AUCtau,
        0.05
      ),
    
    AUCtau_p95 =
      quantile(
        AUCtau,
        0.95
      ),
    
    .groups = "drop"
  )


fig4_summary