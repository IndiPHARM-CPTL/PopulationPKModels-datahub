library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

aripiprazole_code <- '
$PROB
Aripiprazole population PK model: oral and aripiprazole once monthly (AOM)
- Ref: Wang X, Raoufinia A, Bihorel S, Passarell J, Mallikaarjun S, Phillips L.
  Population Pharmacokinetic Modeling and Exposure-Response Analysis for
  Aripiprazole Once Monthly in Subjects With Schizophrenia.
  Clin Pharmacol Drug Dev. 2022;11(2):150-164.
  doi:10.1002/cpdd.1022

$PARAM @annotated
R1           : 9.33     : mg/h  Zero-order oral input rate into DEPOT (fixed)
KA_ORAL      : 0.540    : 1/h   Oral first-order absorption rate (fixed)
KA_IM        : 0.000904 : 1/h   AOM first-order absorption rate (women, BMI 28)
F2           : 1.48     : --    AOM relative bioavailability

CL_EM        : 3.71     : L/h   CL/F, CYP2D6 extensive metabolizer
CL_PM        : 1.88     : L/h   CL/F, CYP2D6 poor metabolizer
VC           : 93.4     : L     Central volume
Q1           : 0.591    : L/h   Intercompartmental CL, peripheral 1 (fixed)
VP1          : 118      : L     Peripheral volume 1 (fixed)
Q2           : 28.8     : L/h   Intercompartmental CL, peripheral 2 (fixed)
VP2          : 134      : L     Peripheral volume 2 (fixed)

BMI          : 28       : kg/m2 Body mass index
MALE         : 1        : --    0 = female, 1 = male
CYP2D6_PM    : 0        : --    1 = CYP2D6 poor metabolizer
CYP2D6_INH   : 0        : --    1 = concomitant CYP2D6 inhibitor
CYP3A4_INH   : 0        : --    1 = concomitant CYP3A4 inhibitor
PHASE3       : 1        : --    1 = phase 3 residual error, 0 = phase 1

TH_KAIM_BMI  : -0.975   : --    BMI exponent on KA_IM (BMI/28)
TH_KAIM_MALE : 0.346    : --    Proportional shift in KA_IM for men
TH_CL_2D6I   : -0.511   : --    CYP2D6 inhibitor effect on CL/F (fixed)
TH_CL_3A4I   : -0.237   : --    CYP3A4 inhibitor effect on CL/F (fixed)

PROP_SD_P1   : 0.2423   : --    Proportional residual SD, phase 1
PROP_SD_P3   : 0.2811   : --    Proportional residual SD, phase 3

$CMT @annotated
DEPOT   : Oral absorption depot (mg)
DEPOT2  : AOM intramuscular depot (mg)
CENT    : Central compartment (mg)
PERIPH1 : Peripheral compartment 1 (mg)
PERIPH2 : Peripheral compartment 2 (mg)

$OMEGA @labels ETA_CL ETA_VC ETA_KAO ETA_KAIM
0.13715 0.93611 0.36048 0.26928

$SIGMA
1

$GLOBAL
double KAOi;
double KAIMi;
double CLi;
double VCi;
double Q1i;
double VP1i;
double Q2i;
double VP2i;

$MAIN
KAOi = KA_ORAL * exp(ETA_KAO);

KAIMi = KA_IM *
        pow(BMI / 28.0, TH_KAIM_BMI) *
        (1.0 + TH_KAIM_MALE * MALE) *
        exp(ETA_KAIM);

double CL_TV = (CYP2D6_PM == 1) ? CL_PM : CL_EM;

CLi = CL_TV *
      (1.0 + TH_CL_2D6I * CYP2D6_INH) *
      (1.0 + TH_CL_3A4I * CYP3A4_INH) *
      exp(ETA_CL);

VCi  = VC * exp(ETA_VC);
Q1i  = Q1;
VP1i = VP1;
Q2i  = Q2;
VP2i = VP2;

R_DEPOT  = R1;       // oral doses given with rate = -1
F_DEPOT2 = F2;

$ODE
dxdt_DEPOT  = -KAOi * DEPOT;

dxdt_DEPOT2 = -KAIMi * DEPOT2;

dxdt_CENT =
    KAOi  * DEPOT
  + KAIMi * DEPOT2
  - (CLi / VCi) * CENT
  - (Q1i / VCi) * CENT + (Q1i / VP1i) * PERIPH1
  - (Q2i / VCi) * CENT + (Q2i / VP2i) * PERIPH2;

dxdt_PERIPH1 =
    (Q1i / VCi) * CENT - (Q1i / VP1i) * PERIPH1;

dxdt_PERIPH2 =
    (Q2i / VCi) * CENT - (Q2i / VP2i) * PERIPH2;

$TABLE
double CP_ngmL = 1000.0 * CENT / VCi;

double PROP_SD = (PHASE3 == 1) ? PROP_SD_P3 : PROP_SD_P1;

double DV_PK =
  CP_ngmL * (1.0 + PROP_SD * EPS(1));

double THALF_ABS_IM_d = log(2.0) / KAIMi / 24.0;

$CAPTURE
CP_ngmL DV_PK THALF_ABS_IM_d
KAOi KAIMi CLi VCi
BMI MALE CYP2D6_PM
'
mod_ari <- mcode("aripiprazole_pk", aripiprazole_code)


N <- 1000

# Oral once daily (therapeutic range used to define the window)
oral_doses_mg <- c(10, 20, 30)
oral_levels <- c("10 mg", "20 mg", "30 mg")
tau_oral <- 24
n_oral <- 60                                   # terminal t1/2 ~7 days
last_oral <- tau_oral * (n_oral - 1)
t_end_oral <- last_oral + tau_oral

# AOM every 28 days (model not valid below 300 mg)
aom_doses_mg <- c(300, 400)
aom_levels <- c("300 mg", "400 mg")
tau_aom <- 672                                 # 28 days in h
n_aom <- 13                                    # absorption t1/2 ~24-32 days
last_aom <- tau_aom * (n_aom - 1)
t_end_aom <- last_aom + tau_aom

# Therapeutic window (Wang 2022 Methods) and relapse Cmin threshold
win_lo <- 94.0
win_hi <- 534
cmin_thr <- 95

# Time-to-relapse model (Table 2): exponential, time in days
#   log(T) = 6.256 + 1.484 * I(Cmin >= 95)  ->  hazard = 1 / exp(log(T))
er_intercept <- 6.256
er_cmin <- 1.484


at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

auc_trap <- function(time, conc) {
  sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2)
}

ss_metrics <- function(df, t_rel_col = "t_rel", tau) {
  df %>%
    summarise(
      Cmax_ss = max(CP_ngmL),
      Tmax_ss_h = t_rel[which.max(CP_ngmL)],
      Cmin_ss = min(CP_ngmL),
      Ctrough_ss = at_time(t_rel, CP_ngmL, tau),
      AUCtau_ss = auc_trap(t_rel, CP_ngmL),
      .groups = "drop"
    )
}




# Reference subject: man, BMI 28, CYP2D6 EM, no inhibitors, phase 3
idata_typ <- tibble(
  ID = 1,
  BMI = 28,
  MALE = 1,
  CYP2D6_PM = 0
)

# Typical EM vs PM for AOM (Wang 2022 Figure 4 panel 2)
idata_typ_pheno <- tibble(
  ID = 1:2,
  BMI = 28,
  MALE = 1,
  CYP2D6_PM = c(0, 1)
)

idata_pop <- tibble(
  ID = 1:N,
  BMI = 28,
  MALE = 1,
  CYP2D6_PM = 0
)

mod_typ <- zero_re(mod_ari)


# Typical AOM absorption half-life (paper: ~24 days men, ~32 days women)
mod_typ %>%
  mrgsim(idata = tibble(ID = 1:2, MALE = c(1, 0)), end = 0) %>%
  as_tibble() %>%
  distinct(ID, MALE, THALF_ABS_IM_d)





# ---------------------------------------------------------------------------
# Figure 1. Typical subject, oral once daily for 60 days
# ---------------------------------------------------------------------------

fig1_list <- lapply(oral_doses_mg, function(d) {
  
  ev_oral <- ev(time = 0, amt = d, cmt = "DEPOT", rate = -1,
                ii = tau_oral, addl = n_oral - 1)
  
  mod_typ %>%
    ev(ev_oral) %>%
    mrgsim(idata = idata_typ, end = t_end_oral, delta = 0.5, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = oral_levels))


p1_ari <- ggplot(fig1_out, aes(time_day, CP_ngmL, color = Dose)) +
  geom_line(linewidth = 0.8) +
  geom_hline(yintercept = c(win_lo, win_hi), linetype = "dashed") +
  scale_x_continuous(breaks = seq(0, n_oral, 7), limits = c(0, n_oral)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Aripiprazole concentration (ng/mL)",
    color = "Oral dose",
    title = paste0("Figure 1. Oral aripiprazole once daily for ", n_oral, " days"),
    subtitle = "Dashed lines: therapeutic window 94.0-534 ng/mL"
  )

p1_ari


fig1_summary <- fig1_out %>%
  filter(time >= last_oral, time <= t_end_oral) %>%
  mutate(t_rel = time - last_oral) %>%
  group_by(Dose) %>%
  ss_metrics(tau = tau_oral)

fig1_summary


# Structural check: AUCtau,ss = Dose / CL (oral F = 1)
fig1_check <- fig1_summary %>%
  mutate(
    dose = as.numeric(sub(" mg", "", as.character(Dose))),
    AUC_expected = 1000 * dose / 3.71,
    pct_diff = 100 * (AUCtau_ss / AUC_expected - 1)
  ) %>%
  select(Dose, AUCtau_ss, AUC_expected, pct_diff)

fig1_check





# ---------------------------------------------------------------------------
# Figure 2. Typical subject, AOM every 28 days, CYP2D6 EM vs PM
# ---------------------------------------------------------------------------

fig2_list <- lapply(aom_doses_mg, function(d) {
  
  ev_aom <- ev(time = 0, amt = d, cmt = "DEPOT2",
               ii = tau_aom, addl = n_aom - 1)
  
  mod_typ %>%
    ev(ev_aom) %>%
    mrgsim(idata = idata_typ_pheno, end = t_end_aom, delta = 6, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(
    Dose = factor(Dose, levels = aom_levels),
    CYP2D6 = factor(ifelse(CYP2D6_PM == 1, "Poor metabolizer", "Extensive metabolizer"),
                    levels = c("Extensive metabolizer", "Poor metabolizer"))
  )


p2_ari <- ggplot(fig2_out, aes(time_day, CP_ngmL, color = Dose)) +
  geom_line(linewidth = 0.8) +
  geom_hline(yintercept = c(win_lo, win_hi), linetype = "dashed") +
  facet_wrap(~ CYP2D6) +
  scale_x_continuous(breaks = seq(0, n_aom * 28, 56), limits = c(0, n_aom * 28)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Aripiprazole concentration (ng/mL)",
    color = "AOM dose",
    title = paste0("Figure 2. AOM every 28 days for ", n_aom, " injections"),
    subtitle = "Dashed lines: therapeutic window 94.0-534 ng/mL"
  )

p2_ari


fig2_summary <- fig2_out %>%
  filter(time >= last_aom, time <= t_end_aom) %>%
  mutate(t_rel = time - last_aom) %>%
  group_by(CYP2D6, Dose) %>%
  ss_metrics(tau = tau_aom) %>%
  mutate(Tmax_ss_d = Tmax_ss_h / 24)

fig2_summary


# Structural check: AUCtau,ss = F2 * Dose / CL
fig2_check <- fig2_summary %>%
  mutate(
    dose = as.numeric(sub(" mg", "", as.character(Dose))),
    CL = ifelse(CYP2D6 == "Poor metabolizer", 1.88, 3.71),
    AUC_expected = 1000 * 1.48 * dose / CL,
    pct_diff = 100 * (AUCtau_ss / AUC_expected - 1)
  ) %>%
  select(CYP2D6, Dose, AUCtau_ss, AUC_expected, pct_diff)

fig2_check
# Paper: 400 mg AOM in a PM "approaches" 534 ng/mL; 300 mg stays in window.





# ---------------------------------------------------------------------------
# Figure 3. Population, oral once daily for 60 days
# ---------------------------------------------------------------------------

fig3_list <- lapply(oral_doses_mg, function(d) {
  
  set.seed(123)
  
  ev_oral <- ev(time = 0, amt = d, cmt = "DEPOT", rate = -1,
                ii = tau_oral, addl = n_oral - 1)
  
  mod_ari %>%
    ev(ev_oral) %>%
    mrgsim(idata = idata_pop, end = t_end_oral, delta = 6,
           add = seq(last_oral, t_end_oral, by = 0.25), obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = oral_levels))


fig3_sum <- fig3_raw %>%
  group_by(Dose, time, time_day) %>%
  summarise(
    CP_med = median(CP_ngmL),
    CP_p05 = quantile(CP_ngmL, 0.05),
    CP_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )


p3_ari <- ggplot(fig3_sum, aes(time_day, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 0.8) +
  geom_hline(yintercept = c(win_lo, win_hi), linetype = "dashed") +
  scale_x_continuous(breaks = seq(0, n_oral, 7), limits = c(0, n_oral)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Aripiprazole concentration (ng/mL)",
    color = "Oral dose",
    fill = "Oral dose",
    title = paste0("Figure 3. Oral aripiprazole once daily for ", n_oral, " days, population"),
    subtitle = "Median with 5th–95th percentiles; dashed lines: therapeutic window"
  )

p3_ari


fig3_ind <- fig3_raw %>%
  filter(time >= last_oral, time <= t_end_oral) %>%
  mutate(t_rel = time - last_oral) %>%
  arrange(Dose, ID, t_rel) %>%
  group_by(Dose, ID) %>%
  ss_metrics(tau = tau_oral)


fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax_ss),
    Cmax_p05 = quantile(Cmax_ss, 0.05),
    Cmax_p75 = quantile(Cmax_ss, 0.75),
    Cmax_p95 = quantile(Cmax_ss, 0.95),
    
    Cmin_med = median(Cmin_ss),
    Cmin_p05 = quantile(Cmin_ss, 0.05),
    Cmin_p95 = quantile(Cmin_ss, 0.95),
    
    AUCtau_med = median(AUCtau_ss),
    AUCtau_p05 = quantile(AUCtau_ss, 0.05),
    AUCtau_p95 = quantile(AUCtau_ss, 0.95),
    
    pct_in_window = 100 * mean(Cmin_ss >= win_lo & Cmax_ss <= win_hi),
    pct_Cmin_ge95 = 100 * mean(Cmin_ss >= cmin_thr),
    
    .groups = "drop"
  )

fig3_summary
# Paper window definition: median Cmin,ss at 10 mg = 94.0 ng/mL;
# 75th percentile Cmax,ss at 30 mg = 534 ng/mL.




# ---------------------------------------------------------------------------
# Figure 4. Population, AOM every 28 days (CYP2D6 EM)
# ---------------------------------------------------------------------------

fig4_list <- lapply(aom_doses_mg, function(d) {
  
  set.seed(123)
  
  ev_aom <- ev(time = 0, amt = d, cmt = "DEPOT2",
               ii = tau_aom, addl = n_aom - 1)
  
  mod_ari %>%
    ev(ev_aom) %>%
    mrgsim(idata = idata_pop, end = t_end_aom, delta = 24,
           add = seq(last_aom, t_end_aom, by = 2), obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = aom_levels))


fig4_sum <- fig4_raw %>%
  group_by(Dose, time, time_day) %>%
  summarise(
    CP_med = median(CP_ngmL),
    CP_p05 = quantile(CP_ngmL, 0.05),
    CP_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )


p4_ari <- ggplot(fig4_sum, aes(time_day, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 0.8) +
  geom_hline(yintercept = c(win_lo, win_hi), linetype = "dashed") +
  scale_x_continuous(breaks = seq(0, n_aom * 28, 56), limits = c(0, n_aom * 28)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Aripiprazole concentration (ng/mL)",
    color = "AOM dose",
    fill = "AOM dose",
    title = paste0("Figure 4. AOM every 28 days for ", n_aom, " injections, population"),
    subtitle = "Median with 5th–95th percentiles; dashed lines: therapeutic window"
  )

p4_ari


fig4_ind <- fig4_raw %>%
  filter(time >= last_aom, time <= t_end_aom) %>%
  mutate(t_rel = time - last_aom) %>%
  arrange(Dose, ID, t_rel) %>%
  group_by(Dose, ID) %>%
  ss_metrics(tau = tau_aom)


fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_mean = mean(Cmax_ss),
    Cmax_med = median(Cmax_ss),
    Cmax_p05 = quantile(Cmax_ss, 0.05),
    Cmax_p95 = quantile(Cmax_ss, 0.95),
    
    Cmin_mean = mean(Cmin_ss),
    Cmin_med = median(Cmin_ss),
    Cmin_p05 = quantile(Cmin_ss, 0.05),
    Cmin_p95 = quantile(Cmin_ss, 0.95),
    
    AUCtau_mean = mean(AUCtau_ss),
    AUCtau_med = median(AUCtau_ss),
    
    pct_in_window = 100 * mean(Cmin_ss >= win_lo & Cmax_ss <= win_hi),
    pct_Cmin_ge95 = 100 * mean(Cmin_ss >= cmin_thr),
    
    .groups = "drop"
  )

fig4_summary