library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

acetazolamide_code <- '
$PROB
Acetazolamide IV PopPK model
- Ref: Yue CS, Huynh HH, Raymond C, Charbonneau L, Roy L. Population pharmacokinetic and pharmacodynamic modeling of acetazolamide in peritoneal dialysis patients and healthy volunteers. J Pharm Pharm Sci. 2013;16(1):89-98. doi:10.18433/j3qg7z
- protein binding is concentration-dependent

$PARAM @annotated
CLNR     : 1.53  : L/h    Non-renal clearance
VC       : 5.77  : L      Central volume for total ACTZ
Q1       : 10.2  : L/h    Distributional clearance between central and peripheral total ACTZ
EXP_AGE  : 1.08  : --     Age exponent on Q1
REF_AGE  : 41.9  : year   Reference age for Q1
VP1      : 6.46  : L      Peripheral volume for total ACTZ

CLRH     : 80.3  : L/h    Renal clearance in healthy volunteers
CLRD     : 1.2   : L/h    Renal clearance in CAPD patients
CLDI     : 1.65  : L/h    Dialysis clearance in CAPD patients

Q2       : 7.97  : L/h    Distributional clearance between total central and unbound ACTZ
VP2      : 6.14  : L      Volume for unbound ACTZ compartment

VMAX     : 1510  : mg/h   Maximal transfer rate from unbound to total ACTZ compartment
KM       : 12.4  : mg/L   Unbound ACTZ concentration associated with 50% VMAX

PT       : 0     : --     Patient type; 0 = healthy volunteer, 1 = CAPD
AGE      : 41.9  : year   Individual age

$CMT 
ACTZ_C ACTZ_P FREE_P

$OMEGA @annotated
ECLNR    : 0.425  : IIV on non-renal clearance
EVC      : 0.225  : IIV on central volume
EQ1      : 0.234  : IIV on Q1
EVP1     : 0.209  : IIV on VP1
ECLRH    : 0.0518 : IIV on renal clearance in healthy volunteers
ECLRD    : 4.32   : IIV on renal clearance in CAPD patients
EVP2     : 0.382  : IIV on VP2
EKM      : 0.0916 : IIV on KM

$MAIN
double CLNRi = CLNR * exp(ECLNR);
double VCi   = VC   * exp(EVC);
double Q1i   = Q1   * pow(AGE / REF_AGE, EXP_AGE) * exp(EQ1);
double VP1i  = VP1  * exp(EVP1);

double CLR_typ = (PT > 0.5) ? CLRD : CLRH;
double ETA_CLR = (PT > 0.5) ? ECLRD : ECLRH;
double CLRi    = CLR_typ * exp(ETA_CLR);

double CLDIi = CLDI;
double Q2i   = Q2;
double VP2i  = VP2 * exp(EVP2);
double KMi   = KM  * exp(EKM);

$ODE
double C_FREE = FREE_P / VP2i;
double BIND_RATE = VMAX * C_FREE / (KMi + C_FREE);

dxdt_ACTZ_C = - ((Q1i + Q2i) / VCi) * ACTZ_C
              + (Q1i / VP1i) * ACTZ_P
              + BIND_RATE;

dxdt_ACTZ_P =   (Q1i / VCi)  * ACTZ_C
              - (Q1i / VP1i) * ACTZ_P;

dxdt_FREE_P =   (Q2i / VCi) * ACTZ_C
              - ((CLNRi + CLRi + PT * CLDIi) / VP2i) * FREE_P
              - BIND_RATE;

$TABLE
double C_TOTAL_ugmL = ACTZ_C / VCi;
double C_FREE_ugmL  = FREE_P / VP2i;

double C_TOTAL_ngmL = C_TOTAL_ugmL * 1000.0;
double C_FREE_ngmL  = C_FREE_ugmL  * 1000.0;


$CAPTURE C_TOTAL_ugmL C_FREE_ugmL C_TOTAL_ngmL C_FREE_ngmL
'
mod <- mcode("acetazolamide_seng_yue_2013_blood_only", acetazolamide_code)

dose_mg <- 500

n_pop <- 1000
set.seed(123)

tau_h    <- 24
n_doses  <- 5
addl_md  <- n_doses - 1

t_end_sd <- 96
t_end_md <- 168

delta_sd <- 0.1
delta_md <- 0.1

last_dose_h <- (n_doses - 1) * tau_h
final_interval_end_h <- last_dose_h + tau_h

infusion_duration_h <- 2 / 60
infusion_rate_mg_h  <- dose_mg / infusion_duration_h

idata_typ <- tibble(
  ID = 1:2,
  PT = c(0, 1),
  AGE = c(29, 54)
)

idata_pop <- tibble(
  ID = 1:n_pop,
  PT = rep(c(0, 1), each = n_pop / 2),
  AGE = case_when(
    PT == 0 ~ pmin(pmax(rnorm(n_pop, mean = 29, sd = 7), 18), 70),
    PT == 1 ~ pmin(pmax(rnorm(n_pop, mean = 54, sd = 6), 18), 80)
  )
)

mod_typ <- zero_re(mod)


get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  
  df$conc[which.min(abs(df$time - t))]
}


make_long_primary <- function(x) {
  x %>%
    pivot_longer(
      cols = c(C_TOTAL_ugmL, C_FREE_ugmL),
      names_to = "analyte",
      values_to = "conc_ugmL"
    ) %>%
    mutate(
      analyte = recode(
        analyte,
        C_TOTAL_ugmL = "Total acetazolamide",
        C_FREE_ugmL  = "Unbound acetazolamide"
      )
    )
}

add_group <- function(x) {
  x %>%
    mutate(
      group = if_else(PT_out > 0.5, "CAPD", "Healthy volunteer"),
      group = factor(group, levels = c("Healthy volunteer", "CAPD"))
    )
}

fig1_raw <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(
    ev(
      time = 0,
      amt  = dose_mg,
      cmt  = 1,
      rate = infusion_rate_mg_h
    )
  ) %>%
  mrgsim(
    end = t_end_sd,
    delta = delta_sd,
    obsonly = TRUE
  ) %>%
  as_tibble() %>%
  add_group() %>%
  mutate(
    dose = paste0(dose_mg, " mg IV")
  )

fig1 <- make_long_primary(fig1_raw)

p1 <- ggplot(fig1, aes(x = time, y = conc_ugmL, color = group)) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  labs(
    x = "Time after IV dose (h)",
    y = "Plasma concentration (ug/mL)",
    title = "Figure 1. Acetazolamide single-dose typical blood concentration",
    color = "Group"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(group, analyte, ID) %>%
  summarise(
    Cmax = max(conc_ugmL, na.rm = TRUE),
    Tmax = time[which.max(conc_ugmL)],
    C0_5 = get_conc_at(time, conc_ugmL, 0.5),
    C1   = get_conc_at(time, conc_ugmL, 1),
    C2   = get_conc_at(time, conc_ugmL, 2),
    C4   = get_conc_at(time, conc_ugmL, 4),
    C6   = get_conc_at(time, conc_ugmL, 6),
    C8   = get_conc_at(time, conc_ugmL, 8),
    C12  = get_conc_at(time, conc_ugmL, 12),
    C24  = get_conc_at(time, conc_ugmL, 24),
    C48  = get_conc_at(time, conc_ugmL, 48),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(group, analyte) %>%
  summarise(
    Cmax_ug_mL = median(Cmax, na.rm = TRUE),
    Tmax_h     = median(Tmax, na.rm = TRUE),
    C0_5_ug_mL = median(C0_5, na.rm = TRUE),
    C1_ug_mL   = median(C1, na.rm = TRUE),
    C2_ug_mL   = median(C2, na.rm = TRUE),
    C4_ug_mL   = median(C4, na.rm = TRUE),
    C6_ug_mL   = median(C6, na.rm = TRUE),
    C8_ug_mL   = median(C8, na.rm = TRUE),
    C12_ug_mL  = median(C12, na.rm = TRUE),
    C24_ug_mL  = median(C24, na.rm = TRUE),
    C48_ug_mL  = median(C48, na.rm = TRUE),
    .groups = "drop"
  )

p1
fig1_summary


fig2_raw <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(
    ev(
      time = 0,
      amt  = dose_mg,
      cmt  = 1,
      rate = infusion_rate_mg_h,
      ii   = tau_h,
      addl = addl_md
    )
  ) %>%
  mrgsim(
    end = t_end_md,
    delta = delta_md,
    obsonly = TRUE
  ) %>%
  as_tibble() %>%
  add_group() %>%
  mutate(
    dose = paste0(dose_mg, " mg IV q24h x", n_doses)
  )

fig2 <- make_long_primary(fig2_raw)

p2 <- ggplot(fig2, aes(x = time, y = conc_ugmL, color = group)) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  labs(
    x = "Time (h)",
    y = "Plasma concentration (ug/mL)",
    title = "Figure 2. Acetazolamide q24h multiple-dose typical blood concentration",
    color = "Group"
  ) +
  theme_bw()

fig2_ind <- fig2 %>%
  group_by(group, analyte, ID) %>%
  summarise(
    AUC_final_interval = calc_auc(time, conc_ugmL, last_dose_h, final_interval_end_h),
    Cmax_final_interval = max(
      conc_ugmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ugmL, -Inf))
    ] - last_dose_h,
    C24_after_last = get_conc_at(time, conc_ugmL, final_interval_end_h),
    C24_day1       = get_conc_at(time, conc_ugmL, 24),
    C48            = get_conc_at(time, conc_ugmL, 48),
    C96            = get_conc_at(time, conc_ugmL, 96),
    C120           = get_conc_at(time, conc_ugmL, 120),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(group, analyte) %>%
  summarise(
    Cmax_final_interval_ug_mL = median(Cmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_h     = median(Tmax_final_interval, na.rm = TRUE),
    C24_after_last_ug_mL      = median(C24_after_last, na.rm = TRUE),
    C24_day1_ug_mL            = median(C24_day1, na.rm = TRUE),
    C48_ug_mL                 = median(C48, na.rm = TRUE),
    C96_ug_mL                 = median(C96, na.rm = TRUE),
    C120_ug_mL                = median(C120, na.rm = TRUE),
    AUC_final_interval_ug_h_mL = median(AUC_final_interval, na.rm = TRUE),
    .groups = "drop"
  )

p2
fig2_summary


fig3_raw <- mod %>%
  idata_set(idata_pop) %>%
  ev(
    ev(
      time = 0,
      amt  = dose_mg,
      cmt  = 1,
      rate = infusion_rate_mg_h
    )
  ) %>%
  mrgsim(
    end = t_end_sd,
    delta = delta_sd,
    obsonly = TRUE
  ) %>%
  as_tibble() %>%
  add_group() %>%
  mutate(
    dose = paste0(dose_mg, " mg IV")
  )

fig3 <- make_long_primary(fig3_raw)

fig3_sum <- fig3 %>%
  group_by(group, analyte, time) %>%
  summarise(
    CP_med = median(conc_ugmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ugmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ugmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  labs(
    x = "Time after IV dose (h)",
    y = "Plasma concentration (ug/mL)",
    title = "Figure 3. Acetazolamide single-dose population blood concentration",
    color = "Group",
    fill = "Group"
  ) +
  theme_bw()

fig3_ind <- fig3 %>%
  group_by(group, analyte, ID) %>%
  summarise(
    Cmax = max(conc_ugmL, na.rm = TRUE),
    Tmax = time[which.max(conc_ugmL)],
    C0_5 = get_conc_at(time, conc_ugmL, 0.5),
    C1   = get_conc_at(time, conc_ugmL, 1),
    C2   = get_conc_at(time, conc_ugmL, 2),
    C4   = get_conc_at(time, conc_ugmL, 4),
    C6   = get_conc_at(time, conc_ugmL, 6),
    C8   = get_conc_at(time, conc_ugmL, 8),
    C12  = get_conc_at(time, conc_ugmL, 12),
    C24  = get_conc_at(time, conc_ugmL, 24),
    C48  = get_conc_at(time, conc_ugmL, 48),
    AUC0_24 = calc_auc(time, conc_ugmL, 0, 24),
    AUC0_48 = calc_auc(time, conc_ugmL, 0, 48),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(group, analyte) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C1_med = median(C1, na.rm = TRUE),
    C1_p05 = quantile(C1, 0.05, na.rm = TRUE),
    C1_p95 = quantile(C1, 0.95, na.rm = TRUE),
    
    C2_med = median(C2, na.rm = TRUE),
    C2_p05 = quantile(C2, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2, 0.95, na.rm = TRUE),
    
    C4_med = median(C4, na.rm = TRUE),
    C4_p05 = quantile(C4, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    AUC0_24_med = median(AUC0_24, na.rm = TRUE),
    AUC0_24_p05 = quantile(AUC0_24, 0.05, na.rm = TRUE),
    AUC0_24_p95 = quantile(AUC0_24, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3
fig3_summary

fig4_raw <- mod %>%
  idata_set(idata_pop) %>%
  ev(
    ev(
      time = 0,
      amt  = dose_mg,
      cmt  = 1,
      rate = infusion_rate_mg_h,
      ii   = tau_h,
      addl = addl_md
    )
  ) %>%
  mrgsim(
    end = t_end_md,
    delta = delta_md,
    obsonly = TRUE
  ) %>%
  as_tibble() %>%
  add_group() %>%
  mutate(
    dose = paste0(dose_mg, " mg IV q24h x", n_doses)
  )

fig4 <- make_long_primary(fig4_raw)

fig4_sum <- fig4 %>%
  group_by(group, analyte, time) %>%
  summarise(
    CP_med = median(conc_ugmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ugmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ugmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(x = time, y = CP_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  labs(
    x = "Time (h)",
    y = "Plasma concentration (ug/mL)",
    title = "Figure 4. Acetazolamide q24h multiple-dose population blood concentration",
    color = "Group",
    fill = "Group"
  ) +
  theme_bw()

fig4_ind <- fig4 %>%
  group_by(group, analyte, ID) %>%
  summarise(
    AUC_final_interval = calc_auc(time, conc_ugmL, last_dose_h, final_interval_end_h),
    Cmax_final_interval = max(
      conc_ugmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ugmL, -Inf))
    ] - last_dose_h,
    C24_after_last = get_conc_at(time, conc_ugmL, final_interval_end_h),
    C24_day1       = get_conc_at(time, conc_ugmL, 24),
    C48            = get_conc_at(time, conc_ugmL, 48),
    C96            = get_conc_at(time, conc_ugmL, 96),
    C120           = get_conc_at(time, conc_ugmL, 120),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(group, analyte) %>%
  summarise(
    Cmax_final_interval_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_final_interval_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_final_interval_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_final_interval_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_final_interval_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C24_after_last_med = median(C24_after_last, na.rm = TRUE),
    C24_after_last_p05 = quantile(C24_after_last, 0.05, na.rm = TRUE),
    C24_after_last_p95 = quantile(C24_after_last, 0.95, na.rm = TRUE),
    
    C24_day1_med = median(C24_day1, na.rm = TRUE),
    C24_day1_p05 = quantile(C24_day1, 0.05, na.rm = TRUE),
    C24_day1_p95 = quantile(C24_day1, 0.95, na.rm = TRUE),
    
    C96_med = median(C96, na.rm = TRUE),
    C96_p05 = quantile(C96, 0.05, na.rm = TRUE),
    C96_p95 = quantile(C96, 0.95, na.rm = TRUE),
    
    C120_med = median(C120, na.rm = TRUE),
    C120_p05 = quantile(C120, 0.05, na.rm = TRUE),
    C120_p95 = quantile(C120, 0.95, na.rm = TRUE),
    
    AUC_final_interval_med = median(AUC_final_interval, na.rm = TRUE),
    AUC_final_interval_p05 = quantile(AUC_final_interval, 0.05, na.rm = TRUE),
    AUC_final_interval_p95 = quantile(AUC_final_interval, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4
fig4_summary