library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

furosemide_code <- '
$PROB
- Ref: Kodati D, Yellu N. Population pharmacokinetic modeling of furosemide in patients with hypertension and fluid overload conditions. Pharmacol Rep. 2017;69(3):492-496. doi:10.1016/j.pharep.2017.01.006

$PARAM @annotated
KA       : 0.76616 : 1/h     First-order absorption rate constant
V1       : 4.419   : L       Apparent central volume, V/F
V2       : 7.9634  : L       Apparent peripheral volume, V2/F
CL       : 15.054  : L/h     Apparent clearance, CL/F
Q        : 0.4861  : L/h     Apparent intercompartmental clearance, CL2/F
TLAG     : 0.4297  : h       Absorption lag time

DCLDCRCL : -0.3053 : --      CRCL effect on CL/F
DCLDAGE  : 0.2534  : --      Age effect on CL/F

CRCL     : 90      : mL/min  Def creatinine clearance
AGE      : 53      : years   Def age
REF_CRCL : 69.65   : mL/min  Ref CRCL
REF_AGE  : 53      : years   Ref age
COV_ON   : 1       : --      0 = no covariate effect; 1 = CRCL and AGE effects

$CMT GUT CENT PERIPH

$OMEGA @annotated
EKA   : 0.01691 : IIV on KA
EV1   : 0.0548  : IIV on V1/F
EV2   : 0.5980  : IIV on V2/F
ECL   : 0.0606  : IIV on CL/F
EQ    : 1.0162  : IIV on Q/F
ETLAG : 0.0119  : IIV on TLAG

$MAIN
double crcl_eff = 1.0;
double age_eff  = 1.0;

if(COV_ON == 1.0) {
  crcl_eff = pow(CRCL / REF_CRCL, DCLDCRCL);
  age_eff  = pow(AGE  / REF_AGE,  DCLDAGE);
}

double KAi    = KA   * exp(EKA);
double V1i    = V1   * exp(EV1);
double V2i    = V2   * exp(EV2);
double CLi    = CL   * crcl_eff * age_eff * exp(ECL);
double Qi     = Q    * exp(EQ);
double TLAGi  = TLAG * exp(ETLAG);

ALAG_GUT = TLAGi;

$ODE
dxdt_GUT    = -KAi * GUT;

dxdt_CENT   =  KAi * GUT
             - (CLi / V1i) * CENT
             - (Qi  / V1i) * CENT
             + (Qi  / V2i) * PERIPH;

dxdt_PERIPH =  (Qi / V1i) * CENT
             - (Qi / V2i) * PERIPH;

$TABLE
double CP_mgL  = CENT / V1i;
double CP_ngmL = CP_mgL * 1000.0;

$CAPTURE CP_mgL CP_ngmL
'
mod <- mcode("furosemide_oral_kodati_2017", furosemide_code)


dose_mg <- c(20, 40, 80)

n_pop <- 1000
set.seed(123)

tau_h    <- 6
n_doses  <- 12
addl_md  <- n_doses - 1

t_end_sd <- 24
t_end_md <- 72

delta_sd <- 0.02
delta_md <- 0.02

idata_pop <- tibble(
  ID = 1:n_pop,
  AGE = pmin(pmax(rnorm(n_pop, mean = 53, sd = 12), 18), 90),
  CRCL = pmin(pmax(rlnorm(n_pop, meanlog = log(69.65), sdlog = 0.35), 15), 180),
  REF_AGE = 53,
  REF_CRCL = 69.65,
  COV_ON = 1
)

idata_typ <- tibble(
  ID = 1,
  AGE = 53,
  CRCL = 69.65,
  REF_AGE = 53,
  REF_CRCL = 69.65,
  COV_ON = 0
)

mod_typ <- zero_re(mod)

get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  df$conc[which.min(abs(df$time - t))]
}

last_dose_h <- (n_doses - 1) * tau_h

fig1 <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(time = 0, amt = d, cmt = 1)
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_one) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

p1 <- ggplot(fig1, aes(x = time, y = CP_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after dose (h)",
    y = "Furosemide concentration (ng/mL)",
    title = "Figure 1. Furosemide Q6 single dose",
    color = "Dose"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(dose, ID) %>%
  summarise(
    Cmax = max(CP_ngmL, na.rm = TRUE),
    Tmax = time[which.max(CP_ngmL)],
    C6   = get_conc_at(time, CP_ngmL, 6),
    C12  = get_conc_at(time, CP_ngmL, 12),
    C24  = get_conc_at(time, CP_ngmL, 24),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(dose) %>%
  summarise(
    Cmax_ng_mL = median(Cmax, na.rm = TRUE),
    Tmax_h     = median(Tmax, na.rm = TRUE),
    C6_ng_mL   = median(C6, na.rm = TRUE),
    C12_ng_mL  = median(C12, na.rm = TRUE),
    C24_ng_mL  = median(C24, na.rm = TRUE),
    .groups = "drop"
  )
p1
fig1_summary

fig2 <- lapply(dose_mg, function(d) {
  
  ev_q6_3d <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_q6_3d) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q6h")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q6h"))
  )

last_dose_h <- (n_doses - 1) * tau_h

fig2_ind <- fig2 %>%
  group_by(dose, ID) %>%
  summarise(
    Cmax_final_interval = max(
      CP_ngmL[time >= last_dose_h & time <= t_end_md],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= t_end_md, CP_ngmL, -Inf))
    ] - last_dose_h,
    
    C6_after_last = get_conc_at(time, CP_ngmL, t_end_md),
    
    C6_day1 = get_conc_at(time, CP_ngmL, 6),
    C24     = get_conc_at(time, CP_ngmL, 24),
    C48     = get_conc_at(time, CP_ngmL, 48),
    C72     = get_conc_at(time, CP_ngmL, 72),

    .groups = "drop"
  )

p2 <- ggplot(fig2, aes(x = time, y = CP_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Furosemide concentration (ng/mL)",
    title = "Figure 2. Furosemide Q6 multi-dose",
    color = "Dose"
  ) +
  theme_bw()



fig2_summary <- fig2 %>%
  group_by(dose) %>%
  summarise(
    Cmax_final_interval_ng_mL = max(CP_ngmL[time >= last_dose_h & time <= t_end_md], na.rm = TRUE),
    Tmax_final_interval_h     = time[which.max(ifelse(time >= last_dose_h & time <= t_end_md, CP_ngmL, -Inf))] - last_dose_h,
    C6_after_last_ng_mL       = get_conc_at(time, CP_ngmL, t_end_md),
    C6_day1_ng_mL             = get_conc_at(time, CP_ngmL, 6),
    C24_ng_mL                 = get_conc_at(time, CP_ngmL, 24),
    C48_ng_mL                 = get_conc_at(time, CP_ngmL, 48),
    C72_ng_mL                 = get_conc_at(time, CP_ngmL, 72),
    .groups = "drop"
  )

p2
fig2_summary


fig3_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(time = 0, amt = d, cmt = 1)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig3_sum <- fig3_raw %>%
  group_by(dose, time) %>%
  summarise(
    CP_med = median(CP_ngmL, na.rm = TRUE),
    CP_p05 = quantile(CP_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after dose (h)",
    y = "Furosemide concentration (ng/mL)",
    title = "Figure 3. Furosemide Q6 single dose, population",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig3_ind <- fig3_raw %>%
  group_by(dose, ID) %>%
  summarise(
    Cmax    = max(CP_ngmL, na.rm = TRUE),
    Tmax    = time[which.max(CP_ngmL)],
    C6      = get_conc_at(time, CP_ngmL, 6),
    C12     = get_conc_at(time, CP_ngmL, 12),
    C24     = get_conc_at(time, CP_ngmL, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C6_med = median(C6, na.rm = TRUE),
    C6_p05 = quantile(C6, 0.05, na.rm = TRUE),
    C6_p95 = quantile(C6, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3
fig3_summary


fig4_raw <- lapply(dose_mg, function(d) {
  
  ev_q6_3d <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_q6_3d) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q6h")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q6h"))
  )

fig4_sum <- fig4_raw %>%
  group_by(dose, time) %>%
  summarise(
    CP_med = median(CP_ngmL, na.rm = TRUE),
    CP_p05 = quantile(CP_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Furosemide concentration (ng/mL)",
    title = "Figure 4. Furosemide Q6 multi-dose, population",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig4_ind <- fig4_raw %>%
  group_by(dose, ID) %>%
  summarise(
    Cmax_final_interval = max(CP_ngmL[time >= last_dose_h & time <= t_end_md], na.rm = TRUE),
    Tmax_final_interval = time[which.max(ifelse(time >= last_dose_h & time <= t_end_md, CP_ngmL, -Inf))] - last_dose_h,
    C6_after_last       = get_conc_at(time, CP_ngmL, t_end_md),
    C24                 = get_conc_at(time, CP_ngmL, 24),
    C48                 = get_conc_at(time, CP_ngmL, 48),
    C72                 = get_conc_at(time, CP_ngmL, 72),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(dose) %>%
  summarise(
    Cmax_final_interval_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_final_interval_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_final_interval_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_final_interval_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_final_interval_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C6_after_last_med = median(C6_after_last, na.rm = TRUE),
    C6_after_last_p05 = quantile(C6_after_last, 0.05, na.rm = TRUE),
    C6_after_last_p95 = quantile(C6_after_last, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    C48_med = median(C48, na.rm = TRUE),
    C48_p05 = quantile(C48, 0.05, na.rm = TRUE),
    C48_p95 = quantile(C48, 0.95, na.rm = TRUE),
    
    C72_med = median(C72, na.rm = TRUE),
    C72_p05 = quantile(C72, 0.05, na.rm = TRUE),
    C72_p95 = quantile(C72, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )

p4
fig4_summary











