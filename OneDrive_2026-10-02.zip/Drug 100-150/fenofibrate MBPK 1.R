library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

fenofibrate_code <- '
$PROB
Mechanism-based population PK model of fenofibrate / fenofibric acid

- Ref: Back HM, Song B, Pradhan S, et al.
  A mechanism-based pharmacokinetic model of fenofibrate
  for explaining increased drug absorption after food consumption.
  BMC Pharmacol Toxicol. 2018;19:4.
  doi:10.1186/s40360-018-0194-5

- Population: 24 healthy Korean adults
- Studied formulation: fenofibrate 250 mg sustained-release capsule
- Observed analyte: fenofibric acid
- Structural model:
    fenofibrate stomach -> duodenum -> systemic fenofibric acid
    food stomach -> food duodenum
- Food affects gastric emptying, absorption, and apparent Vc/F

$PARAM @annotated
KG       : 0.0412  : 1/h    Gastric emptying rate constant for drug
KMA      : 0.198   : 1/h    Combined metabolism and absorption rate
KEL      : 0.270   : 1/h    Fenofibric acid elimination rate constant
VC       : 12.9    : L      Apparent central volume under fasting

KGP      : 0.00971 : 1/h    Gastric emptying rate constant for calories
KOUT     : 0.00972 : 1/h    Calorie elimination rate from duodenum

EBILE    : 0.0239  : --     Calorie-dependent effect on KMA
EFOOD    : 0.617   : --     Food effect on gastric emptying
TFOOD    : 6.94    : h      Duration of food effect

EVC_STD  : -0.394  : --     Standard meal effect on Vc/F
EVC_HIGH : -0.461  : --     High-fat meal effect on Vc/F

MEAL     : 0       : --     0=fasted, 1=standard/low-fat, 2=high-fat
REPEAT   : 0       : --     0=single dose, 1=repeated daily dosing
TAU      : 24      : h      Dosing interval

$OMEGA @labels ETA_KG ETA_VC ETA_KEL
0.09575
0.62321
0.55662

$SIGMA @sd
0.608

$CMT
DRUG_STOM DRUG_DUOD CENT CAL_STOM CAL_DUOD

$GLOBAL
double KGi, KGPi, VCi, KELi;

$MAIN
KGi = KG * exp(ETA(1));

double VCbase = VC;

if(MEAL == 1) {
  VCbase = 7.82;
}

if(MEAL == 2) {
  VCbase = 6.95;
}

VCi = VCbase * exp(ETA(2));
KELi = KEL * exp(ETA(3));

$ODE
double TADi = SOLVERTIME;

if(REPEAT > 0.5) {
  TADi = fmod(SOLVERTIME, TAU);
}

double KGt = KGi;
double KMAeff = KMA;

if(MEAL > 0 && TADi <= TFOOD) {
  KGt = KGi * (1.0 + EFOOD);
}

if(MEAL == 1) {
  KMAeff = 0.230;
}

if(MEAL == 2) {
  KMAeff = 0.240;
}

dxdt_DRUG_STOM = -KGt * DRUG_STOM;

dxdt_DRUG_DUOD = KGt * DRUG_STOM
                  - KMAeff * DRUG_DUOD;

dxdt_CENT = KMAeff * DRUG_DUOD
             - KELi * CENT;

dxdt_CAL_STOM = 0;
dxdt_CAL_DUOD = 0;

$TABLE
double CP_ugmL = CENT / VCi;
double DV = CP_ugmL * (1.0 + EPS(1));

$CAPTURE CP_ugmL
'

mod_feno <- mcode("fenofibrate_back_2018", fenofibrate_code)


dose_mg <- 250

n_pop <- 1000
tau_h <- 24
n_doses <- 7
addl_md <- n_doses - 1

t_end_sd <- 72
delta_sd <- 0.1

t_end_md <- 192
delta_md <- 0.1

last_dose_h <- 144
final_interval_end_h <- 168

mod_typ <- zero_re(mod_feno)

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:n_pop)

meal_sd <- tibble(
  group = c("Fasted", "Standard meal", "High-fat meal"),
  meal_code = c(0, 1, 2),
  calories = c(0, 686.3, 1280)
)

meal_md <- tibble(
  group = c("Fasted", "Low-fat meal", "High-fat meal"),
  meal_code = c(0, 1, 2),
  calories = c(0, 400, 1280)
)

at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

auc_trap <- function(time, conc) {
  sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2)
}

make_sd_event <- function(calories) {
  ev_drug <- ev(time = 0, amt = 250, cmt = 1)
  
  if(calories == 0) {
    return(ev_drug)
  }
  
  ev_food <- ev(time = 0, amt = calories, cmt = 4)
  
  c(ev_drug, ev_food)
}

make_md_event <- function(calories) {
  ev_drug <- ev(time = 0, amt = 250, cmt = 1, ii = 24, addl = 6)
  
  if(calories == 0) {
    return(ev_drug)
  }
  
  ev_food <- ev(time = 0, amt = calories, cmt = 4, ii = 24, addl = 6)
  
  c(ev_drug, ev_food)
}


fig1_list <- lapply(seq_len(nrow(meal_sd)), function(i) {
  ev_i <- make_sd_event(meal_sd$calories[i])
  
  mod_typ %>%
    param(MEAL = meal_sd$meal_code[i], REPEAT = 0) %>%
    idata_set(idata_typ) %>%
    ev(ev_i) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(group = meal_sd$group[i])
})

fig1_out <- bind_rows(fig1_list)

p1 <- ggplot(fig1_out, aes(time, CP_ugmL, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time after dose (hours)",
    y = "Fenofibric acid concentration (ug/mL)",
    color = "Condition",
    title = "Figure 1. Fenofibrate 250 mg SR single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(group) %>%
  summarise(
    Cmax = max(CP_ugmL),
    Tmax_h = time[which.max(CP_ugmL)],
    C6h = at_time(time, CP_ugmL, 6),
    C12h = at_time(time, CP_ugmL, 12),
    C24h = at_time(time, CP_ugmL, 24),
    C48h = at_time(time, CP_ugmL, 48),
    C72h = at_time(time, CP_ugmL, 72),
    .groups = "drop"
  )


fig2_list <- lapply(seq_len(nrow(meal_md)), function(i) {
  ev_i <- make_md_event(meal_md$calories[i])
  
  mod_typ %>%
    param(MEAL = meal_md$meal_code[i], REPEAT = 1) %>%
    idata_set(idata_typ) %>%
    ev(ev_i) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(group = meal_md$group[i])
})

fig2_out <- bind_rows(fig2_list)

p2 <- ggplot(fig2_out, aes(time, CP_ugmL, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Fenofibric acid concentration (ug/mL)",
    color = "Condition",
    title = "Figure 2. Fenofibrate 250 mg q24h x7"
  )

fig2_summary <- fig2_out %>%
  group_by(group) %>%
  summarise(
    Cmax_final = max(CP_ugmL[time >= 144 & time <= 168]),
    Tmax_final_h = time[time >= 144 & time <= 168][which.max(CP_ugmL[time >= 144 & time <= 168])] - 144,
    Ctrough_final = at_time(time, CP_ugmL, 168),
    C24h = at_time(time, CP_ugmL, 24),
    C48h = at_time(time, CP_ugmL, 48),
    C72h = at_time(time, CP_ugmL, 72),
    C96h = at_time(time, CP_ugmL, 96),
    C120h = at_time(time, CP_ugmL, 120),
    C144h = at_time(time, CP_ugmL, 144),
    C168h = at_time(time, CP_ugmL, 168),
    .groups = "drop"
  )


fig3_list <- lapply(seq_len(nrow(meal_sd)), function(i) {
  set.seed(123)
  
  ev_i <- make_sd_event(meal_sd$calories[i])
  
  mod_feno %>%
    param(MEAL = meal_sd$meal_code[i], REPEAT = 0) %>%
    idata_set(idata_pop) %>%
    ev(ev_i) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(group = meal_sd$group[i])
})

fig3_raw <- bind_rows(fig3_list)

fig3_sum <- fig3_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP_ugmL),
    C_p05 = quantile(CP_ugmL, 0.05),
    C_p95 = quantile(CP_ugmL, 0.95),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.15, colour = NA) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time after dose (hours)",
    y = "Fenofibric acid concentration (ug/mL)",
    color = "Condition",
    fill = "Condition",
    title = "Figure 3. Fenofibrate 250 mg SR single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax = max(CP_ugmL),
    Tmax_h = time[which.max(CP_ugmL)],
    C6h = at_time(time, CP_ugmL, 6),
    C12h = at_time(time, CP_ugmL, 12),
    C24h = at_time(time, CP_ugmL, 24),
    C48h = at_time(time, CP_ugmL, 48),
    C72h = at_time(time, CP_ugmL, 72),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med = median(Tmax_h),
    Tmax_p05 = quantile(Tmax_h, 0.05),
    Tmax_p95 = quantile(Tmax_h, 0.95),
    
    C6h_med = median(C6h),
    C6h_p05 = quantile(C6h, 0.05),
    C6h_p95 = quantile(C6h, 0.95),
    
    C12h_med = median(C12h),
    C12h_p05 = quantile(C12h, 0.05),
    C12h_p95 = quantile(C12h, 0.95),
    
    C24h_med = median(C24h),
    C24h_p05 = quantile(C24h, 0.05),
    C24h_p95 = quantile(C24h, 0.95),
    
    C48h_med = median(C48h),
    C48h_p05 = quantile(C48h, 0.05),
    C48h_p95 = quantile(C48h, 0.95),
    
    C72h_med = median(C72h),
    C72h_p05 = quantile(C72h, 0.05),
    C72h_p95 = quantile(C72h, 0.95),
    
    .groups = "drop"
  )


fig4_list <- lapply(seq_len(nrow(meal_md)), function(i) {
  set.seed(123)
  
  ev_i <- make_md_event(meal_md$calories[i])
  
  mod_feno %>%
    param(MEAL = meal_md$meal_code[i], REPEAT = 1) %>%
    idata_set(idata_pop) %>%
    ev(ev_i) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(group = meal_md$group[i])
})

fig4_raw <- bind_rows(fig4_list)

fig4_sum <- fig4_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP_ugmL),
    C_p05 = quantile(CP_ugmL, 0.05),
    C_p95 = quantile(CP_ugmL, 0.95),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.15, colour = NA) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Fenofibric acid concentration (ug/mL)",
    color = "Condition",
    fill = "Condition",
    title = "Figure 4. Fenofibrate 250 mg q24h x7, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= 144, time <= 168) %>%
  group_by(group, ID) %>%
  summarise(
    Cmax = max(CP_ugmL),
    Tmax_h = time[which.max(CP_ugmL)] - 144,
    Ctrough = at_time(time, CP_ugmL, 168),
    AUCtau = auc_trap(time, CP_ugmL),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med = median(Tmax_h),
    Tmax_p05 = quantile(Tmax_h, 0.05),
    Tmax_p95 = quantile(Tmax_h, 0.95),
    
    Ctrough_med = median(Ctrough),
    Ctrough_p05 = quantile(Ctrough, 0.05),
    Ctrough_p95 = quantile(Ctrough, 0.95),
    
    AUCtau_med = median(AUCtau),
    AUCtau_p05 = quantile(AUCtau, 0.05),
    AUCtau_p95 = quantile(AUCtau, 0.95),
    
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary