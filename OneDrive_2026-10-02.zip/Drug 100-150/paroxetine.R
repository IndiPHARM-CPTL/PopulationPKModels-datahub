library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

paroxetine_code <- '
$PROB
Paroxetine population PK model
- Ref: Shigetome K, Egashira T, Tomita T, Higa N, Iwashita K, Morita K,
  Nishimura M, Kaneko T, Maeda H, Yamada KD, Kajiwara-Morita A, Oniki K,
  Yasui-Furukori N, Saruwatari J.
  Effect of Cumulative Exposure on the Efficacy of Paroxetine:
  A Population Pharmacokinetic-Pharmacodynamic and Machine Learning Analyses.
  CPT Pharmacometrics Syst Pharmacol. 2025;14(6):1119-1127.
  doi:10.1002/psp4.70032


$PARAM @annotated
CLF         : 23.6   : L/h    Apparent clearance (typical)
VF          : 1010   : L      Apparent volume (fixed)

AGE         : 41.5   : y      Age
WT          : 58.6   : kg     Total body weight

AGE_REF     : 41.5   : y      Age normalizing value
WT_REF      : 58.6   : kg     Weight normalizing value

TH_CL_AGE   : -0.536 : --     Age effect on CL/F
TH_CL_WT    : 0.563  : --     Weight effect on CL/F

PROP_SD     : 0.3937 : --     Proportional residual SD (sqrt(0.155))

$CMT @annotated
CENT  : Central compartment (mg); oral dose enters here directly

$OMEGA @labels ETA_CL
0.307

$SIGMA
1

$GLOBAL
double CLFi;
double VFi;

$MAIN
CLFi = CLF *
       pow(AGE / AGE_REF, TH_CL_AGE) *
       pow(WT / WT_REF, TH_CL_WT) *
       exp(ETA_CL);

VFi = VF;

$ODE
dxdt_CENT = -(CLFi / VFi) * CENT;

$TABLE
double CP_ngmL = 1000.0 * CENT / VFi;

double DV_PK =
  CP_ngmL * (1.0 + PROP_SD * EPS(1));

double THALF = log(2.0) * VFi / CLFi;

$CAPTURE
CP_ngmL DV_PK
CLFi VFi THALF
AGE WT
'
mod_parox <- mcode("paroxetine_pk", paroxetine_code)


N <- 1000

doses_mg <- c(10, 20, 40)
dose_levels <- c("10 mg", "20 mg", "40 mg")

tau <- 24
n_dose <- 14

t_end_sd <- 120                 # typical t1/2 ~30 h
last_dose <- tau * (n_dose - 1)
t_end_md <- last_dose + tau

delta_sd <- 0.25
delta_md <- 0.5


at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

auc_trap <- function(time, conc) {
  sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2)
}

rtrunc_norm <- function(n, mean, sd, lo, hi) {
  x <- rnorm(n, mean, sd)
  while (any(bad <- x < lo | x > hi)) x[bad] <- rnorm(sum(bad), mean, sd)
  x
}




# Reference subject at the normalizing values (Table 1 means)
idata_typ <- tibble(
  ID = 1,
  AGE = 41.5,
  WT = 58.6
)

idata_pop <- tibble(
  ID = 1:N,
  AGE = 41.5,
  WT = 58.6
)

mod_typ <- zero_re(mod_parox)


# Note: there is no absorption phase, so each dose produces an instantaneous
# peak. Tmax is therefore the dose time (0 h) and is not informative.


# ---------------------------------------------------------------------------
# Figure 1. Typical subject, single dose
# ---------------------------------------------------------------------------

fig1_list <- lapply(doses_mg, function(d) {
  
  ev_sd <- ev(time = 0, amt = d, cmt = "CENT")
  
  mod_typ %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_typ, end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = paste0(d, " mg"))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


p1_parox <- ggplot(fig1_out, aes(time, CP_ngmL, color = Dose)) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, t_end_sd, 12), limits = c(0, t_end_sd)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Paroxetine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Paroxetine single dose"
  )

p1_parox


fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP_ngmL),
    C24 = at_time(time, CP_ngmL, tau),
    AUC0_24 = auc_trap(time[time <= tau], CP_ngmL[time <= tau]),
    AUC0_last = auc_trap(time, CP_ngmL),
    THALF_h = first(THALF),
    .groups = "drop"
  )

fig1_summary





# ---------------------------------------------------------------------------
# Figure 2. Typical subject, once daily for 14 days
# ---------------------------------------------------------------------------

fig2_list <- lapply(doses_mg, function(d) {
  
  ev_md <- ev(time = 0, amt = d, cmt = "CENT", ii = tau, addl = n_dose - 1)
  
  mod_typ %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_typ, end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


p2_parox <- ggplot(fig2_out, aes(time_day, CP_ngmL, color = Dose)) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, n_dose, 1), limits = c(0, n_dose)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Paroxetine concentration (ng/mL)",
    color = "Dose",
    title = paste0("Figure 2. Paroxetine once daily for ", n_dose, " days")
  )

p2_parox


fig2_summary <- fig2_out %>%
  filter(time > last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_ss = max(CP_ngmL),
    Ctrough_ss = at_time(t_rel, CP_ngmL, tau),
    AUCtau_ss = auc_trap(t_rel, CP_ngmL),
    .groups = "drop"
  )

fig2_summary


# Structural check: at steady state AUCtau = Dose / (CL/F).
# The first grid point after the dose is at 0.5 h, so the trapezoid misses
# the 0-0.5 h segment (~1% low); the closed form is exact.
cl_typ <- fig2_out$CLFi[1]

fig2_check <- fig2_summary %>%
  mutate(
    dose = as.numeric(sub(" mg", "", as.character(Dose))),
    AUC_expected = 1000 * dose / cl_typ,
    pct_diff = 100 * (AUCtau_ss / AUC_expected - 1)
  ) %>%
  select(Dose, AUCtau_ss, AUC_expected, pct_diff)

fig2_check





# ---------------------------------------------------------------------------
# Figure 3. Population, single dose
# ---------------------------------------------------------------------------

fig3_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_sd <- ev(time = 0, amt = d, cmt = "CENT")
  
  mod_parox %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_pop, end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = paste0(d, " mg"))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    CP_med = median(CP_ngmL),
    CP_p05 = quantile(CP_ngmL, 0.05),
    CP_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )


p3_parox <- ggplot(fig3_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, t_end_sd, 12), limits = c(0, t_end_sd)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Paroxetine concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Paroxetine single dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p3_parox


fig3_ind <- fig3_raw %>%
  arrange(Dose, ID, time) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP_ngmL),
    C24 = at_time(time, CP_ngmL, tau),
    AUC0_24 = auc_trap(time[time <= tau], CP_ngmL[time <= tau]),
    THALF = first(THALF),
    .groups = "drop"
  )


fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    C24_med = median(C24),
    C24_p05 = quantile(C24, 0.05),
    C24_p95 = quantile(C24, 0.95),
    
    AUC0_24_med = median(AUC0_24),
    AUC0_24_p05 = quantile(AUC0_24, 0.05),
    AUC0_24_p95 = quantile(AUC0_24, 0.95),
    
    THALF_med_h = median(THALF),
    THALF_p05_h = quantile(THALF, 0.05),
    THALF_p95_h = quantile(THALF, 0.95),
    
    .groups = "drop"
  )

fig3_summary




# ---------------------------------------------------------------------------
# Figure 4. Population, once daily for 14 days
# ---------------------------------------------------------------------------

fig4_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_md <- ev(time = 0, amt = d, cmt = "CENT", ii = tau, addl = n_dose - 1)
  
  mod_parox %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_pop, end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


fig4_sum <- fig4_raw %>%
  group_by(Dose, time, time_day) %>%
  summarise(
    CP_med = median(CP_ngmL),
    CP_p05 = quantile(CP_ngmL, 0.05),
    CP_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )


p4_parox <- ggplot(fig4_sum, aes(time_day, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, n_dose, 1), limits = c(0, n_dose)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Paroxetine concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = paste0("Figure 4. Paroxetine once daily for ", n_dose, " days, population"),
    subtitle = "Median with 5th–95th percentiles"
  )

p4_parox


fig4_ind <- fig4_raw %>%
  filter(time > last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  arrange(Dose, ID, t_rel) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Ctrough = at_time(t_rel, CP_ngmL, tau),
    AUCtau = auc_trap(t_rel, CP_ngmL),
    .groups = "drop"
  )


fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Ctrough_med = median(Ctrough),
    Ctrough_p05 = quantile(Ctrough, 0.05),
    Ctrough_p95 = quantile(Ctrough, 0.95),
    
    AUCtau_med = median(AUCtau),
    AUCtau_p05 = quantile(AUCtau, 0.05),
    AUCtau_p95 = quantile(AUCtau, 0.95),
    
    .groups = "drop"
  )

fig4_summary
