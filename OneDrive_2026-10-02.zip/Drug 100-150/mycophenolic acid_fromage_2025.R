library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

mpa_code <- '
$PROB
Mycophenolic acid (MPA) population PK model
after enteric-coated mycophenolate sodium (EC-MPS; Myfortic)

- Ref:
  Fromage Y, Sayadi H, Koloskoff K, et al.
  Killing several birds with one stone:
  A multi-indication population pharmacokinetic model and
  Bayesian estimator for enteric-coated mycophenolate sodium.
  Br J Clin Pharmacol. 2025;91(5):1396-1408.
  doi:10.1111/bcp.16374



$PLUGIN Rcpp


$PARAM @annotated
NTR1         : 1279.97 : --      Gamma component 1: a1 - 1
MAT1         : 3.0614  : h       Mean absorption time component 1
NTR2         : 394.34  : --      Gamma component 2: a2 - 1
MAT2         : 4.1315  : h       Mean absorption time component 2
FDEPOT       : 0.79    : --      Fraction entering component 1
V            : 12.7065 : L       Apparent volume, 100 / FAIV
KEL          : 1.81    : 1/h     Disposition rate constant
C0           : 2.21    : mg/L    Steady-state trough offset
ADD_SD       : 1.38    : mg/L    Additive residual SD

TX_HEART     : 0       : --      Cardiac transplant indicator
TX_LUNG      : 0       : --      Lung transplant indicator
TX_HCT       : 0       : --      Haematopoietic cell transplant indicator
DIS_AUTOIMMUNE : 0     : --      Autoimmune-disease indicator


$CMT @annotated
DOSESTORE : Stores current EC-MPS dose for one dosing interval (mg)


$OMEGA @labels ETA_MAT1 ETA_MAT2 ETA_V ETA_KEL ETA_C0
0.8464
0.2704
0.0144
0.1936
0.2401


$SIGMA
1


$GLOBAL
double MAT1i;
double MAT2i;
double Vi;
double KELi;
double C0i;

double A1;
double A2;
double B1;
double B2;

double IND_EFFECT;


$MAIN

// ------------------------------------------------------------
// Individual parameters
// ------------------------------------------------------------

// IIV was originally reported on log(b1) and log(b2).
// Since MAT = a/b, the same variance transfers to log(MAT)
// with the sign reversed.
//
// Sign is irrelevant for the marginal random-effect distribution,
// but the indication covariate must be inverted explicitly.

MAT1i =
  MAT1 *
  exp(ETA(1));


// ------------------------------------------------------------
// Indication effect on second absorption component
//
// Paper:
// +0.59 on log(b2) for cardiac / pulmonary / HCT
// -0.17 on log(b2) for autoimmune disease
//
// Since MAT2 = a2 / b2:
//
// -0.59 on log(MAT2)
// +0.17 on log(MAT2)
// ------------------------------------------------------------

IND_EFFECT = 0.0;

if(
  TX_HEART == 1 ||
  TX_LUNG  == 1 ||
  TX_HCT   == 1
) {

  IND_EFFECT = -0.59;

}

if(DIS_AUTOIMMUNE == 1) {

  IND_EFFECT = 0.17;

}


MAT2i =
  MAT2 *
  exp(
    IND_EFFECT +
    ETA(2)
  );



Vi =
  V *
  exp(ETA(3));


KELi =
  KEL *
  exp(ETA(4));


C0i =
  C0 *
  exp(ETA(5));


A1 =
  NTR1 + 1.0;

A2 =
  NTR2 + 1.0;


B1 =
  A1 / MAT1i;

B2 =
  A2 / MAT2i;



$ODE
dxdt_DOSESTORE = 0;



$TABLE
double TAD =
  TIME;


double DOSE =
  DOSESTORE;


double PG1 = 0.0;
double PG2 = 0.0;


if(TAD > 0) {

  PG1 =
    R::pgamma(
      (B1 - KELi) * TAD,
      A1,
      1.0,
      1,
      0
    );

  PG2 =
    R::pgamma(
      (B2 - KELi) * TAD,
      A2,
      1.0,
      1,
      0
    );

}



double ARM1 =
  FDEPOT *
  pow(
    B1 / (B1 - KELi),
    A1
  ) *
  PG1;


double ARM2 =
  (1.0 - FDEPOT) *
  pow(
    B2 / (B2 - KELi),
    A2
  ) *
  PG2;



double CP_mgL =
  C0i +
  (DOSE / Vi) *
  (ARM1 + ARM2) *
  exp(
    -KELi * TAD
  );


double DV_PK =
  CP_mgL +
  ADD_SD *
  EPS(1);


$CAPTURE
CP_mgL DV_PK
MAT1i MAT2i
A1 A2 B1 B2
Vi KELi C0i
IND_EFFECT
'
mod_mpa <- mcode(
  "mpa_fromage2025",
  mpa_code
)