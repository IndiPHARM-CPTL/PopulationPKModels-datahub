library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)
everolimus_code <- '
$PROB
Everolimus population PK model

- Ref:
  ter Heine R, et al.
  A pharmacological rationale for improved everolimus dosing
  in oncology and transplant patients.
  Br J Clin Pharmacol. 2018;84(9):1575-1586.
  doi:10.1111/bcp.13591
  

$PARAM @annotated
MAT        : 0.404  : h       Mean absorption time
CLINT      : 340    : L/h     Intrinsic hepatic clearance
VC         : 175    : L       Central plasma volume at FFM 57.2 kg
VP         : 577    : L       Peripheral plasma volume at FFM 57.2 kg
Q          : 85.7   : L/h     Intercompartmental clearance at FFM 57.2 kg
QH         : 90     : L/h     Hepatic blood flow
FU         : 0.27   : --      Plasma unbound fraction
FFM        : 57.2   : kg      Fat-free mass
HCT        : 0.45   : --      Hematocrit fraction
PRED_DOSE  : 0      : mg/day  Prednisolone daily dose
BMAX       : 964    : ng/mL   Maximum erythrocyte binding
KD         : 92     : ng/mL   Binding dissociation constant
KNS        : 0.153  : --      Nonspecific erythrocyte binding
PROP_SD    : 0.179  : --      Proportional residual SD


$CMT @annotated
DEPOT  : Dosing / first transit compartment (mg)
TRANS1 : Transit compartment 1 (mg)
TRANS2 : Transit compartment 2 (mg)
TRANS3 : Transit compartment 3 (mg)
TRANS4 : Transit compartment 4 (mg)
CENT   : Central plasma compartment (mg)
PERIPH : Peripheral plasma compartment (mg)


$OMEGA @labels ETA_CLINT ETA_VC ETA_MAT
0.108784
0.152580
0.792993


$SIGMA
1


$GLOBAL
double MATi;
double KTRi;
double CLINTi;
double VCi;
double VPi;
double Qi;
double QHi;
double QHPi;
double EHi;
double CLHi;
double Fi;


$MAIN

MATi =
  MAT *
  exp(ETA(3));

KTRi =
  5.0 / MATi;


CLINTi =
  CLINT *
  exp(ETA(1));


if(PRED_DOSE >= 20) {
  CLINTi = CLINTi * 1.31;
}



VCi =
  VC *
  pow(FFM / 57.2, 1.0) *
  exp(ETA(2));

VPi =
  VP *
  pow(FFM / 57.2, 1.0);

Qi =
  Q *
  pow(FFM / 57.2, 0.75);

QHi =
  QH *
  pow(FFM / 57.2, 0.75);


// ------------------------------------------------------------
// Well-stirred hepatic model
//
// Convert hepatic blood flow to hepatic plasma flow
// ------------------------------------------------------------

QHPi =
  QHi *
  (1.0 - HCT);


// Hepatic extraction ratio
EHi =
  (FU * CLINTi) /
  (QHPi + FU * CLINTi);


// Hepatic plasma clearance
CLHi =
  QHPi *
  EHi;


// Hepatic availability
Fi =
  1.0 - EHi;


// Apply hepatic first-pass availability to oral dose
F_DEPOT = Fi;



$ODE

// ------------------------------------------------------------
// Transit absorption
//
// n = 4 transit compartments
// Savic convention:
// KTR = (n + 1) / MAT = 5 / MAT
// ------------------------------------------------------------

dxdt_DEPOT =
  - KTRi * DEPOT;

dxdt_TRANS1 =
    KTRi * DEPOT
  - KTRi * TRANS1;

dxdt_TRANS2 =
    KTRi * TRANS1
  - KTRi * TRANS2;

dxdt_TRANS3 =
    KTRi * TRANS2
  - KTRi * TRANS3;

dxdt_TRANS4 =
    KTRi * TRANS3
  - KTRi * TRANS4;


// ------------------------------------------------------------
// Two-compartment disposition
// ------------------------------------------------------------

dxdt_CENT =
    KTRi * TRANS4
  - (CLHi / VCi) * CENT
  - (Qi / VCi) * CENT
  + (Qi / VPi) * PERIPH;

dxdt_PERIPH =
    (Qi / VCi) * CENT
  - (Qi / VPi) * PERIPH;



$TABLE

// ------------------------------------------------------------
// Plasma concentration
//
// CENT / V = mg/L
// x1000 -> ng/mL
// ------------------------------------------------------------

double CP_ngmL =
  1000.0 *
  CENT /
  VCi;


// ------------------------------------------------------------
// Erythrocyte concentration
//
// Langmuir + linear binding
// ------------------------------------------------------------

double CRBC_ngmL =
    BMAX * CP_ngmL /
    (KD + CP_ngmL)
  + KNS * CP_ngmL;


// ------------------------------------------------------------
// Whole-blood concentration
//
// Cblood = HCT * CRBC + (1-HCT) * Cplasma
// ------------------------------------------------------------

double CWB_ngmL =
    HCT * CRBC_ngmL
  + (1.0 - HCT) * CP_ngmL;


// Residual error pertains to modelled plasma concentrations
double DV_PK =
  CP_ngmL *
  (1.0 + PROP_SD * EPS(1));


$CAPTURE
CP_ngmL CWB_ngmL CRBC_ngmL DV_PK
MATi KTRi CLINTi VCi VPi Qi
QHPi EHi CLHi Fi
FFM HCT PRED_DOSE
'


mod_evero <- mcode(
  "everolimus_terheine2018",
  everolimus_code
)



# ============================================================
# SIMULATION SETTINGS
# ============================================================

N <- 1000


# Transplant doses
doses_mg <- c(
  0.75,
  1,
  2.25,
  3
)

dose_levels <- paste0(
  doses_mg,
  " mg"
)


# Reference individual used by ter Heine et al.
FFM_typ <- 57.2
HCT_typ <- 0.45

# Baseline simulation:
# no high-dose prednisolone
PRED_typ <- 0


# BID dosing
tau <- 12


# 14 days of BID dosing
n_dose <- 14 * 2

last_dose <-
  tau *
  (n_dose - 1)


# Single dose
t_end_sd <- 72

# Multiple dose
t_end_md <-
  last_dose + tau


delta_sd <- 0.05
delta_md <- 0.25



# ============================================================
# HELPER FUNCTIONS
# ============================================================

at_time <- function(
    time,
    value,
    target
) {
  
  value[
    which.min(
      abs(
        time - target
      )
    )
  ]
  
}


auc_trap <- function(
    time,
    conc
) {
  
  sum(
    diff(time) *
      (
        head(conc, -1) +
          tail(conc, -1)
      ) / 2
  )
  
}


# Typical individual:
# remove IIV + residual error
mod_typ <- zero_re(
  mod_evero
)



# ============================================================
# FIGURE 1
# TYPICAL INDIVIDUAL — SINGLE DOSE
# Whole-blood concentration
# ============================================================

fig1_list <- lapply(
  doses_mg,
  function(d) {
    
    idata_typ <- tibble(
      ID = 1,
      FFM = FFM_typ,
      HCT = HCT_typ,
      PRED_DOSE = PRED_typ
    )
    
    ev_sd <- ev(
      time = 0,
      amt = d,
      cmt = 1
    )
    
    mod_typ %>%
      
      ev(ev_sd) %>%
      
      mrgsim(
        idata = idata_typ,
        end = t_end_sd,
        delta = delta_sd
      ) %>%
      
      as_tibble() %>%
      
      mutate(
        Dose =
          paste0(
            d,
            " mg"
          )
      )
    
  }
)


fig1_out <- bind_rows(
  fig1_list
) %>%
  
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )



p1_evero <- ggplot(
  fig1_out,
  aes(
    time,
    CWB_ngmL,
    color = Dose
  )
) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (h)",
    y = "Everolimus whole-blood concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Everolimus single dose"
  )


p1_evero



# ============================================================
# FIGURE 1 SUMMARY
# First 12-h interval
# ============================================================

fig1_summary <- fig1_out %>%
  
  filter(
    time <= tau
  ) %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CWB_ngmL
      ),
    
    Tmax_h =
      time[
        which.max(
          CWB_ngmL
        )
      ],
    
    C12 =
      at_time(
        time,
        CWB_ngmL,
        tau
      ),
    
    AUC0_12 =
      auc_trap(
        time,
        CWB_ngmL
      ),
    
    .groups = "drop"
  )


fig1_summary





# ============================================================
# FIGURE 2
# TYPICAL INDIVIDUAL — MULTIPLE DOSE
# 14 days BID
# ============================================================

fig2_list <- lapply(
  doses_mg,
  function(d) {
    
    idata_typ <- tibble(
      ID = 1,
      FFM = FFM_typ,
      HCT = HCT_typ,
      PRED_DOSE = PRED_typ
    )
    
    ev_md <- ev(
      time = 0,
      amt = d,
      cmt = 1,
      ii = tau,
      addl = n_dose - 1
    )
    
    mod_typ %>%
      
      ev(ev_md) %>%
      
      mrgsim(
        idata = idata_typ,
        end = t_end_md,
        delta = delta_md
      ) %>%
      
      as_tibble() %>%
      
      mutate(
        
        Dose =
          paste0(
            d,
            " mg"
          ),
        
        time_day =
          time / 24
      )
    
  }
)


fig2_out <- bind_rows(
  fig2_list
) %>%
  
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )



p2_evero <- ggplot(
  fig2_out,
  aes(
    time_day,
    CWB_ngmL,
    color = Dose
  )
) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (days)",
    y = "Everolimus whole-blood concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Everolimus twice daily for 14 days"
  )


p2_evero





# ============================================================
# FIGURE 2 STEADY-STATE SUMMARY
# Final 12-hour dosing interval
# ============================================================

fig2_summary <- fig2_out %>%
  
  filter(
    time >= last_dose,
    time <= last_dose + tau
  ) %>%
  
  mutate(
    t_rel =
      time - last_dose
  ) %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax_ss =
      max(
        CWB_ngmL
      ),
    
    Tmax_ss_h =
      t_rel[
        which.max(
          CWB_ngmL
        )
      ],
    
    Ctrough_ss =
      at_time(
        t_rel,
        CWB_ngmL,
        tau
      ),
    
    AUCtau_ss =
      auc_trap(
        t_rel,
        CWB_ngmL
      ),
    
    .groups = "drop"
  )


fig2_summary





# ============================================================
# FIGURE 3
# POPULATION — SINGLE DOSE
# ============================================================

set.seed(123)


fig3_list <- lapply(
  doses_mg,
  function(d) {
    
    idata_pop <- tibble(
      ID = 1:N,
      FFM = FFM_typ,
      HCT = HCT_typ,
      PRED_DOSE = PRED_typ
    )
    
    ev_sd <- ev(
      time = 0,
      amt = d,
      cmt = 1
    )
    
    mod_evero %>%
      
      ev(ev_sd) %>%
      
      mrgsim(
        idata = idata_pop,
        end = t_end_sd,
        delta = delta_sd
      ) %>%
      
      as_tibble() %>%
      
      mutate(
        Dose =
          paste0(
            d,
            " mg"
          )
      )
    
  }
)


fig3_raw <- bind_rows(
  fig3_list
) %>%
  
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )



# ============================================================
# POPULATION RIBBON
# ============================================================

fig3_sum <- fig3_raw %>%
  
  group_by(
    Dose,
    time
  ) %>%
  
  summarise(
    
    CP_med =
      median(
        CWB_ngmL
      ),
    
    CP_p05 =
      quantile(
        CWB_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CWB_ngmL,
        0.95
      ),
    
    .groups = "drop"
  )



p3_evero <- ggplot(
  fig3_sum,
  aes(
    time,
    CP_med,
    color = Dose,
    fill = Dose
  )
) +
  
  geom_ribbon(
    aes(
      ymin = CP_p05,
      ymax = CP_p95
    ),
    alpha = 0.25,
    colour = NA
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (h)",
    y = "Everolimus whole-blood concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Everolimus single dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )


p3_evero





# ============================================================
# FIGURE 3 INDIVIDUAL PK METRICS
# ============================================================

fig3_ind <- fig3_raw %>%
  
  filter(
    time <= tau
  ) %>%
  
  arrange(
    Dose,
    ID,
    time
  ) %>%
  
  group_by(
    Dose,
    ID
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CWB_ngmL
      ),
    
    Tmax_h =
      time[
        which.max(
          CWB_ngmL
        )
      ],
    
    C12 =
      at_time(
        time,
        CWB_ngmL,
        tau
      ),
    
    AUC0_12 =
      auc_trap(
        time,
        CWB_ngmL
      ),
    
    .groups = "drop"
  )



fig3_summary <- fig3_ind %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax_med =
      median(Cmax),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(Tmax_h),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    C12_med =
      median(C12),
    
    C12_p05 =
      quantile(
        C12,
        0.05
      ),
    
    C12_p95 =
      quantile(
        C12,
        0.95
      ),
    
    
    AUC0_12_med =
      median(AUC0_12),
    
    AUC0_12_p05 =
      quantile(
        AUC0_12,
        0.05
      ),
    
    AUC0_12_p95 =
      quantile(
        AUC0_12,
        0.95
      ),
    
    .groups = "drop"
  )


fig3_summary





# ============================================================
# FIGURE 4
# POPULATION — MULTIPLE DOSE / STEADY STATE
# ============================================================

set.seed(123)


fig4_list <- lapply(
  doses_mg,
  function(d) {
    
    idata_pop <- tibble(
      ID = 1:N,
      FFM = FFM_typ,
      HCT = HCT_typ,
      PRED_DOSE = PRED_typ
    )
    
    ev_md <- ev(
      time = 0,
      amt = d,
      cmt = 1,
      ii = tau,
      addl = n_dose - 1
    )
    
    mod_evero %>%
      
      ev(ev_md) %>%
      
      mrgsim(
        idata = idata_pop,
        end = t_end_md,
        delta = delta_md
      ) %>%
      
      as_tibble() %>%
      
      mutate(
        
        Dose =
          paste0(
            d,
            " mg"
          ),
        
        time_day =
          time / 24
      )
    
  }
)


fig4_raw <- bind_rows(
  fig4_list
) %>%
  
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )



# ============================================================
# FIGURE 4 POPULATION RIBBON
# ============================================================

fig4_sum <- fig4_raw %>%
  
  group_by(
    Dose,
    time,
    time_day
  ) %>%
  
  summarise(
    
    CP_med =
      median(
        CWB_ngmL
      ),
    
    CP_p05 =
      quantile(
        CWB_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CWB_ngmL,
        0.95
      ),
    
    .groups = "drop"
  )



p4_evero <- ggplot(
  fig4_sum,
  aes(
    time_day,
    CP_med,
    color = Dose,
    fill = Dose
  )
) +
  
  geom_ribbon(
    aes(
      ymin = CP_p05,
      ymax = CP_p95
    ),
    alpha = 0.25,
    colour = NA
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (days)",
    y = "Everolimus whole-blood concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Everolimus twice daily, population",
    subtitle = "Median with 5th–95th percentiles"
  )


p4_evero





# ============================================================
# FIGURE 4 INDIVIDUAL STEADY-STATE PK PARAMETERS
# ============================================================

fig4_ind <- fig4_raw %>%
  
  filter(
    time >= last_dose,
    time <= last_dose + tau
  ) %>%
  
  mutate(
    t_rel =
      time - last_dose
  ) %>%
  
  arrange(
    Dose,
    ID,
    t_rel
  ) %>%
  
  group_by(
    Dose,
    ID
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CWB_ngmL
      ),
    
    Tmax_h =
      t_rel[
        which.max(
          CWB_ngmL
        )
      ],
    
    Ctrough =
      at_time(
        t_rel,
        CWB_ngmL,
        tau
      ),
    
    AUCtau =
      auc_trap(
        t_rel,
        CWB_ngmL
      ),
    
    .groups = "drop"
  )



fig4_summary <- fig4_ind %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax_med =
      median(Cmax),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(Tmax_h),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    Ctrough_med =
      median(Ctrough),
    
    Ctrough_p05 =
      quantile(
        Ctrough,
        0.05
      ),
    
    Ctrough_p95 =
      quantile(
        Ctrough,
        0.95
      ),
    
    
    AUCtau_med =
      median(AUCtau),
    
    AUCtau_p05 =
      quantile(
        AUCtau,
        0.05
      ),
    
    AUCtau_p95 =
      quantile(
        AUCtau,
        0.95
      ),
    
    .groups = "drop"
  )


fig4_summary