library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

amlodipine_code <- '
$PROB
- Ref: Kang D, Verotta D, Schwartz JB. Population analyses of amlodipine in patients living in the community and patients living in nursing homes. Clin Pharmacol Ther. 2006;79(1):114-124. doi:10.1016/j.clpt.2005.09.007

$PARAM @annotated
TH1       : 7.04   : mL/min/kg LBW   Intercept for CL/F
TH_NH     : 1.75   : mL/min/kg LBW   Nursing-home effect on CL/F
TH_SEX    : 1.17   : mL/min/kg LBW   Male effect on CL/F; SEX = 1 male, 0 female
TH_AGE    : 3.77   : mL/min/kg LBW   Age effect on CL/F
TH_NHAGE  : 8.40   : mL/min/kg LBW   Nursing-home by age interaction

AGE       : 75.5   : years           Age
LBW       : 60     : kg              Lean body weight
SEX       : 1      : --              1 = male, 0 = female
NH        : 0      : --              1 = nursing home, 0 = community/assisted living

KA        : 0.35   : 1/h             Assumed absorption rate constant
T_HALF    : 40     : h               Assumed terminal half-life for profile shape

PROP_SD   : 0.383  : --              Proportional residual SD; sqrt(0.147)

$CMT @annotated
DEPOT : Oral absorption depot
CENT  : Central compartment

$OMEGA @diag @labels ETA_CL
0.0823

$SIGMA
1

$GLOBAL
double AGE_C;
double CL_mL_min_kg;
double CL_L_h;
double CLi;
double KAi;
double Vi;

$MAIN
AGE_C = (AGE - 75.5) / 75.5;

CL_mL_min_kg = TH1 +
               TH_NH    * NH +
               TH_SEX   * SEX +
               TH_AGE   * AGE_C +
               TH_NHAGE * NH * AGE_C;

if(CL_mL_min_kg < 0.1) CL_mL_min_kg = 0.1;

CL_L_h = CL_mL_min_kg * LBW * 60.0 / 1000.0;

CLi = CL_L_h * exp(ETA(1));
KAi = KA;

Vi = CLi * T_HALF / log(2.0);

$ODE
dxdt_DEPOT = -KAi * DEPOT;
dxdt_CENT  =  KAi * DEPOT - (CLi / Vi) * CENT;

$TABLE
double CP_mgL  = CENT / Vi;
double CP_ngmL = CP_mgL * 1000.0;
double DV_ngmL = CP_ngmL * exp(PROP_SD * EPS(1));

$CAPTURE CP_mgL CP_ngmL DV_ngmL CL_mL_min_kg CLi Vi KAi AGE LBW SEX NH
'

mod <- mcode("amlodipine_popPK_kang2006", amlodipine_code)


doses_mg <- c(2.5, 5, 10)

tau_h    <- 24
n_doses  <- 28
addl_md  <- n_doses - 1

t_end_sd <- 14 * 24
t_end_md <- n_doses * tau_h

delta_sd <- 1
delta_md <- 1

last_dose_h <- (n_doses - 1) * tau_h

add_amlodipine_units <- function(df) {
  df %>%
    mutate(
      CP = CP_ngmL,
      time_day = time / 24,
      sex_label = ifelse(SEX == 1, "Male", "Female"),
      site_label = ifelse(NH == 1, "Nursing home", "Community"),
      subgroup = paste(site_label, sex_label, sep = " / ")
    )
}

get_conc_at <- function(time_vec, conc_vec, target_time) {
  conc_vec[which.min(abs(time_vec - target_time))]
}

calc_auc <- function(time, conc, from = 0, to = 24) {
  dat <- tibble(time = time, conc = conc) %>%
    filter(time >= from, time <= to) %>%
    arrange(time)
  
  sum(diff(dat$time) * (head(dat$conc, -1) + tail(dat$conc, -1)) / 2)
}


mod_typ <- zero_re(mod)

idata_typ <- tibble(
  ID  = 1:4,
  AGE = c(71, 77, 75, 82),
  LBW = c(61.4, 45.7, 58.4, 42.5),
  SEX = c(1, 0, 1, 0),
  NH  = c(0, 0, 1, 1)
)


make_idata_pop <- function(N, seed = 123) {
  set.seed(seed)
  
  sex <- rbinom(N, size = 1, prob = 105 / 211)  
  nh  <- rbinom(N, size = 1, prob = 72 / 211)   
  
  age <- ifelse(
    sex == 1,
    rnorm(N, mean = 72, sd = 13),
    rnorm(N, mean = 79, sd = 11)
  )
  
  lbw <- ifelse(
    sex == 1,
    rnorm(N, mean = 60.7, sd = 7.6),
    rnorm(N, mean = 44.2, sd = 6.0)
  )
  
  tibble(
    ID  = 1:N,
    AGE = pmin(pmax(age, 35), 100),
    LBW = pmin(pmax(lbw, 30), 85),
    SEX = sex,
    NH  = nh
  )
}


fig1_list <- lapply(doses_mg, function(d) {
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    add_amlodipine_units() %>%
    mutate(group = paste0(d, " mg"))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(group = factor(group, levels = paste0(doses_mg, " mg")))

p1 <- ggplot(fig1_out, aes(time_day, CP, color = group)) +
  geom_line(linewidth = 1) +
  facet_wrap(~subgroup) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Amlodipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Amlodipine single dose, typical subjects"
  )

fig1_summary <- fig1_out %>%
  group_by(subgroup, group) %>%
  summarise(
    AUC0_24_ng_h_mL = calc_auc(time, CP, 0, 24),
    Cmax_ng_mL      = max(CP),
    Tmax_h          = time[which.max(CP)],
    C24_ng_mL       = get_conc_at(time, CP, 24),
    C72_ng_mL       = get_conc_at(time, CP, 72),
    C14d_ng_mL      = get_conc_at(time, CP, 14 * 24),
    CL_L_h          = first(CLi),
    CL_mL_min_kg    = first(CL_mL_min_kg),
    .groups = "drop"
  )


fig2_list <- lapply(doses_mg, function(d) {
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau_h, addl = addl_md)
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    add_amlodipine_units() %>%
    mutate(group = paste0(d, " mg"))
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(group = factor(group, levels = paste0(doses_mg, " mg")))

p2 <- ggplot(fig2_out, aes(time_day, CP, color = group)) +
  geom_line(linewidth = 1) +
  facet_wrap(~subgroup) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Amlodipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Amlodipine q24h for 28 days, typical subjects"
  )

fig2_summary <- fig2_out %>%
  group_by(subgroup, group) %>%
  summarise(
    Cmax_ss_ng_mL = max(CP[time >= last_dose_h & time <= t_end_md]),
    Tmax_ss_h     = time[which.max(ifelse(time >= last_dose_h & time <= t_end_md, CP, -Inf))] - last_dose_h,
    Cmin_day1     = get_conc_at(time, CP, 24),
    Cmin_day7     = get_conc_at(time, CP, 7 * 24),
    Cmin_day14    = get_conc_at(time, CP, 14 * 24),
    Cmin_day28    = get_conc_at(time, CP, 28 * 24),
    CL_L_h        = first(CLi),
    CL_mL_min_kg  = first(CL_mL_min_kg),
    .groups = "drop"
  )

N <- 1000
idata_pop <- make_idata_pop(N, seed = 123)

fig3_list <- lapply(doses_mg, function(d) {
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    add_amlodipine_units() %>%
    mutate(group = paste0(d, " mg"))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(group = factor(group, levels = paste0(doses_mg, " mg")))

fig3_sum <- fig3_raw %>%
  group_by(group, subgroup, time_day) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time_day, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  facet_wrap(~subgroup) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Amlodipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Amlodipine single dose, population",
  )

fig3_ind <- fig3_raw %>%
  group_by(group, subgroup, ID) %>%
  summarise(
    AUC0_24 = calc_auc(time, CP, 0, 24),
    Cmax    = max(CP, na.rm = TRUE),
    Tmax    = time[which.max(CP)],
    C24     = get_conc_at(time, CP, 24),
    C72     = get_conc_at(time, CP, 72),
    C14d    = get_conc_at(time, CP, 14 * 24),
    CL_L_h  = first(CLi),
    CL_mL_min_kg = first(CL_mL_min_kg),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(group, subgroup) %>%
  summarise(
    AUC0_24_med = median(AUC0_24, na.rm = TRUE),
    AUC0_24_p05 = quantile(AUC0_24, 0.05, na.rm = TRUE),
    AUC0_24_p95 = quantile(AUC0_24, 0.95, na.rm = TRUE),
    
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    C14d_med = median(C14d, na.rm = TRUE),
    C14d_p05 = quantile(C14d, 0.05, na.rm = TRUE),
    C14d_p95 = quantile(C14d, 0.95, na.rm = TRUE),
    
    CL_L_h_med = median(CL_L_h, na.rm = TRUE),
    CL_mL_min_kg_med = median(CL_mL_min_kg, na.rm = TRUE),
    .groups = "drop"
  )


fig4_list <- lapply(doses_mg, function(d) {
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau_h, addl = addl_md)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    add_amlodipine_units() %>%
    mutate(group = paste0(d, " mg"))
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(group = factor(group, levels = paste0(doses_mg, " mg")))

fig4_sum <- fig4_raw %>%
  group_by(group, subgroup, time_day) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time_day, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  facet_wrap(~subgroup) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Amlodipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Amlodipine q24h for 28 days, population",
  )

fig4_ind <- fig4_raw %>%
  group_by(group, subgroup, ID) %>%
  summarise(
    Cmax_ss = max(CP[time >= last_dose_h & time <= t_end_md], na.rm = TRUE),
    Tmax_ss = time[which.max(ifelse(time >= last_dose_h & time <= t_end_md, CP, -Inf))] - last_dose_h,
    
    Cmin_day1  = get_conc_at(time, CP, 24),
    Cmin_day7  = get_conc_at(time, CP, 7 * 24),
    Cmin_day14 = get_conc_at(time, CP, 14 * 24),
    Cmin_day28 = get_conc_at(time, CP, 28 * 24),
    
    CL_L_h = first(CLi),
    CL_mL_min_kg = first(CL_mL_min_kg),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(group, subgroup) %>%
  summarise(
    Cmax_ss_med = median(Cmax_ss, na.rm = TRUE),
    Cmax_ss_p05 = quantile(Cmax_ss, 0.05, na.rm = TRUE),
    Cmax_ss_p95 = quantile(Cmax_ss, 0.95, na.rm = TRUE),
    
    Tmax_ss_med = median(Tmax_ss, na.rm = TRUE),
    Tmax_ss_p05 = quantile(Tmax_ss, 0.05, na.rm = TRUE),
    Tmax_ss_p95 = quantile(Tmax_ss, 0.95, na.rm = TRUE),
    
    Cmin_day1_med  = median(Cmin_day1, na.rm = TRUE),
    Cmin_day1_p05  = quantile(Cmin_day1, 0.05, na.rm = TRUE),
    Cmin_day1_p95  = quantile(Cmin_day1, 0.95, na.rm = TRUE),
    
    Cmin_day7_med  = median(Cmin_day7, na.rm = TRUE),
    Cmin_day7_p05  = quantile(Cmin_day7, 0.05, na.rm = TRUE),
    Cmin_day7_p95  = quantile(Cmin_day7, 0.95, na.rm = TRUE),
    
    Cmin_day14_med = median(Cmin_day14, na.rm = TRUE),
    Cmin_day14_p05 = quantile(Cmin_day14, 0.05, na.rm = TRUE),
    Cmin_day14_p95 = quantile(Cmin_day14, 0.95, na.rm = TRUE),
    
    Cmin_day28_med = median(Cmin_day28, na.rm = TRUE),
    Cmin_day28_p05 = quantile(Cmin_day28, 0.05, na.rm = TRUE),
    Cmin_day28_p95 = quantile(Cmin_day28, 0.95, na.rm = TRUE),
    
    CL_L_h_med = median(CL_L_h, na.rm = TRUE),
    CL_mL_min_kg_med = median(CL_mL_min_kg, na.rm = TRUE),
    .groups = "drop"
  )



p1
p2
p3
p4


fig1_summary
fig2_summary
fig3_summary
fig4_summary