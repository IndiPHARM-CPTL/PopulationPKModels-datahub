library(mrgsolve)   # >= 1.0 (uses the outvars argument)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

citalopram_code <- '
$PROB
Citalopram enantiomer + desmethyl metabolite population PK model
- Ref: Akil A, Bies RR, Pollock BG, Avramopoulos D, Devanand DP,
  Mintzer JE, Porsteinsson AP, Schneider LS, Weintraub D, Yesavage J,
  Shade DM, Lyketsos CG.
  A population pharmacokinetic model for R- and S-citalopram and
  desmethylcitalopram in Alzheimer disease patients with agitation.
  J Pharmacokinet Pharmacodyn. 2016;43(1):99-109.
  doi:10.1007/s10928-015-9457-6

$PARAM @annotated
KA          : 1      : 1/h    Absorption rate constant (fixed), both enantiomers
FRAC_R      : 0.5    : --     Fraction of racemic dose as R-enantiomer

CLRP_M      : 13     : L/h    R-citalopram CL/F, male
CLRP_F      : 9.05   : L/h    R-citalopram CL/F, female
VR          : 1830   : L      R-enantiomer V/F (parent and metabolite)
CLRM        : 24.4   : L/h    R-desmethylcitalopram CL/F

CLSP_EM     : 22.1   : L/h    S-citalopram CL/F, CYP2C19 EM/RM
CLSP_IMPM   : 16.3   : L/h    S-citalopram CL/F, CYP2C19 IM/PM
CLSP_MISS   : 16.8   : L/h    S-citalopram CL/F, CYP2C19 genotype missing
VS          : 1390   : L      S-enantiomer V/F (parent and metabolite)
CLSM        : 38.8   : L/h    S-desmethylcitalopram CL/F

AGE         : 60     : y      Age (centring value)
WT          : 70     : kg     Body weight (centring value)
SEXF        : 0      : --     0 = male, 1 = female
CYP_IMPM    : 0      : --     1 = CYP2C19 intermediate or poor metabolizer
CYP_MISS    : 0      : --     1 = CYP2C19 genotype missing

TH_AGE_CLRP : -0.822 : --     Age effect on R-citalopram CL/F
TH_AGE_CLSP : -1.33  : --     Age effect on S-citalopram CL/F
TH_WT_CLSP  : 0.75   : --     Weight effect on S-citalopram CL/F
TH_WT_CLM   : 0.75   : --     Weight effect on both desmethyl CL/F

ADD_SD_RP   : 13.42  : ng/mL  Additive residual SD, R-citalopram
PROP_SD_RM  : 0.2154 : --     Proportional residual SD, R-desmethylcitalopram
PROP_SD_SP  : 0.2161 : --     Proportional residual SD, S-citalopram
PROP_SD_SM  : 0.2161 : --     Proportional residual SD, S-desmethylcitalopram

$CMT @annotated
DEPOT  : Oral racemic dose (mg)
CENT_R : R-citalopram (mg)
CENT_S : S-citalopram (mg)
MET_R  : R-desmethylcitalopram (mg)
MET_S  : S-desmethylcitalopram (mg)

$OMEGA @labels ETA_CLRP ETA_VR ETA_CLRM
0.06728 1.32973 0.08956

$OMEGA @block @labels ETA_CLSP ETA_VS
0.13715
0.11699 0.44984

$OMEGA @labels ETA_CLSM
0.04113

$SIGMA
1 1 1 1

$GLOBAL
double KAi;
double CLRPi;
double VRi;
double CLRMi;
double CLSPi;
double VSi;
double CLSMi;

$MAIN
KAi = KA;

double CLRP_TV = (SEXF == 1) ? CLRP_F : CLRP_M;

double CLSP_TV = CLSP_EM;
if (CYP_IMPM == 1) CLSP_TV = CLSP_IMPM;
if (CYP_MISS == 1) CLSP_TV = CLSP_MISS;

CLRPi = CLRP_TV *
        pow(AGE / 60.0, TH_AGE_CLRP) *
        exp(ETA_CLRP);

VRi   = VR * exp(ETA_VR);

CLRMi = CLRM *
        pow(WT / 70.0, TH_WT_CLM) *
        exp(ETA_CLRM);

CLSPi = CLSP_TV *
        pow(AGE / 60.0, TH_AGE_CLSP) *
        pow(WT / 70.0, TH_WT_CLSP) *
        exp(ETA_CLSP);

VSi   = VS * exp(ETA_VS);

CLSMi = CLSM *
        pow(WT / 70.0, TH_WT_CLM) *
        exp(ETA_CLSM);

$ODE
dxdt_DEPOT  = -KAi * DEPOT;

dxdt_CENT_R =
    FRAC_R * KAi * DEPOT
  - (CLRPi / VRi) * CENT_R;

dxdt_CENT_S =
    (1.0 - FRAC_R) * KAi * DEPOT
  - (CLSPi / VSi) * CENT_S;

dxdt_MET_R =
    (CLRPi / VRi) * CENT_R
  - (CLRMi / VRi) * MET_R;

dxdt_MET_S =
    (CLSPi / VSi) * CENT_S
  - (CLSMi / VSi) * MET_S;

$TABLE
double C_RCIT  = 1000.0 * CENT_R / VRi;
double C_SCIT  = 1000.0 * CENT_S / VSi;
double C_RDCIT = 1000.0 * MET_R  / VRi;
double C_SDCIT = 1000.0 * MET_S  / VSi;

double DV_RCIT  = C_RCIT  + ADD_SD_RP * EPS(1);
double DV_RDCIT = C_RDCIT * (1.0 + PROP_SD_RM * EPS(2));
double DV_SCIT  = C_SCIT  * (1.0 + PROP_SD_SP * EPS(3));
double DV_SDCIT = C_SDCIT * (1.0 + PROP_SD_SM * EPS(4));

double THALF_R = log(2.0) * VRi / CLRPi;
double THALF_S = log(2.0) * VSi / CLSPi;

$CAPTURE
C_RCIT C_SCIT C_RDCIT C_SDCIT
DV_RCIT DV_SCIT DV_RDCIT DV_SDCIT
KAi CLRPi VRi CLRMi CLSPi VSi CLSMi
THALF_R THALF_S
AGE WT SEXF CYP_IMPM CYP_MISS
'
mod_cit <- mcode("citalopram_pk", citalopram_code)


N <- 1000

# Racemic citalopram doses (CitAD titrated 10 -> 20 -> 30 mg once daily)
doses_mg <- c(10, 20, 30)
dose_levels <- paste(doses_mg, "mg")

tau <- 24
n_dose <- 63                      # daily dosing through CitAD week 9

t_end_sd <- 240                   # metabolite Tmax after a single dose is ~50-100 h
last_dose <- tau * (n_dose - 1)
t_end_md <- last_dose + tau

delta_sd <- 0.5
delta_md <- 2                     # typical-value multiple dose
delta_md_pop <- 4                 # population multiple dose (keeps memory manageable)
add_md <- seq(last_dose, t_end_md, by = 0.25)   # fine grid over final interval


# Reference subject: CitAD cohort mean age/weight, male, CYP2C19 EM/RM
ref_cov <- tibble(
  AGE = 77.8,
  WT = 71.5,
  SEXF = 0,
  CYP_IMPM = 0,
  CYP_MISS = 0
)

conc_vars <- c("C_RCIT", "C_SCIT", "C_RDCIT", "C_SDCIT")
pop_outvars <- c(conc_vars, "THALF_R", "THALF_S")

analyte_map <- tibble(
  var = conc_vars,
  Analyte = factor(
    c("R-citalopram", "S-citalopram",
      "R-desmethylcitalopram", "S-desmethylcitalopram"),
    levels = c("R-citalopram", "S-citalopram",
               "R-desmethylcitalopram", "S-desmethylcitalopram")
  )
)


at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

auc_trap <- function(time, conc) {
  sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2)
}

to_long <- function(df) {
  df %>%
    pivot_longer(all_of(conc_vars), names_to = "var", values_to = "CP") %>%
    left_join(analyte_map, by = "var") %>%
    select(-var)
}




idata_typ <- tidyr::crossing(ID = 1, ref_cov)
idata_pop <- tidyr::crossing(ID = 1:N, ref_cov)

mod_typ <- zero_re(mod_cit)





# ---------------------------------------------------------------------------
# Figure 1. Typical subject, single dose
# ---------------------------------------------------------------------------

fig1_list <- lapply(doses_mg, function(d) {
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_typ, end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = paste(d, "mg"))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig1_long <- to_long(fig1_out)


p1_cit <- ggplot(fig1_long, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  facet_wrap(~ Analyte, scales = "free_y") +
  scale_x_continuous(breaks = seq(0, t_end_sd, 24), limits = c(0, t_end_sd)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Concentration (ng/mL)",
    color = "Racemic dose",
    title = "Figure 1. Citalopram single dose"
  )

p1_cit


fig1_summary <- fig1_long %>%
  arrange(Analyte, Dose, time) %>%
  group_by(Analyte, Dose) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C24 = at_time(time, CP, tau),
    AUC0_24 = auc_trap(time[time <= tau], CP[time <= tau]),
    AUC0_last = auc_trap(time, CP),
    .groups = "drop"
  )

fig1_summary





# ---------------------------------------------------------------------------
# Figure 2. Typical subject, once daily for 63 days
# ---------------------------------------------------------------------------

fig2_list <- lapply(doses_mg, function(d) {
  
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau, addl = n_dose - 1)
  
  mod_typ %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_typ, end = t_end_md, delta = delta_md,
           add = add_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = paste(d, "mg"),
      time_day = time / 24
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig2_long <- to_long(fig2_out)


p2_cit <- ggplot(fig2_long, aes(time_day, CP, color = Dose)) +
  geom_line(linewidth = 0.8) +
  facet_wrap(~ Analyte, scales = "free_y") +
  scale_x_continuous(breaks = seq(0, n_dose, 7), limits = c(0, n_dose)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Concentration (ng/mL)",
    color = "Racemic dose",
    title = paste0("Figure 2. Citalopram once daily for ", n_dose, " days")
  )

p2_cit


fig2_summary <- fig2_long %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  arrange(Analyte, Dose, t_rel) %>%
  group_by(Analyte, Dose) %>%
  summarise(
    Cmax_ss = max(CP),
    Tmax_ss_h = t_rel[which.max(CP)],
    Ctrough_ss = at_time(t_rel, CP, tau),
    AUCtau_ss = auc_trap(t_rel, CP),
    .groups = "drop"
  )

fig2_summary


# Typical-subject half-lives (h)
fig2_out %>% slice(1) %>% select(THALF_R, THALF_S)


# Structural check: with complete parent -> metabolite conversion,
# AUCtau,ss of every analyte = (0.5 x racemic dose) / CL of that analyte
par_typ <- fig2_out %>% slice(1)

cl_map <- tibble(
  Analyte = analyte_map$Analyte,
  CL = c(par_typ$CLRPi, par_typ$CLSPi, par_typ$CLRMi, par_typ$CLSMi)
)

fig2_check <- fig2_summary %>%
  mutate(dose = as.numeric(sub(" mg", "", as.character(Dose)))) %>%
  left_join(cl_map, by = "Analyte") %>%
  mutate(
    AUC_expected = 1000 * 0.5 * dose / CL,     # ng*h/mL
    pct_diff = 100 * (AUCtau_ss / AUC_expected - 1)
  ) %>%
  select(Analyte, Dose, AUCtau_ss, AUC_expected, pct_diff)

fig2_check





# ---------------------------------------------------------------------------
# Figure 3. Population, single dose
# ---------------------------------------------------------------------------

fig3_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_cit %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_pop, end = t_end_sd, delta = delta_sd,
           obsonly = TRUE, outvars = pop_outvars) %>%
    as_tibble() %>%
    mutate(Dose = paste(d, "mg"))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig3_long <- to_long(fig3_raw)


fig3_sum <- fig3_long %>%
  group_by(Analyte, Dose, time) %>%
  summarise(
    CP_med = median(CP),
    CP_p05 = quantile(CP, 0.05),
    CP_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )


p3_cit <- ggplot(fig3_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~ Analyte, scales = "free_y") +
  scale_x_continuous(breaks = seq(0, t_end_sd, 24), limits = c(0, t_end_sd)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Concentration (ng/mL)",
    color = "Racemic dose",
    fill = "Racemic dose",
    title = "Figure 3. Citalopram single dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p3_cit


fig3_ind <- fig3_long %>%
  arrange(Analyte, Dose, ID, time) %>%
  group_by(Analyte, Dose, ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C24 = at_time(time, CP, tau),
    AUC0_24 = auc_trap(time[time <= tau], CP[time <= tau]),
    AUC0_last = auc_trap(time, CP),
    .groups = "drop"
  )


fig3_summary <- fig3_ind %>%
  group_by(Analyte, Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    C24_med = median(C24),
    C24_p05 = quantile(C24, 0.05),
    C24_p95 = quantile(C24, 0.95),
    
    AUC0_24_med = median(AUC0_24),
    AUC0_24_p05 = quantile(AUC0_24, 0.05),
    AUC0_24_p95 = quantile(AUC0_24, 0.95),
    
    AUC0_last_med = median(AUC0_last),
    AUC0_last_p05 = quantile(AUC0_last, 0.05),
    AUC0_last_p95 = quantile(AUC0_last, 0.95),
    
    .groups = "drop"
  )

fig3_summary




# ---------------------------------------------------------------------------
# Figure 4. Population, once daily for 63 days
# ---------------------------------------------------------------------------

fig4_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau, addl = n_dose - 1)
  
  mod_cit %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_pop, end = t_end_md, delta = delta_md_pop,
           add = add_md, obsonly = TRUE, outvars = pop_outvars) %>%
    as_tibble() %>%
    mutate(
      Dose = paste(d, "mg"),
      time_day = time / 24
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig4_long <- to_long(fig4_raw)


fig4_sum <- fig4_long %>%
  group_by(Analyte, Dose, time, time_day) %>%
  summarise(
    CP_med = median(CP),
    CP_p05 = quantile(CP, 0.05),
    CP_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )


p4_cit <- ggplot(fig4_sum, aes(time_day, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 0.8) +
  facet_wrap(~ Analyte, scales = "free_y") +
  scale_x_continuous(breaks = seq(0, n_dose, 7), limits = c(0, n_dose)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Concentration (ng/mL)",
    color = "Racemic dose",
    fill = "Racemic dose",
    title = paste0("Figure 4. Citalopram once daily for ", n_dose, " days, population"),
    subtitle = "Median with 5th–95th percentiles"
  )

p4_cit


fig4_ind <- fig4_long %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  arrange(Analyte, Dose, ID, t_rel) %>%
  group_by(Analyte, Dose, ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = t_rel[which.max(CP)],
    Ctrough = at_time(t_rel, CP, tau),
    AUCtau = auc_trap(t_rel, CP),
    .groups = "drop"
  )


fig4_summary <- fig4_ind %>%
  group_by(Analyte, Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    Ctrough_med = median(Ctrough),
    Ctrough_p05 = quantile(Ctrough, 0.05),
    Ctrough_p95 = quantile(Ctrough, 0.95),
    
    AUCtau_med = median(AUCtau),
    AUCtau_p05 = quantile(AUCtau, 0.05),
    AUCtau_p95 = quantile(AUCtau, 0.95),
    
    .groups = "drop"
  )

fig4_summary


