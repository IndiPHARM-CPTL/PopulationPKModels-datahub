library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)


risperidone_code <- '
$PROB
Risperidone and 9-hydroxyrisperidone population PK model

- Ref:
  Sherwin CMT, Saldana SN, Bies RR, Aman MG, Vinks AA.
  Population pharmacokinetic modeling of risperidone and
  9-hydroxyrisperidone to estimate CYP2D6 subpopulations
  in children and adolescents.
  Ther Drug Monit. 2012;34(5):535-544.
  doi:10.1097/FTD.0b013e318261c240


Phenotype coding:

1 = CYP2D6 poor metabolizer (PM)
2 = CYP2D6 intermediate metabolizer (IM)
3 = CYP2D6 extensive metabolizer (EM)

IMPORTANT:

KF represents the fraction of parent clearance contributing to
formation of 9-hydroxyrisperidone.

No molecular-weight correction is applied at metabolite formation,
matching the source NONMEM model.

$PARAM @annotated
KA          : 2.5    : 1/h     First-order absorption rate constant
V70         : 77.3   : L       Apparent volume at 70 kg
CL_PM70     : 9.38   : L/h     Parent CL/F in PM at 70 kg
CL_IM70     : 29.2   : L/h     Parent CL/F in IM at 70 kg
CL_EM70     : 37.4   : L/h     Parent CL/F in EM at 70 kg
CLM70       : 9.0    : L/h     9-OH-risperidone CL/F at 70 kg
KF_PM       : 0.16   : --      Metabolite formation fraction in PM
KF_IM       : 1.0    : --      Metabolite formation fraction in IM
KF_EM       : 0.13   : --      Metabolite formation fraction in EM
WT          : 43     : kg      Body weight
PHENO       : 2      : --      CYP2D6 phenotype code
PROP_RSP    : 0.2828427 : --   Risperidone proportional residual SD
ADD_RSP     : 0.7071068 : ng/mL Risperidone additive residual SD
PROP_9OH    : 0.6855655 : --   9-OH proportional residual SD
ADD_9OH     : 0.6633250 : ng/mL 9-OH additive residual SD

$CMT @annotated
GUT  : Oral dosing compartment (mg)
CENT : Risperidone central compartment (mg)
MET  : 9-hydroxyrisperidone compartment (mg)

$OMEGA @labels ETA_V ETA_CL_PM ETA_CL_IM ETA_CL_EM ETA_CLM
0.20
0.07
0.03
0.06
0.50

$SIGMA
1
1
1
1

$GLOBAL
double Vi;
double CLi;
double CLMi;
double KFi;
double CL_PM_i;
double CL_IM_i;
double CL_EM_i;

$MAIN

Vi = V70 * pow(WT / 70.0, 1.0) * exp(ETA(1));


CL_PM_i = CL_PM70 * pow(WT / 70.0, 0.75) * exp(ETA(2));
CL_IM_i = CL_IM70 * pow(WT / 70.0, 0.75) * exp(ETA(3));
CL_EM_i = CL_EM70 * pow(WT / 70.0, 0.75) * exp(ETA(4));

CLi = CL_IM_i;
KFi = KF_IM;

if(PHENO == 1) {
  CLi = CL_PM_i;
  KFi = KF_PM;
}

if(PHENO == 2) {
  CLi = CL_IM_i;
  KFi = KF_IM;
}

if(PHENO == 3) {
  CLi = CL_EM_i;
  KFi = KF_EM;
}


CLMi = CLM70 * pow(WT / 70.0, 0.75) * exp(ETA(5));


$ODE

// Oral absorption
dxdt_GUT = -KA * GUT;


// Parent risperidone
dxdt_CENT = KA * GUT - (CLi / Vi) * CENT;

dxdt_MET = KFi * (CLi / Vi) * CENT - (CLMi / Vi) * MET;


$TABLE

double RSP_ngmL = 1000.0 * CENT / Vi;
double OH9_ngmL = 1000.0 * MET / Vi;


double ACTIVE_ngmL = RSP_ngmL + OH9_ngmL;
double DV_RSP = RSP_ngmL * (1.0 + PROP_RSP * EPS(1)) + ADD_RSP * EPS(2);

double DV_9OH = OH9_ngmL * (1.0 + PROP_9OH * EPS(3)) + ADD_9OH * EPS(4);


$CAPTURE
RSP_ngmL
OH9_ngmL
ACTIVE_ngmL
DV_RSP
DV_9OH
Vi
CLi
CLMi
KFi
CL_PM_i
CL_IM_i
CL_EM_i
WT
PHENO
'


mod_risp <- mcode(
  "risperidone_sherwin2012",
  risperidone_code
)