library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

eplerenone_code <- '
$PROB
Eplerenone + SC-70303 PopPK model with nonlinear protein binding
- Ref: Mori Y, Chiba K, Takahashi H, Ogata H. A Population Approach to Eplerenone Pharmacokinetics and Saturable Protein Binding. Drug Metab Pharmacokinet. 2010;25(6):551-559.
- Parent eplerenone reversibly convert to SC-70303.

$PARAM @annotated
KA    : 1.73  : 1/h    Absorption rate constant
CL2   : 12.4  : L/h    Eplerenone unbound clearance, CL2/F
VDU   : 148   : L      Eplerenone unbound volume, Vdu/F
Q1    : 37.8  : L/h    Q eplerenone to SC-70303, Q1/F
Q2    : 123   : L/h    Q SC-70303 to eplerenone, Q2/F
CL3   : 136   : L/h    SC-70303 clearance, CL3/F
VD3   : 11    : L      SC-70303 volume, Vd3/F

NPT   : 0.00544 : mM     Protein binding capacity parameter, nPt; 5.44 µM
KD    : 0.00289 : mM     Dissociation constant; 2.89 µM
NS    : 0.14    : --     Nonspecific binding
MW_EPL: 414.5 : g/mol  Molecular weight of eplerenone for mg/L to mM conversion

$CMT 
DEPOT EPL_UNB SC_TOTAL

$OMEGA @annotated
EKA   : 0.497 : IIV on KA; CV 80.2%
ECL2  : 0.240 : IIV on CL2/F; CV 52.2%
EVDU  : 0.048 : IIV on VDU/F; CV 22.2%
ECL3  : 0.236 : IIV on CL3/F; CV 51.6%
ENPT  : 0.070 : IIV on NPT; CV 26.9%
ENS   : 0.261 : IIV on NS; CV 54.6%

$MAIN
double KAi   = KA  * exp(EKA);
double CL2i  = CL2 * exp(ECL2);
double VDUi  = VDU * exp(EVDU);
double CL3i  = CL3 * exp(ECL3);
double NPTi  = NPT * exp(ENPT);
double NSi   = NS  * exp(ENS);

double K20i  = CL2i / VDUi;
double K23i  = Q1   / VDUi;
double K32i  = Q2   / VD3;
double K30i  = CL3i / VD3;

$ODE
dxdt_DEPOT    = -KAi * DEPOT;

dxdt_EPL_UNB  =  KAi  * DEPOT
                -K20i * EPL_UNB
                -K23i * EPL_UNB
                +K32i * SC_TOTAL;

dxdt_SC_TOTAL =  K23i * EPL_UNB
                -K32i * SC_TOTAL
                -K30i * SC_TOTAL;

$TABLE
double C_EPL_UNB_mgL  = EPL_UNB / VDUi;
double C_EPL_UNB_mM   = C_EPL_UNB_mgL / MW_EPL;

double C_EPL_TOTAL_mM = (1.0 + NPTi/(KD + C_EPL_UNB_mM) + NSi) * C_EPL_UNB_mM;
double C_EPL_TOTAL_mgL = C_EPL_TOTAL_mM * MW_EPL;

double C_EPL_TOTAL_ngmL = C_EPL_TOTAL_mgL * 1000.0;
double C_EPL_UNB_ngmL   = C_EPL_UNB_mgL   * 1000.0;
double C_SC_ngmL        = (SC_TOTAL / VD3) * 1000.0;

$CAPTURE C_EPL_TOTAL_ngmL C_EPL_UNB_ngmL C_SC_ngmL
'
mod <- mcode("eplerenone_mori_2010", eplerenone_code)

dose_mg <- c(100, 300, 1000)

n_pop <- 1000
set.seed(123)

tau_h    <- 24
n_doses  <- 11
addl_md  <- n_doses - 1

t_end_sd <- 96
t_end_md <- 288

delta_sd <- 0.1
delta_md <- 0.1

last_dose_h <- (n_doses - 1) * tau_h
final_interval_end_h <- last_dose_h + tau_h

idata_pop <- tibble(
  ID = 1:n_pop
)

idata_typ <- tibble(
  ID = 1
)

mod_typ <- zero_re(mod)

get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  
  df$conc[which.min(abs(df$time - t))]
}


make_long_primary <- function(x) {
  x %>%
    pivot_longer(
      cols = c(C_EPL_TOTAL_ngmL, C_SC_ngmL),
      names_to = "analyte",
      values_to = "conc_ngmL"
    ) %>%
    mutate(
      analyte = recode(
        analyte,
        C_EPL_TOTAL_ngmL = "Eplerenone total",
        C_SC_ngmL = "SC-70303"
      )
    )
}

fig1_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig1 <- make_long_primary(fig1_raw)

p1 <- ggplot(fig1, aes(x = time, y = conc_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  labs(
    x = "Time after dose (h)",
    y = "Plasma concentration (ng/mL)",
    title = "Figure 1. Eplerenone single-dose typical simulation",
    color = "Dose"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax    = max(conc_ngmL, na.rm = TRUE),
    Tmax    = time[which.max(conc_ngmL)],
    C1      = get_conc_at(time, conc_ngmL, 1),
    C2      = get_conc_at(time, conc_ngmL, 2),
    C4      = get_conc_at(time, conc_ngmL, 4),
    C8      = get_conc_at(time, conc_ngmL, 8),
    C12     = get_conc_at(time, conc_ngmL, 12),
    C24     = get_conc_at(time, conc_ngmL, 24),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_ng_mL      = median(Cmax, na.rm = TRUE),
    Tmax_h          = median(Tmax, na.rm = TRUE),
    C1_ng_mL        = median(C1, na.rm = TRUE),
    C2_ng_mL        = median(C2, na.rm = TRUE),
    C4_ng_mL        = median(C4, na.rm = TRUE),
    C8_ng_mL        = median(C8, na.rm = TRUE),
    C12_ng_mL       = median(C12, na.rm = TRUE),
    C24_ng_mL       = median(C24, na.rm = TRUE),
    .groups = "drop"
  )

p1
fig1_summary


fig2_raw <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q24h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q24h x", n_doses))
  )

fig2 <- make_long_primary(fig2_raw)

p2 <- ggplot(fig2, aes(x = time, y = conc_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  labs(
    x = "Time (h)",
    y = "Plasma concentration (ng/mL)",
    title = "Figure 2. Eplerenone q24h multiple-dose typical simulation",
    color = "Dose"
  ) +
  theme_bw()

fig2_ind <- fig2 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_ngmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ngmL, -Inf))
    ] - last_dose_h,
    C24_after_last = get_conc_at(time, conc_ngmL, final_interval_end_h),
    C24_day1       = get_conc_at(time, conc_ngmL, 24),
    C48            = get_conc_at(time, conc_ngmL, 48),
    C120           = get_conc_at(time, conc_ngmL, 120),
    C240           = get_conc_at(time, conc_ngmL, 240),
    C264           = get_conc_at(time, conc_ngmL, 264),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    AUC_final_interval_ng_h_mL = median(AUC_final_interval, na.rm = TRUE),
    Cmax_final_interval_ng_mL  = median(Cmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_h      = median(Tmax_final_interval, na.rm = TRUE),
    C24_after_last_ng_mL       = median(C24_after_last, na.rm = TRUE),
    C24_day1_ng_mL             = median(C24_day1, na.rm = TRUE),
    C48_ng_mL                  = median(C48, na.rm = TRUE),
    C120_ng_mL                 = median(C120, na.rm = TRUE),
    C240_ng_mL                 = median(C240, na.rm = TRUE),
    C264_ng_mL                 = median(C264, na.rm = TRUE),
    .groups = "drop"
  )

p2
fig2_summary



fig3_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig3 <- make_long_primary(fig3_raw)

fig3_sum <- fig3 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_ngmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  labs(
    x = "Time after dose (h)",
    y = "Plasma concentration (ng/mL)",
    title = "Figure 3. Eplerenone single-dose population simulation",
    subtitle = "Line = median; ribbon = 5th-95th percentile",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig3_ind <- fig3 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax    = max(conc_ngmL, na.rm = TRUE),
    Tmax    = time[which.max(conc_ngmL)],
    C1      = get_conc_at(time, conc_ngmL, 1),
    C2      = get_conc_at(time, conc_ngmL, 2),
    C4      = get_conc_at(time, conc_ngmL, 4),
    C8      = get_conc_at(time, conc_ngmL, 8),
    C12     = get_conc_at(time, conc_ngmL, 12),
    C24     = get_conc_at(time, conc_ngmL, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C2_med = median(C2, na.rm = TRUE),
    C2_p05 = quantile(C2, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2, 0.95, na.rm = TRUE),
    
    C4_med = median(C4, na.rm = TRUE),
    C4_p05 = quantile(C4, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3
fig3_summary


fig4_raw <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q24h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q24h x", n_doses))
  )

fig4 <- make_long_primary(fig4_raw)

fig4_sum <- fig4 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_ngmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  labs(
    x = "Time (h)",
    y = "Plasma concentration (ng/mL)",
    title = "Figure 4. Eplerenone q24h multiple-dose population simulation",
    subtitle = "Line = median; ribbon = 5th-95th percentile",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig4_ind <- fig4 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_ngmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ngmL, -Inf))
    ] - last_dose_h,
    C24_after_last = get_conc_at(time, conc_ngmL, final_interval_end_h),
    C24_day1       = get_conc_at(time, conc_ngmL, 24),
    C48            = get_conc_at(time, conc_ngmL, 48),
    C120           = get_conc_at(time, conc_ngmL, 120),
    C240           = get_conc_at(time, conc_ngmL, 240),
    C264           = get_conc_at(time, conc_ngmL, 264),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_final_interval_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_final_interval_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_final_interval_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_final_interval_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C24_after_last_med = median(C24_after_last, na.rm = TRUE),
    C24_after_last_p05 = quantile(C24_after_last, 0.05, na.rm = TRUE),
    C24_after_last_p95 = quantile(C24_after_last, 0.95, na.rm = TRUE),
    
    C24_day1_med = median(C24_day1, na.rm = TRUE),
    C24_day1_p05 = quantile(C24_day1, 0.05, na.rm = TRUE),
    C24_day1_p95 = quantile(C24_day1, 0.95, na.rm = TRUE),
    
    C240_med = median(C240, na.rm = TRUE),
    C240_p05 = quantile(C240, 0.05, na.rm = TRUE),
    C240_p95 = quantile(C240, 0.95, na.rm = TRUE),
    
    C264_med = median(C264, na.rm = TRUE),
    C264_p05 = quantile(C264, 0.05, na.rm = TRUE),
    C264_p95 = quantile(C264, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4
fig4_summary