library(mrgsolve)
library(dplyr)
library(tibble)
library(tidyr)
library(ggplot2)

lansoprazole_code <- '
$PROB
Lansoprazole population PK model

- Ref:
  Sakurai Y, Hirayama M, Hashimoto M, et al.
  Population pharmacokinetics and proton pump inhibitory
  effects of intravenous lansoprazole in healthy Japanese males.
  Biol Pharm Bull. 2007;30(12):2238-2243.
  doi:10.1248/bpb.30.2238

Phenotype coding:

1 = homoEM
2 = heteroEM
3 = PM

$PARAM @annotated
V1_WT     : 0.110   : L/kg      Central volume per kg
CL_WT     : 0.179   : L/h/kg    Clearance per kg, homoEM
V2_WT     : 0.201   : L/kg      Peripheral volume per kg
Q_WT      : 0.0882  : L/h/kg    Intercompartmental clearance per kg
CL_HET    : 0.612   : --        heteroEM / homoEM clearance ratio
CL_PM     : 0.212   : --        PM / homoEM clearance ratio
WT        : 60      : kg        Body weight
PHENO     : 1       : --        CYP2C19 phenotype code
PROP_SD   : 0.0604  : --        Proportional residual SD
ADD_SD    : 0.00640 : mg/L      Additive residual SD


$CMT @annotated
CENT   : Central compartment (mg)
PERIPH : Peripheral compartment (mg)


$OMEGA @labels ETA_V1 ETA_CL ETA_V2
0.022201
0.048841
0.007744


$SIGMA
1
1


$GLOBAL
double V1i;
double CLi;
double V2i;
double Qi;
double CYP_FACTOR;


$MAIN

// ------------------------------------------------------------
// CYP2C19 phenotype effect
// ------------------------------------------------------------

CYP_FACTOR = 1.0;


// heteroEM
if(PHENO == 2) {

  CYP_FACTOR =
    CL_HET;

}


// poor metabolizer
if(PHENO == 3) {

  CYP_FACTOR =
    CL_PM;

}


// ------------------------------------------------------------
// Individual PK parameters
//
// Source equations:
//
// V1 = theta1 * WT * exp(eta_V1)
//
// CL = theta2 * phenotype effect * WT * exp(eta_CL)
//
// V2 = theta5 * WT * exp(eta_V2)
//
// Q  = theta6 * WT
// ------------------------------------------------------------

V1i =
  V1_WT *
  WT *
  exp(ETA(1));


CLi =
  CL_WT *
  CYP_FACTOR *
  WT *
  exp(ETA(2));


V2i =
  V2_WT *
  WT *
  exp(ETA(3));


Qi =
  Q_WT *
  WT;



$ODE

dxdt_CENT =
  - (CLi / V1i) * CENT
  - (Qi  / V1i) * CENT
  + (Qi  / V2i) * PERIPH;


dxdt_PERIPH =
    (Qi / V1i) * CENT
  - (Qi / V2i) * PERIPH;



$TABLE

// Serum concentration in mg/L
double CP_mgL =
  CENT /
  V1i;


// Serum concentration in ng/mL
double CP_ngmL =
  1000.0 *
  CP_mgL;


// Combined residual error
double DV_mgL =
  CP_mgL *
  (
    1.0 +
    PROP_SD *
    EPS(1)
  ) +
  ADD_SD *
  EPS(2);


double DV_ngmL =
  1000.0 *
  DV_mgL;


$CAPTURE
CP_mgL CP_ngmL
DV_mgL DV_ngmL
V1i CLi V2i Qi
CYP_FACTOR WT PHENO
'


mod_lanso <- mcode(
  "lansoprazole_sakurai2007",
  lansoprazole_code
)



# ============================================================
# SIMULATION SETTINGS
# ============================================================

N <- 1000


# ------------------------------------------------------------
# Source regimen
# ------------------------------------------------------------

dose_mg <- 30


# 30-minute infusion
infdur_h <- 0.5


# BID
tau <- 12


# 5 days = 10 doses
n_dose <- 10


dose_times <-
  seq(
    0,
    by = tau,
    length.out = n_dose
  )


last_dose <-
  max(
    dose_times
  )


# ------------------------------------------------------------
# Typical subject
#
# Source Figure 3 uses a typical 60-kg subject.
# ------------------------------------------------------------

WT_typ <- 60


# ------------------------------------------------------------
# CYP2C19 phenotype definitions
# ------------------------------------------------------------

phenotype_table <- tibble(
  
  PHENO = c(
    1,
    2,
    3
  ),
  
  Phenotype = c(
    "homoEM",
    "heteroEM",
    "PM"
  )
  
)


phenotype_levels <- c(
  "homoEM",
  "heteroEM",
  "PM"
)


# ------------------------------------------------------------
# Simulation windows
# ------------------------------------------------------------

t_end_sd <- 12

t_end_md <- 120


delta_sd <- 0.05
delta_md <- 0.05



# ============================================================
# HELPER FUNCTIONS
# ============================================================

at_time <- function(
    time,
    value,
    target
) {
  
  value[
    which.min(
      abs(
        time -
          target
      )
    )
  ]
  
}



auc_trap <- function(
    time,
    conc
) {
  
  sum(
    diff(time) *
      (
        head(conc, -1) +
          tail(conc, -1)
      ) / 2
  )
  
}



# Typical-value model:
# zero IIV and residual error

mod_typ <- zero_re(
  mod_lanso
)



# ============================================================
# PARAMETER / CLEARANCE CHECK
# TYPICAL 60-kg SUBJECT
# ============================================================

parameter_check <- phenotype_table %>%
  
  mutate(
    
    CYP_FACTOR =
      case_when(
        
        PHENO == 1 ~
          1,
        
        PHENO == 2 ~
          0.612,
        
        PHENO == 3 ~
          0.212
        
      ),
    
    V1_L =
      0.110 *
      WT_typ,
    
    CL_L_h =
      0.179 *
      WT_typ *
      CYP_FACTOR,
    
    V2_L =
      0.201 *
      WT_typ,
    
    Q_L_h =
      0.0882 *
      WT_typ
    
  )


parameter_check



# ============================================================
# FIGURE 1
# TYPICAL PATIENT
# SINGLE 30 mg / 30-min IV INFUSION
# ============================================================

fig1_list <- list()

counter <- 1


for(p in seq_len(
  nrow(
    phenotype_table
  )
)) {
  
  
  pheno_i <-
    phenotype_table$PHENO[p]
  
  
  pheno_label <-
    phenotype_table$Phenotype[p]
  
  
  idata_typ <- tibble(
    
    ID = 1,
    
    WT =
      WT_typ,
    
    PHENO =
      pheno_i
    
  )
  
  
  infusion_rate <-
    dose_mg /
    infdur_h
  
  
  ev_sd <- ev(
    
    time = 0,
    
    amt =
      dose_mg,
    
    cmt = 1,
    
    rate =
      infusion_rate
    
  )
  
  
  fig1_list[[counter]] <-
    
    mod_typ %>%
    
    ev(
      ev_sd
    ) %>%
    
    mrgsim(
      
      idata =
        idata_typ,
      
      end =
        t_end_sd,
      
      delta =
        delta_sd
      
    ) %>%
    
    as_tibble() %>%
    
    mutate(
      
      Phenotype =
        pheno_label
      
    )
  
  
  counter <-
    counter + 1
  
}



fig1_out <- bind_rows(
  fig1_list
) %>%
  
  mutate(
    
    Phenotype =
      factor(
        Phenotype,
        levels =
          phenotype_levels
      )
    
  )



p1_lanso <- ggplot(
  
  fig1_out,
  
  aes(
    time,
    CP_ngmL,
    color =
      Phenotype
  )
  
) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    
    x =
      "Time (h)",
    
    y =
      "Lansoprazole concentration (ng/mL)",
    
    color =
      "CYP2C19 phenotype",
    
    title =
      "Figure 1. Lansoprazole 30 mg single IV infusion",
    
    subtitle =
      "Typical 60-kg subject; 30-minute infusion"
    
  )


p1_lanso



# ============================================================
# FIGURE 1 SUMMARY
# ============================================================

fig1_summary <- fig1_out %>%
  
  group_by(
    Phenotype
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      time[
        which.max(
          CP_ngmL
        )
      ],
    
    C12 =
      at_time(
        time,
        CP_ngmL,
        12
      ),
    
    AUC0_12 =
      auc_trap(
        time,
        CP_ngmL
      ),
    
    .groups =
      "drop"
    
  )


fig1_summary





# ============================================================
# FIGURE 2
# TYPICAL PATIENT
# 30 mg BID / 30-min IV INFUSION FOR 5 DAYS
# ============================================================

fig2_list <- list()

counter <- 1


for(p in seq_len(
  nrow(
    phenotype_table
  )
)) {
  
  
  pheno_i <-
    phenotype_table$PHENO[p]
  
  
  pheno_label <-
    phenotype_table$Phenotype[p]
  
  
  idata_typ <- tibble(
    
    ID = 1,
    
    WT =
      WT_typ,
    
    PHENO =
      pheno_i
    
  )
  
  
  infusion_rate <-
    dose_mg /
    infdur_h
  
  
  ev_md <- ev(
    
    time = 0,
    
    amt =
      dose_mg,
    
    cmt = 1,
    
    rate =
      infusion_rate,
    
    ii =
      tau,
    
    addl =
      n_dose - 1
    
  )
  
  
  fig2_list[[counter]] <-
    
    mod_typ %>%
    
    ev(
      ev_md
    ) %>%
    
    mrgsim(
      
      idata =
        idata_typ,
      
      end =
        t_end_md,
      
      delta =
        delta_md
      
    ) %>%
    
    as_tibble() %>%
    
    mutate(
      
      Phenotype =
        pheno_label,
      
      time_day =
        time /
        24
      
    )
  
  
  counter <-
    counter + 1
  
}



fig2_out <- bind_rows(
  fig2_list
) %>%
  
  mutate(
    
    Phenotype =
      factor(
        Phenotype,
        levels =
          phenotype_levels
      )
    
  )



p2_lanso <- ggplot(
  
  fig2_out,
  
  aes(
    time,
    CP_ngmL,
    color =
      Phenotype
  )
  
) +
  
  geom_line(
    linewidth = 0.9
  ) +
  
  theme_bw() +
  
  labs(
    
    x =
      "Time (h)",
    
    y =
      "Lansoprazole concentration (ng/mL)",
    
    color =
      "CYP2C19 phenotype",
    
    title =
      "Figure 2. Lansoprazole 30 mg IV BID for 5 days",
    
    subtitle =
      "Typical 60-kg subject; 30-minute infusions"
    
  )


p2_lanso



# ============================================================
# FIGURE 2 SUMMARY
# FINAL DOSING INTERVAL: 108-120 h
# ============================================================

fig2_summary <- fig2_out %>%
  
  filter(
    
    time >=
      last_dose,
    
    time <=
      last_dose +
      tau
    
  ) %>%
  
  mutate(
    
    t_rel =
      time -
      last_dose
    
  ) %>%
  
  group_by(
    Phenotype
  ) %>%
  
  summarise(
    
    Cmax_last =
      max(
        CP_ngmL
      ),
    
    Tmax_last_h =
      t_rel[
        which.max(
          CP_ngmL
        )
      ],
    
    Ctrough_last =
      at_time(
        t_rel,
        CP_ngmL,
        tau
      ),
    
    AUCtau_last =
      auc_trap(
        t_rel,
        CP_ngmL
      ),
    
    .groups =
      "drop"
    
  )


fig2_summary





# ============================================================
# POPULATION EVENT BUILDER
# ============================================================

make_lanso_population <- function(
    
  pheno,
  
  multiple = FALSE,
  
  id_offset = 0,
  
  seed = NULL
  
) {
  
  
  if(!is.null(seed)) {
    
    set.seed(
      seed
    )
    
  }
  
  
  # ----------------------------------------------------------
  # Body weight
  #
  # Source:
  # mean 61.8 kg
  # SD 6.0 kg
  #
  # Truncated to 45-80 kg for simulation.
  # ----------------------------------------------------------
  
  WT_i <-
    pmin(
      
      pmax(
        
        rnorm(
          N,
          mean = 61.8,
          sd = 6.0
        ),
        
        45
        
      ),
      
      80
      
    )
  
  
  ids <-
    id_offset +
    seq_len(N)
  
  
  subjects <- tibble(
    
    ID =
      ids,
    
    WT =
      WT_i,
    
    PHENO =
      pheno
    
  )
  
  
  infusion_rate <-
    dose_mg /
    infdur_h
  
  
  # ==========================================================
  # SINGLE DOSE
  # ==========================================================
  
  if(!multiple) {
    
    
    dose_rows <- subjects %>%
      
      transmute(
        
        ID,
        
        time =
          0,
        
        evid =
          1,
        
        cmt =
          1,
        
        amt =
          dose_mg,
        
        rate =
          infusion_rate,
        
        WT,
        
        PHENO
        
      )
    
    
    obs_times <-
      sort(
        unique(
          c(
            
            seq(
              0,
              t_end_sd,
              by =
                delta_sd
            ),
            
            infdur_h
            
          )
        )
      )
    
    
    # ==========================================================
    # MULTIPLE DOSE
    # ==========================================================
    
  } else {
    
    
    dose_rows <- crossing(
      
      subjects,
      
      time =
        dose_times
      
    ) %>%
      
      transmute(
        
        ID,
        
        time,
        
        evid =
          1,
        
        cmt =
          1,
        
        amt =
          dose_mg,
        
        rate =
          infusion_rate,
        
        WT,
        
        PHENO
        
      )
    
    
    obs_times <-
      sort(
        unique(
          c(
            
            seq(
              0,
              t_end_md,
              by =
                delta_md
            ),
            
            dose_times,
            
            dose_times +
              infdur_h
            
          )
        )
      )
    
  }
  
  
  # ----------------------------------------------------------
  # Observation rows
  # ----------------------------------------------------------
  
  obs_rows <- crossing(
    
    subjects,
    
    time =
      obs_times
    
  ) %>%
    
    mutate(
      
      evid =
        0,
      
      cmt =
        0,
      
      amt =
        0,
      
      rate =
        0
      
    )
  
  
  # ----------------------------------------------------------
  # Combine records
  # ----------------------------------------------------------
  
  bind_rows(
    
    dose_rows,
    
    obs_rows
    
  ) %>%
    
    arrange(
      
      ID,
      
      time,
      
      desc(
        evid
      )
      
    )
  
}





# ============================================================
# FIGURE 3
# POPULATION
# SINGLE 30 mg / 30-min IV INFUSION
# ============================================================

fig3_list <- list()

counter <- 1


for(p in seq_len(
  nrow(
    phenotype_table
  )
)) {
  
  
  pheno_i <-
    phenotype_table$PHENO[p]
  
  
  pheno_label <-
    phenotype_table$Phenotype[p]
  
  
  data_i <-
    make_lanso_population(
      
      pheno =
        pheno_i,
      
      multiple =
        FALSE,
      
      id_offset =
        (
          counter -
            1
        ) *
        N,
      
      seed =
        100 +
        counter
      
    )
  
  
  fig3_list[[counter]] <-
    
    mod_lanso %>%
    
    data_set(
      data_i
    ) %>%
    
    mrgsim(
      carry_out =
        "evid"
    ) %>%
    
    as_tibble() %>%
    
    filter(
      evid == 0
    ) %>%
    
    mutate(
      
      Phenotype =
        pheno_label
      
    )
  
  
  counter <-
    counter + 1
  
}



fig3_raw <- bind_rows(
  fig3_list
) %>%
  
  mutate(
    
    Phenotype =
      factor(
        Phenotype,
        levels =
          phenotype_levels
      )
    
  )



# ============================================================
# FIGURE 3 POPULATION SUMMARY
# ============================================================

fig3_sum <- fig3_raw %>%
  
  group_by(
    
    Phenotype,
    
    time
    
  ) %>%
  
  summarise(
    
    CP_med =
      median(
        CP_ngmL
      ),
    
    CP_p05 =
      quantile(
        CP_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_ngmL,
        0.95
      ),
    
    .groups =
      "drop"
    
  )



p3_lanso <- ggplot(
  
  fig3_sum,
  
  aes(
    
    time,
    
    CP_med,
    
    color =
      Phenotype,
    
    fill =
      Phenotype
    
  )
  
) +
  
  geom_ribbon(
    
    aes(
      
      ymin =
        CP_p05,
      
      ymax =
        CP_p95
      
    ),
    
    alpha =
      0.20,
    
    colour =
      NA
    
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  facet_wrap(
    ~Phenotype
  ) +
  
  theme_bw() +
  
  labs(
    
    x =
      "Time (h)",
    
    y =
      "Lansoprazole concentration (ng/mL)",
    
    color =
      "CYP2C19 phenotype",
    
    fill =
      "CYP2C19 phenotype",
    
    title =
      "Figure 3. Lansoprazole single IV infusion, population",
    
    subtitle =
      "30 mg over 30 min; median with 5th–95th percentiles"
    
  )


p3_lanso



# ============================================================
# FIGURE 3 INDIVIDUAL PK METRICS
# ============================================================

fig3_ind <- fig3_raw %>%
  
  filter(
    time <=
      12
  ) %>%
  
  arrange(
    
    Phenotype,
    
    ID,
    
    time
    
  ) %>%
  
  group_by(
    
    Phenotype,
    
    ID
    
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      time[
        which.max(
          CP_ngmL
        )
      ],
    
    C12 =
      at_time(
        time,
        CP_ngmL,
        12
      ),
    
    AUC0_12 =
      auc_trap(
        time,
        CP_ngmL
      ),
    
    .groups =
      "drop"
    
  )



fig3_summary <- fig3_ind %>%
  
  group_by(
    Phenotype
  ) %>%
  
  summarise(
    
    Cmax_med =
      median(
        Cmax
      ),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(
        Tmax_h
      ),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    C12_med =
      median(
        C12
      ),
    
    C12_p05 =
      quantile(
        C12,
        0.05
      ),
    
    C12_p95 =
      quantile(
        C12,
        0.95
      ),
    
    
    AUC0_12_med =
      median(
        AUC0_12
      ),
    
    AUC0_12_p05 =
      quantile(
        AUC0_12,
        0.05
      ),
    
    AUC0_12_p95 =
      quantile(
        AUC0_12,
        0.95
      ),
    
    .groups =
      "drop"
    
  )


fig3_summary





# ============================================================
# FIGURE 4
# POPULATION
# 30 mg BID / 30-min IV INFUSION FOR FIVE DAYS
# ============================================================

fig4_list <- list()

counter <- 1


for(p in seq_len(
  nrow(
    phenotype_table
  )
)) {
  
  
  pheno_i <-
    phenotype_table$PHENO[p]
  
  
  pheno_label <-
    phenotype_table$Phenotype[p]
  
  
  data_i <-
    make_lanso_population(
      
      pheno =
        pheno_i,
      
      multiple =
        TRUE,
      
      id_offset =
        (
          counter -
            1
        ) *
        N,
      
      seed =
        200 +
        counter
      
    )
  
  
  fig4_list[[counter]] <-
    
    mod_lanso %>%
    
    data_set(
      data_i
    ) %>%
    
    mrgsim(
      carry_out =
        "evid"
    ) %>%
    
    as_tibble() %>%
    
    filter(
      evid == 0
    ) %>%
    
    mutate(
      
      Phenotype =
        pheno_label,
      
      time_day =
        time /
        24
      
    )
  
  
  counter <-
    counter + 1
  
}



fig4_raw <- bind_rows(
  fig4_list
) %>%
  
  mutate(
    
    Phenotype =
      factor(
        Phenotype,
        levels =
          phenotype_levels
      )
    
  )



# ============================================================
# FIGURE 4 POPULATION SUMMARY
# ============================================================

fig4_sum <- fig4_raw %>%
  
  group_by(
    
    Phenotype,
    
    time,
    
    time_day
    
  ) %>%
  
  summarise(
    
    CP_med =
      median(
        CP_ngmL
      ),
    
    CP_p05 =
      quantile(
        CP_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_ngmL,
        0.95
      ),
    
    .groups =
      "drop"
    
  )



p4_lanso <- ggplot(
  
  fig4_sum,
  
  aes(
    
    time,
    
    CP_med,
    
    color =
      Phenotype,
    
    fill =
      Phenotype
    
  )
  
) +
  
  geom_ribbon(
    
    aes(
      
      ymin =
        CP_p05,
      
      ymax =
        CP_p95
      
    ),
    
    alpha =
      0.20,
    
    colour =
      NA
    
  ) +
  
  geom_line(
    linewidth = 0.9
  ) +
  
  facet_wrap(
    ~Phenotype,
    scales = "free_y"
  ) +
  
  theme_bw() +
  
  labs(
    
    x =
      "Time (h)",
    
    y =
      "Lansoprazole concentration (ng/mL)",
    
    color =
      "CYP2C19 phenotype",
    
    fill =
      "CYP2C19 phenotype",
    
    title =
      "Figure 4. Lansoprazole 30 mg IV BID for 5 days, population",
    
    subtitle =
      "Median with 5th–95th percentiles"
    
  )


p4_lanso



# ============================================================
# FIGURE 4
# INDIVIDUAL FINAL-DOSING-INTERVAL PK METRICS
# ============================================================

fig4_ind <- fig4_raw %>%
  
  filter(
    
    time >=
      last_dose,
    
    time <=
      last_dose +
      tau
    
  ) %>%
  
  mutate(
    
    t_rel =
      time -
      last_dose
    
  ) %>%
  
  arrange(
    
    Phenotype,
    
    ID,
    
    t_rel
    
  ) %>%
  
  group_by(
    
    Phenotype,
    
    ID
    
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      t_rel[
        which.max(
          CP_ngmL
        )
      ],
    
    Ctrough =
      at_time(
        t_rel,
        CP_ngmL,
        tau
      ),
    
    AUCtau =
      auc_trap(
        t_rel,
        CP_ngmL
      ),
    
    .groups =
      "drop"
    
  )



fig4_summary <- fig4_ind %>%
  
  group_by(
    Phenotype
  ) %>%
  
  summarise(
    
    Cmax_med =
      median(
        Cmax
      ),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(
        Tmax_h
      ),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    Ctrough_med =
      median(
        Ctrough
      ),
    
    Ctrough_p05 =
      quantile(
        Ctrough,
        0.05
      ),
    
    Ctrough_p95 =
      quantile(
        Ctrough,
        0.95
      ),
    
    
    AUCtau_med =
      median(
        AUCtau
      ),
    
    AUCtau_p05 =
      quantile(
        AUCtau,
        0.05
      ),
    
    AUCtau_p95 =
      quantile(
        AUCtau,
        0.95
      ),
    
    .groups =
      "drop"
    
  )


fig4_summary
