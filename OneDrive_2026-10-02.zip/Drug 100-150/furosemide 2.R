library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

furosemide_code <- '
$PROB
- Ref: Kodati D, Yellu N. Population pharmacokinetic modeling of furosemide in patients with hypertension and fluid overload conditions. Pharmacol Rep. 2017;69(3):492-496. doi:10.1016/j.pharep.2017.01.006

$PARAM @annotated
KA       : 0.76616 : 1/h
V1       : 4.419   : L
V2       : 7.9634  : L
CL       : 15.054  : L/h
Q        : 0.4861  : L/h
TLAG     : 0.4297  : h
DCLDCRCL : -0.3053 : --
DCLDAGE  : 0.2534  : --
CRCL     : 69.65   : mL/min
AGE      : 53      : years
REF_CRCL : 69.65   : mL/min
REF_AGE  : 53      : years
COV_ON   : 1       : --

$CMT GUT CENT PERIPH

$OMEGA @diag @labels ETA_KA ETA_V1 ETA_V2 ETA_CL ETA_Q ETA_TLAG
0.01691 0.0548 0.5980 0.0606 1.0162 0.0119

$MAIN
double crcl_eff = 1.0;
double age_eff = 1.0;

if(COV_ON == 1.0) {
  crcl_eff = pow(CRCL / REF_CRCL, DCLDCRCL);
  age_eff = pow(AGE / REF_AGE, DCLDAGE);
}

double KAi = KA * exp(ETA_KA);
double V1i = V1 * exp(ETA_V1);
double V2i = V2 * exp(ETA_V2);
double CLi = CL * crcl_eff * age_eff * exp(ETA_CL);
double Qi = Q * exp(ETA_Q);
double TLAGi = TLAG * exp(ETA_TLAG);

ALAG_GUT = TLAGi;

$ODE
dxdt_GUT = -KAi * GUT;
dxdt_CENT = KAi * GUT - (CLi / V1i) * CENT - (Qi / V1i) * CENT + (Qi / V2i) * PERIPH;
dxdt_PERIPH = (Qi / V1i) * CENT - (Qi / V2i) * PERIPH;

$TABLE
double FUR_ngmL = (CENT / V1i) * 1000.0;

$CAPTURE FUR_ngmL
'

mod <- mcode("furosemide_kodati2017", furosemide_code)

set.seed(123)

dose_mg <- c(20, 40, 80)
N <- 1000
tau_h <- 6
n_doses <- 12
addl_md <- n_doses - 1
t_end_sd <- 24
t_end_md <- n_doses * tau_h
delta_sd <- 0.1
delta_md <- 0.1
last_dose_h <- (n_doses - 1) * tau_h

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q6h x", n_doses)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(
  ID = 1,
  AGE = 53,
  CRCL = 69.65,
  REF_AGE = 53,
  REF_CRCL = 69.65,
  COV_ON = 0
)

idata_pop <- tibble(
  ID = 1:N,
  AGE = pmin(pmax(rnorm(N, 53, 12), 18), 90),
  CRCL = pmin(pmax(rlnorm(N, log(69.65), 0.35), 15), 180),
  REF_AGE = 53,
  REF_CRCL = 69.65,
  COV_ON = 1
)



fig1_out <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT")) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(CP = FUR_ngmL, Dose = paste0(d, " mg single dose"))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Furosemide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Furosemide single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C6 = get_nearest(time, CP, 6),
    C12 = get_nearest(time, CP, 12),
    C24 = get_nearest(time, CP, 24),
    .groups = "drop"
  )




fig2_out <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT", ii = tau_h, addl = addl_md)) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(CP = FUR_ngmL, Dose = paste0(d, " mg q6h x", n_doses))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Furosemide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Furosemide q6h multidose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= last_dose_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_final_interval = max(CP, na.rm = TRUE),
    Tmax_final_interval = time[which.max(CP)] - last_dose_h,
    Ctrough_final_interval = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )




set.seed(123)

fig3_raw <- lapply(dose_mg, function(d) {
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT")) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(CP = FUR_ngmL, Dose = paste0(d, " mg single dose"))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Furosemide concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Furosemide single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C6 = get_nearest(time, CP, 6),
    C12 = get_nearest(time, CP, 12),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    C6_med = median(C6, na.rm = TRUE),
    C6_p05 = quantile(C6, 0.05, na.rm = TRUE),
    C6_p95 = quantile(C6, 0.95, na.rm = TRUE),
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    .groups = "drop"
  )



fig4_raw <- lapply(dose_mg, function(d) {
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT", ii = tau_h, addl = addl_md)) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(CP = FUR_ngmL, Dose = paste0(d, " mg q6h x", n_doses))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Furosemide concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Furosemide q6h multidose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= last_dose_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_final_interval = max(CP, na.rm = TRUE),
    Tmax_final_interval = time[which.max(CP)] - last_dose_h,
    Ctrough_final_interval = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    Tmax_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    Ctrough_med = median(Ctrough_final_interval, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough_final_interval, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough_final_interval, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary