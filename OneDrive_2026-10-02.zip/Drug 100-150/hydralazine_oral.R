library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

hydralazine_code <- '
$PROB
Oral hydralazine parent-only empirical PK model in hypertension patients
- Ref: Hanson A, Johansson BW, Wernersson B, Wahlander LA.
  Pharmacokinetics of oral hydralazine in chronic heart failure.
  Eur J Clin Pharmacol. 1983;25:467-473.

$PARAM @annotated
KA      : 2.33  : 1/h      First-order absorption rate constant
CL      : 79.17 : L/h      Apparent oral clearance
VAPP    : 227.5 : L        Apparent volume of distribution

MW_HYD  : 160.18 : g/mol   Molecular weight of hydralazine free base
MG_PER_UMOL_HCL : 0.19664 : mg/umol  Molecular conversion for hydralazine HCl

$CMT 
GUT CENT

$OMEGA @annotated
EKA     : 0.160 : IIV on KA
ECL     : 0.250 : IIV on CL
EVAPP   : 0.120 : IIV on VAPP

$MAIN
double KAi   = KA   * exp(EKA);
double CLi   = CL   * exp(ECL);
double VAPPi = VAPP * exp(EVAPP);

double KELi  = CLi / VAPPi;

$ODE
dxdt_GUT  = -KAi * GUT;

dxdt_CENT =  KAi * GUT / MG_PER_UMOL_HCL
             -KELi * CENT;

$TABLE
double C_HYD_nmolmL = CENT / VAPPi;
double C_HYD_ngmL   = C_HYD_nmolmL * MW_HYD;

$CAPTURE C_HYD_ngmL
'
mod <- mcode("hydralazine_hanson_1983_parent_only", hydralazine_code)

dose_mg <- c(25, 50, 100)

n_pop <- 1000
set.seed(123)

tau_h    <- 8
n_doses  <- 12
addl_md  <- n_doses - 1

t_end_sd <- 12
t_end_md <- 96

delta_sd <- 0.05
delta_md <- 0.05

last_dose_h <- (n_doses - 1) * tau_h
final_interval_end_h <- last_dose_h + tau_h

idata_typ <- tibble(
  ID = 1
)

idata_pop <- tibble(
  ID = 1:n_pop
)

mod_typ <- zero_re(mod)


get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  
  df$conc[which.min(abs(df$time - t))]
}

make_long_primary <- function(x) {
  x %>%
    pivot_longer(
      cols = c(C_HYD_ngmL),
      names_to = "analyte",
      values_to = "conc_ngmL"
    ) %>%
    mutate(
      analyte = recode(
        analyte,
        C_HYD_ngmL = "Hydralazine"
      )
    )
}


fig1_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig1 <- make_long_primary(fig1_raw)

p1 <- ggplot(fig1, aes(x = time, y = conc_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after oral dose (h)",
    y = "Plasma hydralazine concentration (ng/mL)",
    title = "Figure 1. Hydralazine single-dose typical simulation",
    subtitle = "Parent / real hydralazine only; hypertension patients",
    color = "Dose"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_ngmL, na.rm = TRUE),
    Tmax = time[which.max(conc_ngmL)],
    C8   = get_conc_at(time, conc_ngmL, 8),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_ng_mL = median(Cmax, na.rm = TRUE),
    Tmax_h     = median(Tmax, na.rm = TRUE),
    C8_ng_mL   = median(C8, na.rm = TRUE),
    .groups = "drop"
  )

p1
fig1_summary


fig2_raw <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q8h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q8h x", n_doses))
  )

fig2 <- make_long_primary(fig2_raw)

p2 <- ggplot(fig2, aes(x = time, y = conc_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Plasma hydralazine concentration (ng/mL)",
    title = "Figure 2. Hydralazine q8h multiple-dose typical simulation",
    subtitle = "Parent / real hydralazine only; multiple-dose extrapolation",
    color = "Dose"
  ) +
  theme_bw()

fig2_ind <- fig2 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_ngmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ngmL, -Inf))
    ] - last_dose_h,
    C8_after_last = get_conc_at(time, conc_ngmL, final_interval_end_h),
    C8_day1       = get_conc_at(time, conc_ngmL, tau_h),
    C24           = get_conc_at(time, conc_ngmL, 24),
    C48           = get_conc_at(time, conc_ngmL, 48),
    C72           = get_conc_at(time, conc_ngmL, 72),
    C96           = get_conc_at(time, conc_ngmL, 96),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_ng_mL = median(Cmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_h     = median(Tmax_final_interval, na.rm = TRUE),
    C8_after_last_ng_mL       = median(C8_after_last, na.rm = TRUE),
    C8_day1_ng_mL             = median(C8_day1, na.rm = TRUE),
    C24_ng_mL                 = median(C24, na.rm = TRUE),
    C48_ng_mL                 = median(C48, na.rm = TRUE),
    C72_ng_mL                 = median(C72, na.rm = TRUE),
    C96_ng_mL                 = median(C96, na.rm = TRUE),
    .groups = "drop"
  )

p2
fig2_summary


fig3_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig3 <- make_long_primary(fig3_raw)

fig3_sum <- fig3 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_ngmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after oral dose (h)",
    y = "Plasma hydralazine concentration (ng/mL)",
    title = "Figure 3. Hydralazine single-dose population simulation",
    subtitle = "Parent / real hydralazine only; line = median; ribbon = 5th-95th percentile",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig3_ind <- fig3 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_ngmL, na.rm = TRUE),
    Tmax = time[which.max(conc_ngmL)],
    C8   = get_conc_at(time, conc_ngmL, 8),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3
fig3_summary


fig4_raw <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q8h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q8h x", n_doses))
  )

fig4 <- make_long_primary(fig4_raw)

fig4_sum <- fig4 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_ngmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Plasma hydralazine concentration (ng/mL)",
    title = "Figure 4. Hydralazine q8h population simulation",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig4_ind <- fig4 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_ngmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ngmL, -Inf))
    ] - last_dose_h,
    C24           = get_conc_at(time, conc_ngmL, 24),
    C48           = get_conc_at(time, conc_ngmL, 48),
    C72           = get_conc_at(time, conc_ngmL, 72),
    C96           = get_conc_at(time, conc_ngmL, 96),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_final_interval_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_final_interval_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_final_interval_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_final_interval_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
  
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE), 
    
    C48_med = median(C48, na.rm = TRUE),
    C48_p05 = quantile(C48, 0.05, na.rm = TRUE),
    C48_p95 = quantile(C48, 0.95, na.rm = TRUE),
  
    C72_med = median(C72, na.rm = TRUE),
    C72_p05 = quantile(C72, 0.05, na.rm = TRUE),
    C72_p95 = quantile(C72, 0.95, na.rm = TRUE),
    
    C96_med = median(C96, na.rm = TRUE),
    C96_p05 = quantile(C96, 0.05, na.rm = TRUE),
    C96_p95 = quantile(C96, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )

p4
fig4_summary
