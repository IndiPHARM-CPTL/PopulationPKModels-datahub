library(mrgsolve)   # >= 1.0 (uses the outvars argument)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

clozapine_code <- '
$PROB
Clozapine + norclozapine joint population PK model
- Ref: Olmos I, Ibarra M, Vazquez M, Maldonado C, Fagiolino P, Giachetto G.
  Population Pharmacokinetics of Clozapine and Norclozapine and
  Switchability Assessment between Brands in Uruguayan Patients with
  Schizophrenia.
  BioMed Res Int. 2019;2019:3163502.
  doi:10.1155/2019/3163502

- One-compartment parent + one-compartment metabolite, first-order absorption
- KA fixed at 1.24 1/h (Jerling 1996)
- Complete clozapine -> norclozapine conversion, with molecular-weight factor
  MW_NCZP / MW_CZP = 312.80 / 326.83 (weights computed from formulae;
  the paper describes but does not print the factor)
- V/F fixed (Golden & Honigfeld) and linear in weight: 750 L and 1860 L at 70 kg
- CL/F allometric, fixed exponent 0.75 (both analytes)
- Smoking on clozapine CL/F only: 28.1 L/h nonsmoker, 36.5 L/h smoker
- Brand: F = 1 for Leponex (reference), 0.892 for Luverina;
  BSV on F applied to Luverina only
- IIV %CV -> omega^2 = log(1 + CV^2):
    CL_CZP 43.3% -> 0.171841 ; CL_NCZP 49.9% -> 0.222344
    correlation 0.557 -> covariance 0.108876 ; F 43.6% -> 0.174034
- Proportional residual error: 9.54% clozapine, 15.3% norclozapine

$PARAM @annotated
KA           : 1.24    : 1/h    First-order absorption rate constant (fixed)
CL_NS        : 28.1    : L/h    Clozapine CL/F, nonsmoker (70 kg)
CL_SM        : 36.5    : L/h    Clozapine CL/F, smoker (70 kg)
CLM          : 53.6    : L/h    Norclozapine CL/F (70 kg)
VF           : 750     : L      Clozapine V/F at 70 kg (fixed)
VMF          : 1860    : L      Norclozapine V/F at 70 kg (fixed)
F_LUV        : 0.892   : --     Relative bioavailability, Luverina vs Leponex
MW_RATIO     : 0.95707 : --     MW norclozapine / MW clozapine (312.80/326.83)

WT           : 70      : kg     Body weight
SMOKE        : 0       : --     0 = nonsmoker, 1 = smoker
LUVERINA     : 0       : --     0 = Leponex (reference), 1 = Luverina

TH_CL_WT     : 0.75    : --     Allometric exponent on CL/F (fixed)
TH_V_WT      : 1       : --     Weight exponent on V/F (fixed)

PROP_SD_P    : 0.0954  : --     Proportional residual SD, clozapine
PROP_SD_M    : 0.153   : --     Proportional residual SD, norclozapine

$CMT @annotated
DEPOT : Oral dosing/absorption compartment (mg)
CENT  : Clozapine central compartment (mg)
MET   : Norclozapine compartment (mg clozapine-equivalent converted by MW_RATIO)

$OMEGA @block @labels ETA_CL ETA_CLM
0.171841
0.108876 0.222344

$OMEGA @labels ETA_F
0.174034

$SIGMA
1 1

$GLOBAL
double KAi;
double CLi;
double CLMi;
double VFi;
double VMFi;
double Fi;

$MAIN
KAi = KA;

double CL_TV = (SMOKE == 1) ? CL_SM : CL_NS;

CLi = CL_TV *
      pow(WT / 70.0, TH_CL_WT) *
      exp(ETA_CL);

CLMi = CLM *
       pow(WT / 70.0, TH_CL_WT) *
       exp(ETA_CLM);

VFi  = VF  * pow(WT / 70.0, TH_V_WT);
VMFi = VMF * pow(WT / 70.0, TH_V_WT);

Fi = (LUVERINA == 1) ? F_LUV * exp(ETA_F) : 1.0;
F_DEPOT = Fi;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT =
    KAi * DEPOT
  - (CLi / VFi) * CENT;

dxdt_MET =
    MW_RATIO * (CLi / VFi) * CENT
  - (CLMi / VMFi) * MET;

$TABLE
double C_CZP  = 1000.0 * CENT / VFi;
double C_NCZP = 1000.0 * MET  / VMFi;
double RATIO  = (C_NCZP > 0) ? C_CZP / C_NCZP : 0;

double DV_CZP  = C_CZP  * (1.0 + PROP_SD_P * EPS(1));
double DV_NCZP = C_NCZP * (1.0 + PROP_SD_M * EPS(2));

double THALF_CZP  = log(2.0) * VFi  / CLi;
double THALF_NCZP = log(2.0) * VMFi / CLMi;

$CAPTURE
C_CZP C_NCZP RATIO DV_CZP DV_NCZP
KAi CLi CLMi VFi VMFi Fi
THALF_CZP THALF_NCZP
WT SMOKE LUVERINA
'
mod_cloz <- mcode("clozapine_pk", clozapine_code)


N <- 1000

# Twice-daily regimens (cohort: 150-700 mg/day, median 350 mg/day)
doses_mg <- c(100, 175, 300)                      # mg per dose, BID
dose_levels <- c("100 mg BID", "175 mg BID", "300 mg BID")

tau <- 12
n_dose <- 60                                      # 30 days BID

t_end_sd <- 72
last_dose <- tau * (n_dose - 1)
t_end_md <- last_dose + tau

delta_sd <- 0.1
delta_md <- 0.25
delta_md_pop <- 2
add_md <- seq(last_dose, t_end_md, by = 0.25)

mw_ratio <- 312.80 / 326.83

# Commonly used clozapine trough target (not from Olmos 2019)
czp_target <- 350

conc_vars <- c("C_CZP", "C_NCZP")
pop_outvars <- c(conc_vars, "RATIO", "THALF_NCZP")

analyte_map <- tibble(
  var = conc_vars,
  Analyte = factor(c("Clozapine", "Norclozapine"),
                   levels = c("Clozapine", "Norclozapine"))
)


at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

auc_trap <- function(time, conc) {
  sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2)
}

to_long <- function(df) {
  df %>%
    pivot_longer(all_of(conc_vars), names_to = "var", values_to = "CP") %>%
    left_join(analyte_map, by = "var") %>%
    select(-var)
}

dose_label <- function(d) paste0(d, " mg BID")




# Reference subject: 70 kg nonsmoker on Leponex (the model's reference level)
idata_typ <- tibble(
  ID = 1,
  WT = 70,
  SMOKE = 0,
  LUVERINA = 0
)

idata_pop <- tibble(
  ID = 1:N,
  WT = 70,
  SMOKE = 0,
  LUVERINA = 0
)

mod_typ <- zero_re(mod_cloz)





# ---------------------------------------------------------------------------
# Figure 1. Typical subject, single dose
# ---------------------------------------------------------------------------

fig1_list <- lapply(doses_mg, function(d) {
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_typ, end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = dose_label(d))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig1_long <- to_long(fig1_out)


p1_cloz <- ggplot(fig1_long, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  facet_wrap(~ Analyte, scales = "free_y") +
  scale_x_continuous(breaks = seq(0, 72, 12), limits = c(0, 72)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Clozapine single dose"
  )

p1_cloz


fig1_summary <- fig1_long %>%
  arrange(Analyte, Dose, time) %>%
  group_by(Analyte, Dose) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C12 = at_time(time, CP, tau),
    AUC0_12 = auc_trap(time[time <= tau], CP[time <= tau]),
    AUC0_72 = auc_trap(time, CP),
    .groups = "drop"
  )

fig1_summary

# Typical half-lives (h): ~18.5 clozapine, ~24.7 norclozapine at 70 kg
fig1_out %>% slice(1) %>% select(THALF_CZP, THALF_NCZP)





# ---------------------------------------------------------------------------
# Figure 2. Typical subject, twice daily for 30 days
# ---------------------------------------------------------------------------

fig2_list <- lapply(doses_mg, function(d) {
  
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau, addl = n_dose - 1)
  
  mod_typ %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_typ, end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = dose_label(d),
      time_day = time / 24
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig2_long <- to_long(fig2_out)


p2_cloz <- ggplot(fig2_long, aes(time_day, CP, color = Dose)) +
  geom_line(linewidth = 0.8) +
  facet_wrap(~ Analyte, scales = "free_y") +
  scale_x_continuous(breaks = seq(0, n_dose / 2, 5), limits = c(0, n_dose / 2)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    title = paste0("Figure 2. Clozapine twice daily for ", n_dose / 2, " days")
  )

p2_cloz


fig2_summary <- fig2_long %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  arrange(Analyte, Dose, t_rel) %>%
  group_by(Analyte, Dose) %>%
  summarise(
    Cmax_ss = max(CP),
    Tmax_ss_h = t_rel[which.max(CP)],
    Ctrough_ss = at_time(t_rel, CP, tau),
    AUCtau_ss = auc_trap(t_rel, CP),
    .groups = "drop"
  )

fig2_summary


# Structural check (mass balance at steady state, F = 1 for Leponex):
#   CL_CZP  * AUCtau(CZP)  = Dose
#   CL_NCZP * AUCtau(NCZP) = MW_RATIO * Dose
par_typ <- fig2_out %>% slice(1)

fig2_check <- fig2_summary %>%
  mutate(
    dose = as.numeric(sub(" mg BID", "", as.character(Dose))),
    AUC_expected = ifelse(Analyte == "Clozapine",
                          1000 * dose / par_typ$CLi,
                          1000 * mw_ratio * dose / par_typ$CLMi),
    pct_diff = 100 * (AUCtau_ss / AUC_expected - 1)
  ) %>%
  select(Analyte, Dose, AUCtau_ss, AUC_expected, pct_diff)

fig2_check


# Covariate scenarios, typical subject, 175 mg BID at steady state:
# smoker vs nonsmoker, Leponex vs Luverina, 70 vs 140 kg
scen <- tibble(
  ID = 1:5,
  Scenario = c("Reference (70 kg, nonsmoker, Leponex)", "Smoker",
               "Luverina", "140 kg", "Smoker + Luverina"),
  WT = c(70, 70, 70, 140, 70),
  SMOKE = c(0, 1, 0, 0, 1),
  LUVERINA = c(0, 0, 1, 0, 1)
)

ev_scen <- ev(time = 0, amt = 175, cmt = "DEPOT", ii = tau, addl = n_dose - 1)

scen_out <- mod_typ %>%
  ev(ev_scen) %>%
  mrgsim(idata = select(scen, ID, WT, SMOKE, LUVERINA),
         end = t_end_md, delta = 12, add = add_md, obsonly = TRUE) %>%
  as_tibble() %>%
  filter(time >= last_dose, time <= t_end_md) %>%
  mutate(t_rel = time - last_dose) %>%
  left_join(select(scen, ID, Scenario), by = "ID")

scen_summary <- scen_out %>%
  group_by(ID, Scenario) %>%
  summarise(
    AUC_CZP = auc_trap(t_rel, C_CZP),
    AUC_NCZP = auc_trap(t_rel, C_NCZP),
    Ctrough_CZP = at_time(t_rel, C_CZP, tau),
    Ctrough_NCZP = at_time(t_rel, C_NCZP, tau),
    Ratio_trough = at_time(t_rel, RATIO, tau),
    .groups = "drop"
  ) %>%
  mutate(
    AUC_CZP_vs_ref = AUC_CZP / AUC_CZP[ID == 1],
    AUC_NCZP_vs_ref = AUC_NCZP / AUC_NCZP[ID == 1]
  )

scen_summary
# Expected: smoker CZP ratio 28.1/36.5 = 0.770, NCZP unchanged;
# Luverina 0.892 for both; 140 kg (70/140)^0.75 = 0.595.





# ---------------------------------------------------------------------------
# Figure 3. Population, single dose
# ---------------------------------------------------------------------------

fig3_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_cloz %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_pop, end = t_end_sd, delta = delta_sd,
           obsonly = TRUE, outvars = pop_outvars) %>%
    as_tibble() %>%
    mutate(Dose = dose_label(d))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig3_long <- to_long(fig3_raw)


fig3_sum <- fig3_long %>%
  group_by(Analyte, Dose, time) %>%
  summarise(
    CP_med = median(CP),
    CP_p05 = quantile(CP, 0.05),
    CP_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )


p3_cloz <- ggplot(fig3_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~ Analyte, scales = "free_y") +
  scale_x_continuous(breaks = seq(0, 72, 12), limits = c(0, 72)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Clozapine single dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p3_cloz


fig3_ind <- fig3_long %>%
  arrange(Analyte, Dose, ID, time) %>%
  group_by(Analyte, Dose, ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C12 = at_time(time, CP, tau),
    AUC0_12 = auc_trap(time[time <= tau], CP[time <= tau]),
    .groups = "drop"
  )


fig3_summary <- fig3_ind %>%
  group_by(Analyte, Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    C12_med = median(C12),
    C12_p05 = quantile(C12, 0.05),
    C12_p95 = quantile(C12, 0.95),
    
    AUC0_12_med = median(AUC0_12),
    AUC0_12_p05 = quantile(AUC0_12, 0.05),
    AUC0_12_p95 = quantile(AUC0_12, 0.95),
    
    .groups = "drop"
  )

fig3_summary




# ---------------------------------------------------------------------------
# Figure 4. Population, twice daily for 30 days
# ---------------------------------------------------------------------------

fig4_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau, addl = n_dose - 1)
  
  mod_cloz %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_pop, end = t_end_md, delta = delta_md_pop,
           add = add_md, obsonly = TRUE, outvars = pop_outvars) %>%
    as_tibble() %>%
    mutate(
      Dose = dose_label(d),
      time_day = time / 24
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig4_long <- to_long(fig4_raw)


fig4_sum <- fig4_long %>%
  group_by(Analyte, Dose, time, time_day) %>%
  summarise(
    CP_med = median(CP),
    CP_p05 = quantile(CP, 0.05),
    CP_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )


p4_cloz <- ggplot(fig4_sum, aes(time_day, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 0.8) +
  facet_wrap(~ Analyte, scales = "free_y") +
  scale_x_continuous(breaks = seq(0, n_dose / 2, 5), limits = c(0, n_dose / 2)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = paste0("Figure 4. Clozapine twice daily for ", n_dose / 2, " days, population"),
    subtitle = "Median with 5th–95th percentiles"
  )

p4_cloz


fig4_ind <- fig4_long %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  arrange(Analyte, Dose, ID, t_rel) %>%
  group_by(Analyte, Dose, ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = t_rel[which.max(CP)],
    Ctrough = at_time(t_rel, CP, tau),
    AUCtau = auc_trap(t_rel, CP),
    .groups = "drop"
  )


fig4_summary <- fig4_ind %>%
  group_by(Analyte, Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    Ctrough_med = median(Ctrough),
    Ctrough_p05 = quantile(Ctrough, 0.05),
    Ctrough_p95 = quantile(Ctrough, 0.95),
    
    AUCtau_med = median(AUCtau),
    AUCtau_p05 = quantile(AUCtau, 0.05),
    AUCtau_p95 = quantile(AUCtau, 0.95),
    
    .groups = "drop"
  )

fig4_summary
