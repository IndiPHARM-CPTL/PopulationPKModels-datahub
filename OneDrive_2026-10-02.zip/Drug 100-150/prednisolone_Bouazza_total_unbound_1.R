library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

prednisolone_code <- '
$PROB
Prednisolone oral population PK model after prednisone administration

- Ref: Bouazza N, Semeraro M, Lui G, et al. Population pharmacokinetic
  modelling of prednisolone in systemic lupus erythematosus patients:
  Analysis of exposure and disease activity. Br J Clin Pharmacol.
  2025;91(10):2854-2864. doi:10.1002/bcp.70103


$PARAM @annotated
KA       : 1.19    : 1/h       First-order absorption/formation rate
TLAG     : 0.17    : h         Absorption/metabolic lag time
CL_U     : 54.3    : L/h       Apparent unbound clearance at 70 kg
V_U      : 235     : L         Apparent unbound volume at 70 kg
WT       : 70      : kg        Total body weight
BETA_F   : -0.28   : --        Dose exponent on relative bioavailability
BMAX     : 6.77    : --        CBG saturable-binding capacity term
K1       : 0.0095  : L/nmol    CBG affinity constant
KNS      : 0.8     : --        Nonsaturable albumin-binding constant
DOSE_MG  : 30      : mg        Prednisone dose; must match event amt

MW_PRED  : 358.43  : mg/mmol   Molecular weight of prednisone
MW_PSL   : 360.44  : mg/mmol   Molecular weight of prednisolone
REF_NMOL : 80000   : nmol      Reference prednisone dose for F_REL = 1

$CMT 
DEPOT CENT

$OMEGA @annotated
ECL_U  : 0.1225 : IIV variance on CL_U; omega SD = 0.35
EBMAX  : 0.0900 : IIV variance on BMAX; omega SD = 0.30, fixed

$SIGMA @annotated
PROP : 0.1764 : Proportional residual variance; sigma SD = 0.42

$MAIN
double CLUi = CL_U * pow(WT / 70.0, 0.75) * exp(ECL_U);
double VUi  = V_U  * pow(WT / 70.0, 1.00);
double BMAXi = BMAX * exp(EBMAX);

double NMOL_PER_MG = 1.0e6 / MW_PRED;
double DOSE_NMOL = DOSE_MG * NMOL_PER_MG;
double FREL = pow(DOSE_NMOL / REF_NMOL, BETA_F);

F_DEPOT = NMOL_PER_MG * FREL;
ALAG_DEPOT = TLAG;

double KEL = CLUi / VUi;

$ODE
dxdt_DEPOT = -KA * DEPOT;
dxdt_CENT  =  KA * DEPOT - KEL * CENT;

$TABLE
double CU_NMOL_L = CENT / VUi;
double CTOT_NMOL_L = CU_NMOL_L *
  (1.0 + BMAXi / (1.0 + K1 * CU_NMOL_L) + KNS);

double CU = CU_NMOL_L * MW_PSL / 1000.0;
double CP = CTOT_NMOL_L * MW_PSL / 1000.0;
double DV = CP * (1.0 + PROP);

$CAPTURE CP CU DV CU_NMOL_L CTOT_NMOL_L CLUi VUi BMAXi KEL FREL DOSE_NMOL
'

mod_prednisolone <- mcode("prednisolone_bouazza_2025", prednisolone_code)
dose_mg <- 30

mod_typ <- mod_prednisolone %>%
  zero_re() %>%
  param(WT = 70, DOSE_MG = dose_mg)

fig1 <- mod_typ %>%
  ev(amt = dose_mg, cmt = 1) %>%
  mrgsim(start = 0, end = 24, delta = 0.01) %>%
  as_tibble()

p1 <- ggplot(fig1, aes(time, CP)) +
  geom_line(linewidth = 0.9) +
  labs(
    x = "Time (h)",
    y = "Total prednisolone concentration (ng/mL)",
    title = "Figure 1. Single 30 mg oral prednisone dose"
  ) +
  theme_bw()

p1

fig2_all <- mod_typ %>%
  ev(amt = dose_mg, cmt = 1, ii = 24, addl = 6) %>%
  mrgsim(start = 0, end = 168, delta = 0.01) %>%
  as_tibble()

fig2 <- fig2_all %>%
  filter(time >= 144) %>%
  mutate(time_plot = time - 144)

p2 <- ggplot(fig2, aes(time_plot, CP)) +
  geom_line(linewidth = 0.9) +
  labs(
    x = "Time after last dose (h)",
    y = "Total prednisolone concentration (ng/mL)",
    title = "Figure 2. 30 mg oral prednisone QD, Day 7"
  ) +
  theme_bw()

p2

set.seed(1234)

idata <- tibble(
  ID = 1:1000,
  WT = 70
)

fig3_raw <- mod_prednisolone %>%
  param(DOSE_MG = dose_mg) %>%
  idata_set(idata) %>%
  ev(amt = dose_mg, cmt = 1) %>%
  mrgsim(start = 0, end = 24, delta = 0.05) %>%
  as_tibble()

fig3 <- fig3_raw %>%
  group_by(time) %>%
  summarise(
    med = median(CP),
    p05 = quantile(CP, 0.05),
    p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p3 <- ggplot(fig3, aes(time, med)) +
  geom_ribbon(aes(ymin = p05, ymax = p95), alpha = 0.2) +
  geom_line(linewidth = 0.9) +
  labs(
    x = "Time (h)",
    y = "Total prednisolone concentration (ng/mL)",
    title = "Figure 3. Single 30 mg oral prednisone dose, N=1000"
  ) +
  theme_bw()

p3

set.seed(1234)
fig4_raw <- mod_prednisolone %>%
  param(DOSE_MG = dose_mg) %>%
  idata_set(idata) %>%
  ev(amt = dose_mg, cmt = 1, ii = 24, addl = 6) %>%
  mrgsim(start = 0, end = 168, delta = 0.05) %>%
  as_tibble()

fig4 <- fig4_raw %>%
  filter(time >= 144) %>%
  mutate(time_plot = time - 144) %>%
  group_by(time_plot) %>%
  summarise(
    med = median(CP),
    p05 = quantile(CP, 0.05),
    p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p4 <- ggplot(fig4, aes(time_plot, med)) +
  geom_ribbon(aes(ymin = p05, ymax = p95), alpha = 0.2) +
  geom_line(linewidth = 0.9) +
  labs(
    x = "Time after last dose (h)",
    y = "Total prednisolone concentration (ng/mL)",
    title = "Figure 4. 30 mg oral prednisone QD, Day 7, N=1000"
  ) +
  theme_bw()

p4

auc_trap <- function(time, conc) {
  sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2)
}

# Typical-subject summaries
fig1_summary <- fig1 %>%
  summarise(
    Dose = "30 mg single dose",
    Cmax_ng_mL = max(CP),
    Tmax_h = time[which.max(CP)],
    C24_ng_mL = CP[which.max(time)],
    AUC0_24_ng_h_mL = auc_trap(time, CP)
  )

fig2_summary <- fig2 %>%
  summarise(
    Dose = "30 mg QD, Day 7",
    Cmax_day7_ng_mL = max(CP),
    Tmax_day7_h = time_plot[which.max(CP)],
    Ctrough_day7_ng_mL = CP[which.max(time_plot)],
    AUCtau_day7_ng_h_mL = auc_trap(time_plot, CP)
  )

fig1_summary
fig2_summary


fig3_individual <- fig3_raw %>%
  group_by(ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax = time[which.max(CP)],
    C24 = CP[which.max(time)],
    AUC0_24 = auc_trap(time, CP),
    .groups = "drop"
  )

fig3_summary <- fig3_individual %>%
  summarise(
    Dose = "30 mg single dose",
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    Tmax_med = median(Tmax),
    Tmax_p05 = quantile(Tmax, 0.05),
    Tmax_p95 = quantile(Tmax, 0.95),
    C24_med = median(C24),
    C24_p05 = quantile(C24, 0.05),
    C24_p95 = quantile(C24, 0.95),
    AUC0_24_med = median(AUC0_24),
    AUC0_24_p05 = quantile(AUC0_24, 0.05),
    AUC0_24_p95 = quantile(AUC0_24, 0.95)
  )

# Individual PK metrics: Day 7
fig4_individual <- fig4_raw %>%
  filter(time >= 144) %>%
  mutate(time_plot = time - 144) %>%
  group_by(ID) %>%
  summarise(
    Cmax_day7 = max(CP),
    Tmax_day7 = time_plot[which.max(CP)],
    Ctrough_day7 = CP[which.max(time_plot)],
    AUCtau_day7 = auc_trap(time_plot, CP),
    .groups = "drop"
  )

fig4_summary <- fig4_individual %>%
  summarise(
    Dose = "30 mg QD, Day 7",
    Cmax_day7_med = median(Cmax_day7),
    Cmax_day7_p05 = quantile(Cmax_day7, 0.05),
    Cmax_day7_p95 = quantile(Cmax_day7, 0.95),
    Tmax_day7_med = median(Tmax_day7),
    Tmax_day7_p05 = quantile(Tmax_day7, 0.05),
    Tmax_day7_p95 = quantile(Tmax_day7, 0.95),
    Ctrough_day7_med = median(Ctrough_day7),
    Ctrough_day7_p05 = quantile(Ctrough_day7, 0.05),
    Ctrough_day7_p95 = quantile(Ctrough_day7, 0.95),
    AUCtau_day7_med = median(AUCtau_day7),
    AUCtau_day7_p05 = quantile(AUCtau_day7, 0.05),
    AUCtau_day7_p95 = quantile(AUCtau_day7, 0.95)
  )

fig3_summary
fig4_summary