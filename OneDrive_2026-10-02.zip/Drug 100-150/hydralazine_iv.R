library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

hydralazine_code <- '
$PROB
Hydralazine IV one-compartment PK model with empirical HPH metabolite compartment
- Ref: Ludden TM, Shepherd AMM, McNay JL, Lin M-S.
  Hydralazine kinetics in hypertensive patients after intravenous administration.
  Clin Pharmacol Ther. 1980;28(6):736-742.
- Not a good model 

$PARAM @annotated
VKG      : 5.83   : L/kg     Apparent volume of distribution, Vdarea; selected to match terminal half-life
CLKG     : 0.0729 : L/min/kg Total plasma clearance; 72.9 mL/min/kg
FM_HPH   : 1.00   : --       Apparent fraction of parent elimination entering empirical HPH compartment
VHPHKG   : 0.70   : L/kg     Empirical HPH apparent volume; selected to approximate HPH Cmax/AUC
KHPH     : 0.00290: 1/min    HPH elimination rate constant; t1/2 ~239 min
MW_HYD   : 160.18 : g/mol    Molecular weight of hydralazine free base

$CMT 
CENT HPH

$OMEGA @annotated
ECL      : 0.040 : IIV on hydralazine clearance
EV       : 0.090 : IIV on hydralazine apparent volume
EVHPH    : 0.090 : IIV on HPH apparent volume
EKHPH    : 0.090 : IIV on HPH elimination rate

$MAIN
double CLi    = CLKG   * exp(ECL);
double Vi     = VKG    * exp(EV);
double K10i   = CLi / Vi;

double VHPHi  = VHPHKG * exp(EVHPH);
double KHPHi  = KHPH   * exp(EKHPH);

$ODE
dxdt_CENT = -K10i * CENT;

dxdt_HPH  =  FM_HPH * K10i * CENT - KHPHi  * HPH;

$TABLE
double C_HYD_uM   = CENT / Vi;
double C_HYD_ngmL = C_HYD_uM * MW_HYD;

$CAPTURE C_HYD_uM C_HYD_ngmL
'
mod <- mcode("hydralazine_ludden_1980_iv_1c", hydralazine_code)


dose_mgkg <- c(0.1, 0.3, 0.5)

n_pop <- 1000
set.seed(123)

infusion_duration_min <- 100 / 60

mg_per_umol_hcl <- 0.19664

tau_min    <- 360   
n_doses    <- 6
addl_md    <- n_doses - 1

t_end_sd <- 480       
t_end_md <- 2160      

delta_sd <- 1
delta_md <- 1

last_dose_min <- (n_doses - 1) * tau_min
final_interval_end_min <- last_dose_min + tau_min

idata_typ <- tibble(
  ID = 1
)

idata_pop <- tibble(
  ID = 1:n_pop
)

mod_typ <- zero_re(mod)



get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  
  df$conc[which.min(abs(df$time - t))]
}


make_long_primary <- function(x) {
  x %>%
    pivot_longer(
      cols = c(C_HYD_uM),
      names_to = "analyte",
      values_to = "conc_uM"
    ) %>%
    mutate(
      analyte = recode(
        analyte,
        C_HYD_uM = "Hydralazine"
      )
    )
}


fig1_raw <- lapply(dose_mgkg, function(d) {
  
  amt_umolkg <- d / mg_per_umol_hcl
  
  ev_one <- ev(
    time = 0,
    amt  = amt_umolkg,
    cmt  = 1,
    rate = amt_umolkg / infusion_duration_min
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg/kg IV")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mgkg, " mg/kg IV"))
  )

fig1 <- make_long_primary(fig1_raw)

p1 <- ggplot(fig1, aes(x = time, y = conc_uM, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after IV dose (min)",
    y = "Plasma hydralazine concentration (uM)",
    title = "Figure 1. Hydralazine IV single-dose typical simulation",
    color = "Dose"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_uM, na.rm = TRUE),
    Tmax = time[which.max(conc_uM)],
    C2   = get_conc_at(time, conc_uM, 2),
    C5   = get_conc_at(time, conc_uM, 5),
    C10  = get_conc_at(time, conc_uM, 10),
    C15  = get_conc_at(time, conc_uM, 15),
    C30  = get_conc_at(time, conc_uM, 30),
    C60  = get_conc_at(time, conc_uM, 60),
    C90  = get_conc_at(time, conc_uM, 90),
    C120 = get_conc_at(time, conc_uM, 120),
    C180 = get_conc_at(time, conc_uM, 180),
    C240 = get_conc_at(time, conc_uM, 240),
    C360 = get_conc_at(time, conc_uM, 360),
    C480 = get_conc_at(time, conc_uM, 480),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_uM = median(Cmax, na.rm = TRUE),
    Tmax_min = median(Tmax, na.rm = TRUE),
    C2_uM   = median(C2, na.rm = TRUE),
    C5_uM   = median(C5, na.rm = TRUE),
    C10_uM  = median(C10, na.rm = TRUE),
    C15_uM  = median(C15, na.rm = TRUE),
    C30_uM  = median(C30, na.rm = TRUE),
    C60_uM  = median(C60, na.rm = TRUE),
    C90_uM  = median(C90, na.rm = TRUE),
    C120_uM = median(C120, na.rm = TRUE),
    C180_uM = median(C180, na.rm = TRUE),
    C240_uM = median(C240, na.rm = TRUE),
    C360_uM = median(C360, na.rm = TRUE),
    C480_uM = median(C480, na.rm = TRUE),
    .groups = "drop"
  )

p1
fig1_summary




fig2_raw <- lapply(dose_mgkg, function(d) {
  
  amt_umolkg <- d / mg_per_umol_hcl
  
  ev_md <- ev(
    time = 0,
    amt  = amt_umolkg,
    cmt  = 1,
    rate = amt_umolkg / infusion_duration_min,
    ii   = tau_min,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg/kg IV q6h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mgkg, " mg/kg IV q6h x", n_doses))
  )

fig2 <- make_long_primary(fig2_raw)

p2 <- ggplot(fig2, aes(x = time, y = conc_uM, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (min)",
    y = "Plasma hydralazine concentration (uM)",
    title = "Figure 2. Hydralazine IV q6h multiple-dose typical simulation",
    color = "Dose"
  ) +
  theme_bw()

fig2_ind <- fig2 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_uM[time >= last_dose_min & time <= final_interval_end_min],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_min & time <= final_interval_end_min, conc_uM, -Inf))
    ] - last_dose_min,
    C360_after_last = get_conc_at(time, conc_uM, final_interval_end_min),
    C360_day1       = get_conc_at(time, conc_uM, tau_min),
    C720            = get_conc_at(time, conc_uM, 720),
    C1440           = get_conc_at(time, conc_uM, 1440),
    C1800           = get_conc_at(time, conc_uM, 1800),
    C2160           = get_conc_at(time, conc_uM, 2160),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_uM = median(Cmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_min = median(Tmax_final_interval, na.rm = TRUE),
    C360_after_last_uM = median(C360_after_last, na.rm = TRUE),
    C360_day1_uM       = median(C360_day1, na.rm = TRUE),
    C720_uM            = median(C720, na.rm = TRUE),
    C1440_uM           = median(C1440, na.rm = TRUE),
    C1800_uM           = median(C1800, na.rm = TRUE),
    C2160_uM           = median(C2160, na.rm = TRUE),
    .groups = "drop"
  )

p2
fig2_summary





fig3_raw <- lapply(dose_mgkg, function(d) {
  
  amt_umolkg <- d / mg_per_umol_hcl
  
  ev_one <- ev(
    time = 0,
    amt  = amt_umolkg,
    cmt  = 1,
    rate = amt_umolkg / infusion_duration_min
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg/kg IV")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mgkg, " mg/kg IV"))
  )

fig3 <- make_long_primary(fig3_raw)

fig3_sum <- fig3 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_uM, na.rm = TRUE),
    CP_p05 = quantile(conc_uM, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_uM, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after IV dose (min)",
    y = "Plasma hydralazine concentration (uM)",
    title = "Figure 3. Hydralazine IV single-dose population simulation",
    subtitle = "Line = median; ribbon = 5th-95th percentile",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig3_ind <- fig3 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_uM, na.rm = TRUE),
    Tmax = time[which.max(conc_uM)],
    C2   = get_conc_at(time, conc_uM, 2),
    C5   = get_conc_at(time, conc_uM, 5),
    C10  = get_conc_at(time, conc_uM, 10),
    C15  = get_conc_at(time, conc_uM, 15),
    C30  = get_conc_at(time, conc_uM, 30),
    C60  = get_conc_at(time, conc_uM, 60),
    C90  = get_conc_at(time, conc_uM, 90),
    C120 = get_conc_at(time, conc_uM, 120),
    C180 = get_conc_at(time, conc_uM, 180),
    C240 = get_conc_at(time, conc_uM, 240),
    C360 = get_conc_at(time, conc_uM, 360),
    C480 = get_conc_at(time, conc_uM, 480),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C10_med = median(C10, na.rm = TRUE),
    C10_p05 = quantile(C10, 0.05, na.rm = TRUE),
    C10_p95 = quantile(C10, 0.95, na.rm = TRUE),
    
    C30_med = median(C30, na.rm = TRUE),
    C30_p05 = quantile(C30, 0.05, na.rm = TRUE),
    C30_p95 = quantile(C30, 0.95, na.rm = TRUE),
    
    C60_med = median(C60, na.rm = TRUE),
    C60_p05 = quantile(C60, 0.05, na.rm = TRUE),
    C60_p95 = quantile(C60, 0.95, na.rm = TRUE),
    
    C120_med = median(C120, na.rm = TRUE),
    C120_p05 = quantile(C120, 0.05, na.rm = TRUE),
    C120_p95 = quantile(C120, 0.95, na.rm = TRUE),
    
    C180_med = median(C180, na.rm = TRUE),
    C180_p05 = quantile(C180, 0.05, na.rm = TRUE),
    C180_p95 = quantile(C180, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3
fig3_summary


fig4_raw <- lapply(dose_mgkg, function(d) {
  
  amt_umolkg <- d / mg_per_umol_hcl
  
  ev_md <- ev(
    time = 0,
    amt  = amt_umolkg,
    cmt  = 1,
    rate = amt_umolkg / infusion_duration_min,
    ii   = tau_min,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg/kg IV q6h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mgkg, " mg/kg IV q6h x", n_doses))
  )

fig4 <- make_long_primary(fig4_raw)

fig4_sum <- fig4 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_uM, na.rm = TRUE),
    CP_p05 = quantile(conc_uM, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_uM, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (min)",
    y = "Plasma hydralazine concentration (uM)",
    title = "Figure 4. Hydralazine IV q6h population simulation",
    subtitle = "Line = median; ribbon = 5th-95th percentile",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig4_ind <- fig4 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_uM[time >= last_dose_min & time <= final_interval_end_min],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_min & time <= final_interval_end_min, conc_uM, -Inf))
    ] - last_dose_min,
    C360_after_last = get_conc_at(time, conc_uM, final_interval_end_min),
    C360_day1       = get_conc_at(time, conc_uM, tau_min),
    C720            = get_conc_at(time, conc_uM, 720),
    C1440           = get_conc_at(time, conc_uM, 1440),
    C1800           = get_conc_at(time, conc_uM, 1800),
    C2160           = get_conc_at(time, conc_uM, 2160),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_final_interval_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_final_interval_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_final_interval_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_final_interval_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C360_after_last_med = median(C360_after_last, na.rm = TRUE),
    C360_after_last_p05 = quantile(C360_after_last, 0.05, na.rm = TRUE),
    C360_after_last_p95 = quantile(C360_after_last, 0.95, na.rm = TRUE),
    
    C360_day1_med = median(C360_day1, na.rm = TRUE),
    C360_day1_p05 = quantile(C360_day1, 0.05, na.rm = TRUE),
    C360_day1_p95 = quantile(C360_day1, 0.95, na.rm = TRUE),
    
    C1440_med = median(C1440, na.rm = TRUE),
    C1440_p05 = quantile(C1440, 0.05, na.rm = TRUE),
    C1440_p95 = quantile(C1440, 0.95, na.rm = TRUE),
    
    C2160_med = median(C2160, na.rm = TRUE),
    C2160_p05 = quantile(C2160, 0.05, na.rm = TRUE),
    C2160_p95 = quantile(C2160, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4
fig4_summary


