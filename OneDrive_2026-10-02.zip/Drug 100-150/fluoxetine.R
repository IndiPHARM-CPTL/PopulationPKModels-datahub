library(mrgsolve)  
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

fluoxetine_code <- '
$PROB
Fluoxetine + norfluoxetine joint population PK model
- Ref: Han B, Xu N, Ma C, Ju G, Xi X, Qian C, Guo N, Liu X, Zhu X, Li C, Liu L.
  Bridging Literature and Real-World Evidence: External Evaluation and
  Development of Fluoxetine Population Pharmacokinetics Model.
  Pharmaceutics. 2025;17(12):1516.
  doi:10.3390/pharmaceutics17121516
  

$PARAM @annotated
KA          : 0.3    : 1/h    First-order absorption rate constant (fixed)
CLF         : 2.91   : L/h    Fluoxetine apparent clearance (female)
VF          : 24.9   : L      Fluoxetine apparent volume
FM          : 1      : --     Fraction of fluoxetine converted to norfluoxetine (fixed)
CLMF        : 3.24   : L/h    Norfluoxetine apparent clearance
VMF         : 1.52   : L      Norfluoxetine apparent volume

MALE        : 0      : --     0 = female, 1 = male

TH_CL_MALE  : 0.165  : --     Male effect on fluoxetine CL/F (fractional)

PROP_SD_P   : 0.341  : --     Proportional residual SD, fluoxetine
ADD_SD_P    : 14.9   : ng/mL  Additive residual SD, fluoxetine
PROP_SD_M   : 0.305  : --     Proportional residual SD, norfluoxetine
ADD_SD_M    : 22.9   : ng/mL  Additive residual SD, norfluoxetine

$CMT @annotated
DEPOT : Oral dosing/absorption compartment (mg)
CENT  : Fluoxetine central compartment (mg)
MET   : Norfluoxetine compartment (mg)

$OMEGA @labels ETA_CL ETA_CLM
0.0951793 0.0427539

$SIGMA
1 1 1 1

$GLOBAL
double KAi;
double CLFi;
double VFi;
double CLMFi;
double VMFi;

$MAIN
KAi = KA;

CLFi = CLF *
       (1.0 + TH_CL_MALE * MALE) *
       exp(ETA_CL);

VFi = VF;

CLMFi = CLMF * exp(ETA_CLM);

VMFi = VMF;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT =
    KAi * DEPOT
  - (CLFi / VFi) * CENT;

dxdt_MET =
    FM * (CLFi / VFi) * CENT
  - (CLMFi / VMFi) * MET;

$TABLE
double C_FLX  = 1000.0 * CENT / VFi;
double C_NFLX = 1000.0 * MET  / VMFi;
double C_ACT  = C_FLX + C_NFLX;

double DV_FLX =
  C_FLX * (1.0 + PROP_SD_P * EPS(1)) + ADD_SD_P * EPS(2);

double DV_NFLX =
  C_NFLX * (1.0 + PROP_SD_M * EPS(3)) + ADD_SD_M * EPS(4);

$CAPTURE
C_FLX C_NFLX C_ACT
DV_FLX DV_NFLX
KAi CLFi VFi CLMFi VMFi
MALE
'
mod_flx <- mcode("fluoxetine_pk", fluoxetine_code)


N <- 1000

doses_mg <- c(20, 40, 60)
dose_levels <- c("20 mg", "40 mg", "60 mg")

tau <- 24
n_dose <- 10

t_end_sd <- 72
last_dose <- tau * (n_dose - 1)
t_end_md <- last_dose + tau

delta_sd <- 0.1
delta_md <- 0.25

# Therapeutic window for the active moiety (Han 2025 Sect. 2.6)
target_lo <- 120
target_hi <- 500

conc_vars <- c("C_FLX", "C_NFLX", "C_ACT")
pop_outvars <- conc_vars

analyte_map <- tibble(
  var = conc_vars,
  Analyte = factor(
    c("Fluoxetine", "Norfluoxetine", "Active moiety"),
    levels = c("Fluoxetine", "Norfluoxetine", "Active moiety")
  )
)


at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

auc_trap <- function(time, conc) {
  sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2)
}

to_long <- function(df) {
  df %>%
    pivot_longer(all_of(conc_vars), names_to = "var", values_to = "CP") %>%
    left_join(analyte_map, by = "var") %>%
    select(-var)
}




# Reference subject: female (the Table 4 reference level)
idata_typ <- tibble(
  ID = 1,
  MALE = 0
)

idata_pop <- tibble(
  ID = 1:N,
  MALE = 0
)

mod_typ <- zero_re(mod_flx)





# ---------------------------------------------------------------------------
# Figure 1. Typical subject, single dose
# ---------------------------------------------------------------------------

fig1_list <- lapply(doses_mg, function(d) {
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_typ, end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = paste0(d, " mg"))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig1_long <- to_long(fig1_out)


p1_flx <- ggplot(fig1_long, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  facet_wrap(~ Analyte, scales = "free_y") +
  scale_x_continuous(breaks = seq(0, 72, 12), limits = c(0, 72)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Fluoxetine single dose"
  )

p1_flx


fig1_summary <- fig1_long %>%
  filter(time <= tau) %>%
  arrange(Analyte, Dose, time) %>%
  group_by(Analyte, Dose) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C24 = at_time(time, CP, tau),
    AUC0_24 = auc_trap(time, CP),
    .groups = "drop"
  )

fig1_summary





# ---------------------------------------------------------------------------
# Figure 2. Typical subject, once daily for 10 days
# ---------------------------------------------------------------------------

fig2_list <- lapply(doses_mg, function(d) {
  
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau, addl = n_dose - 1)
  
  mod_typ %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_typ, end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig2_long <- to_long(fig2_out)


p2_flx <- ggplot(fig2_long, aes(time_day, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  facet_wrap(~ Analyte, scales = "free_y") +
  scale_x_continuous(breaks = seq(0, 10, 1), limits = c(0, 10)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Fluoxetine once daily for 10 days"
  )

p2_flx


fig2_summary <- fig2_long %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  arrange(Analyte, Dose, t_rel) %>%
  group_by(Analyte, Dose) %>%
  summarise(
    Cmax_ss = max(CP),
    Tmax_ss_h = t_rel[which.max(CP)],
    Ctrough_ss = at_time(t_rel, CP, tau),
    AUCtau_ss = auc_trap(t_rel, CP),
    .groups = "drop"
  )

fig2_summary


# Structural check: at steady state with FM = 1,
#   AUCtau(fluoxetine)    = Dose / CL/F
#   AUCtau(norfluoxetine) = Dose / CLM/F
par_typ <- fig2_out %>% slice(1)

fig2_check <- fig2_summary %>%
  filter(Analyte != "Active moiety") %>%
  mutate(
    dose = as.numeric(sub(" mg", "", as.character(Dose))),
    CL = ifelse(Analyte == "Fluoxetine", par_typ$CLFi, par_typ$CLMFi),
    AUC_expected = 1000 * dose / CL,       # ng*h/mL
    pct_diff = 100 * (AUCtau_ss / AUC_expected - 1)
  ) %>%
  select(Analyte, Dose, AUCtau_ss, AUC_expected, pct_diff)

fig2_check





# ---------------------------------------------------------------------------
# Figure 3. Population, single dose
# ---------------------------------------------------------------------------

fig3_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_flx %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_pop, end = t_end_sd, delta = delta_sd,
           obsonly = TRUE, outvars = pop_outvars) %>%
    as_tibble() %>%
    mutate(Dose = paste0(d, " mg"))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig3_long <- to_long(fig3_raw)


fig3_sum <- fig3_long %>%
  group_by(Analyte, Dose, time) %>%
  summarise(
    CP_med = median(CP),
    CP_p05 = quantile(CP, 0.05),
    CP_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )


p3_flx <- ggplot(fig3_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~ Analyte, scales = "free_y") +
  scale_x_continuous(breaks = seq(0, 72, 12), limits = c(0, 72)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Fluoxetine single dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p3_flx


fig3_ind <- fig3_long %>%
  filter(time <= tau) %>%
  arrange(Analyte, Dose, ID, time) %>%
  group_by(Analyte, Dose, ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C24 = at_time(time, CP, tau),
    AUC0_24 = auc_trap(time, CP),
    .groups = "drop"
  )


fig3_summary <- fig3_ind %>%
  group_by(Analyte, Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    C24_med = median(C24),
    C24_p05 = quantile(C24, 0.05),
    C24_p95 = quantile(C24, 0.95),
    
    AUC0_24_med = median(AUC0_24),
    AUC0_24_p05 = quantile(AUC0_24, 0.05),
    AUC0_24_p95 = quantile(AUC0_24, 0.95),
    
    .groups = "drop"
  )

fig3_summary




# ---------------------------------------------------------------------------
# Figure 4. Population, once daily for 10 days
# ---------------------------------------------------------------------------

fig4_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau, addl = n_dose - 1)
  
  mod_flx %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_pop, end = t_end_md, delta = delta_md,
           obsonly = TRUE, outvars = pop_outvars) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig4_long <- to_long(fig4_raw)


fig4_sum <- fig4_long %>%
  group_by(Analyte, Dose, time, time_day) %>%
  summarise(
    CP_med = median(CP),
    CP_p05 = quantile(CP, 0.05),
    CP_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )


p4_flx <- ggplot(fig4_sum, aes(time_day, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~ Analyte, scales = "free_y") +
  scale_x_continuous(breaks = seq(0, 10, 1), limits = c(0, 10)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Fluoxetine once daily for 10 days, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p4_flx


fig4_ind <- fig4_long %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  arrange(Analyte, Dose, ID, t_rel) %>%
  group_by(Analyte, Dose, ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = t_rel[which.max(CP)],
    Ctrough = at_time(t_rel, CP, tau),
    AUCtau = auc_trap(t_rel, CP),
    .groups = "drop"
  )


fig4_summary <- fig4_ind %>%
  group_by(Analyte, Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    Ctrough_med = median(Ctrough),
    Ctrough_p05 = quantile(Ctrough, 0.05),
    Ctrough_p95 = quantile(Ctrough, 0.95),
    
    AUCtau_med = median(AUCtau),
    AUCtau_p05 = quantile(AUCtau, 0.05),
    AUCtau_p95 = quantile(AUCtau, 0.95),
    
    .groups = "drop"
  )

fig4_summary


fig4_pta <- fig4_ind %>%
  filter(Analyte == "Active moiety") %>%
  group_by(Dose) %>%
  summarise(
    Ctrough_med = median(Ctrough),
    Ctrough_q1 = quantile(Ctrough, 0.25),
    Ctrough_q3 = quantile(Ctrough, 0.75),
    PTA_pct = 100 * mean(Ctrough >= target_lo & Ctrough <= target_hi),
    .groups = "drop"
  )

fig4_pta