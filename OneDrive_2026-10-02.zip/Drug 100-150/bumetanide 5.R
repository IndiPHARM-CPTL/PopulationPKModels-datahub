library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

bumetanide_code <- '
$PROB
- Ref: Holazo AA, Colburn WA, Gustafson JH, Young RL, Parsonnet M. Pharmacokinetics of bumetanide following intravenous, intramuscular, and oral administrations to normal subjects. J Pharm Sci. 1984;73(8):1108-1113. doi:10.1002/jps.2600730821

$PARAM @annotated
KA    : 3.30 : 1/h   Absorption rate constant
CL    : 15.4 : L/h   Apparent oral clearance
VAPP  : 18.9 : L     Apparent oral volume of distribution
TLAG  : 0.55 : h     Absorption lag time

$CMT @annotated
GUT  : Oral depot compartment
CENT : Central compartment

$OMEGA @labels ETA_KA ETA_CL ETA_VAPP ETA_TLAG
0.300 0.120 0.100 0.0253

$MAIN
double KAi = KA * exp(ETA_KA);
double CLi = CL * exp(ETA_CL);
double VAPPi = VAPP * exp(ETA_VAPP);
double TLAGi = TLAG * exp(ETA_TLAG);
double KELi = CLi / VAPPi;

ALAG_GUT = TLAGi;

$ODE
dxdt_GUT = -KAi * GUT;
dxdt_CENT = KAi * GUT - KELi * CENT;

$TABLE
double BUM_ngmL = (CENT / VAPPi) * 1000.0;

$CAPTURE BUM_ngmL
'

mod <- mcode("bumetanide_holazo1984", bumetanide_code)

set.seed(123)

dose_mg <- c(0.5, 1, 2)

N <- 1000
tau_h <- 24
n_doses <- 7
addl_md <- n_doses - 1

t_end_sd <- tau_h
t_end_md <- n_doses * tau_h

delta_sd <- 0.1
delta_md <- 0.1

last_dose_h <- (n_doses - 1) * tau_h

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:N)


fig1_out <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT")) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      CP = pmax(BUM_ngmL, 0),
      Dose = paste0(d, " mg single dose")
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Bumetanide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Bumetanide once-daily single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C1 = get_nearest(time, CP, 1),
    C2 = get_nearest(time, CP, 2),
    C4 = get_nearest(time, CP, 4),
    C8 = get_nearest(time, CP, 8),
    C12 = get_nearest(time, CP, 12),
    Ctrough = get_nearest(time, CP, tau_h),
    .groups = "drop"
  )




fig2_out <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT", ii = tau_h, addl = addl_md)) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      CP = pmax(BUM_ngmL, 0),
      Dose = paste0(d, " mg q24h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Bumetanide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Bumetanide once-daily multidose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= last_dose_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_final_interval = max(CP, na.rm = TRUE),
    Tmax_final_interval = time[which.max(CP)] - last_dose_h,
    C1_final_interval = get_nearest(time, CP, last_dose_h + 1),
    C2_final_interval = get_nearest(time, CP, last_dose_h + 2),
    C4_final_interval = get_nearest(time, CP, last_dose_h + 4),
    C8_final_interval = get_nearest(time, CP, last_dose_h + 8),
    C12_final_interval = get_nearest(time, CP, last_dose_h + 12),
    Ctrough_final_interval = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )



fig3_raw <- lapply(dose_mg, function(d) {
  set.seed(123)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT")) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      CP = pmax(BUM_ngmL, 0),
      Dose = paste0(d, " mg single dose")
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Bumetanide concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Bumetanide once-daily single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C1 = get_nearest(time, CP, 1),
    C2 = get_nearest(time, CP, 2),
    C4 = get_nearest(time, CP, 4),
    C8 = get_nearest(time, CP, 8),
    C12 = get_nearest(time, CP, 12),
    Ctrough = get_nearest(time, CP, tau_h),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C1_med = median(C1, na.rm = TRUE),
    C1_p05 = quantile(C1, 0.05, na.rm = TRUE),
    C1_p95 = quantile(C1, 0.95, na.rm = TRUE),
    
    C2_med = median(C2, na.rm = TRUE),
    C2_p05 = quantile(C2, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2, 0.95, na.rm = TRUE),
    
    C4_med = median(C4, na.rm = TRUE),
    C4_p05 = quantile(C4, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )



fig4_raw <- lapply(dose_mg, function(d) {
  set.seed(123)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = "GUT", ii = tau_h, addl = addl_md)) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      CP = pmax(BUM_ngmL, 0),
      Dose = paste0(d, " mg q24h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Bumetanide concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Bumetanide once daily multidose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= last_dose_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_final_interval = max(CP, na.rm = TRUE),
    Tmax_final_interval = time[which.max(CP)] - last_dose_h,
    C1_final_interval = get_nearest(time, CP, last_dose_h + 1),
    C2_final_interval = get_nearest(time, CP, last_dose_h + 2),
    C4_final_interval = get_nearest(time, CP, last_dose_h + 4),
    C8_final_interval = get_nearest(time, CP, last_dose_h + 8),
    C12_final_interval = get_nearest(time, CP, last_dose_h + 12),
    Ctrough_final_interval = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C1_med = median(C1_final_interval, na.rm = TRUE),
    C1_p05 = quantile(C1_final_interval, 0.05, na.rm = TRUE),
    C1_p95 = quantile(C1_final_interval, 0.95, na.rm = TRUE),
    
    C2_med = median(C2_final_interval, na.rm = TRUE),
    C2_p05 = quantile(C2_final_interval, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2_final_interval, 0.95, na.rm = TRUE),
    
    C4_med = median(C4_final_interval, na.rm = TRUE),
    C4_p05 = quantile(C4_final_interval, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4_final_interval, 0.95, na.rm = TRUE),
    
    C8_med = median(C8_final_interval, na.rm = TRUE),
    C8_p05 = quantile(C8_final_interval, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8_final_interval, 0.95, na.rm = TRUE),
    
    C12_med = median(C12_final_interval, na.rm = TRUE),
    C12_p05 = quantile(C12_final_interval, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12_final_interval, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough_final_interval, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough_final_interval, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough_final_interval, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary
