library(mrgsolve)
library(dplyr)
library(ggplot2)

aliskiren_pk <- '
$PROB
Aliskiren PK model from Hong et al. 2008
- Ref: Hong Y, Dingemanse J, Mager DE. Pharmacokinetic/pharmacodynamic modeling of renin biomarkers in subjects treated with the renin inhibitor aliskiren. Clin Pharmacol Ther. 2008;84(1):136-143. doi:10.1038/sj.clpt.6100495

$PARAM @annotated
KA   : 0.0748   : 1/h, absorption rate constant
VC   : 176      : L, apparent central volume
VM1  : 0.812    : mg/h, nonlinear elimination capacity (812 ug/h)
KM1  : 0.516    : ng/mL, nonlinear elimination affinity
VM2  : 87.48    : mg/h, nonlinear distribution capacity (87480 ug/h)
KM2  : 135      : ng/mL, nonlinear distribution affinity
K21  : 0.00248  : 1/h, peripheral-to-central first-order rate constant

$CMT @annotated
GUT    : absorption depot (mg)
CENT   : central compartment (mg)
PERIPH : peripheral compartment (mg)

$ODE
double CP = CENT/VC*1000.0;

double DENOM_ELIM = KM1*VC/1000.0 + CENT;
double DENOM_DIST = KM2*VC/1000.0 + CENT;

double ELIM = VM1*CENT/DENOM_ELIM;
double DIST = VM2*CENT/DENOM_DIST;

dxdt_GUT    = -KA*GUT;
dxdt_CENT   =  KA*GUT - ELIM - DIST + K21*PERIPH;
dxdt_PERIPH =  DIST - K21*PERIPH;

$TABLE
double CP_ngmL = CENT/VC*1000.0;

$Capture 
CP_ngmL
'
mod_aliskiren_pk <- mcode("aliskiren_pk", aliskiren_pk)

dose_levels <- c(150, 300)

dose_labs <- c(
  "150 mg" = "150 mg",
  "300 mg" = "300 mg"
)


run_single <- function(dose_mg, end = 72, delta = 0.1) {
  mod_aliskiren_pk %>%
    ev(amt = dose_mg, cmt = 1) %>%
    mrgsim(end = end, delta = delta) %>%
    as_tibble() %>%
    mutate(
      dose_lbl = factor(paste0(dose_mg, " mg"),
                        levels = names(dose_labs))
    )
}

run_multiple <- function(dose_mg, end = 240, delta = 0.1) {
  mod_aliskiren_pk %>%
    ev(amt = dose_mg, ii = 24, addl = 7, cmt = 1) %>%
    mrgsim(end = end, delta = delta) %>%
    as_tibble() %>%
    mutate(
      dose_lbl = factor(paste0(dose_mg, " mg"),
                        levels = names(dose_labs))
    )
}


fig1_raw <- bind_rows(lapply(dose_levels, run_single))

fig1_plot <- ggplot(fig1_raw, aes(x = time, y = CP_ngmL, linetype = dose_lbl)) +
  geom_line(linewidth = 1) +
  scale_y_log10() +
  labs(
    x = "Time (h)",
    y = "Aliskiren plasma concentration (ng/mL)",
    linetype = "Dose"
  ) +
  theme_bw()

fig1_summary <- fig1_raw %>%
  group_by(dose_lbl) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax = time[which.max(CP_ngmL)],
    C24  = CP_ngmL[which.min(abs(time - 24))],
    C48  = CP_ngmL[which.min(abs(time - 48))],
    .groups = "drop"
  )


fig2_raw <- bind_rows(lapply(dose_levels, run_multiple))

fig2_plot <- ggplot(fig2_raw, aes(x = time, y = CP_ngmL, linetype = dose_lbl)) +
  geom_line(linewidth = 1) +
  scale_y_log10() +
  labs(
    x = "Time (h)",
    y = "Aliskiren plasma concentration (ng/mL)",
    linetype = "Dose"
  ) +
  theme_bw()

fig2_summary <- fig2_raw %>%
  group_by(dose_lbl) %>%
  summarise(
    Cmax_ss = max(CP_ngmL[time >= 168 & time <= 192]),
    Tmax_ss = time[time >= 168 & time <= 192][which.max(CP_ngmL[time >= 168 & time <= 192])] - 168,
    C24_ss  = CP_ngmL[which.min(abs(time - 192))],
    Cday1   = CP_ngmL[which.min(abs(time - 24))],
    Cday2   = CP_ngmL[which.min(abs(time - 48))],
    Cday3   = CP_ngmL[which.min(abs(time - 72))],
    Cday4   = CP_ngmL[which.min(abs(time - 96))],
    Cday5   = CP_ngmL[which.min(abs(time - 120))],
    Cday6   = CP_ngmL[which.min(abs(time - 144))],
    Cday7   = CP_ngmL[which.min(abs(time - 168))],
    Cday8   = CP_ngmL[which.min(abs(time - 192))],
    .groups = "drop"
  )


set.seed(1234)

n_sub <- 500

cv_to_sdlog <- function(cv) {
  sqrt(log(1 + cv^2))
}

omega_KA  <- cv_to_sdlog(0.30)
omega_VC  <- cv_to_sdlog(0.25)
omega_VM1 <- cv_to_sdlog(0.30)
omega_VM2 <- cv_to_sdlog(0.30)
omega_K21 <- cv_to_sdlog(0.25)

idata_pop <- tibble(
  ID  = 1:n_sub,
  KA  = 0.0748  * exp(rnorm(n_sub, 0, omega_KA)),
  VC  = 176     * exp(rnorm(n_sub, 0, omega_VC)),
  VM1 = 0.812   * exp(rnorm(n_sub, 0, omega_VM1)),
  VM2 = 87.48   * exp(rnorm(n_sub, 0, omega_VM2)),
  K21 = 0.00248 * exp(rnorm(n_sub, 0, omega_K21))
)

run_single_pop <- function(dose_mg, end = 72, delta = 0.1) {
  mod_aliskiren_pk %>%
    idata_set(idata_pop) %>%
    ev(amt = dose_mg, cmt = 1) %>%
    mrgsim(end = end, delta = delta) %>%
    as_tibble() %>%
    mutate(
      dose_lbl = factor(paste0(dose_mg, " mg"),
                        levels = names(dose_labs))
    )
}

run_multiple_pop <- function(dose_mg, end = 240, delta = 0.1) {
  mod_aliskiren_pk %>%
    idata_set(idata_pop) %>%
    ev(amt = dose_mg, ii = 24, addl = 9, cmt = 1) %>%
    mrgsim(end = end, delta = delta) %>%
    as_tibble() %>%
    mutate(
      dose_lbl = factor(paste0(dose_mg, " mg"),
                        levels = names(dose_labs))
    )
}


fig3_raw <- bind_rows(lapply(dose_levels, run_single_pop))

fig3_plotdat <- fig3_raw %>%
  group_by(dose_lbl, time) %>%
  summarise(
    med = median(CP_ngmL),
    p05 = quantile(CP_ngmL, 0.05),
    p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )

fig3_plot <- ggplot(
  fig3_plotdat,
  aes(x = time, y = med, ymin = p05, ymax = p95,
      group = dose_lbl, color = dose_lbl, fill = dose_lbl)
) +
  geom_ribbon(alpha = 0.15, colour = NA) +
  geom_line(linewidth = 1) +
  scale_y_log10() +
  labs(
    x = "Time (h)",
    y = "Aliskiren plasma concentration (ng/mL)",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig3_summary <- fig3_raw %>%
  group_by(dose_lbl, ID) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax = time[which.max(CP_ngmL)],
    C24  = CP_ngmL[which.min(abs(time - 24))],
    C48  = CP_ngmL[which.min(abs(time - 48))],
    .groups = "drop"
  ) %>%
  group_by(dose_lbl) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    Tmax_med = median(Tmax),
    Tmax_p05 = quantile(Tmax, 0.05),
    Tmax_p95 = quantile(Tmax, 0.95),
    C24_med  = median(C24),
    C24_p05  = quantile(C24, 0.05),
    C24_p95  = quantile(C24, 0.95),
    C48_med  = median(C48),
    C48_p05  = quantile(C48, 0.05),
    C48_p95  = quantile(C48, 0.95),
    .groups = "drop"
  )


fig4_raw <- bind_rows(lapply(dose_levels, run_multiple_pop))

fig4_plotdat <- fig4_raw %>%
  group_by(dose_lbl, time) %>%
  summarise(
    med = median(CP_ngmL),
    p05 = quantile(CP_ngmL, 0.05),
    p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )

fig4_plot <- ggplot(
  fig4_plotdat,
  aes(x = time, y = med, ymin = p05, ymax = p95,
      group = dose_lbl, color = dose_lbl, fill = dose_lbl)
) +
  geom_ribbon(alpha = 0.15, colour = NA) +
  geom_line(linewidth = 1) +
  scale_y_log10() +
  labs(
    x = "Time (h)",
    y = "Aliskiren plasma concentration (ng/mL)",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig4_summary <- fig4_raw %>%
  group_by(dose_lbl, ID) %>%
  summarise(
    Cmax_ss = max(CP_ngmL[time >= 168 & time <= 192]),
    Tmax_ss = time[time >= 168 & time <= 192][which.max(CP_ngmL[time >= 168 & time <= 192])] - 168,
    C24_ss  = CP_ngmL[which.min(abs(time - 192))],
    C48_ss  = CP_ngmL[which.min(abs(time - 216))],
    C72_ss  = CP_ngmL[which.min(abs(time - 240))],
    .groups = "drop"
  ) %>%
  group_by(dose_lbl) %>%
  summarise(
    Cmax_med = median(Cmax_ss),
    Cmax_p05 = quantile(Cmax_ss, 0.05),
    Cmax_p95 = quantile(Cmax_ss, 0.95),
    Tmax_med = median(Tmax_ss),
    Tmax_p05 = quantile(Tmax_ss, 0.05),
    Tmax_p95 = quantile(Tmax_ss, 0.95),
    C24_med  = median(C24_ss),
    C24_p05  = quantile(C24_ss, 0.05),
    C24_p95  = quantile(C24_ss, 0.95),
    C48_med  = median(C48_ss),
    C48_p05  = quantile(C48_ss, 0.05),
    C48_p95  = quantile(C48_ss, 0.95),
    C72_med  = median(C72_ss),
    C72_p05  = quantile(C72_ss, 0.05),
    C72_p95  = quantile(C72_ss, 0.95),
    .groups = "drop"
  )


fig1_plot
fig1_summary

fig2_plot
fig2_summary

fig3_plot
fig3_summary

fig4_plot
fig4_summary

