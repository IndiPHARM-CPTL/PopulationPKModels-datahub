library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

amlodipine_ped_code <- '
$PROB
- Ref: Flynn JT, Nahata MC, Mahan JD Jr, Portman RJ; PATH-2 Investigators. Population pharmacokinetics of amlodipine in hypertensive children and adolescents. J Clin Pharmacol. 2006;46(8):905-916. doi:10.1177/0091270006289844

$PARAM @annotated
KA      : 0.807 : 1/h      First-order absorption rate constant
WT      : 45    : kg       Body weight
SEX     : 0     : --       Sex; 0 = male, 1 = female

THCL    : 23.7  : L/h      CL/F at WT = 45 kg, male
THWTCL  : 0.176 : L/h/kg   Weight effect on CL/F
THSEXCL : 6.09  : L/h      Female effect on CL/F; subtracted when SEX = 1

THV     : 1130  : L        V/F at WT = 45 kg
THWTV   : 16.0  : L/kg     Weight effect on V/F

FREL    : 1.00  : --       Relative bioavailability
PROP_SD : 0.218 : --       Proportional residual SD converted from 22.07% CV

$CMT @annotated
DEPOT : Oral absorption compartment
CENT  : Central compartment

$OMEGA @diag @labels ETA_CL ETA_V ETA_KA
0.1714 0.2127 0.2280

$SIGMA
1

$GLOBAL
double CLcov;
double Vcov;

double KAi;
double CLi;
double Vi;
double KEi;

$MAIN
F_DEPOT = FREL;

CLcov = THCL + THWTCL * (WT - 45.0) - THSEXCL * SEX;
Vcov  = THV  + THWTV  * (WT - 45.0);

CLi = fmax(CLcov, 0.1) * exp(ETA(1));
Vi  = fmax(Vcov,  1.0) * exp(ETA(2));
KAi = KA * exp(ETA(3));

KEi = CLi / Vi;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT  =  KAi * DEPOT
             -KEi * CENT;

$TABLE
double AML_mgL  = CENT / Vi;
double AML_ngmL = fmax(AML_mgL * 1000.0, 0.0);

double DV_ngmL = fmax(AML_ngmL * exp(PROP_SD * EPS(1)), 0.0);

$CAPTURE
AML_ngmL DV_ngmL
KAi CLi Vi KEi WT SEX
'

mod <- mcode("amlodipine_pediatric_flynn2006", amlodipine_ped_code)



set.seed(123)

dose_mgkg_day <- c(0.10, 0.20)

N        <- 1000
tau_h    <- 24
n_doses  <- 10
addl_md  <- n_doses - 1

t_end_sd <- 168
t_end_md <- 240

delta_sd <- 0.25
delta_md <- 0.25

MAX_DOSE_MG <- 20

dose_levels_sd <- paste0(dose_mgkg_day, " mg/kg single dose")
dose_levels_md <- paste0(dose_mgkg_day, " mg/kg q24h x", n_doses)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

calc_amt <- function(dose_mgkg, wt) {
  pmin(dose_mgkg * wt, MAX_DOSE_MG)
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(
  ID  = 1,
  WT  = 45,
  SEX = 0
)


idata_pop <- tibble(
  ID  = 1:N,
  WT  = pmin(pmax(rnorm(N, mean = 51.8, sd = 31.6), 6), 142),
  SEX = rbinom(N, size = 1, prob = 24 / 73)
)


fig1_list <- lapply(dose_mgkg_day, function(d) {
  
  amt_mg <- calc_amt(d, idata_typ$WT[1])
  
  ev_sd <- ev(
    time = 0,
    amt  = amt_mg,
    cmt  = "DEPOT"
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = AML_ngmL,
      Dose = paste0(d, " mg/kg single dose")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Amlodipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Pediatric amlodipine concentration, single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C24  = get_nearest(time, CP, 24),
    C48  = get_nearest(time, CP, 48),
    C168 = get_nearest(time, CP, 168),
    .groups = "drop"
  )



fig2_list <- lapply(dose_mgkg_day, function(d) {
  
  amt_mg <- calc_amt(d, idata_typ$WT[1])
  
  ev_md <- ev(
    time = 0,
    amt  = amt_mg,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = AML_ngmL,
      Dose = paste0(d, " mg/kg q24h x", n_doses)
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Amlodipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Pediatric amlodipine concentration, q24h x10"
  )

fig2_summary <- fig2_out %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day10 = max(CP, na.rm = TRUE),
    Tmax_day10 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    Ctrough_day10 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )


set.seed(123)

fig3_list <- lapply(dose_mgkg_day, function(d) {
  
  ev_df <- idata_pop %>%
    mutate(
      time = 0,
      amt  = calc_amt(d, WT),
      cmt  = 1,
      evid = 1
    ) %>%
    select(ID, time, amt, cmt, evid)
  
  mod %>%
    idata_set(idata_pop) %>%
    data_set(ev_df) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = AML_ngmL,
      Dose = paste0(d, " mg/kg single dose")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Amlodipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Pediatric amlodipine concentration, single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C24  = get_nearest(time, CP, 24),
    C48  = get_nearest(time, CP, 48),
    C168 = get_nearest(time, CP, 168),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    C48_med = median(C48, na.rm = TRUE),
    C48_p05 = quantile(C48, 0.05, na.rm = TRUE),
    C48_p95 = quantile(C48, 0.95, na.rm = TRUE),
    
    C168_med = median(C168, na.rm = TRUE),
    C168_p05 = quantile(C168, 0.05, na.rm = TRUE),
    C168_p95 = quantile(C168, 0.95, na.rm = TRUE),
    .groups = "drop"
  )



set.seed(123)

fig4_list <- lapply(dose_mgkg_day, function(d) {
  
  ev_df <- idata_pop %>%
    mutate(
      time = 0,
      amt  = calc_amt(d, WT),
      cmt  = 1,
      evid = 1,
      ii   = tau_h,
      addl = addl_md
    ) %>%
    select(ID, time, amt, cmt, evid, ii, addl)
  
  mod %>%
    idata_set(idata_pop) %>%
    data_set(ev_df) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = AML_ngmL,
      Dose = paste0(d, " mg/kg q24h x", n_doses)
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Amlodipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Pediatric amlodipine concentration, q24h x10, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_day10 = max(CP, na.rm = TRUE),
    Tmax_day10 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    Ctrough_day10 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day10_med = median(Cmax_day10, na.rm = TRUE),
    Cmax_day10_p05 = quantile(Cmax_day10, 0.05, na.rm = TRUE),
    Cmax_day10_p95 = quantile(Cmax_day10, 0.95, na.rm = TRUE),
    
    Tmax_day10_med = median(Tmax_day10, na.rm = TRUE),
    Tmax_day10_p05 = quantile(Tmax_day10, 0.05, na.rm = TRUE),
    Tmax_day10_p95 = quantile(Tmax_day10, 0.95, na.rm = TRUE),
    
    Ctrough_day10_med = median(Ctrough_day10, na.rm = TRUE),
    Ctrough_day10_p05 = quantile(Ctrough_day10, 0.05, na.rm = TRUE),
    Ctrough_day10_p95 = quantile(Ctrough_day10, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary

