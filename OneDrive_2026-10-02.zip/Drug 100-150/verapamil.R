library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

verapamil_code <- '
$PROB
- Ref: Gupta S, Modi NB, Sathyan G, Ho Pl PL, Aarons L. Pharmacokinetics of controlled-release verapamil in healthy volunteers and patients with hypertension or angina. Biopharm Drug Dispos. 2002;23(1):17-31. doi:10.1002/bdd.289

$PARAM @annotated
DOSEMG : 180 : mg      Total racemic verapamil dose

LAG    : 5   : h       Approximate controlled-onset delay
DUR    : 10  : h       Approximate zero-order release duration

CL_R   : 91.7  : L/h   Apparent clearance of R-verapamil
V_R    : 884   : L     Apparent volume of R-verapamil

CL_S   : 379   : L/h   Apparent clearance of S-verapamil
V_S    : 3080  : L     Apparent volume of S-verapamil

PROP_R : 0.261 : --    Proportional residual SD for R-verapamil
PROP_S : 0.409 : --    Proportional residual SD for S-verapamil

$CMT @annotated
DEPOT_R : GI absorption compartment for R-verapamil
DEPOT_S : GI absorption compartment for S-verapamil
CENT_R  : Central compartment for R-verapamil
CENT_S  : Central compartment for S-verapamil

$OMEGA @diag @labels ETA_CL_R ETA_V_R ETA_CL_S ETA_V_S
0.0574 0.0507 0.0987 0.0469

$SIGMA
1 1

$GLOBAL
double KAi_R;
double KAi_S;

double FREL_R;
double FREL_S;

double CLi_R;
double Vi_R;
double KEi_R;

double CLi_S;
double Vi_S;
double KEi_S;

$MAIN
ALAG_DEPOT_R = LAG;
ALAG_DEPOT_S = LAG;

D_DEPOT_R = DUR;
D_DEPOT_S = DUR;


if(DOSEMG <= 120.0) {
  KAi_R  = 1.72;
  KAi_S  = 0.681;
  FREL_R = 1.00;
  FREL_S = 1.00;
} else if(DOSEMG <= 180.0) {
  KAi_R  = 1.41;
  KAi_S  = 0.570;
  FREL_R = 1.0;
  FREL_S = 0.833;
} else if(DOSEMG <= 360.0) {
  KAi_R  = 1.13;
  KAi_S  = 1.57;
  FREL_R = 1.55;
  FREL_S = 1.25;
} else {
  KAi_R  = 2.83;
  KAi_S  = 1.85;
  FREL_R = 1.69;
  FREL_S = 1.25;
}
F_DEPOT_R = FREL_R;
F_DEPOT_S = FREL_S;


CLi_R = CL_R * exp(ETA(1));
Vi_R  = V_R  * exp(ETA(2));
KEi_R = CLi_R / Vi_R;

CLi_S = CL_S * exp(ETA(3));
Vi_S  = V_S  * exp(ETA(4));
KEi_S = CLi_S / Vi_S;

$ODE
dxdt_DEPOT_R = -KAi_R * DEPOT_R;
dxdt_DEPOT_S = -KAi_S * DEPOT_S;

dxdt_CENT_R  =  KAi_R * DEPOT_R
               -KEi_R * CENT_R;

dxdt_CENT_S  =  KAi_S * DEPOT_S
               -KEi_S * CENT_S;

$TABLE
double RVER_mgL  = CENT_R / Vi_R;
double SVER_mgL  = CENT_S / Vi_S;

double RVER_ngmL = RVER_mgL * 1000.0;
double SVER_ngmL = SVER_mgL * 1000.0;

double VER_TOTAL_ngmL = RVER_ngmL + SVER_ngmL;

double DV_R_ngmL = RVER_ngmL * (1.0 + PROP_R * EPS(1));
double DV_S_ngmL = SVER_ngmL * (1.0 + PROP_S * EPS(2));

$CAPTURE
RVER_ngmL SVER_ngmL VER_TOTAL_ngmL
DV_R_ngmL DV_S_ngmL
KAi_R KAi_S FREL_R FREL_S
CLi_R Vi_R KEi_R
CLi_S Vi_S KEi_S
DOSEMG
'
mod <- mcode("verapamil_gupta2002_CR", verapamil_code)


set.seed(123)

dose_mg <- c(120, 180)

N        <- 1000
tau_h    <- 24
n_doses  <- 5
addl_md  <- n_doses - 1

t_end_sd <- 48
t_end_md <- 120

delta_sd <- 0.1
delta_md <- 0.1

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

make_verapamil_ev <- function(dose_mg, ii = NULL, addl = NULL) {
  
  if(is.null(ii)) {
    ev_r <- ev(
      time = 0,
      amt  = dose_mg / 2,
      cmt  = "DEPOT_R",
      rate = -2
    )
    
    ev_s <- ev(
      time = 0,
      amt  = dose_mg / 2,
      cmt  = "DEPOT_S",
      rate = -2
    )
    
  } else {
    ev_r <- ev(
      time = 0,
      amt  = dose_mg / 2,
      cmt  = "DEPOT_R",
      rate = -2,
      ii   = ii,
      addl = addl
    )
    
    ev_s <- ev(
      time = 0,
      amt  = dose_mg / 2,
      cmt  = "DEPOT_S",
      rate = -2,
      ii   = ii,
      addl = addl
    )
  }
  
  c(ev_r, ev_s)
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:N)

fig1_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- make_verapamil_ev(dose_mg = d)
  
  mod_typ %>%
    param(DOSEMG = d) %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = VER_TOTAL_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Total verapamil concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Verapamil CR (120/180 mg) once daily, single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax_total = max(CP, na.rm = TRUE),
    Tmax_total = time[which.max(CP)],
    C12_total  = get_nearest(time, CP, 12),
    C24_total  = get_nearest(time, CP, 24),
    C48_total  = get_nearest(time, CP, 48),
    R_Cmax     = max(RVER_ngmL, na.rm = TRUE),
    S_Cmax     = max(SVER_ngmL, na.rm = TRUE),
    .groups = "drop"
  )


fig2_list <- lapply(dose_mg, function(d) {
  
  ev_md <- make_verapamil_ev(
    dose_mg = d,
    ii      = tau_h,
    addl    = addl_md
  )
  
  mod_typ %>%
    param(DOSEMG = d) %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = VER_TOTAL_ngmL,
      Dose = paste0(d, " mg q24h x", n_doses)
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Total verapamil concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Verapamil CR (120/180 mg) once daily, multi-dose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day5_total = max(CP, na.rm = TRUE),
    Tmax_day5_total = time[which.max(CP)] - (n_doses - 1) * tau_h,
    C12_day5_total  = get_nearest(time, CP, (n_doses - 1) * tau_h + 12),
    C24_day5_total  = get_nearest(time, CP, t_end_md),
    R_Cmax_day5     = max(RVER_ngmL, na.rm = TRUE),
    S_Cmax_day5     = max(SVER_ngmL, na.rm = TRUE),
    .groups = "drop"
  )



set.seed(123)

fig3_list <- lapply(dose_mg, function(d) {
  
  ev_sd <- make_verapamil_ev(dose_mg = d)
  
  mod %>%
    param(DOSEMG = d) %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = VER_TOTAL_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Total verapamil concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Verapamil CR (120/180 mg) once daily, single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_total = max(CP, na.rm = TRUE),
    Tmax_total = time[which.max(CP)],
    C12_total  = get_nearest(time, CP, 12),
    C24_total  = get_nearest(time, CP, 24),
    C48_total  = get_nearest(time, CP, 48),
    R_Cmax     = max(RVER_ngmL, na.rm = TRUE),
    S_Cmax     = max(SVER_ngmL, na.rm = TRUE),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_total_med = median(Cmax_total, na.rm = TRUE),
    Cmax_total_p05 = quantile(Cmax_total, 0.05, na.rm = TRUE),
    Cmax_total_p95 = quantile(Cmax_total, 0.95, na.rm = TRUE),
    
    Tmax_total_med = median(Tmax_total, na.rm = TRUE),
    Tmax_total_p05 = quantile(Tmax_total, 0.05, na.rm = TRUE),
    Tmax_total_p95 = quantile(Tmax_total, 0.95, na.rm = TRUE),
    
    C12_total_med = median(C12_total, na.rm = TRUE),
    C12_total_p05 = quantile(C12_total, 0.05, na.rm = TRUE),
    C12_total_p95 = quantile(C12_total, 0.95, na.rm = TRUE),
    
    C24_total_med = median(C24_total, na.rm = TRUE),
    C24_total_p05 = quantile(C24_total, 0.05, na.rm = TRUE),
    C24_total_p95 = quantile(C24_total, 0.95, na.rm = TRUE),
    
    C48_total_med = median(C48_total, na.rm = TRUE),
    C48_total_p05 = quantile(C48_total, 0.05, na.rm = TRUE),
    C48_total_p95 = quantile(C48_total, 0.95, na.rm = TRUE),
    
    R_Cmax_med = median(R_Cmax, na.rm = TRUE),
    S_Cmax_med = median(S_Cmax, na.rm = TRUE),
    .groups = "drop"
  )


set.seed(123)

fig4_list <- lapply(dose_mg, function(d) {
  
  ev_md <- make_verapamil_ev(
    dose_mg = d,
    ii      = tau_h,
    addl    = addl_md
  )
  
  mod %>%
    param(DOSEMG = d) %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = VER_TOTAL_ngmL,
      Dose = paste0(d, " mg q24h x", n_doses)
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Total verapamil concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Verapamil CR (120/180 mg) once daily, multi-dose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_day5_total = max(CP, na.rm = TRUE),
    Tmax_day5_total = time[which.max(CP)] - (n_doses - 1) * tau_h,
    C12_day5_total  = get_nearest(time, CP, (n_doses - 1) * tau_h + 12),
    C24_day5_total  = get_nearest(time, CP, t_end_md),
    R_Cmax_day5     = max(RVER_ngmL, na.rm = TRUE),
    S_Cmax_day5     = max(SVER_ngmL, na.rm = TRUE),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day5_total_med = median(Cmax_day5_total, na.rm = TRUE),
    Cmax_day5_total_p05 = quantile(Cmax_day5_total, 0.05, na.rm = TRUE),
    Cmax_day5_total_p95 = quantile(Cmax_day5_total, 0.95, na.rm = TRUE),
    
    Tmax_day5_total_med = median(Tmax_day5_total, na.rm = TRUE),
    Tmax_day5_total_p05 = quantile(Tmax_day5_total, 0.05, na.rm = TRUE),
    Tmax_day5_total_p95 = quantile(Tmax_day5_total, 0.95, na.rm = TRUE),
    
    C12_day5_total_med = median(C12_day5_total, na.rm = TRUE),
    C12_day5_total_p05 = quantile(C12_day5_total, 0.05, na.rm = TRUE),
    C12_day5_total_p95 = quantile(C12_day5_total, 0.95, na.rm = TRUE),
    
    C24_day5_total_med = median(C24_day5_total, na.rm = TRUE),
    C24_day5_total_p05 = quantile(C24_day5_total, 0.05, na.rm = TRUE),
    C24_day5_total_p95 = quantile(C24_day5_total, 0.95, na.rm = TRUE),
    
    R_Cmax_day5_med = median(R_Cmax_day5, na.rm = TRUE),
    S_Cmax_day5_med = median(S_Cmax_day5, na.rm = TRUE),
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary

