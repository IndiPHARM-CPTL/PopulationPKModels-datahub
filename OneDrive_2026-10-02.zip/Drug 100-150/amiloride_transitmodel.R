library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

amiloride_code <- '
$PROB
Amiloride oral PopPK model with transit absorption
- Ref: Savic RM, Jonker DM, Kerbusch T, Karlsson MO. Implementation of a transit compartment model for describing drug absorption in pharmacokinetic studies. J Pharmacokinet Pharmacodyn. 2007;34(5):711-726. doi:10.1007/s10928-007-9066-0
- ********Not for assay ref, MTT transit model only

$PARAM @annotated
KA      : 1.77  : 1/h     First-order absorption rate constant from absorption compartment
CL      : 0.354 : L/h     Apparent clearance, CL/F, from TRANSIT final model
V1      : 487   : L       Apparent central volume, V/F, from TRANSIT final model
MTT     : 1.03  : h       Mean transit time to absorption compartment
N_EXP   : 8.15  : --      Estimated number of transit compartments from source model

$CMT
TRANS0 TRANS1 TRANS2 TRANS3 TRANS4 TRANS5 TRANS6 TRANS7 TRANS8 ABS CENT

$OMEGA @annotated
ECL   : 0.0355 : IIV variance on CL/F;
EV1   : 0.1484 : IIV variance on V/F;
EMTT  : 0.2393 : IIV variance on MTT; 

$MAIN
double CLi  = CL  * exp(ECL);
double V1i  = V1  * exp(EV1);
double MTTi = MTT * exp(EMTT);

double KAi  = KA;
double KTRi = (N_EXP + 1.0) / MTTi;
double KELi = CLi / V1i;

$ODE
dxdt_TRANS0 = -KTRi * TRANS0;

dxdt_TRANS1 =  KTRi * TRANS0 - KTRi * TRANS1;
dxdt_TRANS2 =  KTRi * TRANS1 - KTRi * TRANS2;
dxdt_TRANS3 =  KTRi * TRANS2 - KTRi * TRANS3;
dxdt_TRANS4 =  KTRi * TRANS3 - KTRi * TRANS4;
dxdt_TRANS5 =  KTRi * TRANS4 - KTRi * TRANS5;
dxdt_TRANS6 =  KTRi * TRANS5 - KTRi * TRANS6;
dxdt_TRANS7 =  KTRi * TRANS6 - KTRi * TRANS7;
dxdt_TRANS8 =  KTRi * TRANS7 - KTRi * TRANS8;

dxdt_ABS    =  KTRi * TRANS8 - KAi * ABS;

dxdt_CENT   =  KAi * ABS - KELi * CENT;

$TABLE
double CP_mgL  = CENT / V1i;
double CP_ngmL = CP_mgL * 1000.0;

$CAPTURE CP_mgL CP_ngmL KAi KTRi MTTi CLi V1i KELi
'
mod <- mcode("amiloride_oral_savic_2007", amiloride_code)


dose_mg <- c(5, 10, 20)

n_pop <- 1000
set.seed(123)

tau_h    <- 24
n_doses  <- 10
addl_md  <- n_doses - 1

t_end_sd <- 120
t_end_md <- 240

delta_sd <- 0.02
delta_md <- 0.02

last_dose_h <- (n_doses - 1) * tau_h

idata_pop <- tibble(
  ID = 1:n_pop
)

idata_typ <- tibble(
  ID = 1
)

mod_typ <- zero_re(mod)


get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  
  df$conc[which.min(abs(df$time - t))]
}


fig1 <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(time = 0, amt = d, cmt = 1)
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

p1 <- ggplot(fig1, aes(x = time, y = CP_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after dose (h)",
    y = "Amiloride concentration (ng/mL)",
    title = "Figure 1. Amiloride once-daily single-dose",
    color = "Dose"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(dose, ID) %>%
  summarise(
    Cmax  = max(CP_ngmL, na.rm = TRUE),
    Tmax  = time[which.max(CP_ngmL)],
    C6    = get_conc_at(time, CP_ngmL, 6),
    C12   = get_conc_at(time, CP_ngmL, 12),
    C24   = get_conc_at(time, CP_ngmL, 24),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(dose) %>%
  summarise(
    Cmax_ng_mL = median(Cmax, na.rm = TRUE),
    Tmax_h     = median(Tmax, na.rm = TRUE),
    C6_ng_mL   = median(C6, na.rm = TRUE),
    C12_ng_mL  = median(C12, na.rm = TRUE),
    C24_ng_mL  = median(C24, na.rm = TRUE),
    .groups = "drop"
  )

p1
fig1_summary



fig2 <- lapply(dose_mg, function(d) {
  
  ev_qd_3d <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_qd_3d) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q24h")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q24h"))
  )

p2 <- ggplot(fig2, aes(x = time, y = CP_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Amiloride concentration (ng/mL)",
    title = "Figure 2. Amiloride once-daily multi-dose",
    color = "Dose"
  ) +
  theme_bw()

fig2_ind <- fig2 %>%
  group_by(dose, ID) %>%
  summarise(
    Cmax_final_interval = {
      idx <- time >= last_dose_h & time <= t_end_md
      max(CP_ngmL[idx], na.rm = TRUE)
    },
    Tmax_final_interval = {
      idx <- time >= last_dose_h & time <= t_end_md
      time[idx][which.max(CP_ngmL[idx])] - last_dose_h
    },
    C24_after_last = get_conc_at(time, CP_ngmL, t_end_md),
    C24_day1       = get_conc_at(time, CP_ngmL, 24),
    C48            = get_conc_at(time, CP_ngmL, 48),
    C72            = get_conc_at(time, CP_ngmL, 72),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(dose) %>%
  summarise(
    Cmax_final_interval_ng_mL = median(Cmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_h     = median(Tmax_final_interval, na.rm = TRUE),
    C24_after_last_ng_mL      = median(C24_after_last, na.rm = TRUE),
    C24_day1_ng_mL            = median(C24_day1, na.rm = TRUE),
    C48_ng_mL                 = median(C48, na.rm = TRUE),
    C72_ng_mL                 = median(C72, na.rm = TRUE),
    .groups = "drop"
  )

p2
fig2_summary





fig3_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(time = 0, amt = d, cmt = 1)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig3_sum <- fig3_raw %>%
  group_by(dose, time) %>%
  summarise(
    CP_med = median(CP_ngmL, na.rm = TRUE),
    CP_p05 = quantile(CP_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after dose (h)",
    y = "Amiloride concentration (ng/mL)",
    title = "Figure 3. Amiloride once-daily single-dose, population",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig3_ind <- fig3_raw %>%
  group_by(dose, ID) %>%
  summarise(
    Cmax  = max(CP_ngmL, na.rm = TRUE),
    Tmax  = time[which.max(CP_ngmL)],
    C6    = get_conc_at(time, CP_ngmL, 6),
    C12   = get_conc_at(time, CP_ngmL, 12),
    C24   = get_conc_at(time, CP_ngmL, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C6_med = median(C6, na.rm = TRUE),
    C6_p05 = quantile(C6, 0.05, na.rm = TRUE),
    C6_p95 = quantile(C6, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3
fig3_summary


fig4_raw <- lapply(dose_mg, function(d) {
  
  ev_qd_3d <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_qd_3d) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q24h")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q24h"))
  )

fig4_sum <- fig4_raw %>%
  group_by(dose, time) %>%
  summarise(
    CP_med = median(CP_ngmL, na.rm = TRUE),
    CP_p05 = quantile(CP_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Amiloride concentration (ng/mL)",
    title = "Figure 4. Amiloride once-daily multi-dose, population",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig4_ind <- fig4_raw %>%
  group_by(dose, ID) %>%
  summarise(
    Cmax_final_interval = {
      idx <- time >= last_dose_h & time <= t_end_md
      max(CP_ngmL[idx], na.rm = TRUE)
    },
    Tmax_final_interval = {
      idx <- time >= last_dose_h & time <= t_end_md
      time[idx][which.max(CP_ngmL[idx])] - last_dose_h
    },
    C24_after_last = get_conc_at(time, CP_ngmL, t_end_md),
    C24_day1       = get_conc_at(time, CP_ngmL, 24),
    C48            = get_conc_at(time, CP_ngmL, 48),
    C72            = get_conc_at(time, CP_ngmL, 72),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(dose) %>%
  summarise(
    Cmax_final_interval_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_final_interval_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_final_interval_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_final_interval_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_final_interval_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C24_after_last_med = median(C24_after_last, na.rm = TRUE),
    C24_after_last_p05 = quantile(C24_after_last, 0.05, na.rm = TRUE),
    C24_after_last_p95 = quantile(C24_after_last, 0.95, na.rm = TRUE),
    
    C24_day1_med = median(C24_day1, na.rm = TRUE),
    C24_day1_p05 = quantile(C24_day1, 0.05, na.rm = TRUE),
    C24_day1_p95 = quantile(C24_day1, 0.95, na.rm = TRUE),
    
    C48_med = median(C48, na.rm = TRUE),
    C48_p05 = quantile(C48, 0.05, na.rm = TRUE),
    C48_p95 = quantile(C48, 0.95, na.rm = TRUE),
    
    C72_med = median(C72, na.rm = TRUE),
    C72_p05 = quantile(C72, 0.05, na.rm = TRUE),
    C72_p95 = quantile(C72, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4
fig4_summary