library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

hctz_code <- '
$PROB
- Ref: Van Wart SA, Shoaf SE, Mallikaarjun S, Mager DE.
  Population-based meta-analysis of hydrochlorothiazide pharmacokinetics.
  Biopharm Drug Dispos. 2013;34(9):527-539.
  doi:10.1002/bdd.1863

$PARAM @annotated
KA       : 1.34  : 1/h      Absorption rate constant
CLCR     : 120   : mL/min    Creatinine clearance
CLR_COEF : 18.3  : L/h      Renal clearance at CLCR = 120 mL/min
TH_CLCR  : 1.38  : --       Power effect of CLCR on renal clearance
CLNR     : 2.44  : L/h      Nonrenal clearance
VC       : 97.3  : L        Central volume
Q        : 17.2  : L/h      Intercompartmental clearance
VP       : 178   : L        Peripheral volume
PROP_SD  : 0.180 : --       Proportional residual SD
ADD_SD   : 1.735 : ng/mL    Additive residual SD

$CMT @annotated
DEPOT  : Oral depot compartment
CENT   : Central compartment
PERIPH : Peripheral compartment

$OMEGA @diag @labels ETA_KA ETA_CLR ETA_VC ETA_VP
0.321 0.116 0.117 0.428

$SIGMA
1 1

$MAIN
double KAi    = KA * exp(ETA_KA);
double CLRi   = CLR_COEF * pow(CLCR / 120.0, TH_CLCR) * exp(ETA_CLR);
double CLTOTi = CLRi + CLNR;
double VCi    = VC * exp(ETA_VC);
double Qi     = Q;
double VPi    = VP * exp(ETA_VP);

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT =
    KAi * DEPOT
  - (CLTOTi / VCi) * CENT
  - (Qi / VCi) * CENT
  + (Qi / VPi) * PERIPH;

dxdt_PERIPH =
    (Qi / VCi) * CENT
  - (Qi / VPi) * PERIPH;

$TABLE
double HCTZ_mgL  = CENT / VCi;
double HCTZ_ngmL = fmax(HCTZ_mgL * 1000.0, 0.0);

$CAPTURE
HCTZ_ngmL 
'
mod <- mcode("hctz_vanwart_2013", hctz_code)

set.seed(123)

dose_mg <- c(12.5, 25, 50)

N        <- 1000
tau_h    <- 24
n_doses  <- 10
addl_md  <- n_doses - 1

t_end_sd <- 48
t_end_md <- 240

delta_sd <- 0.1
delta_md <- 0.1

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(
  ID = 1,
  CLCR = 120
)

idata_pop <- tibble(
  ID = 1:N,
  CLCR = pmin(
    pmax(rnorm(N, mean = 101, sd = 31.5), 30),
    160
  )
)

fig1_list <- lapply(dose_mg, function(d) {
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = HCTZ_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Hydrochlorothiazide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. HCTZ once-daily single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C24  = get_nearest(time, CP, 24),
    C48  = get_nearest(time, CP, 48),
    .groups = "drop"
  )

fig2_list <- lapply(dose_mg, function(d) {
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = HCTZ_ngmL,
      Dose = paste0(d, " mg q24h x", n_doses)
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Hydrochlorothiazide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. HCTZ once-daily, multi-dose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_ss = max(CP, na.rm = TRUE),
    Tmax_ss = time[which.max(CP)] - (n_doses - 1) * tau_h,
    Ctrough = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig3_list <- lapply(dose_mg, function(d) {
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = HCTZ_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Hydrochlorothiazide concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. HCTZ once-daily single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C24  = get_nearest(time, CP, 24),
    C48  = get_nearest(time, CP, 48),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    C48_med = median(C48, na.rm = TRUE),
    C48_p05 = quantile(C48, 0.05, na.rm = TRUE),
    C48_p95 = quantile(C48, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

fig4_list <- lapply(dose_mg, function(d) {
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = HCTZ_ngmL,
      Dose = paste0(d, " mg q24h x", n_doses)
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Hydrochlorothiazide concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. HCTZ once-daily multidose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_ss = max(CP, na.rm = TRUE),
    Tmax_ss = time[which.max(CP)] - (n_doses - 1) * tau_h,
    Ctrough = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax_ss, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax_ss, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax_ss, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax_ss, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax_ss, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax_ss, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary

