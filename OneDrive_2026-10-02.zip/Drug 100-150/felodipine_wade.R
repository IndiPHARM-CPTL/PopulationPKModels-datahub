library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

felodipine_code <- '
$PROB
- Ref: Wade JR, Sambol NC. Felodipine population dose-response and concentration-response relationships in patients with essential hypertension. Clin Pharmacol Ther. 1995;57(5):569-581. doi:10.1016/0009-9236(95)90042-X
- Problem: not for clinical use, only for illustrative purpose and as a bridge to PD model
$PARAM @annotated
TVCL        : 1260   : L/h      Apparent oral clearance for 60-year-old non-Black patient
TVV         : 33100  : L        Apparent volume of distribution

AGE         : 60     : years    Age
BLACK       : 0      : --       Race indicator; 1 = Black, 0 = non-Black

TH_BLACK_CL : 477    : L/h      Black race effect on CL/F
TH_AGE_CL   : 16.8   : L/h/yr   Age effect on CL/F when AGE < 60

MW          : 384.25 : g/mol    Felodipine molecular weight
PROP_SD     : 0.20   : --       Proportional residual SD; assumed

$CMT @annotated
CENT : Central compartment

$OMEGA @diag @labels ETA_CL ETA_V
0.1086 0.1180

$SIGMA
1

$GLOBAL
double Q;
double R;
double CLi;
double Vi;
double KEi;

$MAIN

if(BLACK == 1) {
  Q = 1.0;
} else {
  Q = 0.0;
}

if(AGE < 60.0) {
  R = 1.0;
} else {
  R = 0.0;
}


CLi = (TVCL +
       Q * TH_BLACK_CL +
       R * (60.0 - AGE) * TH_AGE_CL) *
       exp(ETA(1));

Vi = TVV * exp(ETA(2));

KEi = CLi / Vi;

$ODE
dxdt_CENT = -KEi * CENT;

$TABLE
double FEL_mgL   = CENT / Vi;
double FEL_ngmL  = FEL_mgL * 1000.0;
double FEL_nmolL = FEL_ngmL * 1000.0 / MW;

double DV_ngmL = FEL_ngmL * exp(PROP_SD * EPS(1));

$CAPTURE
FEL_ngmL FEL_nmolL DV_ngmL
CLi Vi KEi AGE BLACK Q R
'

mod <- mcode("felodipine_wade1995_popPK", felodipine_code)