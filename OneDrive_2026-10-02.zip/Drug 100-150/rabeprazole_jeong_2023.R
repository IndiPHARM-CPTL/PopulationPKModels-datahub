library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

rabeprazole_code <- '
$PROB
Rabeprazole population PK-PD model
- Ref: Jeong SH, Jang JH, Lee YB.
  Exploring Differences in Pharmacometrics of Rabeprazole between Genders
  via Population Pharmacokinetic-Pharmacodynamic Modeling.
  Biomedicines. 2023;11(11):3021.
  doi:10.3390/biomedicines11113021
  (PD data digitised from Chen ZY et al. Eur J Drug Metab Pharmacokinet.
   2006;31(1):27-33)

$PARAM @annotated
KA1         : 1.91   : 1/h    Absorption rate constant, depot -> transit 1
KA2         : 2.43   : 1/h    Absorption rate constant, transit 1 -> transit 2
KA3         : 3.34   : 1/h    Absorption rate constant, transit 2 -> central
TLAG        : 1.56   : h      Absorption lag time (male)
VCF         : 10.31  : L      Apparent central volume
CLF         : 25.65  : L/h    Apparent clearance
VPF         : 11.46  : L      Apparent peripheral volume
QF          : 5.45   : L/h    Apparent intercompartmental clearance

SEXF        : 0      : --     0 = male, 1 = female
BSA         : 1.75   : m2     Body surface area (Mosteller)
BSA_REF     : 1.75   : m2     Cohort median BSA

TH_TLAG_F   : 0.73   : --     Female effect on TLAG (linear fraction)
TH_KA3_BSA  : -1.11  : --     BSA exponent on KA3

E0          : 2.50   : pH     Baseline intragastric pH
EMAX        : 4.72   : pH     Maximum pH increase
EC50        : 51.58  : ng/mL  Concentration at half-maximal effect
HILL        : 5.04   : --     Hill coefficient

LOG_SD      : 0.37   : --     Log-additive residual SD

$CMT @annotated
DEPOT  : Enteric-coated tablet, dosing compartment (mg)
TR1    : Absorption transit compartment 1 (mg)
TR2    : Absorption transit compartment 2 (mg)
CENT   : Central compartment (mg)
PERIPH : Peripheral compartment (mg)

$OMEGA @labels ETA_VC ETA_CL ETA_KA3 ETA_TLAG
2.04 0.14 1.74 0.23

$SIGMA
1

$GLOBAL
double KA1i;
double KA2i;
double KA3i;
double TLAGi;
double VCFi;
double CLFi;
double VPFi;
double QFi;

$MAIN
KA1i = KA1;
KA2i = KA2;

KA3i = KA3 *
       pow(BSA / BSA_REF, TH_KA3_BSA) *
       exp(ETA_KA3);

TLAGi = TLAG *
        (1.0 + TH_TLAG_F * SEXF) *
        exp(ETA_TLAG);

VCFi = VCF * exp(ETA_VC);
CLFi = CLF * exp(ETA_CL);
VPFi = VPF;
QFi  = QF;

ALAG_DEPOT = TLAGi;

$ODE
dxdt_DEPOT = -KA1i * DEPOT;

dxdt_TR1 =
    KA1i * DEPOT
  - KA2i * TR1;

dxdt_TR2 =
    KA2i * TR1
  - KA3i * TR2;

dxdt_CENT =
    KA3i * TR2
  - (CLFi / VCFi) * CENT
  - (QFi  / VCFi) * CENT
  + (QFi  / VPFi) * PERIPH;

dxdt_PERIPH =
    (QFi / VCFi) * CENT
  - (QFi / VPFi) * PERIPH;

$TABLE
double CP_ngmL = 1000.0 * CENT / VCFi;
if (CP_ngmL < 0) CP_ngmL = 0;

double DV_PK =
  CP_ngmL * exp(LOG_SD * EPS(1));

double PH =
  E0 + EMAX * pow(CP_ngmL, HILL) /
       (pow(EC50, HILL) + pow(CP_ngmL, HILL));

$CAPTURE
CP_ngmL DV_PK PH
KA1i KA2i KA3i TLAGi VCFi CLFi VPFi QFi
SEXF BSA
'
mod_rab <- mcode("rabeprazole_pkpd", rabeprazole_code)


N <- 1000                         # per sex

doses_mg <- c(10, 20)
dose_levels <- c("10 mg", "20 mg")

tau <- 24
n_dose <- 5

t_end_sd <- 24
last_dose <- tau * (n_dose - 1)
t_end_md <- last_dose + tau

delta_sd <- 0.05
delta_md <- 0.1

ph_target <- 4                    # pH 4 efficacy threshold


at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

auc_trap <- function(time, conc) {
  sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2)
}

# Hours with pH above threshold, and first crossing time
time_above <- function(time, y, thr) {
  sum(diff(time) * (head(y, -1) > thr))
}

onset_time <- function(time, y, thr) {
  if (any(y > thr)) min(time[y > thr]) else NA_real_
}

add_sex <- function(df) {
  df %>% mutate(Sex = factor(ifelse(SEXF == 1, "Female", "Male"),
                             levels = c("Male", "Female")))
}




# Reference subjects at the per-sex median BSA the paper simulated
# (Results 3.4: male 1.87 m^2, female 1.58 m^2)
idata_typ <- tibble(
  ID = 1:2,
  SEXF = c(0, 1),
  BSA = c(1.87, 1.58)
)

idata_pop <- tibble(
  ID = 1:(2 * N),
  SEXF = rep(c(0, 1), each = N),
  BSA = rep(c(1.87, 1.58), each = N)
)

mod_typ <- zero_re(mod_rab)





# ---------------------------------------------------------------------------
# Figure 1. Typical male and female, single dose (PK and gastric pH)
# ---------------------------------------------------------------------------

fig1_list <- lapply(doses_mg, function(d) {
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_typ, end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = paste0(d, " mg"))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels)) %>%
  add_sex()


p1_rab <- ggplot(fig1_out, aes(time, CP_ngmL, color = Dose)) +
  geom_line(linewidth = 1) +
  facet_wrap(~ Sex) +
  scale_x_continuous(breaks = seq(0, 24, 2), limits = c(0, 12)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Rabeprazole concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Rabeprazole single dose"
  )

p1_rab


p1_rab_ph <- ggplot(fig1_out, aes(time, PH, color = Dose)) +
  geom_line(linewidth = 1) +
  geom_hline(yintercept = ph_target, linetype = "dotted") +
  facet_wrap(~ Sex) +
  scale_x_continuous(breaks = seq(0, 24, 2), limits = c(0, 12)) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Intragastric pH",
    color = "Dose",
    title = "Figure 1b. Rabeprazole single dose, gastric pH"
  )

p1_rab_ph


fig1_summary <- fig1_out %>%
  group_by(Sex, Dose) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = time[which.max(CP_ngmL)],
    AUC0_24 = auc_trap(time, CP_ngmL),
    TLAG_h = first(TLAGi),
    pH_max = max(PH),
    pH4_onset_h = onset_time(time, PH, ph_target),
    pH4_hours = time_above(time, PH, ph_target),
    .groups = "drop"
  )

fig1_summary


# Structural checks
# 1. AUC0-24 ~ Dose / CL (t1/2 ~1.6 h, so 0-24 h captures essentially all)
fig1_check <- fig1_summary %>%
  mutate(
    dose = as.numeric(sub(" mg", "", as.character(Dose))),
    AUC_expected = 1000 * dose / 25.65,
    pct_diff = 100 * (AUC0_24 / AUC_expected - 1)
  ) %>%
  select(Sex, Dose, AUC0_24, AUC_expected, pct_diff)

fig1_check

# 2. Female / male pH-4 onset ratio at 10 mg (Jeong 2023: 3.20 / 2.02 = 1.58)
fig1_summary %>%
  filter(Dose == "10 mg") %>%
  summarise(onset_ratio_F_over_M =
              pH4_onset_h[Sex == "Female"] / pH4_onset_h[Sex == "Male"])





# ---------------------------------------------------------------------------
# Figure 2. Typical male and female, once daily for 5 days
# ---------------------------------------------------------------------------

fig2_list <- lapply(doses_mg, function(d) {
  
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau, addl = n_dose - 1)
  
  mod_typ %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_typ, end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels)) %>%
  add_sex()


p2_rab <- ggplot(fig2_out, aes(time_day, CP_ngmL, color = Dose)) +
  geom_line(linewidth = 0.8) +
  facet_wrap(~ Sex) +
  scale_x_continuous(breaks = seq(0, n_dose, 1), limits = c(0, n_dose)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Rabeprazole concentration (ng/mL)",
    color = "Dose",
    title = paste0("Figure 2. Rabeprazole once daily for ", n_dose, " days")
  )

p2_rab


fig2_summary <- fig2_out %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  group_by(Sex, Dose) %>%
  summarise(
    Cmax_ss = max(CP_ngmL),
    Tmax_ss_h = t_rel[which.max(CP_ngmL)],
    Ctrough_ss = at_time(t_rel, CP_ngmL, tau),
    AUCtau_ss = auc_trap(t_rel, CP_ngmL),
    pH4_hours_ss = time_above(t_rel, PH, ph_target),
    .groups = "drop"
  )

fig2_summary





# ---------------------------------------------------------------------------
# Figure 3. Population, single dose (per sex)
# ---------------------------------------------------------------------------

fig3_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_rab %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_pop, end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = paste0(d, " mg"))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels)) %>%
  add_sex()


fig3_sum <- fig3_raw %>%
  group_by(Sex, Dose, time) %>%
  summarise(
    CP_med = median(CP_ngmL),
    CP_p05 = quantile(CP_ngmL, 0.05),
    CP_p95 = quantile(CP_ngmL, 0.95),
    PH_med = median(PH),
    PH_p05 = quantile(PH, 0.05),
    PH_p95 = quantile(PH, 0.95),
    .groups = "drop"
  )


p3_rab <- ggplot(fig3_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~ Sex) +
  scale_x_continuous(breaks = seq(0, 24, 2), limits = c(0, 12)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Rabeprazole concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Rabeprazole single dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p3_rab


p3_rab_ph <- ggplot(fig3_sum, aes(time, PH_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = PH_p05, ymax = PH_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  geom_hline(yintercept = ph_target, linetype = "dotted") +
  facet_wrap(~ Sex) +
  scale_x_continuous(breaks = seq(0, 24, 2), limits = c(0, 12)) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Intragastric pH",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3b. Rabeprazole single dose, population gastric pH",
    subtitle = "Median with 5th–95th percentiles"
  )

p3_rab_ph


fig3_ind <- fig3_raw %>%
  arrange(Sex, Dose, ID, time) %>%
  group_by(Sex, Dose, ID) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = time[which.max(CP_ngmL)],
    AUC0_24 = auc_trap(time, CP_ngmL),
    pH4_onset_h = onset_time(time, PH, ph_target),
    pH4_hours = time_above(time, PH, ph_target),
    .groups = "drop"
  )


fig3_summary <- fig3_ind %>%
  group_by(Sex, Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    AUC0_24_med = median(AUC0_24),
    AUC0_24_p05 = quantile(AUC0_24, 0.05),
    AUC0_24_p95 = quantile(AUC0_24, 0.95),
    
    pct_reach_pH4 = 100 * mean(!is.na(pH4_onset_h)),
    pH4_onset_med_h = median(pH4_onset_h, na.rm = TRUE),
    pH4_hours_med = median(pH4_hours),
    pH4_hours_p05 = quantile(pH4_hours, 0.05),
    pH4_hours_p95 = quantile(pH4_hours, 0.95),
    
    .groups = "drop"
  )

fig3_summary




# ---------------------------------------------------------------------------
# Figure 4. Population, once daily for 5 days (per sex)
# ---------------------------------------------------------------------------

fig4_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau, addl = n_dose - 1)
  
  mod_rab %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_pop, end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels)) %>%
  add_sex()


fig4_sum <- fig4_raw %>%
  group_by(Sex, Dose, time, time_day) %>%
  summarise(
    CP_med = median(CP_ngmL),
    CP_p05 = quantile(CP_ngmL, 0.05),
    CP_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )


p4_rab <- ggplot(fig4_sum, aes(time_day, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 0.8) +
  facet_wrap(~ Sex) +
  scale_x_continuous(breaks = seq(0, n_dose, 1), limits = c(0, n_dose)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Rabeprazole concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = paste0("Figure 4. Rabeprazole once daily for ", n_dose, " days, population"),
    subtitle = "Median with 5th–95th percentiles"
  )

p4_rab


fig4_ind <- fig4_raw %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  arrange(Sex, Dose, ID, t_rel) %>%
  group_by(Sex, Dose, ID) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = t_rel[which.max(CP_ngmL)],
    Ctrough = at_time(t_rel, CP_ngmL, tau),
    AUCtau = auc_trap(t_rel, CP_ngmL),
    pH4_hours = time_above(t_rel, PH, ph_target),
    .groups = "drop"
  )


fig4_summary <- fig4_ind %>%
  group_by(Sex, Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    Ctrough_med = median(Ctrough),
    Ctrough_p05 = quantile(Ctrough, 0.05),
    Ctrough_p95 = quantile(Ctrough, 0.95),
    
    AUCtau_med = median(AUCtau),
    AUCtau_p05 = quantile(AUCtau, 0.05),
    AUCtau_p95 = quantile(AUCtau, 0.95),
    
    pH4_hours_med = median(pH4_hours),
    pH4_hours_p05 = quantile(pH4_hours, 0.05),
    pH4_hours_p95 = quantile(pH4_hours, 0.95),
    
    .groups = "drop"
  )

fig4_summary