library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

letrozole_code <- '
$PROB
Letrozole population PK model

- Ref: Tanii H, Shitara Y, Horie T.
  Population pharmacokinetic analysis of letrozole
  in Japanese postmenopausal women.
  Eur J Clin Pharmacol. 2011;67:1017-1025.
  doi:10.1007/s00228-011-1042-3

- One-compartment model with first-order oral absorption
- Apparent clearance and apparent volume
- CYP2A6 genotype, creatinine and AST effects on CL/F
- Body-weight effect on V/F

$PARAM @annotated
KA       : 4.04    : 1/h   Absorption rate constant
CL       : 1.03    : L/h   Apparent oral clearance
V        : 94.2    : L     Apparent distribution volume

TH_PG1   : 0.843   : --    CL multiplier, 1 reference allele
TH_PG0   : 0.448   : --    CL multiplier, 0 reference alleles
TH_CRE   : -1.27   : --    Creatinine exponent
TH_AST   : -0.793  : --    AST exponent
TH_WT    : 1.12    : --    Weight exponent

CRE      : 0.70    : mg/dL Serum creatinine
AST      : 17.5    : IU/L  Serum AST
WTKG     : 51.1    : kg    Body weight
CYP_REF  : 2       : --    Number of reference CYP2A6 alleles

$CMT @annotated
GUT  : Oral absorption compartment (mg)
CENT : Central compartment (mg)

$OMEGA @labels ETA_CL ETA_V ETA_KA
0.174
0.0147
1.04

$SIGMA
0.0754

$GLOBAL
double CLi;
double Vi;
double KAi;
double PG_FACTOR;

$MAIN

PG_FACTOR = 1.0;

if(CYP_REF == 1) {
  PG_FACTOR = TH_PG1;
}

if(CYP_REF == 0) {
  PG_FACTOR = TH_PG0;
}

CLi = CL * PG_FACTOR
      * pow(CRE / 0.70, TH_CRE)
      * pow(AST / 17.5, TH_AST)
      * exp(ETA(1));

Vi = V
     * pow(WTKG / 51.1, TH_WT)
     * exp(ETA(2));

KAi = KA * exp(ETA(3));

$ODE

dxdt_GUT = -KAi * GUT;

dxdt_CENT = KAi * GUT
            - (CLi / Vi) * CENT;

$TABLE

double CP_ngmL = 1000.0 * CENT / Vi;

double DV_PK = CP_ngmL * exp(EPS(1));

$CAPTURE
CP_ngmL DV_PK CLi Vi KAi PG_FACTOR
WTKG CRE AST CYP_REF
'

mod_let <- mcode("letrozole_pk", letrozole_code)


set.seed(123)

N <- 1000

doses_mg <- c(2.5)
dose_levels <- c("2.5 mg")

tau <- 24
n_dose <- 28

t_end_sd <- 14 * tau
t_end_md <- n_dose * tau

delta_sd <- 0.1
delta_md <- 0.25

last_dose <- (n_dose - 1) * tau

idata_typ <- tibble(
  ID = 1,
  WTKG = 51.1,
  CRE = 0.70,
  AST = 17.5,
  CYP_REF = 2
)

# Reference-covariate virtual population
idata_pop <- tibble(
  ID = 1:N,
  WTKG = 51.1,
  CRE = 0.70,
  AST = 17.5,
  CYP_REF = 2
)

mod_typ <- zero_re(mod_let)

at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

auc_trap <- function(time, conc) {
  sum(
    diff(time) *
      (head(conc, -1) + tail(conc, -1)) / 2
  )
}





fig1_list <- lapply(doses_mg, function(d) {
  
  ev_sd <- ev(
    time = 0,
    amt = d,
    cmt = 1
  )
  
  mod_typ %>%
    ev(ev_sd) %>%
    mrgsim(
      idata = idata_typ,
      end = t_end_sd,
      delta = delta_sd
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

p1_let <- ggplot(
  fig1_out,
  aes(time_day, CP_ngmL, color = Dose)
) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Letrozole concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Letrozole single dose"
  )

p1_let

fig1_summary <- fig1_out %>%
  filter(time <= tau) %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = time[which.max(CP_ngmL)],
    C24 = at_time(time, CP_ngmL, tau),
    AUC0_24 = auc_trap(time, CP_ngmL),
    .groups = "drop"
  )

fig1_summary





fig2_list <- lapply(doses_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt = d,
    cmt = 1,
    ii = tau,
    addl = n_dose - 1
  )
  
  mod_typ %>%
    ev(ev_md) %>%
    mrgsim(
      idata = idata_typ,
      end = t_end_md,
      delta = delta_md
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

p2_let <- ggplot(
  fig2_out,
  aes(time_day, CP_ngmL, color = Dose)
) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Letrozole concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Letrozole 2.5 mg QD for 28 days"
  )

p2_let

fig2_summary <- fig2_out %>%
  filter(
    time >= last_dose,
    time <= last_dose + tau
  ) %>%
  mutate(t_rel = time - last_dose) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_ss = max(CP_ngmL),
    Tmax_ss_h = t_rel[which.max(CP_ngmL)],
    Ctrough_ss = at_time(t_rel, CP_ngmL, tau),
    AUCtau_ss = auc_trap(t_rel, CP_ngmL),
    .groups = "drop"
  )

fig2_summary





fig3_list <- lapply(doses_mg, function(d) {
  
  ev_sd <- ev(
    time = 0,
    amt = d,
    cmt = 1
  )
  
  mod_let %>%
    ev(ev_sd) %>%
    mrgsim(
      idata = idata_pop,
      end = t_end_sd,
      delta = delta_sd
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time, time_day) %>%
  summarise(
    CP_med = median(CP_ngmL),
    CP_p05 = quantile(CP_ngmL, 0.05),
    CP_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )

p3_let <- ggplot(
  fig3_sum,
  aes(
    time_day,
    CP_med,
    color = Dose,
    fill = Dose
  )
) +
  geom_ribbon(
    aes(ymin = CP_p05, ymax = CP_p95),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Letrozole concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Letrozole single dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p3_let

fig3_ind <- fig3_raw %>%
  filter(time <= tau) %>%
  arrange(Dose, ID, time) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = time[which.max(CP_ngmL)],
    C24 = at_time(time, CP_ngmL, tau),
    AUC0_24 = auc_trap(time, CP_ngmL),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    C24_med = median(C24),
    C24_p05 = quantile(C24, 0.05),
    C24_p95 = quantile(C24, 0.95),
    
    AUC0_24_med = median(AUC0_24),
    AUC0_24_p05 = quantile(AUC0_24, 0.05),
    AUC0_24_p95 = quantile(AUC0_24, 0.95),
    
    .groups = "drop"
  )

fig3_summary




fig4_list <- lapply(doses_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt = d,
    cmt = 1,
    ii = tau,
    addl = n_dose - 1
  )
  
  mod_let %>%
    ev(ev_md) %>%
    mrgsim(
      idata = idata_pop,
      end = t_end_md,
      delta = delta_md
    ) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time, time_day) %>%
  summarise(
    CP_med = median(CP_ngmL),
    CP_p05 = quantile(CP_ngmL, 0.05),
    CP_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )

p4_let <- ggplot(
  fig4_sum,
  aes(
    time_day,
    CP_med,
    color = Dose,
    fill = Dose
  )
) +
  geom_ribbon(
    aes(ymin = CP_p05, ymax = CP_p95),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Letrozole concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Letrozole 2.5 mg QD, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p4_let

fig4_ind <- fig4_raw %>%
  filter(
    time >= last_dose,
    time <= last_dose + tau
  ) %>%
  mutate(t_rel = time - last_dose) %>%
  arrange(Dose, ID, t_rel) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = t_rel[which.max(CP_ngmL)],
    Ctrough = at_time(t_rel, CP_ngmL, tau),
    AUCtau = auc_trap(t_rel, CP_ngmL),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    Ctrough_med = median(Ctrough),
    Ctrough_p05 = quantile(Ctrough, 0.05),
    Ctrough_p95 = quantile(Ctrough, 0.95),
    
    AUCtau_med = median(AUCtau),
    AUCtau_p05 = quantile(AUCtau, 0.05),
    AUCtau_p95 = quantile(AUCtau, 0.95),
    
    .groups = "drop"
  )

fig4_summary