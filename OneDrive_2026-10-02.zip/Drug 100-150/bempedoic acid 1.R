library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

bempedoic_code <- '
$PROB
Bempedoic acid oral PopPK model
- Ref: Jadhav SB, Amore BM, Bockbrader H, Crass RL, Chapel S, Sasiela WJ, Emery MG.
  Population pharmacokinetic and pharmacokinetic-pharmacodynamic modeling of bempedoic acid
  and low-density lipoprotein cholesterol in healthy subjects and patients with dyslipidemia.
  J Pharmacokinet Pharmacodyn. 2023;50:351-364.

$PARAM @annotated
CL      : 0.755 : L/h     Apparent systemic clearance, CL/F
VC      : 19.1  : L       Apparent central volume, Vc/F
KA      : 1.41  : 1/h     Absorption/transit rate constant
K23     : 0.184 : 1/h     Central-to-peripheral rate constant
K32     : 0.156 : 1/h     Peripheral-to-central rate constant

FED     : 0     : --      0 = fasted, 1 = fed
FEMALE  : 0     : --      0 = male, 1 = female
BLACK   : 0     : --      0 = reference, 1 = Black
HYPERLIP: 1     : --      Hyperlipidemia
T2DM    : 0     : --      Type 2 diabetes
EZET    : 0     : --      Ezetimibe
ATORVA  : 0     : --      Atorvastatin
SIMVA   : 0     : --      Simvastatin

WT      : 85.1  : kg
AGE     : 60.5  : year
EGFR    : 91.4  : mL/min

REF_WT  : 85.1  : kg
REF_AGE : 60.5  : year
REF_EGFR: 91.4  : mL/min

COV_ON  : 1     : --      0 = no covariates, 1 = covariates

$CMT
TRANSIT ABS CENT PERIPH

$OMEGA @annotated
ECL : 0.0845 : IIV on CL/F
EVC : 0.6931 : IIV on Vc/F
EKA : 0.4364 : IIV on KA

$MAIN
double food_eff = 1.0;
double cl_eff = 1.0;
double vc_eff = 1.0;
double f1_eff = 1.0;

if(COV_ON == 1) {
  food_eff = 1.0 - 0.777 * FED;

  cl_eff = (1.0 - 0.127 * FEMALE) *
           (1.0 - 0.143 * BLACK) *
           (1.0 - 0.0945 * HYPERLIP) *
           (1.0 - 0.177 * T2DM) *
           (1.0 - 0.0934 * EZET) *
           pow(WT / REF_WT, 0.61) *
           pow(EGFR / REF_EGFR, 0.574);

  vc_eff = (1.0 - 0.0895 * FEMALE) *
           (1.0 - 0.154 * SIMVA) *
           pow(WT / REF_WT, 0.94) *
           pow(AGE / REF_AGE, 0.743);

  f1_eff = 1.0 + 0.142 * ATORVA;
}

double CLi = CL * cl_eff * exp(ECL);
double VCi = VC * vc_eff * exp(EVC);
double KAi = KA * food_eff * exp(EKA);

double K10i = CLi / VCi;

F_TRANSIT = f1_eff;

$ODE
dxdt_TRANSIT = -KAi * TRANSIT;
dxdt_ABS = KAi * TRANSIT - KAi * ABS;
dxdt_CENT = KAi * ABS - K10i * CENT - K23 * CENT + K32 * PERIPH;
dxdt_PERIPH = K23 * CENT - K32 * PERIPH;

$TABLE
double CP_ugmL = CENT / VCi;

$CAPTURE CP_ugmL
'

mod <- mcode("bempedoic_jadhav_2023", bempedoic_code)

dose_mg <- c(60, 120, 180, 240)
n_pop <- 1000

tau_h <- 24
n_doses <- 10
addl_md <- n_doses - 1

t_end_sd <- 240
last_dose_h <- (n_doses - 1) * tau_h
final_interval_end_h <- last_dose_h + tau_h
t_end_md <- final_interval_end_h

delta_sd <- 0.2
delta_md <- 0.2

idata_typ <- tibble(
  ID = 1, FED = 0, FEMALE = 0, BLACK = 0, HYPERLIP = 1, T2DM = 0,
  EZET = 0, ATORVA = 0, SIMVA = 0, WT = 85.1, AGE = 60.5, EGFR = 91.4,
  REF_WT = 85.1, REF_AGE = 60.5, REF_EGFR = 91.4, COV_ON = 0
)

set.seed(123)

idata_pop <- tibble(
  ID = 1:n_pop,
  FED = 0,
  FEMALE = rbinom(n_pop, 1, 0.406),
  BLACK = rbinom(n_pop, 1, 0.092),
  HYPERLIP = rbinom(n_pop, 1, 0.896),
  T2DM = rbinom(n_pop, 1, 0.161),
  EZET = 0,
  ATORVA = 0,
  SIMVA = 0,
  WT = pmin(pmax(rnorm(n_pop, 85.1, 17.3), 42.5), 160),
  AGE = pmin(pmax(rnorm(n_pop, 60.5, 12.3), 18), 90),
  EGFR = pmin(pmax(rnorm(n_pop, 91.4, 24.5), 30), 180),
  REF_WT = 85.1,
  REF_AGE = 60.5,
  REF_EGFR = 91.4,
  COV_ON = 1
)

mod_typ <- zero_re(mod)

get_nearest <- function(time, conc, target_time) conc[which.min(abs(time - target_time))]

dose_levels_sd <- paste0(dose_mg, " mg")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses)


fig1_raw <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = 1)) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(ID, time, CP = pmax(CP_ugmL, 0), Dose = paste0(d, " mg"))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_raw, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(x = "Time after dose (h)", y = "Plasma concentration (ug/mL)", color = "Dose",
       title = "Figure 1. Bempedoic acid once-daily single-dose")

fig1_summary <- fig1_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_ug_mL = max(CP, na.rm = TRUE),
    Tmax_h = time[which.max(CP)],
    C24_ug_mL = get_nearest(time, CP, 24),
    .groups = "drop"
  )


fig2_raw <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = 1, ii = tau_h, addl = addl_md)) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(ID, time, CP = pmax(CP_ugmL, 0), Dose = paste0(d, " mg q24h x", n_doses))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_raw, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(x = "Time (h)", y = "Plasma concentration (ug/mL)", color = "Dose",
       title = "Figure 2. Bempedoic acid once-daily for 10 days")

fig2_summary <- fig2_raw %>%
  filter(time >= last_dose_h, time <= final_interval_end_h) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_ug_mL = max(CP, na.rm = TRUE),
    Tmax_h = time[which.max(CP)] - last_dose_h,
    Ctrough_ug_mL = get_nearest(time, CP, final_interval_end_h),
    .groups = "drop"
  )


fig3_raw <- lapply(dose_mg, function(d) {
  set.seed(123)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = 1)) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(ID, time, CP = pmax(CP_ugmL, 0), Dose = paste0(d, " mg"))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    CP_med = median(CP, na.rm = TRUE),
    CP_p05 = quantile(CP, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(x = "Time after dose (h)", y = "Plasma concentration (ug/mL)", color = "Dose", fill = "Dose",
       title = "Figure 3. Bempedoic acid once-daily single-dose, population")

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C24 = get_nearest(time, CP, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )


fig4_raw <- lapply(dose_mg, function(d) {
  set.seed(123)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = 1, ii = tau_h, addl = addl_md)) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(ID, time, CP = pmax(CP_ugmL, 0), Dose = paste0(d, " mg q24h x", n_doses))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    CP_med = median(CP, na.rm = TRUE),
    CP_p05 = quantile(CP, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(x = "Time (h)", y = "Plasma concentration (ug/mL)", color = "Dose", fill = "Dose",
       title = "Figure 4. Bempedoic acid once-daily for 10 days, population")

fig4_ind <- fig4_raw %>%
  filter(time >= last_dose_h, time <= final_interval_end_h) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)] - last_dose_h,
    Ctrough = get_nearest(time, CP, final_interval_end_h),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary

