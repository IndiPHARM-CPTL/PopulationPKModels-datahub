library(mrgsolve)
library(dplyr)
library(tibble)
library(tidyr)
library(ggplot2)


pantoprazole_code <- '
$PROB
Pantoprazole population PK model

- Ref:
  Pettersen G, Mouksassi MS, Theoret Y, et al.
  Population pharmacokinetics of intravenous pantoprazole
  in paediatric intensive care patients.
  Br J Clin Pharmacol. 2009;67(2):216-227.
  doi:10.1111/j.1365-2125.2008.03328.x


$PARAM @annotated
CL_REF     : 5.28    : L/h     Clearance at 20 kg / 5 yr
VC_REF     : 2.22    : L       Central volume at 20 kg
Q_REF      : 1.10    : L/h     Intercompartmental clearance at 20 kg
VP_REF     : 2.73    : L       Peripheral volume at 20 kg
WT         : 20      : kg      Body weight
AGE        : 5       : yr      Age
DIS_SIRS   : 0       : --      Systemic inflammatory response syndrome
CYP2C19_INH: 0       : --      Concomitant CYP2C19 inhibitor
HEPIMP     : 0       : --      Hepatic dysfunction
AGE_EXP    : 0.316   : --      Age exponent on clearance
SIRS_FAC   : 0.377   : --      CL multiplier when SIRS present
INH_FAC    : 0.342   : --      CL multiplier with CYP2C19 inhibitor
HEP_FAC    : 0.495   : --      CL multiplier with hepatic dysfunction
PROP_SD    : 0.195   : --      Proportional residual SD
ADD_SD     : 0.00001 : mg/L    Additive residual SD

$CMT @annotated
CENT   : Central compartment (mg)
PERIPH : Peripheral compartment (mg)

$OMEGA @labels ETA_CL ETA_VC ETA_Q ETA_VP
0.100411
0.152580
0.059220
0.674148

$SIGMA
1
1

$GLOBAL
double CLi;
double VCi;
double Qi;
double VPi;
double COV_SIRS;
double COV_INH;
double COV_HEP;

$MAIN

// ------------------------------------------------------------
// Clinical covariate multipliers
// ------------------------------------------------------------

COV_SIRS = 1.0;

if(DIS_SIRS == 1) {
  COV_SIRS = SIRS_FAC;
}


COV_INH = 1.0;

if(CYP2C19_INH == 1) {
  COV_INH = INH_FAC;
}


COV_HEP = 1.0;

if(HEPIMP == 1) {
  COV_HEP = HEP_FAC;
}


// ------------------------------------------------------------
// Individual clearance
//
// CL = 5.28 *
//      (WT/20)^0.75 *
//      (AGE/5)^0.316 *
//      clinical covariates *
//      exp(ETA_CL)
// ------------------------------------------------------------

CLi =
  CL_REF *
  pow(WT / 20.0, 0.75) *
  pow(AGE / 5.0, AGE_EXP) *
  COV_SIRS *
  COV_INH *
  COV_HEP *
  exp(ETA(1));


// ------------------------------------------------------------
// Central volume
// ------------------------------------------------------------

VCi =
  VC_REF *
  pow(WT / 20.0, 1.0) *
  exp(ETA(2));


// ------------------------------------------------------------
// Intercompartmental clearance
// ------------------------------------------------------------

Qi =
  Q_REF *
  pow(WT / 20.0, 0.75) *
  exp(ETA(3));


// ------------------------------------------------------------
// Peripheral volume
// ------------------------------------------------------------

VPi =
  VP_REF *
  pow(WT / 20.0, 1.0) *
  exp(ETA(4));


$ODE

dxdt_CENT =
  - (CLi / VCi) * CENT
  - (Qi  / VCi) * CENT
  + (Qi  / VPi) * PERIPH;

dxdt_PERIPH =
    (Qi / VCi) * CENT
  - (Qi / VPi) * PERIPH;


$TABLE

// Plasma concentration
double CP_mgL =
  CENT / VCi;

double CP_ngmL =
  1000.0 * CP_mgL;


// Combined residual error
double DV_mgL =
  CP_mgL *
  (
    1.0 +
    PROP_SD * EPS(1)
  ) +
  ADD_SD * EPS(2);

double DV_ngmL =
  1000.0 * DV_mgL;


$CAPTURE
CP_mgL CP_ngmL
DV_mgL DV_ngmL
CLi VCi Qi VPi
WT AGE
DIS_SIRS CYP2C19_INH HEPIMP
COV_SIRS COV_INH COV_HEP
'


mod_panto <- mcode(
  "pantoprazole_pettersen2009",
  pantoprazole_code
)

library(mrgsolve)
library(dplyr)
library(tibble)
library(tidyr)
library(ggplot2)


# ============================================================
# PANTOPRAZOLE POPULATION PK MODEL
# Pettersen et al. 2009
# ============================================================

pantoprazole_code <- '
$PROB
Pantoprazole population PK model

- Ref:
  Pettersen G, Mouksassi MS, Theoret Y, et al.
  Population pharmacokinetics of intravenous pantoprazole
  in paediatric intensive care patients.
  Br J Clin Pharmacol. 2009;67(2):216-227.
  doi:10.1111/j.1365-2125.2008.03328.x

- Pediatric intensive-care patients
- Intravenous pantoprazole
- Two-compartment disposition
- Zero-order IV infusion
- First-order elimination
- Fixed allometric body-weight scaling
- Age effect on clearance
- SIRS effect on clearance
- CYP2C19 inhibitor effect on clearance
- Hepatic dysfunction effect on clearance
- IIV on CL, VC, Q, and VP
- Combined proportional + additive residual error

Reference patient:
- WT = 20 kg
- AGE = 5 years
- No SIRS
- No CYP2C19 inhibitor
- No hepatic dysfunction

$PARAM @annotated
CL_REF     : 5.28    : L/h     Clearance at 20 kg / 5 yr
VC_REF     : 2.22    : L       Central volume at 20 kg
Q_REF      : 1.10    : L/h     Intercompartmental clearance at 20 kg
VP_REF     : 2.73    : L       Peripheral volume at 20 kg
WT         : 20      : kg      Body weight
AGE        : 5       : yr      Age
DIS_SIRS   : 0       : --      Systemic inflammatory response syndrome
CYP2C19_INH: 0       : --      Concomitant CYP2C19 inhibitor
HEPIMP     : 0       : --      Hepatic dysfunction
AGE_EXP    : 0.316   : --      Age exponent on clearance
SIRS_FAC   : 0.377   : --      CL multiplier when SIRS present
INH_FAC    : 0.342   : --      CL multiplier with CYP2C19 inhibitor
HEP_FAC    : 0.495   : --      CL multiplier with hepatic dysfunction
PROP_SD    : 0.195   : --      Proportional residual SD
ADD_SD     : 0.00001 : mg/L    Additive residual SD

$CMT @annotated
CENT   : Central compartment (mg)
PERIPH : Peripheral compartment (mg)

$OMEGA @labels ETA_CL ETA_VC ETA_Q ETA_VP
0.100411
0.152580
0.059220
0.674148

$SIGMA
1
1

$GLOBAL
double CLi;
double VCi;
double Qi;
double VPi;
double COV_SIRS;
double COV_INH;
double COV_HEP;

$MAIN

// ------------------------------------------------------------
// Clinical covariate multipliers
// ------------------------------------------------------------

COV_SIRS = 1.0;

if(DIS_SIRS == 1) {
  COV_SIRS = SIRS_FAC;
}


COV_INH = 1.0;

if(CYP2C19_INH == 1) {
  COV_INH = INH_FAC;
}


COV_HEP = 1.0;

if(HEPIMP == 1) {
  COV_HEP = HEP_FAC;
}


// ------------------------------------------------------------
// Individual clearance
//
// CL = 5.28 *
//      (WT/20)^0.75 *
//      (AGE/5)^0.316 *
//      clinical covariates *
//      exp(ETA_CL)
// ------------------------------------------------------------

CLi =
  CL_REF *
  pow(WT / 20.0, 0.75) *
  pow(AGE / 5.0, AGE_EXP) *
  COV_SIRS *
  COV_INH *
  COV_HEP *
  exp(ETA(1));


// ------------------------------------------------------------
// Central volume
// ------------------------------------------------------------

VCi =
  VC_REF *
  pow(WT / 20.0, 1.0) *
  exp(ETA(2));


// ------------------------------------------------------------
// Intercompartmental clearance
// ------------------------------------------------------------

Qi =
  Q_REF *
  pow(WT / 20.0, 0.75) *
  exp(ETA(3));


// ------------------------------------------------------------
// Peripheral volume
// ------------------------------------------------------------

VPi =
  VP_REF *
  pow(WT / 20.0, 1.0) *
  exp(ETA(4));


$ODE

dxdt_CENT =
  - (CLi / VCi) * CENT
  - (Qi  / VCi) * CENT
  + (Qi  / VPi) * PERIPH;

dxdt_PERIPH =
    (Qi / VCi) * CENT
  - (Qi / VPi) * PERIPH;


$TABLE

// Plasma concentration
double CP_mgL =
  CENT / VCi;

double CP_ngmL =
  1000.0 * CP_mgL;


// Combined residual error
double DV_mgL =
  CP_mgL *
  (
    1.0 +
    PROP_SD * EPS(1)
  ) +
  ADD_SD * EPS(2);

double DV_ngmL =
  1000.0 * DV_mgL;


$CAPTURE
CP_mgL CP_ngmL
DV_mgL DV_ngmL
CLi VCi Qi VPi
WT AGE
DIS_SIRS CYP2C19_INH HEPIMP
COV_SIRS COV_INH COV_HEP
'


mod_panto <- mcode(
  "pantoprazole_pettersen2009",
  pantoprazole_code
)



N <- 1000
WT_typ <- 20
AGE_typ <- 5
tau <- 24
n_dose <- 5
last_dose <- tau * (n_dose - 1)
t_end_sd <- 24
t_end_md <- last_dose + tau
delta_sd <- 0.05
delta_md <- 0.05
infdur_h <- 0.5



height_cm_boys <- function(age_years) { age <- pmax(0, pmin(age_years, 5)); 50 + 25 * sqrt(age) }
bsa_m2 <- function(wt_kg, ht_cm) { sqrt(wt_kg * ht_cm / 3600) }

HT_typ <- height_cm_boys(AGE_typ)
BSA_typ <- bsa_m2(WT_typ, HT_typ)
dose_mg <- 40 * BSA_typ / 1.73
infusion_rate <- dose_mg / infdur_h

dose_mg

scenario_table <- tribble(
  ~Scenario, ~DIS_SIRS, ~CYP2C19_INH, ~HEPIMP,
  "Reference", 0, 0, 0,
  "SIRS", 1, 0, 0,
  "CYP2C19 inhibitor", 0, 1, 0,
  "Hepatic dysfunction", 0, 0, 1,
  "SIRS + CYP2C19 inhibitor", 1, 1, 0,
  "SIRS + hepatic dysfunction", 1, 0, 1,
  "CYP2C19 inhibitor + hepatic dysfunction", 0, 1, 1,
  "All three", 1, 1, 1
)

scenario_levels <- scenario_table$Scenario

at_time <- function(time, value, target) { value[which.min(abs(time - target))] }
auc_trap <- function(time, conc) { sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2) }

mod_typ <- zero_re(mod_panto)




fig1_list <- vector("list", nrow(scenario_table))

for(i in seq_len(nrow(scenario_table))) {
  sc <- scenario_table[i, ]
  idata_typ <- tibble(ID = 1, WT = WT_typ, AGE = AGE_typ, DIS_SIRS = sc$DIS_SIRS, CYP2C19_INH = sc$CYP2C19_INH, HEPIMP = sc$HEPIMP)
  ev_sd <- ev(time = 0, amt = dose_mg, cmt = 1, rate = infusion_rate)
  fig1_list[[i]] <- mod_typ %>% ev(ev_sd) %>% mrgsim(idata = idata_typ, end = t_end_sd, delta = delta_sd) %>% as_tibble() %>% mutate(Scenario = sc$Scenario)
}

fig1_out <- bind_rows(fig1_list) %>% mutate(Scenario = factor(Scenario, levels = scenario_levels))

p1_panto <- ggplot(fig1_out, aes(x = time, y = CP_ngmL, color = Scenario)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(x = "Time (h)", y = "Pantoprazole concentration (ng/mL)", color = "Clinical scenario", title = "Figure 1. Pantoprazole single IV infusion", subtitle = paste0(round(dose_mg, 1), " mg over 30 min; 20-kg, 5-year reference patient"))

p1_panto



fig1_summary <- fig1_out %>%
  group_by(Scenario) %>%
  summarise(Cmax_ngmL = max(CP_ngmL), Tmax_h = time[which.max(CP_ngmL)], C24_ngmL = at_time(time, CP_ngmL, 24), AUC0_24_ng_h_mL = auc_trap(time, CP_ngmL), .groups = "drop")

fig1_summary



fig2_list <- vector("list", nrow(scenario_table))

for(i in seq_len(nrow(scenario_table))) {
  sc <- scenario_table[i, ]
  idata_typ <- tibble(ID = 1, WT = WT_typ, AGE = AGE_typ, DIS_SIRS = sc$DIS_SIRS, CYP2C19_INH = sc$CYP2C19_INH, HEPIMP = sc$HEPIMP)
  ev_md <- ev(time = 0, amt = dose_mg, cmt = 1, rate = infusion_rate, ii = tau, addl = n_dose - 1)
  fig2_list[[i]] <- mod_typ %>% ev(ev_md) %>% mrgsim(idata = idata_typ, end = t_end_md, delta = delta_md) %>% as_tibble() %>% mutate(Scenario = sc$Scenario, time_day = time / 24)
}

fig2_out <- bind_rows(fig2_list) %>% mutate(Scenario = factor(Scenario, levels = scenario_levels))

p2_panto <- ggplot(fig2_out, aes(x = time_day, y = CP_ngmL, color = Scenario)) +
  geom_line(linewidth = 0.9) +
  theme_bw() +
  labs(x = "Time (days)", y = "Pantoprazole concentration (ng/mL)", color = "Clinical scenario", title = "Figure 2. Pantoprazole IV once daily for five days", subtitle = paste0(round(dose_mg, 1), " mg over 30 min every 24 h"))

p2_panto


fig2_summary <- fig2_out %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  group_by(Scenario) %>%
  summarise(Cmax_day5_ngmL = max(CP_ngmL), Tmax_day5_h = t_rel[which.max(CP_ngmL)], Ctrough_day5_ngmL = at_time(t_rel, CP_ngmL, tau), AUCtau_day5_ng_h_mL = auc_trap(t_rel, CP_ngmL), .groups = "drop")

fig2_summary


set.seed(123)

fig3_list <- vector("list", nrow(scenario_table))

for(i in seq_len(nrow(scenario_table))) {
  sc <- scenario_table[i, ]
  idata_pop <- tibble(ID = 1:N, WT = WT_typ, AGE = AGE_typ, DIS_SIRS = sc$DIS_SIRS, CYP2C19_INH = sc$CYP2C19_INH, HEPIMP = sc$HEPIMP)
  ev_sd <- ev(time = 0, amt = dose_mg, cmt = 1, rate = infusion_rate)
  fig3_list[[i]] <- mod_panto %>% ev(ev_sd) %>% mrgsim(idata = idata_pop, end = t_end_sd, delta = delta_sd) %>% as_tibble() %>% mutate(Scenario = sc$Scenario)
}

fig3_raw <- bind_rows(fig3_list) %>% mutate(Scenario = factor(Scenario, levels = scenario_levels))

fig3_sum <- fig3_raw %>%
  group_by(Scenario, time) %>%
  summarise(CP_med = median(CP_ngmL), CP_p05 = quantile(CP_ngmL, 0.05), CP_p95 = quantile(CP_ngmL, 0.95), .groups = "drop")

p3_panto <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = Scenario, fill = Scenario)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.20, colour = NA) +
  geom_line(linewidth = 0.9) +
  facet_wrap(~Scenario, scales = "free_y") +
  theme_bw() +
  theme(legend.position = "none") +
  labs(x = "Time (h)", y = "Pantoprazole concentration (ng/mL)", title = "Figure 3. Pantoprazole single IV infusion, population", subtitle = "Median with 5th–95th percentiles")

p3_panto

fig3_ind <- fig3_raw %>%
  arrange(Scenario, ID, time) %>%
  group_by(Scenario, ID) %>%
  summarise(Cmax = max(CP_ngmL), Tmax_h = time[which.max(CP_ngmL)], C24 = at_time(time, CP_ngmL, 24), AUC0_24 = auc_trap(time, CP_ngmL), .groups = "drop")

fig3_summary <- fig3_ind %>%
  group_by(Scenario) %>%
  summarise(Cmax_med = median(Cmax), Cmax_p05 = quantile(Cmax, 0.05), Cmax_p95 = quantile(Cmax, 0.95), Tmax_med_h = median(Tmax_h), Tmax_p05_h = quantile(Tmax_h, 0.05), Tmax_p95_h = quantile(Tmax_h, 0.95), C24_med = median(C24), C24_p05 = quantile(C24, 0.05), C24_p95 = quantile(C24, 0.95), AUC0_24_med = median(AUC0_24), AUC0_24_p05 = quantile(AUC0_24, 0.05), AUC0_24_p95 = quantile(AUC0_24, 0.95), .groups = "drop")

fig3_summary



set.seed(456)

fig4_list <- vector("list", nrow(scenario_table))

for(i in seq_len(nrow(scenario_table))) {
  sc <- scenario_table[i, ]
  idata_pop <- tibble(ID = 1:N, WT = WT_typ, AGE = AGE_typ, DIS_SIRS = sc$DIS_SIRS, CYP2C19_INH = sc$CYP2C19_INH, HEPIMP = sc$HEPIMP)
  ev_md <- ev(time = 0, amt = dose_mg, cmt = 1, rate = infusion_rate, ii = tau, addl = n_dose - 1)
  fig4_list[[i]] <- mod_panto %>% ev(ev_md) %>% mrgsim(idata = idata_pop, end = t_end_md, delta = delta_md) %>% as_tibble() %>% mutate(Scenario = sc$Scenario, time_day = time / 24)
}

fig4_raw <- bind_rows(fig4_list) %>% mutate(Scenario = factor(Scenario, levels = scenario_levels))

fig4_sum <- fig4_raw %>%
  group_by(Scenario, time, time_day) %>%
  summarise(CP_med = median(CP_ngmL), CP_p05 = quantile(CP_ngmL, 0.05), CP_p95 = quantile(CP_ngmL, 0.95), .groups = "drop")

p4_panto <- ggplot(fig4_sum, aes(x = time_day, y = CP_med, color = Scenario, fill = Scenario)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.20, colour = NA) +
  geom_line(linewidth = 0.9) +
  facet_wrap(~Scenario, scales = "free_y") +
  theme_bw() +
  theme(legend.position = "none") +
  labs(x = "Time (days)", y = "Pantoprazole concentration (ng/mL)", title = "Figure 4. Pantoprazole IV once daily for five days, population", subtitle = "Median with 5th–95th percentiles")

p4_panto


fig4_ind <- fig4_raw %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  arrange(Scenario, ID, t_rel) %>%
  group_by(Scenario, ID) %>%
  summarise(Cmax = max(CP_ngmL), Tmax_h = t_rel[which.max(CP_ngmL)], Ctrough = at_time(t_rel, CP_ngmL, tau), AUCtau = auc_trap(t_rel, CP_ngmL), .groups = "drop")

fig4_summary <- fig4_ind %>%
  group_by(Scenario) %>%
  summarise(Cmax_med = median(Cmax), Cmax_p05 = quantile(Cmax, 0.05), Cmax_p95 = quantile(Cmax, 0.95), Tmax_med_h = median(Tmax_h), Tmax_p05_h = quantile(Tmax_h, 0.05), Tmax_p95_h = quantile(Tmax_h, 0.95), Ctrough_med = median(Ctrough), Ctrough_p05 = quantile(Ctrough, 0.05), Ctrough_p95 = quantile(Ctrough, 0.95), AUCtau_med = median(AUCtau), AUCtau_p05 = quantile(AUCtau, 0.05), AUCtau_p95 = quantile(AUCtau, 0.95), .groups = "drop")

fig4_summary


fig1_table <- fig1_summary %>% mutate(across(where(is.numeric), ~round(.x, 2)))
fig2_table <- fig2_summary %>% mutate(across(where(is.numeric), ~round(.x, 2)))
fig3_table <- fig3_summary %>% mutate(across(where(is.numeric), ~round(.x, 2)))
fig4_table <- fig4_summary %>% mutate(across(where(is.numeric), ~round(.x, 2)))

fig1_table
fig2_table
fig3_table
fig4_table


p1_panto
p2_panto
p3_panto
p4_panto