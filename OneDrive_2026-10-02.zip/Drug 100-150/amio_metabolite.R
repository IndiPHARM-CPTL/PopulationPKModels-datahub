library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

amiodarone_code <- '
$PROB
- Ref: Pollak PT, Bouillon T, Shafer SL. Population pharmacokinetics of long-term oral amiodarone therapy. Clin Pharmacol Ther. 2000;67(6):642-652.
- Amiodarone and desethylamiodarone model
- Study: long washout period 

$PARAM @annotated
V1A   : 882   : L      Amiodarone central volume, V1/F
V2A   : 12700 : L      Amiodarone peripheral volume, V2/F
CL1A  : 229   : L/day  Amiodarone elimination clearance, CL1/F
QA    : 588   : L/day  Amiodarone intercompartmental clearance, CL2/F

V1M   : 2790  : L      Desethylamiodarone central volume
V2M   : 7830  : L      Desethylamiodarone peripheral volume
CL1M  : 254   : L/day  Desethylamiodarone elimination clearance
QM    : 151   : L/day  Desethylamiodarone intercompartmental clearance

FMET  : 1     : --     Apparent parent-to-metabolite formation fraction; fixed

$CMT 
AMI_CENT AMI_PERIPH DEA_CENT DEA_PERIPH

$OMEGA @annotated
EV2A   : 0.294  : V2; CV 58.4%
ECL1A  : 0.0929 : CL1; CV 31.2%
EQA    : 0.274  : Q/F; CV 56.2%

EV1M   : 0.0439 : desethylamiodarone V1; CV 21.2%
EV2M   : 0.779  : desethylamiodarone V2; CV 108.6%
ECL1M  : 0.0884 : desethylamiodarone CL1; CV 30.4%
EQM    : 0.180  : desethylamiodarone Q; CV 44.4%

$MAIN
double V1Ai  = V1A;
double V2Ai  = V2A  * exp(EV2A);
double CL1Ai = CL1A * exp(ECL1A);
double QAi   = QA   * exp(EQA);

double V1Mi  = V1M  * exp(EV1M);
double V2Mi  = V2M  * exp(EV2M);
double CL1Mi = CL1M * exp(ECL1M);
double QMi   = QM   * exp(EQM);

double K10A = CL1Ai / V1Ai;
double K12A = QAi   / V1Ai;
double K21A = QAi   / V2Ai;

double K10M = CL1Mi / V1Mi;
double K12M = QMi   / V1Mi;
double K21M = QMi   / V2Mi;

$ODE
dxdt_AMI_CENT   = - K10A * AMI_CENT
- K12A * AMI_CENT
+ K21A * AMI_PERIPH;

dxdt_AMI_PERIPH =   K12A * AMI_CENT
- K21A * AMI_PERIPH;

dxdt_DEA_CENT   =   FMET * K10A * AMI_CENT
- K10M * DEA_CENT
- K12M * DEA_CENT
+ K21M * DEA_PERIPH;

dxdt_DEA_PERIPH =   K12M * DEA_CENT
- K21M * DEA_PERIPH;

$TABLE
double C_AMI_mgL   = AMI_CENT / V1Ai;
double C_DEA_mgL   = DEA_CENT / V1Mi;
double C_TOTAL_mgL = C_AMI_mgL + C_DEA_mgL;

$CAPTURE C_AMI_mgL C_DEA_mgL C_TOTAL_mgL
$CAPTURE V1Ai V2Ai CL1Ai QAi V1Mi V2Mi CL1Mi QMi
$CAPTURE K10A K12A K21A K10M K12M K21M
'
mod <- mcode("amiodarone_pollak_2000_fig1_4", amiodarone_code)

dose_mg_day <- c(200, 400, 600)
n_pop <- 1000
set.seed(123)

n_days_treat <- 730     
n_days_wash  <- 365    
t_end        <- n_days_treat + n_days_wash

delta_day <- 1

idata_pop <- tibble(
  ID = 1:n_pop
)

idata_typ <- tibble(
  ID = 1
)

mod_typ <- zero_re(mod)


get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  
  df$conc[which.min(abs(df$time - t))]
}

make_long <- function(x) {
  x %>%
    pivot_longer(
      cols = c(C_AMI_mgL, C_DEA_mgL, C_TOTAL_mgL),
      names_to = "analyte",
      values_to = "conc_mgL"
    ) %>%
    mutate(
      analyte = recode(
        analyte,
        C_AMI_mgL = "Amiodarone",
        C_DEA_mgL = "Desethylamiodarone",
        C_TOTAL_mgL = "Total"
      )
    )
}

make_daily_input_ev <- function(schedule_df) {
  schedule_df %>%
    filter(n_days > 0) %>%
    transmute(
      time = start_day,
      amt  = dose_mg_day,
      cmt  = 1,
      evid = 1,
      rate = dose_mg_day,
      ii   = 1,
      addl = n_days - 1
    ) %>%
    as.ev()
}


fig1_raw <- lapply(dose_mg_day, function(d) {
  
  ev_qd <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    rate = d,
    ii   = 1,
    addl = n_days_treat - 1
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_qd) %>%
    mrgsim(
      end = t_end,
      delta = delta_day,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      regimen = paste0(d, " mg/day")
    )
}) %>%
  bind_rows() %>%
  mutate(
    regimen = factor(regimen, levels = paste0(dose_mg_day, " mg/day"))
  )

fig1 <- make_long(fig1_raw)

p1 <- fig1 %>%
  filter(analyte != "Total") %>%
  ggplot(aes(x = time, y = conc_mgL, color = regimen)) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  geom_hline(
    data = tibble(analyte = "Amiodarone"),
    aes(yintercept = 1.0),
    linetype = "dashed",
    inherit.aes = FALSE
  ) +
  geom_hline(
    data = tibble(analyte = "Amiodarone"),
    aes(yintercept = 2.5),
    linetype = "dashed",
    inherit.aes = FALSE
  ) +
  labs(
    x = "Time (days)",
    y = "Serum concentration (mg/L)",
    title = "Figure 1. Amiodarone daily dose (200/400/600 mg/d)",
    color = "Regimen"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(regimen, analyte, ID) %>%
  summarise(
    Cmax_0_730 = max(conc_mgL[time <= n_days_treat], na.rm = TRUE),
    Tmax_0_730 = time[which.max(ifelse(time <= n_days_treat, conc_mgL, -Inf))],
    C_day7     = get_conc_at(time, conc_mgL, 7),
    C_day14    = get_conc_at(time, conc_mgL, 14),
    C_day28    = get_conc_at(time, conc_mgL, 28),
    C_day90    = get_conc_at(time, conc_mgL, 90),
    C_day180   = get_conc_at(time, conc_mgL, 180),
    C_day365   = get_conc_at(time, conc_mgL, 365),
    C_day730   = get_conc_at(time, conc_mgL, 730),
    C_day1095  = get_conc_at(time, conc_mgL, 1095),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(regimen, analyte) %>%
  summarise(
    Cmax_0_730_mgL = median(Cmax_0_730, na.rm = TRUE),
    Tmax_0_730_day = median(Tmax_0_730, na.rm = TRUE),
    C_day7_mgL     = median(C_day7, na.rm = TRUE),
    C_day14_mgL    = median(C_day14, na.rm = TRUE),
    C_day28_mgL    = median(C_day28, na.rm = TRUE),
    C_day90_mgL    = median(C_day90, na.rm = TRUE),
    C_day180_mgL   = median(C_day180, na.rm = TRUE),
    C_day365_mgL   = median(C_day365, na.rm = TRUE),
    C_day730_mgL   = median(C_day730, na.rm = TRUE),
    C_day1095_mgL  = median(C_day1095, na.rm = TRUE),
    .groups = "drop"
  )

p1
fig1_summary


fig2_raw <- lapply(dose_mg_day, function(d) {
  
  ev_qd <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    rate = d,
    ii   = 1,
    addl = n_days_treat - 1
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_qd) %>%
    mrgsim(
      end = t_end,
      delta = delta_day,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      regimen = paste0(d, " mg/day")
    )
}) %>%
  bind_rows() %>%
  mutate(
    regimen = factor(regimen, levels = paste0(dose_mg_day, " mg/day"))
  )

fig2 <- make_long(fig2_raw)

fig2_sum <- fig2 %>%
  group_by(regimen, analyte, time) %>%
  summarise(
    CP_med = median(conc_mgL, na.rm = TRUE),
    CP_p05 = quantile(conc_mgL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_mgL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p2 <- fig2_sum %>%
  filter(analyte != "Total") %>%
  ggplot(aes(x = time, y = CP_med, color = regimen, fill = regimen)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  geom_hline(
    data = tibble(analyte = "Amiodarone"),
    aes(yintercept = 1.0),
    linetype = "dashed",
    inherit.aes = FALSE
  ) +
  geom_hline(
    data = tibble(analyte = "Amiodarone"),
    aes(yintercept = 2.5),
    linetype = "dashed",
    inherit.aes = FALSE
  ) +
  labs(
    x = "Time (days)",
    y = "Serum concentration (mg/L)",
    title = "Figure 2. Amiodarone daily dose (200/400/600 mg/d), population",
    color = "Regimen",
    fill = "Regimen"
  ) +
  theme_bw()

fig2_ind <- fig2 %>%
  group_by(regimen, analyte, ID) %>%
  summarise(
    Cmax_0_730 = max(conc_mgL[time <= n_days_treat], na.rm = TRUE),
    Tmax_0_730 = time[which.max(ifelse(time <= n_days_treat, conc_mgL, -Inf))],
    C_day7     = get_conc_at(time, conc_mgL, 7),
    C_day14    = get_conc_at(time, conc_mgL, 14),
    C_day28    = get_conc_at(time, conc_mgL, 28),
    C_day90    = get_conc_at(time, conc_mgL, 90),
    C_day180   = get_conc_at(time, conc_mgL, 180),
    C_day365   = get_conc_at(time, conc_mgL, 365),
    C_day730   = get_conc_at(time, conc_mgL, 730),
    C_day1095  = get_conc_at(time, conc_mgL, 1095),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(regimen, analyte) %>%
  summarise(
    Cmax_0_730_med = median(Cmax_0_730, na.rm = TRUE),
    Cmax_0_730_p05 = quantile(Cmax_0_730, 0.05, na.rm = TRUE),
    Cmax_0_730_p95 = quantile(Cmax_0_730, 0.95, na.rm = TRUE),
    
    Tmax_0_730_med = median(Tmax_0_730, na.rm = TRUE),
    Tmax_0_730_p05 = quantile(Tmax_0_730, 0.05, na.rm = TRUE),
    Tmax_0_730_p95 = quantile(Tmax_0_730, 0.95, na.rm = TRUE),
    
    C_day28_med = median(C_day28, na.rm = TRUE),
    C_day28_p05 = quantile(C_day28, 0.05, na.rm = TRUE),
    C_day28_p95 = quantile(C_day28, 0.95, na.rm = TRUE),
    
    C_day90_med = median(C_day90, na.rm = TRUE),
    C_day90_p05 = quantile(C_day90, 0.05, na.rm = TRUE),
    C_day90_p95 = quantile(C_day90, 0.95, na.rm = TRUE),
    
    C_day180_med = median(C_day180, na.rm = TRUE),
    C_day180_p05 = quantile(C_day180, 0.05, na.rm = TRUE),
    C_day180_p95 = quantile(C_day180, 0.95, na.rm = TRUE),
    
    C_day365_med = median(C_day365, na.rm = TRUE),
    C_day365_p05 = quantile(C_day365, 0.05, na.rm = TRUE),
    C_day365_p95 = quantile(C_day365, 0.95, na.rm = TRUE),
    
    C_day730_med = median(C_day730, na.rm = TRUE),
    C_day730_p05 = quantile(C_day730, 0.05, na.rm = TRUE),
    C_day730_p95 = quantile(C_day730, 0.95, na.rm = TRUE),
    
    C_day1095_med = median(C_day1095, na.rm = TRUE),
    C_day1095_p05 = quantile(C_day1095, 0.05, na.rm = TRUE),
    C_day1095_p95 = quantile(C_day1095, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p2
fig2_summary

# ============================================================
# Figure 3: Pollak proposed regimen, typical simulation
# Regimen:
# 1600 mg/day x 2 days
# 1200 mg/day x 5 days
# 1000 mg/day x 7 days
# 800 mg/day x 7 days
# 600 mg/day x 7 days
# 400 mg/day x 62 days
# 343 mg/day maintenance thereafter
# ============================================================

proposed_schedule <- tibble(
  start_day   = c(0,    2,    7,    14,   21,   28,   90),
  dose_mg_day = c(1600, 1200, 1000, 800,  600,  400,  343),
  n_days      = c(2,    5,    7,    7,    7,    62,   n_days_treat - 90)
)

ev_proposed <- make_daily_input_ev(proposed_schedule)

fig3_raw <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_proposed) %>%
  mrgsim(
    end = t_end,
    delta = delta_day,
    obsonly = TRUE
  ) %>%
  as_tibble() %>%
  mutate(
    regimen = "Pollak proposed regimen"
  )

fig3 <- make_long(fig3_raw)

p3 <- fig3 %>%
  filter(analyte != "Total") %>%
  ggplot(aes(x = time, y = conc_mgL, color = analyte)) +
  geom_line(linewidth = 1) +
  geom_hline(yintercept = 1.0, linetype = "dashed") +
  geom_hline(yintercept = 2.5, linetype = "dashed") +
  labs(
    x = "Time (days)",
    y = "Serum concentration (mg/L)",
    title = "Figure 3. Pollak proposed amiodarone regimen",
    color = "Analyte"
  ) +
  theme_bw()

fig3_ind <- fig3 %>%
  group_by(regimen, analyte, ID) %>%
  summarise(
    Cmax_0_730 = max(conc_mgL[time <= n_days_treat], na.rm = TRUE),
    Tmax_0_730 = time[which.max(ifelse(time <= n_days_treat, conc_mgL, -Inf))],
    C_day7     = get_conc_at(time, conc_mgL, 7),
    C_day14    = get_conc_at(time, conc_mgL, 14),
    C_day28    = get_conc_at(time, conc_mgL, 28),
    C_day90    = get_conc_at(time, conc_mgL, 90),
    C_day180   = get_conc_at(time, conc_mgL, 180),
    C_day365   = get_conc_at(time, conc_mgL, 365),
    C_day730   = get_conc_at(time, conc_mgL, 730),
    C_day1095  = get_conc_at(time, conc_mgL, 1095),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(regimen, analyte) %>%
  summarise(
    Cmax_0_730_mgL = median(Cmax_0_730, na.rm = TRUE),
    Tmax_0_730_day = median(Tmax_0_730, na.rm = TRUE),
    C_day7_mgL     = median(C_day7, na.rm = TRUE),
    C_day14_mgL    = median(C_day14, na.rm = TRUE),
    C_day28_mgL    = median(C_day28, na.rm = TRUE),
    C_day90_mgL    = median(C_day90, na.rm = TRUE),
    C_day180_mgL   = median(C_day180, na.rm = TRUE),
    C_day365_mgL   = median(C_day365, na.rm = TRUE),
    C_day730_mgL   = median(C_day730, na.rm = TRUE),
    C_day1095_mgL  = median(C_day1095, na.rm = TRUE),
    .groups = "drop"
  )

p3
fig3_summary


fig4_raw <- mod %>%
  idata_set(idata_pop) %>%
  ev(ev_proposed) %>%
  mrgsim(
    end = t_end,
    delta = delta_day,
    obsonly = TRUE
  ) %>%
  as_tibble() %>%
  mutate(
    regimen = "Pollak proposed regimen"
  )

fig4 <- make_long(fig4_raw)

fig4_sum <- fig4 %>%
  group_by(regimen, analyte, time) %>%
  summarise(
    CP_med = median(conc_mgL, na.rm = TRUE),
    CP_p05 = quantile(conc_mgL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_mgL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- fig4_sum %>%
  filter(analyte != "Total") %>%
  ggplot(aes(x = time, y = CP_med, color = analyte, fill = analyte)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  geom_hline(yintercept = 1.0, linetype = "dashed") +
  geom_hline(yintercept = 2.5, linetype = "dashed") +
  labs(
    x = "Time (days)",
    y = "Serum concentration (mg/L)",
    title = "Figure 4. Pollak proposed amiodarone regimen, population",
    color = "Analyte",
    fill = "Analyte"
  ) +
  theme_bw()

fig4_ind <- fig4 %>%
  group_by(regimen, analyte, ID) %>%
  summarise(
    Cmax_0_730 = max(conc_mgL[time <= n_days_treat], na.rm = TRUE),
    Tmax_0_730 = time[which.max(ifelse(time <= n_days_treat, conc_mgL, -Inf))],
    C_day7     = get_conc_at(time, conc_mgL, 7),
    C_day14    = get_conc_at(time, conc_mgL, 14),
    C_day28    = get_conc_at(time, conc_mgL, 28),
    C_day90    = get_conc_at(time, conc_mgL, 90),
    C_day180   = get_conc_at(time, conc_mgL, 180),
    C_day365   = get_conc_at(time, conc_mgL, 365),
    C_day730   = get_conc_at(time, conc_mgL, 730),
    C_day1095  = get_conc_at(time, conc_mgL, 1095),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(regimen, analyte) %>%
  summarise(
    Cmax_0_730_med = median(Cmax_0_730, na.rm = TRUE),
    Cmax_0_730_p05 = quantile(Cmax_0_730, 0.05, na.rm = TRUE),
    Cmax_0_730_p95 = quantile(Cmax_0_730, 0.95, na.rm = TRUE),
    
    Tmax_0_730_med = median(Tmax_0_730, na.rm = TRUE),
    Tmax_0_730_p05 = quantile(Tmax_0_730, 0.05, na.rm = TRUE),
    Tmax_0_730_p95 = quantile(Tmax_0_730, 0.95, na.rm = TRUE),
    
    C_day28_med = median(C_day28, na.rm = TRUE),
    C_day28_p05 = quantile(C_day28, 0.05, na.rm = TRUE),
    C_day28_p95 = quantile(C_day28, 0.95, na.rm = TRUE),
    
    C_day90_med = median(C_day90, na.rm = TRUE),
    C_day90_p05 = quantile(C_day90, 0.05, na.rm = TRUE),
    C_day90_p95 = quantile(C_day90, 0.95, na.rm = TRUE),
    
    C_day180_med = median(C_day180, na.rm = TRUE),
    C_day180_p05 = quantile(C_day180, 0.05, na.rm = TRUE),
    C_day180_p95 = quantile(C_day180, 0.95, na.rm = TRUE),
    
    C_day365_med = median(C_day365, na.rm = TRUE),
    C_day365_p05 = quantile(C_day365, 0.05, na.rm = TRUE),
    C_day365_p95 = quantile(C_day365, 0.95, na.rm = TRUE),
    
    C_day730_med = median(C_day730, na.rm = TRUE),
    C_day730_p05 = quantile(C_day730, 0.05, na.rm = TRUE),
    C_day730_p95 = quantile(C_day730, 0.95, na.rm = TRUE),
    
    C_day1095_med = median(C_day1095, na.rm = TRUE),
    C_day1095_p05 = quantile(C_day1095, 0.05, na.rm = TRUE),
    C_day1095_p95 = quantile(C_day1095, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4
fig4_summary




























dose_mg_day <- c(200, 400, 600)

n_pop <- 1000
set.seed(123)

tau_day <- 1
n_doses_md <- 10
addl_md <- n_doses_md - 1

t_end_sd <- 180
t_end_md <- 180

delta_day <- 1

last_dose_day <- (n_doses_md - 1) * tau_day

idata_pop <- tibble(
  ID = 1:n_pop
)

idata_typ <- tibble(
  ID = 1
)

mod_typ <- zero_re(mod)


get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  
  df$conc[which.min(abs(df$time - t))]
}

make_long <- function(x) {
  x %>%
    pivot_longer(
      cols = c(C_AMI_mgL, C_DEA_mgL, C_TOTAL_mgL),
      names_to = "analyte",
      values_to = "conc_mgL"
    ) %>%
    mutate(
      analyte = recode(
        analyte,
        C_AMI_mgL = "Amiodarone",
        C_DEA_mgL = "Desethylamiodarone",
        C_TOTAL_mgL = "Total"
      )
    )
}

fig1_raw <- lapply(dose_mg_day, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    rate = d
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_day,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg x1")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg_day, " mg x1"))
  )

fig1 <- make_long(fig1_raw)

p1 <- fig1 %>%
  filter(analyte != "Total") %>%
  ggplot(aes(x = time, y = conc_mgL, color = dose)) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  labs(
    x = "Time after dose (days)",
    y = "Serum concentration (mg/L)",
    title = "Figure 1. Amiodarone one-dose simulation",
    color = "Dose"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_mgL, na.rm = TRUE),
    Tmax = time[which.max(conc_mgL)],
    C_day1   = get_conc_at(time, conc_mgL, 1),
    C_day3   = get_conc_at(time, conc_mgL, 3),
    C_day7   = get_conc_at(time, conc_mgL, 7),
    C_day14  = get_conc_at(time, conc_mgL, 14),
    C_day28  = get_conc_at(time, conc_mgL, 28),
    C_day60  = get_conc_at(time, conc_mgL, 60),
    C_day90  = get_conc_at(time, conc_mgL, 90),
    C_day180 = get_conc_at(time, conc_mgL, 180),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_mgL = median(Cmax, na.rm = TRUE),
    Tmax_day = median(Tmax, na.rm = TRUE),
    C_day1_mgL   = median(C_day1, na.rm = TRUE),
    C_day3_mgL   = median(C_day3, na.rm = TRUE),
    C_day7_mgL   = median(C_day7, na.rm = TRUE),
    C_day14_mgL  = median(C_day14, na.rm = TRUE),
    C_day28_mgL  = median(C_day28, na.rm = TRUE),
    C_day60_mgL  = median(C_day60, na.rm = TRUE),
    C_day90_mgL  = median(C_day90, na.rm = TRUE),
    C_day180_mgL = median(C_day180, na.rm = TRUE),
    .groups = "drop"
  )

p1
fig1_summary


fig2_raw <- lapply(dose_mg_day, function(d) {
  
  ev_10 <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    rate = d,
    ii   = tau_day,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_10) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_day,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q24h x10")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg_day, " mg q24h x10"))
  )

fig2 <- make_long(fig2_raw)

p2 <- fig2 %>%
  filter(analyte != "Total") %>%
  ggplot(aes(x = time, y = conc_mgL, color = dose)) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  labs(
    x = "Time (days)",
    y = "Serum concentration (mg/L)",
    title = "Figure 2. Amiodarone ten-dose simulation",
    color = "Dose"
  ) +
  theme_bw()

fig2_ind <- fig2 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_mgL, na.rm = TRUE),
    Tmax = time[which.max(conc_mgL)],
    C_day1   = get_conc_at(time, conc_mgL, 1),
    C_day3   = get_conc_at(time, conc_mgL, 3),
    C_day7   = get_conc_at(time, conc_mgL, 7),
    C_day10  = get_conc_at(time, conc_mgL, 10),
    C_day14  = get_conc_at(time, conc_mgL, 14),
    C_day28  = get_conc_at(time, conc_mgL, 28),
    C_day60  = get_conc_at(time, conc_mgL, 60),
    C_day90  = get_conc_at(time, conc_mgL, 90),
    C_day180 = get_conc_at(time, conc_mgL, 180),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_mgL = median(Cmax, na.rm = TRUE),
    Tmax_day = median(Tmax, na.rm = TRUE),
    C_day1_mgL   = median(C_day1, na.rm = TRUE),
    C_day3_mgL   = median(C_day3, na.rm = TRUE),
    C_day7_mgL   = median(C_day7, na.rm = TRUE),
    C_day10_mgL  = median(C_day10, na.rm = TRUE),
    C_day14_mgL  = median(C_day14, na.rm = TRUE),
    C_day28_mgL  = median(C_day28, na.rm = TRUE),
    C_day60_mgL  = median(C_day60, na.rm = TRUE),
    C_day90_mgL  = median(C_day90, na.rm = TRUE),
    C_day180_mgL = median(C_day180, na.rm = TRUE),
    .groups = "drop"
  )

p2
fig2_summary


fig3_raw <- lapply(dose_mg_day, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    rate = d
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_day,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg x1")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg_day, " mg x1"))
  )

fig3 <- make_long(fig3_raw)

fig3_sum <- fig3 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_mgL, na.rm = TRUE),
    CP_p05 = quantile(conc_mgL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_mgL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- fig3_sum %>%
  filter(analyte != "Total") %>%
  ggplot(aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  labs(
    x = "Time after dose (days)",
    y = "Serum concentration (mg/L)",
    title = "Figure 3. Amiodarone one-dose population simulation",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig3_ind <- fig3 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_mgL, na.rm = TRUE),
    Tmax = time[which.max(conc_mgL)],
    C_day1   = get_conc_at(time, conc_mgL, 1),
    C_day3   = get_conc_at(time, conc_mgL, 3),
    C_day7   = get_conc_at(time, conc_mgL, 7),
    C_day14  = get_conc_at(time, conc_mgL, 14),
    C_day28  = get_conc_at(time, conc_mgL, 28),
    C_day60  = get_conc_at(time, conc_mgL, 60),
    C_day90  = get_conc_at(time, conc_mgL, 90),
    C_day180 = get_conc_at(time, conc_mgL, 180),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C_day7_med = median(C_day7, na.rm = TRUE),
    C_day7_p05 = quantile(C_day7, 0.05, na.rm = TRUE),
    C_day7_p95 = quantile(C_day7, 0.95, na.rm = TRUE),
    
    C_day28_med = median(C_day28, na.rm = TRUE),
    C_day28_p05 = quantile(C_day28, 0.05, na.rm = TRUE),
    C_day28_p95 = quantile(C_day28, 0.95, na.rm = TRUE),
    
    C_day90_med = median(C_day90, na.rm = TRUE),
    C_day90_p05 = quantile(C_day90, 0.05, na.rm = TRUE),
    C_day90_p95 = quantile(C_day90, 0.95, na.rm = TRUE),
    
    C_day180_med = median(C_day180, na.rm = TRUE),
    C_day180_p05 = quantile(C_day180, 0.05, na.rm = TRUE),
    C_day180_p95 = quantile(C_day180, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3
fig3_summary


fig4_raw <- lapply(dose_mg_day, function(d) {
  
  ev_10 <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    rate = d,
    ii   = tau_day,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_10) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_day,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q24h x10")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg_day, " mg q24h x10"))
  )

fig4 <- make_long(fig4_raw)

fig4_sum <- fig4 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_mgL, na.rm = TRUE),
    CP_p05 = quantile(conc_mgL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_mgL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- fig4_sum %>%
  filter(analyte != "Total") %>%
  ggplot(aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  facet_wrap(~ analyte, scales = "free_y") +
  labs(
    x = "Time (days)",
    y = "Serum concentration (mg/L)",
    title = "Figure 4. Amiodarone ten-dose population",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig4_ind <- fig4 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_mgL, na.rm = TRUE),
    Tmax = time[which.max(conc_mgL)],
    C_day1   = get_conc_at(time, conc_mgL, 1),
    C_day3   = get_conc_at(time, conc_mgL, 3),
    C_day7   = get_conc_at(time, conc_mgL, 7),
    C_day10  = get_conc_at(time, conc_mgL, 10),
    C_day14  = get_conc_at(time, conc_mgL, 14),
    C_day28  = get_conc_at(time, conc_mgL, 28),
    C_day60  = get_conc_at(time, conc_mgL, 60),
    C_day90  = get_conc_at(time, conc_mgL, 90),
    C_day180 = get_conc_at(time, conc_mgL, 180),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C_day7_med = median(C_day7, na.rm = TRUE),
    C_day7_p05 = quantile(C_day7, 0.05, na.rm = TRUE),
    C_day7_p95 = quantile(C_day7, 0.95, na.rm = TRUE),
    
    C_day10_med = median(C_day10, na.rm = TRUE),
    C_day10_p05 = quantile(C_day10, 0.05, na.rm = TRUE),
    C_day10_p95 = quantile(C_day10, 0.95, na.rm = TRUE),
    
    C_day28_med = median(C_day28, na.rm = TRUE),
    C_day28_p05 = quantile(C_day28, 0.05, na.rm = TRUE),
    C_day28_p95 = quantile(C_day28, 0.95, na.rm = TRUE),
    
    C_day90_med = median(C_day90, na.rm = TRUE),
    C_day90_p05 = quantile(C_day90, 0.05, na.rm = TRUE),
    C_day90_p95 = quantile(C_day90, 0.95, na.rm = TRUE),
    
    C_day180_med = median(C_day180, na.rm = TRUE),
    C_day180_p05 = quantile(C_day180, 0.05, na.rm = TRUE),
    C_day180_p95 = quantile(C_day180, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4
fig4_summary