library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

furosemide_code <- '
$PROB
Furosemide oral PopPK model
- Source: Kodati D, Yellu N. Population pharmacokinetic modeling of furosemide 
  in patients with hypertension and fluid overload conditions. Pharmacol Rep. 2017.
- Structure: two-compartment linear model with first-order absorption and absorption lag time.
- Parameters are apparent oral parameters: CL/F, V/F, V2/F, CL2/F.

$PARAM @annotated
KA       : 0.76616 : 1/h     First-order absorption rate constant
V1       : 4.419   : L       Apparent central volume, V/F
V2       : 7.9634  : L       Apparent peripheral volume, V2/F
CL       : 15.054  : L/h     Apparent clearance, CL/F
Q        : 0.4861  : L/h     Apparent intercompartmental clearance, CL2/F
TLAG     : 0.4297  : h       Absorption lag time

DCLDCRCL : -0.3053 : --      CRCL coefficient on CL/F
DCLDAGE  : 0.2534  : --      Age coefficient on CL/F

CRCL     : 90      : mL/min  Individual creatinine clearance
AGE      : 60      : years   Individual age
REF_CRCL : 90      : mL/min  Reference CRCL for centering
REF_AGE  : 60      : years   Reference age for centering
COV_ON   : 0       : --      0 = no covariate effect; 1 = apply CRCL and AGE effects

$CMT GUT CENT PERIPH

$OMEGA @annotated
EKA   : 0.01691 : IIV on KA
EV1   : 0.0548  : IIV on V1/F
EV2   : 0.5980  : IIV on V2/F
ECL   : 0.0606  : IIV on CL/F
EQ    : 1.0162  : IIV on Q/F
ETLAG : 0.0119  : IIV on TLAG

$MAIN
double crcl_eff = 1.0;
double age_eff  = 1.0;

if(COV_ON > 0.5) {
  crcl_eff = pow(CRCL / REF_CRCL, DCLDCRCL);
  age_eff  = pow(AGE  / REF_AGE,  DCLDAGE);
}

double KAi    = KA   * exp(EKA);
double V1i    = V1   * exp(EV1);
double V2i    = V2   * exp(EV2);
double CLi    = CL   * crcl_eff * age_eff * exp(ECL);
double Qi     = Q    * exp(EQ);
double TLAGi  = TLAG * exp(ETLAG);

ALAG_GUT = TLAGi;

$ODE
dxdt_GUT    = -KAi * GUT;

dxdt_CENT   =  KAi * GUT
             - (CLi / V1i) * CENT
             - (Qi  / V1i) * CENT
             + (Qi  / V2i) * PERIPH;

dxdt_PERIPH =  (Qi / V1i) * CENT
             - (Qi / V2i) * PERIPH;

$TABLE
double CP_mgL  = CENT / V1i;
double CP_ngmL = CP_mgL * 1000.0;

$CAPTURE CP_mgL CP_ngmL KAi V1i V2i CLi Qi TLAGi
'

mod <- mcode("furosemide_oral_kodati_2017", furosemide_code)