library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

prazosin_code <- '
$PROB
Prazosin oral PK model in hypertensive patients
- Ref: Grahnen A, Seideman P, Lindstrom B, Haglund K, von Bahr C.  Prazosin kinetics in hypertension. Clin Pharmacol Ther. 1981;30(4):439-446.

$PARAM @annotated
KA      : 2.5   : 1/h       First-order absorption rate constant
F1      : 0.631 : --        Oral bioavailability
WT      : 82.8  : kg        Body weight

V1KG    : 0.15  : L/kg      Central volume 
CLKG    : 0.144 : L/kg/h    Total plasma clearance
K12     : 2.80  : 1/h       Central-to-peripheral 
K21     : 1.30  : 1/h       Peripheral-to-central 

$CMT 
GUT CENT PERIPH

$OMEGA @annotated
EKA     : 0.223 : IIV on KA; 
EF1     : 0.042 : IIV on oral bioavailability; 
EV1KG   : 0.069 : IIV on V1/kg; 
ECLKG   : 0.114 : IIV on CL/kg;
EK12    : 0.334 : IIV on K12; 
EK21    : 0.016 : IIV on K21; 

$MAIN
double KAi   = KA    * exp(EKA);

double F1i   = F1    * exp(EF1);
if(F1i > 1.0)  F1i = 1.0;
if(F1i < 0.05) F1i = 0.05;

double V1KGi  = V1KG * exp(EV1KG);
double CLKGi  = CLKG * exp(ECLKG);
double K12i   = K12  * exp(EK12);
double K21i   = K21  * exp(EK21);

double V1i    = V1KGi * WT;
double CLi    = CLKGi * WT;
double K10i   = CLi / V1i;

$ODE
dxdt_GUT    = -KAi * GUT;

dxdt_CENT   =  F1i * KAi * GUT
              -K10i * CENT
              -K12i * CENT
              +K21i * PERIPH;

dxdt_PERIPH =  K12i * CENT
              -K21i * PERIPH;

$TABLE
double CP_mgL  = CENT / V1i;
double CP_ngmL = CP_mgL * 1000.0;

$CAPTURE CP_mgL CP_ngmL
'
mod <- mcode("prazosin_grahnen_1981", prazosin_code)

dose_mg <- c(0.5, 1, 2, 5)

n_pop <- 1000
set.seed(123)

tau_h    <- 8
n_doses  <- 15        
addl_md  <- n_doses - 1

t_end_sd <- 24
t_end_md <- 120

delta_sd <- 0.1
delta_md <- 0.1

last_dose_h <- (n_doses - 1) * tau_h
final_interval_end_h <- last_dose_h + tau_h

idata_pop <- tibble(
  ID = 1:n_pop,
  WT = pmin(pmax(rnorm(n_pop, mean = 82.8, sd = 15.0), 50), 120)
)

idata_typ <- tibble(
  ID = 1,
  WT = 82.8
)

mod_typ <- zero_re(mod)



get_conc_at <- function(time, conc, t) {
  conc[which.min(abs(time - t))]
}


make_long_primary <- function(x) {
  x %>%
    pivot_longer(
      cols = c(CP_ngmL),
      names_to = "analyte",
      values_to = "conc_ngmL"
    ) %>%
    mutate(
      analyte = recode(
        analyte,
        CP_ngmL = "Prazosin"
      )
    )
}


fig1_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig1 <- make_long_primary(fig1_raw)

p1 <- ggplot(fig1, aes(x = time, y = conc_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after dose (h)",
    y = "Plasma concentration (ng/mL)",
    title = "Figure 1. Prazosin (q8h) single-dose",
    color = "Dose"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_ngmL, na.rm = TRUE),
    Tmax = time[which.max(conc_ngmL)],
    C0_5 = get_conc_at(time, conc_ngmL, 0.5),
    C1   = get_conc_at(time, conc_ngmL, 1),
    C2   = get_conc_at(time, conc_ngmL, 2),
    C4   = get_conc_at(time, conc_ngmL, 4),
    C6   = get_conc_at(time, conc_ngmL, 6),
    C8   = get_conc_at(time, conc_ngmL, 8),
    C12  = get_conc_at(time, conc_ngmL, 12),
    C24  = get_conc_at(time, conc_ngmL, 24),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_ng_mL = median(Cmax, na.rm = TRUE),
    Tmax_h     = median(Tmax, na.rm = TRUE),
    C0_5_ng_mL = median(C0_5, na.rm = TRUE),
    C1_ng_mL   = median(C1, na.rm = TRUE),
    C2_ng_mL   = median(C2, na.rm = TRUE),
    C4_ng_mL   = median(C4, na.rm = TRUE),
    C6_ng_mL   = median(C6, na.rm = TRUE),
    C8_ng_mL   = median(C8, na.rm = TRUE),
    C12_ng_mL  = median(C12, na.rm = TRUE),
    C24_ng_mL  = median(C24, na.rm = TRUE),
    .groups = "drop"
  )

p1
fig1_summary



fig2_raw <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q8h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q8h x", n_doses))
  )

fig2 <- make_long_primary(fig2_raw)

p2 <- ggplot(fig2, aes(x = time, y = conc_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Plasma concentration (ng/mL)",
    title = "Figure 2. Prazosin q8h multiple-dose",
    color = "Dose"
  ) +
  theme_bw()

fig2_ind <- fig2 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_ngmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ngmL, -Inf))
    ] - last_dose_h,
    C8_after_last = get_conc_at(time, conc_ngmL, final_interval_end_h),
    C8_day1       = get_conc_at(time, conc_ngmL, 8),
    C24           = get_conc_at(time, conc_ngmL, 24),
    C48           = get_conc_at(time, conc_ngmL, 48),
    C160          = get_conc_at(time, conc_ngmL, 160),
    C168          = get_conc_at(time, conc_ngmL, 168),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_ng_mL = median(Cmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_h     = median(Tmax_final_interval, na.rm = TRUE),
    C8_after_last_ng_mL       = median(C8_after_last, na.rm = TRUE),
    C8_day1_ng_mL             = median(C8_day1, na.rm = TRUE),
    C24_ng_mL                 = median(C24, na.rm = TRUE),
    C48_ng_mL                 = median(C48, na.rm = TRUE),
    C160_ng_mL                = median(C160, na.rm = TRUE),
    C168_ng_mL                = median(C168, na.rm = TRUE),
    .groups = "drop"
  )

p2
fig2_summary





fig3_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg")
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg"))
  )

fig3 <- make_long_primary(fig3_raw)

fig3_sum <- fig3 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_ngmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after dose (h)",
    y = "Plasma concentration (ng/mL)",
    title = "Figure 3. Prazosin (q8h) single-dose, population",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig3_ind <- fig3 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_ngmL, na.rm = TRUE),
    Tmax = time[which.max(conc_ngmL)],
    C0_5 = get_conc_at(time, conc_ngmL, 0.5),
    C1   = get_conc_at(time, conc_ngmL, 1),
    C2   = get_conc_at(time, conc_ngmL, 2),
    C4   = get_conc_at(time, conc_ngmL, 4),
    C6   = get_conc_at(time, conc_ngmL, 6),
    C8   = get_conc_at(time, conc_ngmL, 8),
    C12  = get_conc_at(time, conc_ngmL, 12),
    C24  = get_conc_at(time, conc_ngmL, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C1_med = median(C1, na.rm = TRUE),
    C1_p05 = quantile(C1, 0.05, na.rm = TRUE),
    C1_p95 = quantile(C1, 0.95, na.rm = TRUE),
    
    C2_med = median(C2, na.rm = TRUE),
    C2_p05 = quantile(C2, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2, 0.95, na.rm = TRUE),
    
    C4_med = median(C4, na.rm = TRUE),
    C4_p05 = quantile(C4, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3
fig3_summary





fig4_raw <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(
      dose = paste0(d, " mg q8h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(
    dose = factor(dose, levels = paste0(dose_mg, " mg q8h x", n_doses))
  )

fig4 <- make_long_primary(fig4_raw)

fig4_sum <- fig4 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_ngmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Plasma concentration (ng/mL)",
    title = "Figure 4. Prazosin (q8h) multiple-dose, population ",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig4_ind <- fig4 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_ngmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ngmL, -Inf))
    ] - last_dose_h,
    C8_after_last = get_conc_at(time, conc_ngmL, final_interval_end_h),
    C8_day1       = get_conc_at(time, conc_ngmL, 8),
    C24           = get_conc_at(time, conc_ngmL, 24),
    C48           = get_conc_at(time, conc_ngmL, 48),
    C160          = get_conc_at(time, conc_ngmL, 160),
    C168          = get_conc_at(time, conc_ngmL, 168),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_final_interval_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_final_interval_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_final_interval_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_final_interval_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C8_after_last_med = median(C8_after_last, na.rm = TRUE),
    C8_after_last_p05 = quantile(C8_after_last, 0.05, na.rm = TRUE),
    C8_after_last_p95 = quantile(C8_after_last, 0.95, na.rm = TRUE),
    
    C8_day1_med = median(C8_day1, na.rm = TRUE),
    C8_day1_p05 = quantile(C8_day1, 0.05, na.rm = TRUE),
    C8_day1_p95 = quantile(C8_day1, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    C48_med = median(C48, na.rm = TRUE),
    C48_p05 = quantile(C48, 0.05, na.rm = TRUE),
    C48_p95 = quantile(C48, 0.95, na.rm = TRUE),
    
    C160_med = median(C160, na.rm = TRUE),
    C160_p05 = quantile(C160, 0.05, na.rm = TRUE),
    C160_p95 = quantile(C160, 0.95, na.rm = TRUE),
    
    C168_med = median(C168, na.rm = TRUE),
    C168_p05 = quantile(C168, 0.05, na.rm = TRUE),
    C168_p95 = quantile(C168, 0.05, na.rm = TRUE),
    .groups = "drop"
  )

p4
fig4_summary

