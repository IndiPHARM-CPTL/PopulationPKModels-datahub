library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

hydrocortisone_code <- '
$PROB
Adult intravenous hydrocortisone population PK model
- Ref: Hamitouche N, Comets E, Ribot M, Alvarez JC,
  Bellissant E, Laviolle B. Population pharmacokinetic-
  pharmacodynamic model of oral fludrocortisone and
  intravenous hydrocortisone in healthy volunteers.
  AAPS J. 2017;19(3):727-735.
  doi:10.1208/s12248-016-0041-9


$PARAM @annotated
CL       : 30.0   : L/h    Hydrocortisone clearance
V        : 85.5   : L      Volume of distribution


$OMEGA @labels ETA_CL ETA_V ETA_CL_OCC ETA_V_OCC
0.0441
0.0225
0.0441
0.0484

$SIGMA @labels EPS_PROP EPS_ADD
0.04
20

$CMT
CENT

$GLOBAL
double CLi, Vi;

$MAIN
CLi = CL * exp(ETA(1) + ETA(3));
Vi  = V  * exp(ETA(2) + ETA(4));

$ODE
dxdt_CENT = -(CLi / Vi) * CENT;

$TABLE
double CP = (CENT / Vi) * 1000.0;
double DV = CP * (1.0 + EPS(1)) + EPS(2);

$CAPTURE CP
'

mod_hc <- mcode("hydrocortisone_popPK", hydrocortisone_code)


dose_mg <- 50
dose_label <- "50 mg IV"

tau_h <- 6
n_doses <- 4
addl_md <- n_doses - 1

t_end_sd <- 24
delta_sd <- 0.05

# Doses at 0, 6, 12, and 18 hours
t_end_md <- 30
delta_md <- 0.05

mod_typ <- zero_re(mod_hc)
idata_typ <- tibble(ID = 1)

N <- 1000
idata_pop <- tibble(ID = 1:N)

at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}


ev_sd <- ev(amt = dose_mg, cmt = 1, time = 0)

fig1_out <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_sd) %>%
  mrgsim(end = t_end_sd, delta = delta_sd) %>%
  as_tibble() %>%
  mutate(group = dose_label)

p1 <- ggplot(fig1_out, aes(time, CP, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Hydrocortisone concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Hydrocortisone single IV bolus"
  )

fig1_summary <- fig1_out %>%
  group_by(group) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C2h = at_time(time, CP, 2),
    C4h = at_time(time, CP, 4),
    C6h = at_time(time, CP, 6),
    C8h = at_time(time, CP, 8),
    C12h = at_time(time, CP, 12),
    C24h = at_time(time, CP, 24),
    .groups = "drop"
  )


ev_md <- ev(amt = dose_mg, ii = tau_h, addl = addl_md, cmt = 1)

fig2_out <- mod_typ %>%
  idata_set(idata_typ) %>%
  ev(ev_md) %>%
  mrgsim(end = t_end_md, delta = delta_md) %>%
  as_tibble() %>%
  mutate(group = "50 mg IV q6h x4")

p2 <- ggplot(fig2_out, aes(time, CP, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Hydrocortisone concentration (ng/mL)",
    color = "Regimen",
    title = "Figure 2. Hydrocortisone 50 mg IV q6h for four doses"
  )

fig2_summary <- fig2_out %>%
  group_by(group) %>%
  summarise(
    Cmax_last = max(CP[time >= 18 & time <= 24]),
    Tmax_last_h = time[time >= 18 & time <= 24][which.max(CP[time >= 18 & time <= 24])] - 18,
    Ctrough_24h = at_time(time, CP, 24),
    C6h = at_time(time, CP, 6),
    C12h = at_time(time, CP, 12),
    C18h = at_time(time, CP, 18),
    C24h = at_time(time, CP, 24),
    C30h = at_time(time, CP, 30),
    .groups = "drop"
  )


set.seed(123)

fig3_raw <- mod_hc %>%
  idata_set(idata_pop) %>%
  ev(ev_sd) %>%
  mrgsim(end = t_end_sd, delta = delta_sd) %>%
  as_tibble() %>%
  mutate(group = dose_label)

fig3_sum <- fig3_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP),
    C_p05 = quantile(CP, 0.05),
    C_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95),
              alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Hydrocortisone concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Hydrocortisone single IV bolus, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C2h = at_time(time, CP, 2),
    C4h = at_time(time, CP, 4),
    C6h = at_time(time, CP, 6),
    C8h = at_time(time, CP, 8),
    C12h = at_time(time, CP, 12),
    C24h = at_time(time, CP, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med = median(Tmax_h),
    Tmax_p05 = quantile(Tmax_h, 0.05),
    Tmax_p95 = quantile(Tmax_h, 0.95),
    
    C2h_med = median(C2h),
    C2h_p05 = quantile(C2h, 0.05),
    C2h_p95 = quantile(C2h, 0.95),
    
    C4h_med = median(C4h),
    C4h_p05 = quantile(C4h, 0.05),
    C4h_p95 = quantile(C4h, 0.95),
    
    C6h_med = median(C6h),
    C6h_p05 = quantile(C6h, 0.05),
    C6h_p95 = quantile(C6h, 0.95),
    
    C8h_med = median(C8h),
    C8h_p05 = quantile(C8h, 0.05),
    C8h_p95 = quantile(C8h, 0.95),
    
    C12h_med = median(C12h),
    C12h_p05 = quantile(C12h, 0.05),
    C12h_p95 = quantile(C12h, 0.95),
    
    C24h_med = median(C24h),
    C24h_p05 = quantile(C24h, 0.05),
    C24h_p95 = quantile(C24h, 0.95),
    
    .groups = "drop"
  )



set.seed(123)

fig4_raw <- mod_hc %>%
  idata_set(idata_pop) %>%
  ev(ev_md) %>%
  mrgsim(end = t_end_md, delta = delta_md) %>%
  as_tibble() %>%
  mutate(group = "50 mg IV q6h x4")

fig4_sum <- fig4_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP),
    C_p05 = quantile(CP, 0.05),
    C_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95),
              alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Hydrocortisone concentration (ng/mL)",
    color = "Regimen",
    fill = "Regimen",
    title = "Figure 4. Hydrocortisone 50 mg IV q6h x4, population"
  )

fig4_ind <- fig4_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax_dose1 = max(CP[time >= 0 & time < 6]),
    Ctrough_pre2 = at_time(time, CP, 5.95),
    
    Cmax_dose2 = max(CP[time >= 6 & time < 12]),
    Ctrough_pre3 = at_time(time, CP, 11.95),
    
    Cmax_dose3 = max(CP[time >= 12 & time < 18]),
    Ctrough_pre4 = at_time(time, CP, 17.95),
    
    Cmax_dose4 = max(CP[time >= 18 & time <= 24]),
    Tmax_dose4_h = time[time >= 18 & time <= 24][which.max(CP[time >= 18 & time <= 24])] - 18,
    
    C6h_after_dose4 = at_time(time, CP, 24),
    C12h_after_dose4 = at_time(time, CP, 30),
    .groups = "drop"
  )


fig4_summary <- fig4_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_dose1_med = median(Cmax_dose1),
    Cmax_dose1_p05 = quantile(Cmax_dose1, 0.05),
    Cmax_dose1_p95 = quantile(Cmax_dose1, 0.95),
    
    Ctrough_pre2_med = median(Ctrough_pre2),
    Ctrough_pre2_p05 = quantile(Ctrough_pre2, 0.05),
    Ctrough_pre2_p95 = quantile(Ctrough_pre2, 0.95),
    
    Cmax_dose2_med = median(Cmax_dose2),
    Cmax_dose2_p05 = quantile(Cmax_dose2, 0.05),
    Cmax_dose2_p95 = quantile(Cmax_dose2, 0.95),
    
    Ctrough_pre3_med = median(Ctrough_pre3),
    Ctrough_pre3_p05 = quantile(Ctrough_pre3, 0.05),
    Ctrough_pre3_p95 = quantile(Ctrough_pre3, 0.95),
    
    Cmax_dose3_med = median(Cmax_dose3),
    Cmax_dose3_p05 = quantile(Cmax_dose3, 0.05),
    Cmax_dose3_p95 = quantile(Cmax_dose3, 0.95),
    
    Ctrough_pre4_med = median(Ctrough_pre4),
    Ctrough_pre4_p05 = quantile(Ctrough_pre4, 0.05),
    Ctrough_pre4_p95 = quantile(Ctrough_pre4, 0.95),
    
    Cmax_dose4_med = median(Cmax_dose4),
    Cmax_dose4_p05 = quantile(Cmax_dose4, 0.05),
    Cmax_dose4_p95 = quantile(Cmax_dose4, 0.95),
    
    Tmax_dose4_med = median(Tmax_dose4_h),
    Tmax_dose4_p05 = quantile(Tmax_dose4_h, 0.05),
    Tmax_dose4_p95 = quantile(Tmax_dose4_h, 0.95),
    
    C6h_after_dose4_med = median(C6h_after_dose4),
    C6h_after_dose4_p05 = quantile(C6h_after_dose4, 0.05),
    C6h_after_dose4_p95 = quantile(C6h_after_dose4, 0.95),
    
    C12h_after_dose4_med = median(C12h_after_dose4),
    C12h_after_dose4_p05 = quantile(C12h_after_dose4, 0.05),
    C12h_after_dose4_p95 = quantile(C12h_after_dose4, 0.95),
    .groups = "drop"
  )



p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary