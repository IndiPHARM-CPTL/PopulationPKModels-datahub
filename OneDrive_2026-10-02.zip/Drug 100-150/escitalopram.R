library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

escitalopram_code <- '
$PROB
Escitalopram population PK model
- Ref: Areberg J, Christophersen JS, Poulsen MN, Larsen F, Molz K-H.
  The Pharmacokinetics of Escitalopram in Patients With Hepatic Impairment.
  AAPS J. 2006;8(1):E14-E19.
  doi:10.1208/aapsj080102


$PARAM @annotated
KA          : 3.6    : 1/h    First-order absorption rate constant (fixed)
CLF         : 19     : L/h    Apparent clearance (typical)
VF          : 800    : L      Apparent central volume (typical)
V2F         : 470    : L      Apparent peripheral volume
QF          : 98     : L/h    Apparent intercompartmental clearance
TLAG        : 0.93   : h      Absorption lag time

WT          : 79     : kg     Body weight
CYP2C19     : 0.769  : --     Urinary S/R-mephenytoin ratio

WT_REF      : 79     : kg     Weight centring value
CYP_REF     : 0.769  : --     S/R ratio centring value

TH_VF_WT    : 12     : L/kg   Linear weight effect on V/F
TH_CL_CYP   : -17    : L/h    Linear S/R-ratio effect on CL/F

MW          : 324.39 : g/mol  Escitalopram free-base molecular weight

PROP_SD     : 0.096  : --     Proportional residual SD

$CMT @annotated
DEPOT  : Oral dosing/absorption compartment (mg)
CENT   : Central compartment (mg)
PERIPH : Peripheral compartment (mg)

$OMEGA @labels ETA_VF ETA_CL ETA_KA
0.02849 0.10940 1.16025

$SIGMA
1

$GLOBAL
double KAi;
double CLFi;
double VFi;
double V2Fi;
double QFi;
double TLAGi;

$MAIN
KAi = KA * exp(ETA_KA);

CLFi = (CLF + TH_CL_CYP * (CYP2C19 - CYP_REF)) *
       exp(ETA_CL);

VFi  = (VF + TH_VF_WT * (WT - WT_REF)) *
       exp(ETA_VF);

V2Fi = V2F;
QFi  = QF;

TLAGi = TLAG;
ALAG_DEPOT = TLAGi;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT =
    KAi * DEPOT
  - (CLFi / VFi) * CENT
  - (QFi  / VFi) * CENT
  + (QFi / V2Fi) * PERIPH;

dxdt_PERIPH =
    (QFi / VFi)  * CENT
  - (QFi / V2Fi) * PERIPH;

$TABLE
double CP_ngmL  = 1000.0 * CENT / VFi;
double CP_nmolL = CP_ngmL * 1000.0 / MW;

double DV_PK =
  CP_ngmL * (1.0 + PROP_SD * EPS(1));

$CAPTURE
CP_ngmL CP_nmolL DV_PK
KAi CLFi VFi V2Fi QFi TLAGi
WT CYP2C19
'
mod_escit <- mcode("escitalopram_pk", escitalopram_code)


N <- 1000

doses_mg <- c(5, 10, 20)
dose_levels <- c("5 mg", "10 mg", "20 mg")

tau <- 24
n_dose <- 14

t_end_sd <- 168                # matches the Areberg 2006 sampling window
last_dose <- tau * (n_dose - 1)
t_end_md <- last_dose + tau

delta_sd <- 0.1
delta_md <- 0.5


at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

auc_trap <- function(time, conc) {
  sum(diff(time) * (head(conc, -1) + tail(conc, -1)) / 2)
}




# Reference subject at the model centring values (pooled cohort means)
idata_typ <- tibble(
  ID = 1,
  WT = 79,
  CYP2C19 = 0.769
)

idata_pop <- tibble(
  ID = 1:N,
  WT = 79,
  CYP2C19 = 0.769
)

mod_typ <- zero_re(mod_escit)





# ---------------------------------------------------------------------------
# Figure 1. Typical subject, single dose
# ---------------------------------------------------------------------------

fig1_list <- lapply(doses_mg, function(d) {
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_typ, end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = paste0(d, " mg"))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


p1_escit <- ggplot(fig1_out, aes(time, CP_ngmL, color = Dose)) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, t_end_sd, 24), limits = c(0, t_end_sd)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Escitalopram concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Escitalopram single dose"
  )

p1_escit


fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = time[which.max(CP_ngmL)],
    C24 = at_time(time, CP_ngmL, tau),
    AUC0_24 = auc_trap(time[time <= tau], CP_ngmL[time <= tau]),
    AUC0_168 = auc_trap(time, CP_ngmL),
    .groups = "drop"
  )

fig1_summary





# ---------------------------------------------------------------------------
# Figure 2. Typical subject, once daily for 14 days
# ---------------------------------------------------------------------------

fig2_list <- lapply(doses_mg, function(d) {
  
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau, addl = n_dose - 1)
  
  mod_typ %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_typ, end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


p2_escit <- ggplot(fig2_out, aes(time_day, CP_ngmL, color = Dose)) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, n_dose, 1), limits = c(0, n_dose)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Escitalopram concentration (ng/mL)",
    color = "Dose",
    title = paste0("Figure 2. Escitalopram once daily for ", n_dose, " days")
  )

p2_escit


fig2_summary <- fig2_out %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_ss = max(CP_ngmL),
    Tmax_ss_h = t_rel[which.max(CP_ngmL)],
    Ctrough_ss = at_time(t_rel, CP_ngmL, tau),
    AUCtau_ss = auc_trap(t_rel, CP_ngmL),
    .groups = "drop"
  )

fig2_summary


# Structural check: at steady state AUCtau = Dose / (CL/F)
cl_typ <- fig2_out$CLFi[1]

fig2_check <- fig2_summary %>%
  mutate(
    dose = as.numeric(sub(" mg", "", as.character(Dose))),
    AUC_expected = 1000 * dose / cl_typ,        # ng*h/mL
    pct_diff = 100 * (AUCtau_ss / AUC_expected - 1)
  ) %>%
  select(Dose, AUCtau_ss, AUC_expected, pct_diff)

fig2_check





# ---------------------------------------------------------------------------
# Figure 3. Population, single dose
# ---------------------------------------------------------------------------

fig3_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_escit %>%
    ev(ev_sd) %>%
    mrgsim(idata = idata_pop, end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(Dose = paste0(d, " mg"))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    CP_med = median(CP_ngmL),
    CP_p05 = quantile(CP_ngmL, 0.05),
    CP_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )


p3_escit <- ggplot(fig3_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, t_end_sd, 24), limits = c(0, t_end_sd)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Escitalopram concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Escitalopram single dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )

p3_escit


fig3_ind <- fig3_raw %>%
  arrange(Dose, ID, time) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = time[which.max(CP_ngmL)],
    C24 = at_time(time, CP_ngmL, tau),
    AUC0_24 = auc_trap(time[time <= tau], CP_ngmL[time <= tau]),
    AUC0_168 = auc_trap(time, CP_ngmL),
    .groups = "drop"
  )


fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    C24_med = median(C24),
    C24_p05 = quantile(C24, 0.05),
    C24_p95 = quantile(C24, 0.95),
    
    AUC0_24_med = median(AUC0_24),
    AUC0_24_p05 = quantile(AUC0_24, 0.05),
    AUC0_24_p95 = quantile(AUC0_24, 0.95),
    
    AUC0_168_med = median(AUC0_168),
    AUC0_168_p05 = quantile(AUC0_168, 0.05),
    AUC0_168_p95 = quantile(AUC0_168, 0.95),
    
    .groups = "drop"
  )

fig3_summary




# ---------------------------------------------------------------------------
# Figure 4. Population, once daily for 14 days
# ---------------------------------------------------------------------------

fig4_list <- lapply(doses_mg, function(d) {
  
  set.seed(123)
  
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau, addl = n_dose - 1)
  
  mod_escit %>%
    ev(ev_md) %>%
    mrgsim(idata = idata_pop, end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    mutate(
      Dose = paste0(d, " mg"),
      time_day = time / 24
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels))


fig4_sum <- fig4_raw %>%
  group_by(Dose, time, time_day) %>%
  summarise(
    CP_med = median(CP_ngmL),
    CP_p05 = quantile(CP_ngmL, 0.05),
    CP_p95 = quantile(CP_ngmL, 0.95),
    .groups = "drop"
  )


p4_escit <- ggplot(fig4_sum, aes(time_day, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1) +
  scale_x_continuous(breaks = seq(0, n_dose, 1), limits = c(0, n_dose)) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Escitalopram concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = paste0("Figure 4. Escitalopram once daily for ", n_dose, " days, population"),
    subtitle = "Median with 5th–95th percentiles"
  )

p4_escit


fig4_ind <- fig4_raw %>%
  filter(time >= last_dose, time <= last_dose + tau) %>%
  mutate(t_rel = time - last_dose) %>%
  arrange(Dose, ID, t_rel) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP_ngmL),
    Tmax_h = t_rel[which.max(CP_ngmL)],
    Ctrough = at_time(t_rel, CP_ngmL, tau),
    AUCtau = auc_trap(t_rel, CP_ngmL),
    .groups = "drop"
  )


fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med_h = median(Tmax_h),
    Tmax_p05_h = quantile(Tmax_h, 0.05),
    Tmax_p95_h = quantile(Tmax_h, 0.95),
    
    Ctrough_med = median(Ctrough),
    Ctrough_p05 = quantile(Ctrough, 0.05),
    Ctrough_p95 = quantile(Ctrough, 0.95),
    
    AUCtau_med = median(AUCtau),
    AUCtau_p05 = quantile(AUCtau, 0.05),
    AUCtau_p95 = quantile(AUCtau, 0.95),
    
    .groups = "drop"
  )

fig4_summary