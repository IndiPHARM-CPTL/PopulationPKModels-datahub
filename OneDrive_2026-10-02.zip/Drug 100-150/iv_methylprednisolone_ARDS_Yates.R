library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

methylprednisolone_ards_code <- '
$PROB
Methylprednisolone IV population PK model in ARDS

- Ref: Yates CR, Vysokanov A, Mukherjee A, Ludden TM,
  Tolley E, Meduri GU, Dalton JT.
  Time-Variant Increase in Methylprednisolone Clearance
  in Patients with Acute Respiratory Distress Syndrome:
  A Population Pharmacokinetic Study.
  J Clin Pharmacol. 2001;41:415-424.


$PARAM @annotated
CLMAX : 25.1 : L/h   Maximum methylprednisolone clearance
T50   : 41.2 : h     Time to 50% of maximal clearance increase
CL0   : 13.2 : L/h   Initial methylprednisolone clearance
V     : 137  : L     Volume of distribution
GAM   : 3.81 : --    Hill coefficient for time-dependent clearance

$CMT 
CENT

$OMEGA @annotated
ECLMAX : 0.353 : CLMAX
ET50   : 0.127 : T50
ECL0   : 0.392 : CL0
EV     : 0.159 : V

$SIGMA
0.0049

$MAIN
double CLMAXi = CLMAX * exp(ECLMAX);
double T50i   = T50   * exp(ET50);
double CL0i   = CL0   * exp(ECL0);
double Vi     = V     * exp(EV);

$ODE
double TG   = pow(SOLVERTIME, GAM);
double T50G = pow(T50i, GAM);

double CLt = CL0i +
  (CLMAXi - CL0i) * TG / (T50G + TG);

dxdt_CENT = -(CLt / Vi) * CENT;

$TABLE
double TGtab   = pow(TIME, GAM);
double T50Gtab = pow(T50i, GAM);

double CLTIME = CL0i +
  (CLMAXi - CL0i) * TGtab / (T50Gtab + TGtab);

double CP = CENT / Vi * 1000.0;
double DV = CP * (1.0 + EPS(1)) + EPS(2);

$CAPTURE CP 
'

mod_methylprednisolone_ards <- mcode("methylprednisolone_ards", methylprednisolone_ards_code)