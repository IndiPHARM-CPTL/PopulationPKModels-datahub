library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

nicardipine_code <- '
$PROB
- Ref:Modi NB, Veng-Pedersen P, Graham DJ, Dow RJ. Application of a system analysis approach to population pharmacokinetics and pharmacodynamics of nicardipine hydrochloride in healthy males. J Pharm Sci. 1993;82(7):705-713. doi:10.1002/jps.2600820707

$PARAM @annotated
TVCL    : 0.920 : L/h/kg   Plasma clearance per kg
TVVC    : 0.291 : L/kg     Central/sampling volume per kg
TVQ     : 0.826 : L/h/kg   Distribution clearance per kg
TVVP    : 0.839 : L/kg     Peripheral volume per kg; Vdss - Vc

WT      : 74.0  : kg       Body weight
PROP_SD : 0.20  : --       Proportional residual SD; assumed

$CMT @annotated
CENT   : Central plasma compartment
PERIPH : Peripheral compartment

$OMEGA @diag @labels ETA_CL ETA_VC ETA_Q ETA_VP
0.0263 0.0894 0.0747 0.243

$SIGMA
1

$GLOBAL
double CLi;
double VCi;
double Qi;
double VPi;
double K10i;
double K12i;
double K21i;

$MAIN
CLi = TVCL * WT * exp(ETA(1));
VCi = TVVC * WT * exp(ETA(2));
Qi  = TVQ  * WT * exp(ETA(3));
VPi = TVVP * WT * exp(ETA(4));

K10i = CLi / VCi;
K12i = Qi  / VCi;
K21i = Qi  / VPi;

$ODE
dxdt_CENT   = -K10i * CENT
              -K12i * CENT
              +K21i * PERIPH;

dxdt_PERIPH =  K12i * CENT
              -K21i * PERIPH;

$TABLE
double NIC_mgL  = CENT / VCi;
double NIC_ngmL = NIC_mgL * 1000.0;

double DV_ngmL = NIC_ngmL * exp(PROP_SD * EPS(1));

$CAPTURE
NIC_ngmL DV_ngmL
CLi VCi Qi VPi K10i K12i K21i WT
'
mod <- mcode("nicardipine_mod", nicardipine_code)

set.seed(123)

rate_mg_h <- c(5, 7.5, 10, 12.5, 15)

N        <- 1000
WT_FIXED <- 74.0

t_end_inf <- 48   
delta_inf <- 0.05

rate_levels <- paste0(rate_mg_h, " mg/h continuous IV infusion")

idata_typ <- tibble(
  ID = 1,
  WT = WT_FIXED
)

idata_pop <- tibble(
  ID = 1:N,
  WT = WT_FIXED
)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod)

set.seed(123)

ci_pop_list <- lapply(rate_mg_h, function(r) {
  
  ev_ci <- ev(
    time = 0,
    amt  = r * t_end_inf,
    rate = r,
    cmt  = "CENT"
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_ci) %>%
    mrgsim(end = t_end_inf, delta = delta_inf) %>%
    as_tibble() %>%
    mutate(
      CP = NIC_ngmL,
      Rate_mg_h = r,
      Regimen = paste0(r, " mg/h continuous IV infusion")
    )
})

ci_pop_raw <- bind_rows(ci_pop_list) %>%
  mutate(Regimen = factor(Regimen, levels = rate_levels))

ci_pop_sum <- ci_pop_raw %>%
  group_by(Regimen, Rate_mg_h, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p_ci_pop <- ggplot(ci_pop_sum, aes(time, C_med, color = Regimen, fill = Regimen)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Nicardipine concentration (ng/mL)",
    color = "Infusion rate",
    fill  = "Infusion rate",
    title = "Nicardipine continuous IV infusion, population"
  )

ci_pop_ind <- ci_pop_raw %>%
  group_by(Regimen, Rate_mg_h, ID) %>%
  summarise(
    CL_L_h = first(CLi),
    Css_pred = 1000 * first(Rate_mg_h) / first(CLi),
    C4  = get_nearest(time, CP, 4),
    C6  = get_nearest(time, CP, 6),
    C8  = get_nearest(time, CP, 8),
    C12 = get_nearest(time, CP, 12),
    C24 = get_nearest(time, CP, 24),
    C48 = get_nearest(time, CP, 48),
    .groups = "drop"
  )

ci_pop_summary <- ci_pop_ind %>%
  group_by(Regimen, Rate_mg_h) %>%
  summarise(
    Css_med = median(Css_pred, na.rm = TRUE),
    Css_p05 = quantile(Css_pred, 0.05, na.rm = TRUE),
    Css_p95 = quantile(Css_pred, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    C48_med = median(C48, na.rm = TRUE),
    C48_p05 = quantile(C48, 0.05, na.rm = TRUE),
    C48_p95 = quantile(C48, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p_ci_pop
ci_pop_summary