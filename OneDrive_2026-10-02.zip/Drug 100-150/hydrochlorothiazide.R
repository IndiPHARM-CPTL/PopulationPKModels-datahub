library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

hctz_code <- '
$PROB
- Ref: Van Wart SA, Shoaf SE, Mallikaarjun S, Mager DE. Population-based meta-analysis of hydrochlorothiazide pharmacokinetics. Biopharm Drug Dispos. 2013;34(9):527-539. doi:10.1002/bdd.1863

$PARAM @annotated
KA       : 1.34   : 1/h     Weibull absorption coefficient
GAM      : 2.84   : --      Weibull shape parameter
TH_CLR   : 18.3   : L/h     Renal clearance at CLCR = 120 mL/min
TH_CLCR  : 1.38   : --      Power effect of CLCR on renal clearance
CLNR     : 2.44   : L/h     Nonrenal clearance
VC       : 97.3   : L       Central volume
Q        : 17.2   : L/h     Distribution clearance
VP       : 178    : L       Peripheral volume

CLCR     : 120    : mL/min  Creatinine clearance
PROP_SD  : 0.00   : --      Proportional residual SD placeholder
TAU      : 24     : h       Dosing interval
MULTI    : 0      : --      0 = single-dose TSLD, 1 = repeated-dose TSLD

$CMT @annotated
DEPOT  : Oral dosing / absorption compartment (mg)
CENT   : Central compartment (mg)
PERIPH : Peripheral compartment (mg)
URINE  : Cumulative urinary excretion amount (mg)

$OMEGA @block @labels ETA_KA ETA_GAM ETA_CLR ETA_VC ETA_VP
0.321
0      0.306
0      0      0.116
0      0      0.0767 0.117
0      0      0      0      0.428

$SIGMA
1

$GLOBAL
double KAi;
double GAMi;
double CLRi;
double CLi;
double VCi;
double Qi;
double VPi;
double TSLD;
double KABS;

$MAIN
KAi  = KA  * exp(ETA(1));
GAMi = GAM * exp(ETA(2));

CLRi = TH_CLR * pow(CLCR / 120.0, TH_CLCR) * exp(ETA(3));
CLi  = CLRi + CLNR;

VCi = VC * exp(ETA(4));
Qi  = Q;
VPi = VP * exp(ETA(5));

$ODE
if(MULTI > 0.5) {
  TSLD = fmod(SOLVERTIME, TAU);
} else {
  TSLD = SOLVERTIME;
}

KABS = 1.0 - exp(-pow(KAi * TSLD, GAMi));

dxdt_DEPOT  = -KABS * DEPOT;

dxdt_CENT   =  KABS * DEPOT
             - (CLi / VCi) * CENT
             - (Qi / VCi) * CENT
             + (Qi / VPi) * PERIPH;

dxdt_PERIPH =  (Qi / VCi) * CENT
             - (Qi / VPi) * PERIPH;

dxdt_URINE  =  (CLRi / VCi) * CENT;

$TABLE
double CP_mgL  = CENT / VCi;
double CP_ngmL = CP_mgL * 1000.0;
double DV_ngmL = CP_ngmL * exp(PROP_SD * EPS(1));

double AE_URINE_mg = URINE;
double URINE_RATE_mg_h = (CLRi / VCi) * CENT;

$CAPTURE CP_mgL CP_ngmL DV_ngmL AE_URINE_mg URINE_RATE_mg_h KAi GAMi CLRi CLi VCi Qi VPi CLCR KABS
'

mod <- mcode("hctz_popPK_vanwart2013", hctz_code)

## =========================================================
## Simulation settings
## =========================================================

doses_mg <- c(12.5, 25, 50)

tau_h    <- 24
n_doses  <- 14
addl_md  <- n_doses - 1

t_end_sd <- 72
t_end_md <- n_doses * tau_h

delta_sd <- 0.25
delta_md <- 0.25

last_dose_h   <- (n_doses - 1) * tau_h
last_dose_day <- last_dose_h / 24

add_hctz_units <- function(df) {
  df %>%
    mutate(
      CP = CP_ngmL,
      time_day = time / 24
    )
}

get_conc_at <- function(time_vec, conc_vec, target_time) {
  conc_vec[which.min(abs(time_vec - target_time))]
}

get_urine_at <- function(time_vec, urine_vec, target_time) {
  urine_vec[which.min(abs(time_vec - target_time))]
}

## =========================================================
## Typical subject
## =========================================================

mod_typ <- zero_re(mod)

idata_typ <- tibble(
  ID   = 1,
  CLCR = 120,
  TAU  = tau_h
)


make_idata_pop <- function(N, seed = 123) {
  set.seed(seed)
  
  tibble(
    ID   = 1:N,
    CLCR = pmin(pmax(rnorm(N, mean = 120, sd = 30), 30), 160),
    TAU  = tau_h
  )
}

## =========================================================
## Figure 1: typical single dose
## =========================================================

fig1_list <- lapply(doses_mg, function(d) {
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    add_hctz_units() %>%
    mutate(group = paste0(d, " mg"))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(group = factor(group, levels = paste0(doses_mg, " mg")))

p1 <- ggplot(fig1_out, aes(time_day, CP, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Hydrochlorothiazide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Hydrochlorothiazide single dose, typical subject"
  )

fig1_summary <- fig1_out %>%
  group_by(group) %>%
  summarise(
    Cmax_ng_mL = max(CP),
    Tmax_h     = time[which.max(CP)],
    C24_ng_mL  = get_conc_at(time, CP, 24),
    C48_ng_mL  = get_conc_at(time, CP, 48),
    C72_ng_mL  = get_conc_at(time, CP, 72),
    Ae24_mg    = get_urine_at(time, URINE, 24),
    Ae72_mg    = get_urine_at(time, URINE, 72),
    .groups    = "drop"
  )

## =========================================================
## Figure 2: typical once-daily multidose
## =========================================================

fig2_list <- lapply(doses_mg, function(d) {
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau_h, addl = addl_md)
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    add_hctz_units() %>%
    mutate(group = paste0(d, " mg"))
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(group = factor(group, levels = paste0(doses_mg, " mg")))

p2 <- ggplot(fig2_out, aes(time_day, CP, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Hydrochlorothiazide concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Hydrochlorothiazide q24h for 14 days, typical subject"
  )

fig2_summary <- fig2_out %>%
  group_by(group) %>%
  summarise(
    Cmax_ss_ng_mL = max(CP[time >= last_dose_h & time <= t_end_md]),
    Tmax_ss_h     = time[which.max(ifelse(time >= last_dose_h & time <= t_end_md, CP, -Inf))] - last_dose_h,
    
    Cmin_day1     = get_conc_at(time, CP, 24),
    Cmin_day2     = get_conc_at(time, CP, 48),
    Cmin_day3     = get_conc_at(time, CP, 72),
    Cmin_day7     = get_conc_at(time, CP, 168),
    Cmin_day14    = get_conc_at(time, CP, 336),
    
    Ae_day1_mg    = get_urine_at(time, URINE, 24),
    Ae_day7_mg    = get_urine_at(time, URINE, 168),
    Ae_day14_mg   = get_urine_at(time, URINE, 336),
    .groups       = "drop"
  )

## =========================================================
## Figure 3: population single dose
## =========================================================

N <- 1000
idata_pop <- make_idata_pop(N, seed = 123)

fig3_list <- lapply(doses_mg, function(d) {
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    add_hctz_units() %>%
    mutate(group = paste0(d, " mg"))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(group = factor(group, levels = paste0(doses_mg, " mg")))

fig3_sum <- fig3_raw %>%
  group_by(group, time_day) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time_day, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Hydrochlorothiazide concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Hydrochlorothiazide single dose, population",
    subtitle = "Median profile with 5th-95th percentile ribbon"
  )

fig3_ind <- fig3_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C24  = get_conc_at(time, CP, 24),
    C48  = get_conc_at(time, CP, 48),
    C72  = get_conc_at(time, CP, 72),
    Ae24 = get_urine_at(time, URINE, 24),
    Ae72 = get_urine_at(time, URINE, 72),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    C48_med = median(C48, na.rm = TRUE),
    C48_p05 = quantile(C48, 0.05, na.rm = TRUE),
    C48_p95 = quantile(C48, 0.95, na.rm = TRUE),
    
    C72_med = median(C72, na.rm = TRUE),
    C72_p05 = quantile(C72, 0.05, na.rm = TRUE),
    C72_p95 = quantile(C72, 0.95, na.rm = TRUE),
    
    Ae24_med = median(Ae24, na.rm = TRUE),
    Ae24_p05 = quantile(Ae24, 0.05, na.rm = TRUE),
    Ae24_p95 = quantile(Ae24, 0.95, na.rm = TRUE),
    
    Ae72_med = median(Ae72, na.rm = TRUE),
    Ae72_p05 = quantile(Ae72, 0.05, na.rm = TRUE),
    Ae72_p95 = quantile(Ae72, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

## =========================================================
## Figure 4: population once-daily multidose
## =========================================================

fig4_list <- lapply(doses_mg, function(d) {
  ev_md <- ev(time = 0, amt = d, cmt = "DEPOT", ii = tau_h, addl = addl_md)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    add_hctz_units() %>%
    mutate(group = paste0(d, " mg"))
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(group = factor(group, levels = paste0(doses_mg, " mg")))

fig4_sum <- fig4_raw %>%
  group_by(group, time_day) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time_day, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Hydrochlorothiazide concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Hydrochlorothiazide q24h for 14 days, population",
    subtitle = "Median profile with 5th-95th percentile ribbon"
  )

fig4_ind <- fig4_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax_ss = max(CP[time >= last_dose_h & time <= t_end_md], na.rm = TRUE),
    Tmax_ss = time[which.max(ifelse(time >= last_dose_h & time <= t_end_md, CP, -Inf))] - last_dose_h,
    
    Cmin_day1  = get_conc_at(time, CP, 24),
    Cmin_day2  = get_conc_at(time, CP, 48),
    Cmin_day3  = get_conc_at(time, CP, 72),
    Cmin_day7  = get_conc_at(time, CP, 168),
    Cmin_day14 = get_conc_at(time, CP, 336),
    
    Ae_day1  = get_urine_at(time, URINE, 24),
    Ae_day7  = get_urine_at(time, URINE, 168),
    Ae_day14 = get_urine_at(time, URINE, 336),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_ss_med = median(Cmax_ss, na.rm = TRUE),
    Cmax_ss_p05 = quantile(Cmax_ss, 0.05, na.rm = TRUE),
    Cmax_ss_p95 = quantile(Cmax_ss, 0.95, na.rm = TRUE),
    
    Tmax_ss_med = median(Tmax_ss, na.rm = TRUE),
    Tmax_ss_p05 = quantile(Tmax_ss, 0.05, na.rm = TRUE),
    Tmax_ss_p95 = quantile(Tmax_ss, 0.95, na.rm = TRUE),
    
    Cmin_day1_med  = median(Cmin_day1, na.rm = TRUE),
    Cmin_day1_p05  = quantile(Cmin_day1, 0.05, na.rm = TRUE),
    Cmin_day1_p95  = quantile(Cmin_day1, 0.95, na.rm = TRUE),
    
    Cmin_day2_med  = median(Cmin_day2, na.rm = TRUE),
    Cmin_day2_p05  = quantile(Cmin_day2, 0.05, na.rm = TRUE),
    Cmin_day2_p95  = quantile(Cmin_day2, 0.95, na.rm = TRUE),
    
    Cmin_day3_med  = median(Cmin_day3, na.rm = TRUE),
    Cmin_day3_p05  = quantile(Cmin_day3, 0.05, na.rm = TRUE),
    Cmin_day3_p95  = quantile(Cmin_day3, 0.95, na.rm = TRUE),
    
    Cmin_day7_med  = median(Cmin_day7, na.rm = TRUE),
    Cmin_day7_p05  = quantile(Cmin_day7, 0.05, na.rm = TRUE),
    Cmin_day7_p95  = quantile(Cmin_day7, 0.95, na.rm = TRUE),
    
    Cmin_day14_med = median(Cmin_day14, na.rm = TRUE),
    Cmin_day14_p05 = quantile(Cmin_day14, 0.05, na.rm = TRUE),
    Cmin_day14_p95 = quantile(Cmin_day14, 0.95, na.rm = TRUE),
    
    Ae_day1_med  = median(Ae_day1, na.rm = TRUE),
    Ae_day1_p05  = quantile(Ae_day1, 0.05, na.rm = TRUE),
    Ae_day1_p95  = quantile(Ae_day1, 0.95, na.rm = TRUE),
    
    Ae_day14_med = median(Ae_day14, na.rm = TRUE),
    Ae_day14_p05 = quantile(Ae_day14, 0.05, na.rm = TRUE),
    Ae_day14_p95 = quantile(Ae_day14, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

## =========================================================
## Optional Figure 4b: final steady-state dosing interval only
## =========================================================

fig4_ss_sum <- fig4_sum %>%
  filter(time_day >= last_dose_day, time_day <= t_end_md / 24) %>%
  mutate(time_after_last_dose_h = (time_day - last_dose_day) * 24)

p4_ss <- ggplot(fig4_ss_sum, aes(time_after_last_dose_h, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time after last dose (h)",
    y = "Hydrochlorothiazide concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Optional Figure 4b. Hydrochlorothiazide final dosing interval",
    subtitle = "Median profile with 5th-95th percentile ribbon"
  )

## =========================================================
## Print plots
## =========================================================

p1
p2
p3
p4
p4_ss

## =========================================================
## Rounded summary tables
## =========================================================

fig1_summary_rounded <- fig1_summary %>%
  mutate(across(where(is.numeric), ~round(.x, 2)))

fig2_summary_rounded <- fig2_summary %>%
  mutate(across(where(is.numeric), ~round(.x, 2)))

fig3_summary_rounded <- fig3_summary %>%
  mutate(across(where(is.numeric), ~round(.x, 2)))

fig4_summary_rounded <- fig4_summary %>%
  mutate(across(where(is.numeric), ~round(.x, 2)))

fig1_summary_rounded
fig2_summary_rounded
fig3_summary_rounded
fig4_summary_rounded