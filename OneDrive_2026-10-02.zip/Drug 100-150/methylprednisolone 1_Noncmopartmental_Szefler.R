library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

methylprednisolone_code <- '
$PROB
- Ref: Szefler SJ, Ebling WF, Georgitis JW, Jusko WJ. Methylprednisolone versus prednisolone pharmacokinetics in relation to dose in adults. Eur J Clin Pharmacol. 1986;30(3):323-329. doi:10.1007/BF00541537
Non-compartmental PK study
$PARAM @annotated
WT    : 70     : kg       Body weight
CLKG  : 0.337  : L/h/kg   Plasma clearance per kg
VKG   : 1.38   : L/kg     Volume of distribution per kg
FU    : 0.232  : --       Unbound fraction; 76.8% plasma binding

$CMT CENT

$OMEGA @block
0.04235
0.03253 0.03189

$MAIN
double CL = CLKG * WT * exp(ETA(1));
double V  = VKG  * WT * exp(ETA(2));
double KEL = CL / V;

$ODE
dxdt_CENT = -KEL * CENT;

$TABLE
double CP = CENT / V * 1000.0;

$CAPTURE CP 
'
mod_methylprednisolone <- mcode("methylprednisolone", methylprednisolone_code)