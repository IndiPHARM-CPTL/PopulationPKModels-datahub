library(mrgsolve)
library(dplyr)
library(tidyr)
library(tibble)
library(ggplot2)

bumetanide_code <- '
$PROB
Bumetanide oral tablet one-compartment PK model
- Ref:Holazo AA, Colburn WA, Gustafson JH, Young RL, Parsonnet M. Pharmacokinetics of bumetanide following intravenous, intramuscular, and oral administrations to normal subjects. J Pharm Sci. 1984;73(8):1108-1113. doi:10.1002/jps.2600730821

$PARAM @annotated
KA      : 3.30  : 1/h   First-order absorption rate constant; oral tablet fitted mean
CL      : 15.4  : L/h   Apparent oral clearance; derived from 1 mg / AUC ~65 ng*h/mL
VAPP    : 18.9  : L     Apparent volume; CL / beta, beta ~0.817 1/h
TLAG    : 0.55  : h     Absorption lag time; 33 min

$CMT 
GUT CENT

$OMEGA @annotated
EKA     : 0.300 : IIV on KA
ECL     : 0.120 : IIV on CL
EVAPP   : 0.100 : IIV on VAPP
ETLAG   : 0.160 : IIV on TLAG

$MAIN
double KAi    = KA    * exp(EKA);
double CLi    = CL    * exp(ECL);
double VAPPi  = VAPP  * exp(EVAPP);
double TLAGi  = TLAG  * exp(ETLAG);

double KELi   = CLi / VAPPi;
ALAG_GUT = TLAGi;
$ODE
dxdt_GUT  = -KAi * GUT;

dxdt_CENT =  KAi * GUT
             -KELi * CENT;
$TABLE
double C_BUM_mgL  = CENT / VAPPi;
double C_BUM_ngmL = C_BUM_mgL * 1000.0;

$CAPTURE C_BUM_ngmL C_BUM_mgL
'
mod <- mcode("bumetanide_oral_tablet_1c", bumetanide_code)


dose_mg <- c(0.5, 1, 2)

n_pop <- 1000
set.seed(123)

tau_h    <- 24
n_doses  <- 7
addl_md  <- n_doses - 1

t_end_sd <- 12
t_end_md <- 168

delta_sd <- 0.2
delta_md <- 0.2

last_dose_h <- (n_doses - 1) * tau_h
final_interval_end_h <- last_dose_h + tau_h

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:n_pop)

mod_typ <- zero_re(mod)



get_conc_at <- function(time, conc, t) {
  df <- tibble(time = time, conc = conc) %>%
    group_by(time) %>%
    summarise(conc = mean(conc, na.rm = TRUE), .groups = "drop") %>%
    arrange(time)
  
  df$conc[which.min(abs(df$time - t))]
}


make_long_primary <- function(x) {
  x %>%
    pivot_longer(
      cols = c(C_BUM_ngmL),
      names_to = "analyte",
      values_to = "conc_ngmL"
    ) %>%
    mutate(
      analyte = recode(
        analyte,
        C_BUM_ngmL = "Bumetanide"
      )
    )
}




fig1_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(dose = paste0(d, " mg"))
}) %>%
  bind_rows() %>%
  mutate(dose = factor(dose, levels = paste0(dose_mg, " mg")))

fig1 <- make_long_primary(fig1_raw)

p1 <- ggplot(fig1, aes(x = time, y = conc_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after oral tablet dose (h)",
    y = "Plasma bumetanide concentration (ng/mL)",
    title = "Figure 1. Bumetanide oral tablet single-dose typical simulation",
    color = "Dose"
  ) +
  theme_bw()

fig1_ind <- fig1 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_ngmL, na.rm = TRUE),
    Tmax = time[which.max(conc_ngmL)],
    C0_5 = get_conc_at(time, conc_ngmL, 0.5),
    C0_75 = get_conc_at(time, conc_ngmL, 0.75),
    C1   = get_conc_at(time, conc_ngmL, 1),
    C1_5 = get_conc_at(time, conc_ngmL, 1.5),
    C2   = get_conc_at(time, conc_ngmL, 2),
    C3   = get_conc_at(time, conc_ngmL, 3),
    C4   = get_conc_at(time, conc_ngmL, 4),
    C5   = get_conc_at(time, conc_ngmL, 5),
    C8   = get_conc_at(time, conc_ngmL, 8),
    C12  = get_conc_at(time, conc_ngmL, 12),
    .groups = "drop"
  )

fig1_summary <- fig1_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_ng_mL = median(Cmax, na.rm = TRUE),
    Tmax_h     = median(Tmax, na.rm = TRUE),
    C0_5_ng_mL = median(C0_5, na.rm = TRUE),
    C0_75_ng_mL = median(C0_75, na.rm = TRUE),
    C1_ng_mL   = median(C1, na.rm = TRUE),
    C1_5_ng_mL = median(C1_5, na.rm = TRUE),
    C2_ng_mL   = median(C2, na.rm = TRUE),
    C3_ng_mL   = median(C3, na.rm = TRUE),
    C4_ng_mL   = median(C4, na.rm = TRUE),
    C5_ng_mL   = median(C5, na.rm = TRUE),
    C8_ng_mL   = median(C8, na.rm = TRUE),
    C12_ng_mL  = median(C12, na.rm = TRUE),
    .groups = "drop"
  )

p1
fig1_summary




fig2_raw <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(dose = paste0(d, " mg q24h x", n_doses))
}) %>%
  bind_rows() %>%
  mutate(dose = factor(dose, levels = paste0(dose_mg, " mg q24h x", n_doses)))

fig2 <- make_long_primary(fig2_raw)

p2 <- ggplot(fig2, aes(x = time, y = conc_ngmL, color = dose)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Plasma bumetanide concentration (ng/mL)",
    title = "Figure 2. Bumetanide oral tablet q24h multiple-dose typical simulation",
    subtitle = "Multiple-dose extrapolation",
    color = "Dose"
  ) +
  theme_bw()

fig2_ind <- fig2 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_ngmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ngmL, -Inf))
    ] - last_dose_h,
    C24_after_last = get_conc_at(time, conc_ngmL, final_interval_end_h),
    C24_day1       = get_conc_at(time, conc_ngmL, tau_h),
    C48            = get_conc_at(time, conc_ngmL, 48),
    C96            = get_conc_at(time, conc_ngmL, 96),
    C144           = get_conc_at(time, conc_ngmL, 144),
    C168           = get_conc_at(time, conc_ngmL, 168),
    .groups = "drop"
  )

fig2_summary <- fig2_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_ng_mL = median(Cmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_h     = median(Tmax_final_interval, na.rm = TRUE),
    C24_after_last_ng_mL      = median(C24_after_last, na.rm = TRUE),
    C24_day1_ng_mL            = median(C24_day1, na.rm = TRUE),
    C48_ng_mL                 = median(C48, na.rm = TRUE),
    C96_ng_mL                 = median(C96, na.rm = TRUE),
    C144_ng_mL                = median(C144, na.rm = TRUE),
    C168_ng_mL                = median(C168, na.rm = TRUE),
    .groups = "drop"
  )

p2
fig2_summary





fig3_raw <- lapply(dose_mg, function(d) {
  
  ev_one <- ev(
    time = 0,
    amt  = d,
    cmt  = 1
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_one) %>%
    mrgsim(
      end = t_end_sd,
      delta = delta_sd,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(dose = paste0(d, " mg"))
}) %>%
  bind_rows() %>%
  mutate(dose = factor(dose, levels = paste0(dose_mg, " mg")))

fig3 <- make_long_primary(fig3_raw)

fig3_sum <- fig3 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_ngmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time after oral tablet dose (h)",
    y = "Plasma bumetanide concentration (ng/mL)",
    title = "Figure 3. Bumetanide oral tablet single-dose population simulation",
    subtitle = "Line = median; ribbon = 5th-95th percentile",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig3_ind <- fig3 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax = max(conc_ngmL, na.rm = TRUE),
    Tmax = time[which.max(conc_ngmL)],
    C0_5 = get_conc_at(time, conc_ngmL, 0.5),
    C0_75 = get_conc_at(time, conc_ngmL, 0.75),
    C1   = get_conc_at(time, conc_ngmL, 1),
    C1_5 = get_conc_at(time, conc_ngmL, 1.5),
    C2   = get_conc_at(time, conc_ngmL, 2),
    C3   = get_conc_at(time, conc_ngmL, 3),
    C4   = get_conc_at(time, conc_ngmL, 4),
    C5   = get_conc_at(time, conc_ngmL, 5),
    C8   = get_conc_at(time, conc_ngmL, 8),
    C12  = get_conc_at(time, conc_ngmL, 12),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C1_med = median(C1, na.rm = TRUE),
    C1_p05 = quantile(C1, 0.05, na.rm = TRUE),
    C1_p95 = quantile(C1, 0.95, na.rm = TRUE),
    
    C2_med = median(C2, na.rm = TRUE),
    C2_p05 = quantile(C2, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2, 0.95, na.rm = TRUE),
    
    C4_med = median(C4, na.rm = TRUE),
    C4_p05 = quantile(C4, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4, 0.95, na.rm = TRUE),
    
    C5_med = median(C5, na.rm = TRUE),
    C5_p05 = quantile(C5, 0.05, na.rm = TRUE),
    C5_p95 = quantile(C5, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3
fig3_summary



fig4_raw <- lapply(dose_mg, function(d) {
  
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = 1,
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(
      end = t_end_md,
      delta = delta_md,
      obsonly = TRUE
    ) %>%
    as_tibble() %>%
    mutate(dose = paste0(d, " mg q24h x", n_doses))
}) %>%
  bind_rows() %>%
  mutate(dose = factor(dose, levels = paste0(dose_mg, " mg q24h x", n_doses)))

fig4 <- make_long_primary(fig4_raw)

fig4_sum <- fig4 %>%
  group_by(dose, analyte, time) %>%
  summarise(
    CP_med = median(conc_ngmL, na.rm = TRUE),
    CP_p05 = quantile(conc_ngmL, 0.05, na.rm = TRUE),
    CP_p95 = quantile(conc_ngmL, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(x = time, y = CP_med, color = dose, fill = dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  labs(
    x = "Time (h)",
    y = "Plasma bumetanide concentration (ng/mL)",
    title = "Figure 4. Bumetanide oral tablet q24h population simulation",
    subtitle = "Line = median; ribbon = 5th-95th percentile",
    color = "Dose",
    fill = "Dose"
  ) +
  theme_bw()

fig4_ind <- fig4 %>%
  group_by(dose, analyte, ID) %>%
  summarise(
    Cmax_final_interval = max(
      conc_ngmL[time >= last_dose_h & time <= final_interval_end_h],
      na.rm = TRUE
    ),
    Tmax_final_interval = time[
      which.max(ifelse(time >= last_dose_h & time <= final_interval_end_h, conc_ngmL, -Inf))
    ] - last_dose_h,
    C24_after_last = get_conc_at(time, conc_ngmL, final_interval_end_h),
    C24_day1       = get_conc_at(time, conc_ngmL, tau_h),
    C48            = get_conc_at(time, conc_ngmL, 48),
    C96            = get_conc_at(time, conc_ngmL, 96),
    C144           = get_conc_at(time, conc_ngmL, 144),
    C168           = get_conc_at(time, conc_ngmL, 168),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(dose, analyte) %>%
  summarise(
    Cmax_final_interval_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_final_interval_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_final_interval_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_final_interval_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_final_interval_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_final_interval_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C24_after_last_med = median(C24_after_last, na.rm = TRUE),
    C24_after_last_p05 = quantile(C24_after_last, 0.05, na.rm = TRUE),
    C24_after_last_p95 = quantile(C24_after_last, 0.95, na.rm = TRUE),
    
    C24_day1_med = median(C24_day1, na.rm = TRUE),
    C24_day1_p05 = quantile(C24_day1, 0.05, na.rm = TRUE),
    C24_day1_p95 = quantile(C24_day1, 0.95, na.rm = TRUE),
    
    C144_med = median(C144, na.rm = TRUE),
    C144_p05 = quantile(C144, 0.05, na.rm = TRUE),
    C144_p95 = quantile(C144, 0.95, na.rm = TRUE),
    
    C168_med = median(C168, na.rm = TRUE),
    C168_p05 = quantile(C168, 0.05, na.rm = TRUE),
    C168_p95 = quantile(C168, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4
fig4_summary