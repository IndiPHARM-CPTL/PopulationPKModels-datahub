library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

isradipine_code <- '
$PROB
- PMID: 33460320 PMCID: PMC7951102 DOI: 10.1002/acn3.51300
- PD patients
$PARAM @annotated
KTR       : 1.68  : 1/h      Transit / absorption rate constant
TVCL      : 292   : L/h      Apparent oral clearance at reference age
TVC       : 895   : L        Apparent central volume
Q         : 354   : L/h      Apparent intercompartmental clearance
TVP       : 1320  : L        Apparent peripheral volume

AGE       : 62.3  : years    Age
AGE_REF   : 62.3  : years    Reference age
TH_AGE_CL : -4.15 : L/h/year Linear age effect on CL/F

ADD_SD    : 0.21  : ng/mL    Additive residual error SD

$CMT @annotated
DEPOT   : Oral dose depot compartment
TRANSIT : Transit absorption compartment
CENT    : Central compartment
PERIPH  : Peripheral compartment

$OMEGA @diag @labels ETA_CL ETA_VC
0.207 1.45

$SIGMA
1

$GLOBAL
double KTRi;
double CLcov;
double CLi;
double VCi;
double Qi;
double VPi;
double K10i;
double K12i;
double K21i;

$MAIN

KTRi = KTR;
CLcov = TVCL + TH_AGE_CL * (AGE - AGE_REF);

if(CLcov < 20.0) {
  CLcov = 20.0;
} else {
  CLcov = CLcov;
}

CLi = CLcov * exp(ETA(1));
VCi = TVC   * exp(ETA(2));
Qi  = Q;
VPi = TVP;

K10i = CLi / VCi;
K12i = Qi  / VCi;
K21i = Qi  / VPi;

$ODE
dxdt_DEPOT   = -KTRi * DEPOT;

dxdt_TRANSIT =  KTRi * DEPOT
               -KTRi * TRANSIT;

dxdt_CENT    =  KTRi * TRANSIT
               -K10i * CENT
               -K12i * CENT
               +K21i * PERIPH;

dxdt_PERIPH  =  K12i * CENT
               -K21i * PERIPH;

$TABLE
double ISO_mgL  = CENT / VCi;
double ISO_ngmL = ISO_mgL * 1000.0;

double DV_ngmL = ISO_ngmL + ADD_SD * EPS(1);

$CAPTURE
ISO_ngmL DV_ngmL
KTRi CLi VCi Qi VPi K10i K12i K21i AGE
'

mod <- mcode("isradipine_venuto2021", isradipine_code)

set.seed(123)

dose_mg <- c(2.5, 5)

N        <- 1000
tau_h    <- 12
n_days   <- 10
n_doses  <- n_days * 2
addl_md  <- n_doses - 1

t_end_sd <- 24
t_end_md <- 240

delta_sd <- 0.05
delta_md <- 0.05

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q12h x", n_days, " days")

mod_typ <- zero_re(mod)


idata_typ <- tibble(
  ID  = 1,
  AGE = 60
)


idata_pop <- tibble(
  ID  = 1:N,
  AGE = pmin(pmax(rnorm(N, mean = 62.3, sd = 8.7), 40), 85)
)


fig1_list <- lapply(dose_mg, function(d) {
  ev_sd <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT"
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = ISO_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Isradipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Isradipine twice daily (2.5/5 mg), single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C12  = get_nearest(time, CP, 12),
    C24  = get_nearest(time, CP, 24),
    .groups = "drop"
  )


fig2_list <- lapply(dose_mg, function(d) {
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = ISO_ngmL,
      Dose = paste0(d, " mg q12h x", n_days, " days")
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Isradipine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Isradipine twice daily (2.5/5 mg), multi-dose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day10 = max(CP, na.rm = TRUE),
    Tmax_day10 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    Ctrough_day10 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )



set.seed(123)

fig3_list <- lapply(dose_mg, function(d) {
  ev_sd <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT"
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = ISO_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Isradipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Isradipine twice daily (2.5/5 mg), single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C12  = get_nearest(time, CP, 12),
    C24  = get_nearest(time, CP, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


set.seed(123)

fig4_list <- lapply(dose_mg, function(d) {
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = ISO_ngmL,
      Dose = paste0(d, " mg q12h x", n_days, " days")
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Isradipine concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Isradipine twice daily (2.5/5 mg), multi-dose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_day10 = max(CP, na.rm = TRUE),
    Tmax_day10 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    Ctrough_day10 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day10_med = median(Cmax_day10, na.rm = TRUE),
    Cmax_day10_p05 = quantile(Cmax_day10, 0.05, na.rm = TRUE),
    Cmax_day10_p95 = quantile(Cmax_day10, 0.95, na.rm = TRUE),
    
    Tmax_day10_med = median(Tmax_day10, na.rm = TRUE),
    Tmax_day10_p05 = quantile(Tmax_day10, 0.05, na.rm = TRUE),
    Tmax_day10_p95 = quantile(Tmax_day10, 0.95, na.rm = TRUE),
    
    Ctrough_day10_med = median(Ctrough_day10, na.rm = TRUE),
    Ctrough_day10_p05 = quantile(Ctrough_day10, 0.05, na.rm = TRUE),
    Ctrough_day10_p95 = quantile(Ctrough_day10, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary

