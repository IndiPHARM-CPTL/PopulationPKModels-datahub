library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

eplerenone_code <- '
$PROB
Eplerenone PopPK model with nonlinear protein binding

- Ref: Mori Y, Chiba K, Takahashi H, Ogata H. A Population Approach to Eplerenone Pharmacokinetics and Saturable Protein Binding. Drug Metab Pharmacokinet. 2010;25(6):551-559.

$PARAM @annotated
KA     : 1.73    : 1/h    Absorption rate constant
CL2    : 12.4    : L/h    Eplerenone unbound clearance
VDU    : 148     : L      Eplerenone unbound volume
Q1     : 37.8    : L/h    Forward interconversion clearance
Q2     : 123     : L/h    Reverse interconversion clearance
CL3    : 136     : L/h    Latent compartment clearance
VD3    : 11      : L      Latent compartment volume

NPT    : 0.00544 : mM     Protein-binding capacity
KD     : 0.00289 : mM     Dissociation constant
NS     : 0.14    : --     Nonspecific binding
MW_EPL : 414.5   : g/mol  Eplerenone molecular weight

$CMT @annotated
DEPOT      : Oral depot compartment
EPL_UNB    : Unbound eplerenone compartment
LATENT_MET : Latent interconversion compartment

$OMEGA @diag @labels ETA_KA ETA_CL2 ETA_VDU ETA_CL3 ETA_NPT ETA_NS
0.497 0.240 0.048 0.236 0.070 0.261

$MAIN
double KAi = KA * exp(ETA_KA);
double CL2i = CL2 * exp(ETA_CL2);
double VDUi = VDU * exp(ETA_VDU);
double CL3i = CL3 * exp(ETA_CL3);
double NPTi = NPT * exp(ETA_NPT);
double NSi = NS * exp(ETA_NS);

double K20i = CL2i / VDUi;
double K23i = Q1 / VDUi;
double K32i = Q2 / VD3;
double K30i = CL3i / VD3;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_EPL_UNB = KAi * DEPOT
               - K20i * EPL_UNB
               - K23i * EPL_UNB
               + K32i * LATENT_MET;

dxdt_LATENT_MET = K23i * EPL_UNB
                  - K32i * LATENT_MET
                  - K30i * LATENT_MET;

$TABLE
double C_EPL_UNB_mM = (EPL_UNB / VDUi) / MW_EPL;

double C_EPL_TOTAL_ngmL =
  (1.0 + NPTi / (KD + C_EPL_UNB_mM) + NSi) * C_EPL_UNB_mM * 1000;

$CAPTURE C_EPL_TOTAL_ngmL
'

mod <- mcode("eplerenone_mori2010", eplerenone_code)

dose_mg <- c(100, 300, 1000)

N <- 1000
tau_h <- 24
n_doses <- 11
addl_md <- n_doses - 1

t_end_sd <- tau_h
t_end_md <- n_doses * tau_h

delta_sd <- 0.1
delta_md <- 0.25

last_dose_h <- (n_doses - 1) * tau_h

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:N)




fig1_out <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = "DEPOT")) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(
      ID,
      time,
      CP = pmax(C_EPL_TOTAL_ngmL, 0),
      Dose = paste0(d, " mg single dose")
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Eplerenone concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Eplerenone single dose, typical profile"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C1 = get_nearest(time, CP, 1),
    C2 = get_nearest(time, CP, 2),
    C4 = get_nearest(time, CP, 4),
    C8 = get_nearest(time, CP, 8),
    C12 = get_nearest(time, CP, 12),
    Ctrough = get_nearest(time, CP, tau_h),
    .groups = "drop"
  )



fig2_out <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(
      time = 0,
      amt = d,
      cmt = "DEPOT",
      ii = tau_h,
      addl = addl_md
    )) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(
      ID,
      time,
      CP = pmax(C_EPL_TOTAL_ngmL, 0),
      Dose = paste0(d, " mg q24h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Eplerenone concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Eplerenone q24h x11, typical profile"
  )

fig2_summary <- fig2_out %>%
  filter(time >= last_dose_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_final_interval = max(CP, na.rm = TRUE),
    Tmax_final_interval = time[which.max(CP)] - last_dose_h,
    C1_final_interval = get_nearest(time, CP, last_dose_h + 1),
    C2_final_interval = get_nearest(time, CP, last_dose_h + 2),
    C4_final_interval = get_nearest(time, CP, last_dose_h + 4),
    C8_final_interval = get_nearest(time, CP, last_dose_h + 8),
    C12_final_interval = get_nearest(time, CP, last_dose_h + 12),
    Ctrough_final_interval = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )




fig3_raw <- lapply(dose_mg, function(d) {
  set.seed(123)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = "DEPOT")) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(
      ID,
      time,
      CP = pmax(C_EPL_TOTAL_ngmL, 0),
      Dose = paste0(d, " mg single dose")
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Eplerenone concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Eplerenone single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C1 = get_nearest(time, CP, 1),
    C2 = get_nearest(time, CP, 2),
    C4 = get_nearest(time, CP, 4),
    C8 = get_nearest(time, CP, 8),
    C12 = get_nearest(time, CP, 12),
    Ctrough = get_nearest(time, CP, tau_h),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C1_med = median(C1, na.rm = TRUE),
    C1_p05 = quantile(C1, 0.05, na.rm = TRUE),
    C1_p95 = quantile(C1, 0.95, na.rm = TRUE),
    
    C2_med = median(C2, na.rm = TRUE),
    C2_p05 = quantile(C2, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2, 0.95, na.rm = TRUE),
    
    C4_med = median(C4, na.rm = TRUE),
    C4_p05 = quantile(C4, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )




fig4_raw <- lapply(dose_mg, function(d) {
  set.seed(123)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(
      time = 0,
      amt = d,
      cmt = "DEPOT",
      ii = tau_h,
      addl = addl_md
    )) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(
      ID,
      time,
      CP = pmax(C_EPL_TOTAL_ngmL, 0),
      Dose = paste0(d, " mg q24h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Eplerenone concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Eplerenone q24h x11, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= last_dose_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_final_interval = max(CP, na.rm = TRUE),
    Tmax_final_interval = time[which.max(CP)] - last_dose_h,
    C1_final_interval = get_nearest(time, CP, last_dose_h + 1),
    C2_final_interval = get_nearest(time, CP, last_dose_h + 2),
    C4_final_interval = get_nearest(time, CP, last_dose_h + 4),
    C8_final_interval = get_nearest(time, CP, last_dose_h + 8),
    C12_final_interval = get_nearest(time, CP, last_dose_h + 12),
    Ctrough_final_interval = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C1_med = median(C1_final_interval, na.rm = TRUE),
    C1_p05 = quantile(C1_final_interval, 0.05, na.rm = TRUE),
    C1_p95 = quantile(C1_final_interval, 0.95, na.rm = TRUE),
    
    C2_med = median(C2_final_interval, na.rm = TRUE),
    C2_p05 = quantile(C2_final_interval, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2_final_interval, 0.95, na.rm = TRUE),
    
    C4_med = median(C4_final_interval, na.rm = TRUE),
    C4_p05 = quantile(C4_final_interval, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4_final_interval, 0.95, na.rm = TRUE),
    
    C8_med = median(C8_final_interval, na.rm = TRUE),
    C8_p05 = quantile(C8_final_interval, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8_final_interval, 0.95, na.rm = TRUE),
    
    C12_med = median(C12_final_interval, na.rm = TRUE),
    C12_p05 = quantile(C12_final_interval, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12_final_interval, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough_final_interval, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough_final_interval, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough_final_interval, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )



p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary