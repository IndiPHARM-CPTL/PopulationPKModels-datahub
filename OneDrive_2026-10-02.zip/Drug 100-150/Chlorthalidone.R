library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

cld_code <- '
$PROB
- Ref: Tsai MC, Wu J, Kupfer S, Vakilynejad M. Population Pharmacokinetics and Exposure-Response of a Fixed-Dose Combination of Azilsartan Medoxomil and Chlorthalidone in Patients With Stage 2 Hypertension. J Clin Pharmacol. 2016;56(8):988-998. doi:10.1002/jcph.684

$PARAM @annotated
KA        : 1.13  : 1/h      First-order absorption rate constant
TVCL      : 4.13  : L/h      Apparent oral clearance for reference subject
TVVC      : 62.1  : L        Apparent central volume for reference subject
Q         : 36.9  : L/h      Intercompartmental clearance
VP        : 120   : L        Apparent peripheral volume

AGE       : 58    : years    Age
SEX       : 0     : --       Sex; 0 = female, 1 = male
CYS       : 0.73  : mg/L     Cystatin C
BMI       : 30.9  : kg/m2    Body mass index

TH_AGE_CL : 0.0451 : L/h/year  Age effect on CL/F
TH_SEX_CL : 0.253  : --        Male effect on CL/F
TH_CYS_CL : 2.61   : L/h       Cystatin C effect on CL/F
TH_SEX_VC : 1.19   : --        Male effect on Vc/F
TH_BMI_VC : 2.41   : L         BMI effect on Vc/F

PROP_SD   : 0.127  : --        Proportional residual SD, sqrt(0.0162)
ADD_RATIO : 90.2   : ng/mL     Additive-to-proportional residual ratio

$CMT @annotated
DEPOT  : Oral absorption compartment
CENT   : Central compartment
PERIPH : Peripheral compartment

$OMEGA @block @labels ETA_CL ETA_VC
0.104
0.155 0.561

$SIGMA
1

$GLOBAL
double KAi;
double CLi;
double VCi;
double Qi;
double VPi;
double K10i;
double K12i;
double K21i;
double CLcov;
double VCcov;

$MAIN

CLcov = (TVCL - TH_AGE_CL * (AGE - 58.0)) *
        (1.0 + TH_SEX_CL * SEX) -
        TH_CYS_CL * (CYS - 0.73);

VCcov = (TVVC + TH_BMI_VC * (BMI - 30.9)) *
        (1.0 + TH_SEX_VC * SEX);

KAi = KA;
CLi = fmax(CLcov, 0.1) * exp(ETA(1));
VCi = fmax(VCcov, 1.0) * exp(ETA(2));
Qi  = Q;
VPi = VP;

K10i = CLi / VCi;
K12i = Qi  / VCi;
K21i = Qi  / VPi;

$ODE
dxdt_DEPOT  = -KAi * DEPOT;

dxdt_CENT   =  KAi * DEPOT
              -K10i * CENT
              -K12i * CENT
              +K21i * PERIPH;

dxdt_PERIPH =  K12i * CENT
              -K21i * PERIPH;

$TABLE
double CLD_mgL  = CENT / VCi;
double CLD_ngmL = fmax(CLD_mgL * 1000.0, 0.0);

$CAPTURE CLD_ngmL
'
mod <- mcode("chlorthalidone_tsai2016", cld_code)

set.seed(123)

dose_mg <- c(12.5, 25)

N        <- 1000
tau_h    <- 24
n_doses  <- 10
addl_md  <- n_doses - 1

t_end_sd <- 168
t_end_md <- 240

delta_sd <- 0.25
delta_md <- 0.25

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod)

idata_typ <- tibble(
  ID  = 1,
  AGE = 58,
  SEX = 0,
  BMI = 30.9,
  CYS = 0.73
)

idata_pop <- tibble(
  ID  = 1:N,
  AGE = pmin(pmax(rnorm(N, mean = 57, sd = 10), 40), 75),
  SEX = rbinom(N, size = 1, prob = 0.46),
  BMI = pmin(pmax(rnorm(N, mean = 30.9, sd = 5.5), 23.4), 42.9),
  CYS = pmin(pmax(rnorm(N, mean = 0.73, sd = 0.14), 0.55), 1.03)
)


fig1_list <- lapply(dose_mg, function(d) {
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = CLD_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Chlorthalidone concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Chlorthalidone once-daily, single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C24  = get_nearest(time, CP, 24),
    C48  = get_nearest(time, CP, 48),
    C168 = get_nearest(time, CP, 168),
    .groups = "drop"
  )


fig2_list <- lapply(dose_mg, function(d) {
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = CLD_ngmL,
      Dose = paste0(d, " mg q24h x", n_doses)
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Chlorthalidone concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Chlorthalidone once-daily multi-dose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day10 = max(CP, na.rm = TRUE),
    Tmax_day10 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    Ctrough_day10 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

set.seed(123)

fig3_list <- lapply(dose_mg, function(d) {
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = CLD_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Chlorthalidone concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 3. Chlorthalidone once-daily single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C24  = get_nearest(time, CP, 24),
    C48  = get_nearest(time, CP, 48),
    C168 = get_nearest(time, CP, 168),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    
    C48_med = median(C48, na.rm = TRUE),
    C48_p05 = quantile(C48, 0.05, na.rm = TRUE),
    C48_p95 = quantile(C48, 0.95, na.rm = TRUE),
    
    C168_med = median(C168, na.rm = TRUE),
    C168_p05 = quantile(C168, 0.05, na.rm = TRUE),
    C168_p95 = quantile(C168, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


set.seed(123)

fig4_list <- lapply(dose_mg, function(d) {
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = CLD_ngmL,
      Dose = paste0(d, " mg q24h x", n_doses)
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Chlorthalidone concentration (ng/mL)",
    color = "Dose",
    fill  = "Dose",
    title = "Figure 4. Chlorthalidone once-daily multidose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_day10 = max(CP, na.rm = TRUE),
    Tmax_day10 = time[which.max(CP)] - (n_doses - 1) * tau_h,
    Ctrough_day10 = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_day10_med = median(Cmax_day10, na.rm = TRUE),
    Cmax_day10_p05 = quantile(Cmax_day10, 0.05, na.rm = TRUE),
    Cmax_day10_p95 = quantile(Cmax_day10, 0.95, na.rm = TRUE),
    
    Tmax_day10_med = median(Tmax_day10, na.rm = TRUE),
    Tmax_day10_p05 = quantile(Tmax_day10, 0.05, na.rm = TRUE),
    Tmax_day10_p95 = quantile(Tmax_day10, 0.95, na.rm = TRUE),
    
    Ctrough_day10_med = median(Ctrough_day10, na.rm = TRUE),
    Ctrough_day10_p05 = quantile(Ctrough_day10, 0.05, na.rm = TRUE),
    Ctrough_day10_p95 = quantile(Ctrough_day10, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary
