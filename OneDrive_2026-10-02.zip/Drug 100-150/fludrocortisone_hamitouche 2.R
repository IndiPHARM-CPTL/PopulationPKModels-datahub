library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

fludrocortisone_code <- '
$PROB
- Ref: Hamitouche N, Comets E, Ribot M, Alvarez JC,
  Bellissant E, Laviolle B. Population pharmacokinetic-
  pharmacodynamic model of oral fludrocortisone and
  intravenous hydrocortisone in healthy volunteers.
  AAPS J. 2017;19(3):727-735.
  doi:10.1208/s12248-016-0041-9

$PARAM @annotated
KA       : 0.43   : 1/h    First-order absorption rate constant
CL       : 40.8   : L/h    Apparent oral clearance
V        : 82.4   : L      Apparent volume of distribution
F1       : 1.00   : --     Relative oral bioavailability


$OMEGA @labels ETA_KA ETA_V ETA_CL_OCC
0.03
0.06
0.14

$SIGMA
0.34

$CMT
DEPOT CENT

$GLOBAL
double KAi, CLi, Vi;

$MAIN
KAi = KA * exp(ETA(1));
Vi  = V  * exp(ETA(2));
CLi = CL * exp(ETA(3));

F_DEPOT = F1;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT = KAi * DEPOT
            - (CLi / Vi) * CENT;

$TABLE
double CP = (CENT / Vi) * 1000.0;
double DV = CP * (1.0 + EPS(1));

$CAPTURE CP
'
mod_flu <- mcode("fludrocortisone_popPK", fludrocortisone_code)

doses_mg <- c(0.05)
tau_h <- 24
n_doses <- 7
addl_md <- 6
t_end_sd <- 24
delta_sd <- 0.05

t_end_md <- 168
delta_md <- 0.05

mod_typ <- zero_re(mod_flu)
idata_typ <- tibble(ID = 1)

N <- 1000
idata_pop <- tibble(ID = 1:N)

at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}


fig1_list <- lapply(doses_mg, function(d) {
  ev_sd <- ev(amt = d, cmt = 1, time = 0)
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(group = paste0(d * 1000, " mcg"))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(group = factor(group, levels = dose_levels))

p1 <- ggplot(fig1_out, aes(time, CP, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Fludrocortisone concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Fludrocortisone single oral dose"
  )

fig1_summary <- fig1_out %>%
  group_by(group) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C2h = at_time(time, CP, 2),
    C4h = at_time(time, CP, 4),
    C6h = at_time(time, CP, 6),
    C12h = at_time(time, CP, 12),
    Cmin_24h = at_time(time, CP, 24),
    .groups = "drop"
  )


fig2_list <- lapply(doses_mg, function(d) {
  ev_md <- ev(amt = d, ii = tau_h, addl = addl_md, cmt = 1)
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(group = paste0(d * 1000, " mcg"))
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(group = factor(group, levels = dose_levels))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Fludrocortisone concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Fludrocortisone 50 mcg once daily for 7 days"
  )

fig2_summary <- fig2_out %>%
  group_by(group) %>%
  summarise(
    Cmax_day1 = max(CP[time >= 0 & time <= 24]),
    Tmax_day1_h = time[time >= 0 & time <= 24][which.max(CP[time >= 0 & time <= 24])],
    Cmin_day1 = at_time(time, CP, 24),
    
    Cmax_day7 = max(CP[time >= 144 & time <= 168]),
    Tmax_day7_h = time[time >= 144 & time <= 168][which.max(CP[time >= 144 & time <= 168])] - 144,
    Cmin_day7 = at_time(time, CP, 168),
    
    Cmin_day2 = at_time(time, CP, 48),
    Cmin_day3 = at_time(time, CP, 72),
    Cmin_day4 = at_time(time, CP, 96),
    Cmin_day5 = at_time(time, CP, 120),
    Cmin_day6 = at_time(time, CP, 144),
    
    .groups = "drop"
  )


fig3_list <- lapply(doses_mg, function(d) {
  set.seed(123)
  
  ev_sd <- ev(amt = d, cmt = 1, time = 0)
  
  mod_flu %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(group = paste0(d * 1000, " mcg"))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(group = factor(group, levels = dose_levels))

fig3_sum <- fig3_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP),
    C_p05 = quantile(CP, 0.05),
    C_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Fludrocortisone concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Fludrocortisone single oral dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C2h = at_time(time, CP, 2),
    C4h = at_time(time, CP, 4),
    C6h = at_time(time, CP, 6),
    C12h = at_time(time, CP, 12),
    Cmin_24h = at_time(time, CP, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med = median(Tmax_h),
    Tmax_p05 = quantile(Tmax_h, 0.05),
    Tmax_p95 = quantile(Tmax_h, 0.95),
    
    C2h_med = median(C2h),
    C2h_p05 = quantile(C2h, 0.05),
    C2h_p95 = quantile(C2h, 0.95),
    
    C4h_med = median(C4h),
    C4h_p05 = quantile(C4h, 0.05),
    C4h_p95 = quantile(C4h, 0.95),
    
    C6h_med = median(C6h),
    C6h_p05 = quantile(C6h, 0.05),
    C6h_p95 = quantile(C6h, 0.95),
    
    C12h_med = median(C12h),
    C12h_p05 = quantile(C12h, 0.05),
    C12h_p95 = quantile(C12h, 0.95),
    
    Cmin_24h_med = median(Cmin_24h),
    Cmin_24h_p05 = quantile(Cmin_24h, 0.05),
    Cmin_24h_p95 = quantile(Cmin_24h, 0.95),
    
    .groups = "drop"
  )


fig4_list <- lapply(doses_mg, function(d) {
  set.seed(123)
  
  ev_md <- ev(amt = d, ii = tau_h, addl = addl_md, cmt = 1)
  
  mod_flu %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(group = paste0(d * 1000, " mcg"))
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(group = factor(group, levels = dose_levels))

fig4_sum <- fig4_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP),
    C_p05 = quantile(CP, 0.05),
    C_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = group, fill = group)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Fludrocortisone concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Fludrocortisone 50 mcg once daily for 7 days, population"
  )

fig4_ind <- fig4_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax_day1 = max(CP[time >= 0 & time <= 24]),
    Tmax_day1_h = time[time >= 0 & time <= 24][which.max(CP[time >= 0 & time <= 24])],
    Cmin_day1 = at_time(time, CP, 24),
    
    Cmax_day7 = max(CP[time >= 144 & time <= 168]),
    Tmax_day7_h = time[time >= 144 & time <= 168][which.max(CP[time >= 144 & time <= 168])] - 144,
    Cmin_day7 = at_time(time, CP, 168),
    
    Cmin_day2 = at_time(time, CP, 48),
    Cmin_day3 = at_time(time, CP, 72),
    Cmin_day4 = at_time(time, CP, 96),
    Cmin_day5 = at_time(time, CP, 120),
    Cmin_day6 = at_time(time, CP, 144),
    
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_day1_med = median(Cmax_day1),
    Cmax_day1_p05 = quantile(Cmax_day1, 0.05),
    Cmax_day1_p95 = quantile(Cmax_day1, 0.95),
    
    Tmax_day1_med = median(Tmax_day1_h),
    Tmax_day1_p05 = quantile(Tmax_day1_h, 0.05),
    Tmax_day1_p95 = quantile(Tmax_day1_h, 0.95),
    
    Cmin_day1_med = median(Cmin_day1),
    Cmin_day1_p05 = quantile(Cmin_day1, 0.05),
    Cmin_day1_p95 = quantile(Cmin_day1, 0.95),
    
    Cmax_day7_med = median(Cmax_day7),
    Cmax_day7_p05 = quantile(Cmax_day7, 0.05),
    Cmax_day7_p95 = quantile(Cmax_day7, 0.95),
    
    Tmax_day7_med = median(Tmax_day7_h),
    Tmax_day7_p05 = quantile(Tmax_day7_h, 0.05),
    Tmax_day7_p95 = quantile(Tmax_day7_h, 0.95),
    
    Cmin_day2_med = median(Cmin_day2),
    Cmin_day2_p05 = quantile(Cmin_day2, 0.05),
    Cmin_day2_p95 = quantile(Cmin_day2, 0.95),
    
    Cmin_day3_med = median(Cmin_day3),
    Cmin_day3_p05 = quantile(Cmin_day3, 0.05),
    Cmin_day3_p95 = quantile(Cmin_day3, 0.95),
    
    Cmin_day4_med = median(Cmin_day4),
    Cmin_day4_p05 = quantile(Cmin_day4, 0.05),
    Cmin_day4_p95 = quantile(Cmin_day4, 0.95),
    
    Cmin_day5_med = median(Cmin_day5),
    Cmin_day5_p05 = quantile(Cmin_day5, 0.05),
    Cmin_day5_p95 = quantile(Cmin_day5, 0.95),
    
    Cmin_day6_med = median(Cmin_day6),
    Cmin_day6_p05 = quantile(Cmin_day6, 0.05),
    Cmin_day6_p95 = quantile(Cmin_day6, 0.95),
    
    Cmin_day7_med = median(Cmin_day7),
    Cmin_day7_p05 = quantile(Cmin_day7, 0.05),
    Cmin_day7_p95 = quantile(Cmin_day7, 0.95),
    
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary