esomeprazole_code <- '
$PROB
Esomeprazole population PK model

- Ref:
  Nagase M, Shimada H, Nii M, et al.
  Population pharmacokinetic analysis of esomeprazole in
  Japanese subjects with various CYP2C19 phenotypes.
  J Clin Pharm Ther. 2020;45(5).
  doi:10.1111/jcpt.13129

Phenotype coding:

1 = Homozygous extensive metabolizer (Homo-EM)
2 = Heterozygous extensive metabolizer (Hetero-EM)
3 = Poor metabolizer (PM)


$PARAM @annotated
KTR        : 5.95   : 1/h    Transit rate constant
V          : 16.36  : L      Apparent volume of distribution
CL_CYP3A4  : 7.37   : L/h    CYP3A4 / non-CYP2C19 clearance
CL_CYP2C19 : 41.25  : L/h    CYP2C19 clearance component
TH_HET     : 0.24   : --     Hetero-EM relative CYP2C19 activity
PHI5       : 0.14   : 1/mg   Dose-dependent CYP2C19 inhibition
DOSEMG     : 20     : mg     Daily esomeprazole dose
PHENO      : 1      : --     CYP2C19 phenotype
OCC        : 1      : --     Dosing occasion
ADD_SD     : 0.34   : mg/L   Additive residual error SD


$CMT @annotated
TRANS1 : Transit absorption compartment 1 (mg)
TRANS2 : Transit absorption compartment 2 (mg)
TRANS3 : Transit absorption compartment 3 (mg)
TRANS4 : Transit absorption compartment 4 (mg)
TRANS5 : Transit absorption compartment 5 (mg)
TRANS6 : Transit absorption compartment 6 (mg)
TRANS7 : Transit absorption compartment 7 (mg)
CENT   : Central compartment (mg)


$OMEGA @labels ETA_KTR1 ETA_KTR2 ETA_KTR3 ETA_KTR4 ETA_KTR5 ETA_CL
0.3721
0.3721
0.3721
0.3721
0.3721
0.0529


$SIGMA
1


$GLOBAL
double KTRi;
double CLi;
double Vi;
double CYP_FACTOR;
double CL2C19i;
double CL3A4i;
double ETA_KTR_OCC;


$MAIN

// ------------------------------------------------------------
// Occasion-specific absorption variability
// ------------------------------------------------------------

ETA_KTR_OCC = ETA(1);

if(OCC == 2) {
  ETA_KTR_OCC = ETA(2);
}

if(OCC == 3) {
  ETA_KTR_OCC = ETA(3);
}

if(OCC == 4) {
  ETA_KTR_OCC = ETA(4);
}

if(OCC == 5) {
  ETA_KTR_OCC = ETA(5);
}


KTRi =
  KTR *
  exp(ETA_KTR_OCC);


// ------------------------------------------------------------
// CYP2C19 phenotype effect
// ------------------------------------------------------------

CYP_FACTOR = 1.0;


// Heterozygous extensive metabolizer
if(PHENO == 2) {

  CYP_FACTOR =
    TH_HET;

}


// Poor metabolizer
if(PHENO == 3) {

  CYP_FACTOR =
    0.0;

}


// ------------------------------------------------------------
// CYP2C19 clearance component
//
// CL2C19 =
// CL_CYP2C19 *
// phenotype factor *
// exp(-PHI5 * dose)
// ------------------------------------------------------------

CL2C19i =
  CL_CYP2C19 *
  CYP_FACTOR *
  exp(
    -PHI5 *
    DOSEMG
  );


// ------------------------------------------------------------
// CYP3A4 / other linear clearance component
// ------------------------------------------------------------

CL3A4i =
  CL_CYP3A4;


// ------------------------------------------------------------
// Total apparent clearance
// ------------------------------------------------------------

CLi =
  (
    CL3A4i +
    CL2C19i
  ) *
  exp(ETA(6));


Vi =
  V;



$ODE

// ------------------------------------------------------------
// Seven sequential transit absorption compartments
// ------------------------------------------------------------

dxdt_TRANS1 =
  - KTRi *
  TRANS1;


dxdt_TRANS2 =
    KTRi * TRANS1
  - KTRi * TRANS2;


dxdt_TRANS3 =
    KTRi * TRANS2
  - KTRi * TRANS3;


dxdt_TRANS4 =
    KTRi * TRANS3
  - KTRi * TRANS4;


dxdt_TRANS5 =
    KTRi * TRANS4
  - KTRi * TRANS5;


dxdt_TRANS6 =
    KTRi * TRANS5
  - KTRi * TRANS6;


dxdt_TRANS7 =
    KTRi * TRANS6
  - KTRi * TRANS7;



dxdt_CENT =
    KTRi * TRANS7
  - (CLi / Vi) * CENT;



$TABLE

// Plasma concentration in mg/L
double CP_mgL =
  CENT / Vi;


// Plasma concentration in ng/mL
double CP_ngmL =
  1000.0 *
  CP_mgL;


// Additive residual error
double DV_mgL =
  CP_mgL +
  ADD_SD *
  EPS(1);


double DV_ngmL =
  1000.0 *
  DV_mgL;


$CAPTURE
CP_mgL CP_ngmL
DV_mgL DV_ngmL
KTRi CLi Vi
CL2C19i CL3A4i
CYP_FACTOR
PHENO DOSEMG OCC
'


mod_eso <- mcode(
  "esomeprazole_nagase2020",
  esomeprazole_code
)
N <- 1000


# ------------------------------------------------------------
# Trial doses
# ------------------------------------------------------------

doses_mg <- c(
  10,
  20,
  40
)


dose_levels <- c(
  "10 mg",
  "20 mg",
  "40 mg"
)


# ------------------------------------------------------------
# CYP2C19 phenotypes
# ------------------------------------------------------------

phenotype_table <- tibble(
  
  PHENO = c(
    1,
    2,
    3
  ),
  
  Phenotype = c(
    "Homo-EM",
    "Hetero-EM",
    "PM"
  )
  
)


phenotype_levels <- c(
  "Homo-EM",
  "Hetero-EM",
  "PM"
)


# ------------------------------------------------------------
# Once-daily dosing
# ------------------------------------------------------------

tau <- 24


# Five daily doses:
#
# 0, 24, 48, 72, 96 h
# ------------------------------------------------------------

n_dose <- 5


last_dose <-
  tau *
  (n_dose - 1)


# ------------------------------------------------------------
# Simulation windows
# ------------------------------------------------------------

t_end_sd <- 24

t_end_md <-
  last_dose +
  tau


# Fine grid to characterize absorption phase
delta_sd <- 0.05
delta_md <- 0.05



# ============================================================
# HELPER FUNCTIONS
# ============================================================

at_time <- function(
    time,
    value,
    target
) {
  
  value[
    which.min(
      abs(
        time - target
      )
    )
  ]
  
}



auc_trap <- function(
    time,
    conc
) {
  
  sum(
    diff(time) *
      (
        head(conc, -1) +
          tail(conc, -1)
      ) / 2
  )
  
}



# ------------------------------------------------------------
# Typical-value model
#
# Remove:
# - CL IIV
# - KTR IOV
# - residual error
# ------------------------------------------------------------

mod_typ <- zero_re(
  mod_eso
)



# ============================================================
# PUBLISHED CLEARANCE CHECK
# ============================================================

clearance_check <- expand_grid(
  
  Dose_mg =
    doses_mg,
  
  PHENO =
    1:3
  
) %>%
  
  mutate(
    
    Phenotype =
      case_when(
        
        PHENO == 1 ~
          "Homo-EM",
        
        PHENO == 2 ~
          "Hetero-EM",
        
        PHENO == 3 ~
          "PM"
        
      ),
    
    
    CYP_FACTOR =
      case_when(
        
        PHENO == 1 ~
          1,
        
        PHENO == 2 ~
          0.24,
        
        PHENO == 3 ~
          0
        
      ),
    
    
    CL_L_h =
      7.37 +
      41.25 *
      CYP_FACTOR *
      exp(
        -0.14 *
          Dose_mg
      )
    
  )


clearance_check





# ============================================================
# FIGURE 1
# TYPICAL PATIENT — SINGLE ORAL DOSE
#
# NOTE:
# The clearance relationship represents the Day-5 empirical
# dose effect from Nagase et al.
# ============================================================

fig1_list <- list()

counter <- 1


for(p in seq_len(
  nrow(
    phenotype_table
  )
)) {
  
  
  for(d in doses_mg) {
    
    
    pheno_i <-
      phenotype_table$PHENO[p]
    
    
    pheno_label <-
      phenotype_table$Phenotype[p]
    
    
    idata_typ <- tibble(
      
      ID = 1,
      
      PHENO =
        pheno_i,
      
      DOSEMG =
        d,
      
      OCC =
        1
      
    )
    
    
    ev_sd <- ev(
      
      time = 0,
      
      amt = d,
      
      cmt = 1
      
    )
    
    
    fig1_list[[counter]] <-
      
      mod_typ %>%
      
      ev(
        ev_sd
      ) %>%
      
      mrgsim(
        
        idata =
          idata_typ,
        
        end =
          t_end_sd,
        
        delta =
          delta_sd
        
      ) %>%
      
      as_tibble() %>%
      
      mutate(
        
        Dose =
          paste0(
            d,
            " mg"
          ),
        
        Phenotype =
          pheno_label
        
      )
    
    
    counter <-
      counter + 1
    
  }
  
}



fig1_out <- bind_rows(
  fig1_list
) %>%
  
  mutate(
    
    Dose =
      factor(
        Dose,
        levels =
          dose_levels
      ),
    
    Phenotype =
      factor(
        Phenotype,
        levels =
          phenotype_levels
      )
    
  )



p1_eso <- ggplot(
  
  fig1_out,
  
  aes(
    time,
    CP_ngmL,
    color = Dose
  )
  
) +
  
  geom_line(
    linewidth = 1
  ) +
  
  facet_wrap(
    ~Phenotype,
    scales = "free_y"
  ) +
  
  theme_bw() +
  
  labs(
    
    x =
      "Time (h)",
    
    y =
      "Esomeprazole concentration (ng/mL)",
    
    color =
      "Dose",
    
    title =
      "Figure 1. Esomeprazole single oral dose"
    
  )


p1_eso



# ============================================================
# FIGURE 1 SUMMARY
# FIRST 24-HOUR INTERVAL
# ============================================================

fig1_summary <- fig1_out %>%
  
  filter(
    time <= tau
  ) %>%
  
  group_by(
    Phenotype,
    Dose
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      time[
        which.max(
          CP_ngmL
        )
      ],
    
    C24 =
      at_time(
        time,
        CP_ngmL,
        tau
      ),
    
    AUC0_24 =
      auc_trap(
        time,
        CP_ngmL
      ),
    
    .groups =
      "drop"
    
  )


fig1_summary





# ============================================================
# FIGURE 2
# TYPICAL PATIENT
# ORAL QD FOR FIVE DAYS
# ============================================================

fig2_list <- list()

counter <- 1


for(p in seq_len(
  nrow(
    phenotype_table
  )
)) {
  
  
  for(d in doses_mg) {
    
    
    pheno_i <-
      phenotype_table$PHENO[p]
    
    
    pheno_label <-
      phenotype_table$Phenotype[p]
    
    
    idata_typ <- tibble(
      
      ID = 1,
      
      PHENO =
        pheno_i,
      
      DOSEMG =
        d,
      
      OCC =
        1
      
    )
    
    
    ev_md <- ev(
      
      time = 0,
      
      amt = d,
      
      cmt = 1,
      
      ii =
        tau,
      
      addl =
        n_dose - 1
      
    )
    
    
    fig2_list[[counter]] <-
      
      mod_typ %>%
      
      ev(
        ev_md
      ) %>%
      
      mrgsim(
        
        idata =
          idata_typ,
        
        end =
          t_end_md,
        
        delta =
          delta_md
        
      ) %>%
      
      as_tibble() %>%
      
      mutate(
        
        Dose =
          paste0(
            d,
            " mg"
          ),
        
        Phenotype =
          pheno_label,
        
        time_day =
          time / 24
        
      )
    
    
    counter <-
      counter + 1
    
  }
  
}



fig2_out <- bind_rows(
  fig2_list
) %>%
  
  mutate(
    
    Dose =
      factor(
        Dose,
        levels =
          dose_levels
      ),
    
    Phenotype =
      factor(
        Phenotype,
        levels =
          phenotype_levels
      )
    
  )



p2_eso <- ggplot(
  
  fig2_out,
  
  aes(
    time_day,
    CP_ngmL,
    color = Dose
  )
  
) +
  
  geom_line(
    linewidth = 1
  ) +
  
  facet_wrap(
    ~Phenotype,
    scales = "free_y"
  ) +
  
  theme_bw() +
  
  labs(
    
    x =
      "Time (days)",
    
    y =
      "Esomeprazole concentration (ng/mL)",
    
    color =
      "Dose",
    
    title =
      "Figure 2. Esomeprazole once daily for five days"
    
  )


p2_eso



# ============================================================
# FIGURE 2 SUMMARY
# DAY-5 DOSING INTERVAL: 96-120 h
# ============================================================

fig2_summary <- fig2_out %>%
  
  filter(
    
    time >=
      last_dose,
    
    time <=
      last_dose +
      tau
    
  ) %>%
  
  mutate(
    
    t_rel =
      time -
      last_dose
    
  ) %>%
  
  group_by(
    Phenotype,
    Dose
  ) %>%
  
  summarise(
    
    Cmax_day5 =
      max(
        CP_ngmL
      ),
    
    Tmax_day5_h =
      t_rel[
        which.max(
          CP_ngmL
        )
      ],
    
    Ctrough_day5 =
      at_time(
        t_rel,
        CP_ngmL,
        tau
      ),
    
    AUCtau_day5 =
      auc_trap(
        t_rel,
        CP_ngmL
      ),
    
    .groups =
      "drop"
    
  )


fig2_summary






make_eso_population <- function(
    
  dose_mg,
  
  pheno,
  
  multiple = FALSE,
  
  id_offset = 0
  
) {
  
  
  ids <-
    id_offset +
    seq_len(N)
  
  
  subjects <- tibble(
    
    ID =
      ids,
    
    PHENO =
      pheno,
    
    DOSEMG =
      dose_mg
    
  )
  
  
  # ==========================================================
  # SINGLE DOSE
  # ==========================================================
  
  if(!multiple) {
    
    
    dose_rows <- subjects %>%
      
      transmute(
        
        ID,
        
        time =
          0,
        
        evid =
          1,
        
        cmt =
          1,
        
        amt =
          dose_mg,
        
        PHENO,
        
        DOSEMG,
        
        OCC =
          1
        
      )
    
    
    obs_times <-
      seq(
        0,
        t_end_sd,
        by =
          delta_sd
      )
    
    
    obs_rows <- crossing(
      
      subjects,
      
      time =
        obs_times
      
    ) %>%
      
      mutate(
        
        evid =
          0,
        
        cmt =
          0,
        
        amt =
          0,
        
        OCC =
          1
        
      )
    
    
    # ==========================================================
    # MULTIPLE DOSE
    # ==========================================================
    
  } else {
    
    
    dose_times <-
      seq(
        
        0,
        
        by =
          tau,
        
        length.out =
          n_dose
        
      )
    
    
    dose_rows <- crossing(
      
      subjects,
      
      dose_number =
        seq_len(
          n_dose
        )
      
    ) %>%
      
      mutate(
        
        time =
          (
            dose_number -
              1
          ) *
          tau,
        
        evid =
          1,
        
        cmt =
          1,
        
        amt =
          dose_mg,
        
        OCC =
          dose_number
        
      ) %>%
      
      select(
        
        ID,
        time,
        evid,
        cmt,
        amt,
        PHENO,
        DOSEMG,
        OCC
        
      )
    
    
    obs_times <-
      seq(
        0,
        t_end_md,
        by =
          delta_md
      )
    
    
    obs_rows <- crossing(
      
      subjects,
      
      time =
        obs_times
      
    ) %>%
      
      mutate(
        
        evid =
          0,
        
        cmt =
          0,
        
        amt =
          0,
        
        OCC =
          pmin(
            floor(
              time /
                tau
            ) +
              1,
            n_dose
          )
        
      )
    
  }
  
  
  # ----------------------------------------------------------
  # Combine dosing and observation records
  # ----------------------------------------------------------
  
  bind_rows(
    
    dose_rows,
    
    obs_rows
    
  ) %>%
    
    arrange(
      
      ID,
      
      time,
      
      desc(
        evid
      )
      
    )
  
}





# ============================================================
# FIGURE 3
# POPULATION — SINGLE ORAL DOSE
# ============================================================

set.seed(123)


fig3_list <- list()

counter <- 1


for(p in seq_len(
  nrow(
    phenotype_table
  )
)) {
  
  
  for(d in doses_mg) {
    
    
    pheno_i <-
      phenotype_table$PHENO[p]
    
    
    pheno_label <-
      phenotype_table$Phenotype[p]
    
    
    data_i <-
      make_eso_population(
        
        dose_mg =
          d,
        
        pheno =
          pheno_i,
        
        multiple =
          FALSE,
        
        id_offset =
          (
            counter -
              1
          ) *
          N
        
      )
    
    
    fig3_list[[counter]] <-
      
      mod_eso %>%
      
      data_set(
        data_i
      ) %>%
      
      mrgsim(
        carry_out =
          "evid"
      ) %>%
      
      as_tibble() %>%
      
      filter(
        evid == 0
      ) %>%
      
      mutate(
        
        Dose =
          paste0(
            d,
            " mg"
          ),
        
        Phenotype =
          pheno_label
        
      )
    
    
    counter <-
      counter + 1
    
  }
  
}



fig3_raw <- bind_rows(
  fig3_list
) %>%
  
  mutate(
    
    Dose =
      factor(
        Dose,
        levels =
          dose_levels
      ),
    
    Phenotype =
      factor(
        Phenotype,
        levels =
          phenotype_levels
      )
    
  )



# ============================================================
# FIGURE 3 POPULATION SUMMARY
# ============================================================

fig3_sum <- fig3_raw %>%
  
  group_by(
    
    Phenotype,
    
    Dose,
    
    time
    
  ) %>%
  
  summarise(
    
    CP_med =
      median(
        CP_ngmL
      ),
    
    CP_p05 =
      quantile(
        CP_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_ngmL,
        0.95
      ),
    
    .groups =
      "drop"
    
  )



p3_eso <- ggplot(
  
  fig3_sum,
  
  aes(
    
    time,
    
    CP_med,
    
    color =
      Dose,
    
    fill =
      Dose
    
  )
  
) +
  
  geom_ribbon(
    
    aes(
      
      ymin =
        CP_p05,
      
      ymax =
        CP_p95
      
    ),
    
    alpha =
      0.25,
    
    colour =
      NA
    
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  facet_wrap(
    
    ~Phenotype,
    
    scales =
      "free_y"
    
  ) +
  
  theme_bw() +
  
  labs(
    
    x =
      "Time (h)",
    
    y =
      "Esomeprazole concentration (ng/mL)",
    
    color =
      "Dose",
    
    fill =
      "Dose",
    
    title =
      "Figure 3. Esomeprazole single oral dose, population",
    
    subtitle =
      "Median with 5th–95th percentiles"
    
  )


p3_eso



# ============================================================
# FIGURE 3 INDIVIDUAL PK METRICS
# ============================================================

fig3_ind <- fig3_raw %>%
  
  filter(
    time <= tau
  ) %>%
  
  arrange(
    
    Phenotype,
    
    Dose,
    
    ID,
    
    time
    
  ) %>%
  
  group_by(
    
    Phenotype,
    
    Dose,
    
    ID
    
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      time[
        which.max(
          CP_ngmL
        )
      ],
    
    C24 =
      at_time(
        time,
        CP_ngmL,
        tau
      ),
    
    AUC0_24 =
      auc_trap(
        time,
        CP_ngmL
      ),
    
    .groups =
      "drop"
    
  )



fig3_summary <- fig3_ind %>%
  
  group_by(
    Phenotype,
    Dose
  ) %>%
  
  summarise(
    
    Cmax_med =
      median(
        Cmax
      ),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(
        Tmax_h
      ),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    C24_med =
      median(
        C24
      ),
    
    C24_p05 =
      quantile(
        C24,
        0.05
      ),
    
    C24_p95 =
      quantile(
        C24,
        0.95
      ),
    
    
    AUC0_24_med =
      median(
        AUC0_24
      ),
    
    AUC0_24_p05 =
      quantile(
        AUC0_24,
        0.05
      ),
    
    AUC0_24_p95 =
      quantile(
        AUC0_24,
        0.95
      ),
    
    .groups =
      "drop"
    
  )


fig3_summary




set.seed(123)


fig4_list <- list()

counter <- 1


for(p in seq_len(
  nrow(
    phenotype_table
  )
)) {
  
  
  for(d in doses_mg) {
    
    
    pheno_i <-
      phenotype_table$PHENO[p]
    
    
    pheno_label <-
      phenotype_table$Phenotype[p]
    
    
    data_i <-
      make_eso_population(
        
        dose_mg =
          d,
        
        pheno =
          pheno_i,
        
        multiple =
          TRUE,
        
        id_offset =
          (
            counter -
              1
          ) *
          N
        
      )
    
    
    fig4_list[[counter]] <-
      
      mod_eso %>%
      
      data_set(
        data_i
      ) %>%
      
      mrgsim(
        carry_out =
          "evid"
      ) %>%
      
      as_tibble() %>%
      
      filter(
        evid == 0
      ) %>%
      
      mutate(
        
        Dose =
          paste0(
            d,
            " mg"
          ),
        
        Phenotype =
          pheno_label,
        
        time_day =
          time /
          24
        
      )
    
    
    counter <-
      counter + 1
    
  }
  
}



fig4_raw <- bind_rows(
  fig4_list
) %>%
  
  mutate(
    
    Dose =
      factor(
        Dose,
        levels =
          dose_levels
      ),
    
    Phenotype =
      factor(
        Phenotype,
        levels =
          phenotype_levels
      )
    
  )







fig4_sum <- fig4_raw %>%
  
  group_by(
    
    Phenotype,
    
    Dose,
    
    time,
    
    time_day
    
  ) %>%
  
  summarise(
    
    CP_med =
      median(
        CP_ngmL
      ),
    
    CP_p05 =
      quantile(
        CP_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_ngmL,
        0.95
      ),
    
    .groups =
      "drop"
    
  )



p4_eso <- ggplot(
  
  fig4_sum,
  
  aes(
    
    time_day,
    
    CP_med,
    
    color =
      Dose,
    
    fill =
      Dose
    
  )
  
) +
  
  geom_ribbon(
    
    aes(
      
      ymin =
        CP_p05,
      
      ymax =
        CP_p95
      
    ),
    
    alpha =
      0.25,
    
    colour =
      NA
    
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  facet_wrap(
    
    ~Phenotype,
    
    scales =
      "free_y"
    
  ) +
  
  theme_bw() +
  
  labs(
    
    x =
      "Time (days)",
    
    y =
      "Esomeprazole concentration (ng/mL)",
    
    color =
      "Dose",
    
    fill =
      "Dose",
    
    title =
      "Figure 4. Esomeprazole once daily for five days, population",
    
    subtitle =
      "Median with 5th–95th percentiles"
    
  )


p4_eso

fig4_ind <- fig4_raw %>%
  
  filter(
    
    time >=
      last_dose,
    
    time <=
      last_dose +
      tau
    
  ) %>%
  
  mutate(
    
    t_rel =
      time -
      last_dose
    
  ) %>%
  
  arrange(
    
    Phenotype,
    
    Dose,
    
    ID,
    
    t_rel
    
  ) %>%
  
  group_by(
    
    Phenotype,
    
    Dose,
    
    ID
    
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      t_rel[
        which.max(
          CP_ngmL
        )
      ],
    
    Ctrough =
      at_time(
        t_rel,
        CP_ngmL,
        tau
      ),
    
    AUCtau =
      auc_trap(
        t_rel,
        CP_ngmL
      ),
    
    .groups =
      "drop"
    
  )



fig4_summary <- fig4_ind %>%
  
  group_by(
    Phenotype,
    Dose
  ) %>%
  
  summarise(
    
    Cmax_med =
      median(
        Cmax
      ),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(
        Tmax_h
      ),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    Ctrough_med =
      median(
        Ctrough
      ),
    
    Ctrough_p05 =
      quantile(
        Ctrough,
        0.05
      ),
    
    Ctrough_p95 =
      quantile(
        Ctrough,
        0.95
      ),
    
    
    AUCtau_med =
      median(
        AUCtau
      ),
    
    AUCtau_p05 =
      quantile(
        AUCtau,
        0.05
      ),
    
    AUCtau_p95 =
      quantile(
        AUCtau,
        0.95
      ),
    
    .groups =
      "drop"
    
  )


fig4_summary