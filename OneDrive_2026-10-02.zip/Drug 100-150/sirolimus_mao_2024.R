library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

sirolimus_code <- '
$PROB
Sirolimus population PK model

- Ref:
  Mao J, Cheng Y, Liu D, Zhang B, Li X.
  Dosing Regimen Recommendations for Sirolimus in Adult Liver
  Transplant Recipients: Insights from a Population
  Pharmacokinetic Model.
  Drug Des Devel Ther. 2024;18:6379-6388.
  doi:10.2147/DDDT.S503463

- Adult liver transplant recipients
- One-compartment disposition
- First-order oral absorption
- First-order elimination
- Hematocrit covariate on apparent clearance

IMPORTANT:
CL and V are apparent oral parameters (CL/F and V/F).
No additional bioavailability term should be applied.

The source dataset contained trough concentrations only.
KA was fixed at 0.75 1/h.

$PARAM @annotated
KA       : 0.75    : 1/h     First-order absorption rate constant, fixed
CL       : 7.09    : L/h     Apparent clearance at HCT = 38%
V        : 496     : L       Apparent volume of distribution
TH_HCT   : -0.901  : --      Hematocrit effect on CL/F
HCT      : 38      : %       Hematocrit
PROP_SD  : 0.033   : --      Proportional residual SD

$CMT @annotated
DEPOT : Oral absorption compartment (mg)
CENT  : Central compartment (mg)

$OMEGA @block @labels ETA_CL ETA_V
0.104976
0.0665 0.182329

$SIGMA
1

$GLOBAL
double CLi;
double Vi;
double KAi;

$MAIN

KAi = KA;

CLi =
  CL *
  pow(HCT / 38.0, TH_HCT) *
  exp(ETA(1));

Vi =
  V *
  exp(ETA(2));


$ODE

dxdt_DEPOT =
  - KAi * DEPOT;

dxdt_CENT =
    KAi * DEPOT
  - (CLi / Vi) * CENT;


$TABLE

// CENT / V = mg/L
// 1000 converts mg/L -> ng/mL

double CP_ngmL =
  1000.0 * CENT / Vi;

double DV_PK =
  CP_ngmL *
  (1.0 + PROP_SD * EPS(1));


$CAPTURE
CP_ngmL DV_PK
KAi CLi Vi HCT
'


mod_siro <- mcode(
  "sirolimus_mao2024",
  sirolimus_code
)



N <- 1000

doses_mg <- c(
  0.5,
  1,
  1.5,
  2
)

dose_levels <- paste0(
  doses_mg,
  " mg"
)

# Typical / reference hematocrit
HCT_typ <- 38

# Once-daily dosing
tau <- 24

# Show 7 days of steady-state dosing
n_dose <- 7

last_dose <- tau * (n_dose - 1)

# Single-dose simulation
t_end_sd <- 96

# Multiple-dose / SS simulation
t_end_md <- last_dose + tau

delta_sd <- 0.1
delta_md <- 0.1


at_time <- function(time, value, target) {
  
  value[
    which.min(
      abs(time - target)
    )
  ]
  
}


auc_trap <- function(time, conc) {
  
  sum(
    diff(time) *
      (
        head(conc, -1) +
          tail(conc, -1)
      ) / 2
  )
  
}

mod_typ <- zero_re(mod_siro)



fig1_list <- lapply(
  doses_mg,
  function(d) {
    
    idata_typ <- tibble(
      ID = 1,
      HCT = HCT_typ
    )
    
    ev_sd <- ev(
      time = 0,
      amt = d,
      cmt = 1
    )
    
    mod_typ %>%
      
      ev(ev_sd) %>%
      
      mrgsim(
        idata = idata_typ,
        end = t_end_sd,
        delta = delta_sd
      ) %>%
      
      as_tibble() %>%
      
      mutate(
        Dose = paste0(
          d,
          " mg"
        ),
        time_day = time / 24
      )
  }
)



fig1_out <- bind_rows(
  fig1_list
) %>%
  
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )



p1_siro <- ggplot(
  fig1_out,
  aes(
    time_day,
    CP_ngmL,
    color = Dose
  )
) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (days)",
    y = "Sirolimus concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Sirolimus single dose"
  )


p1_siro


fig1_summary <- fig1_out %>%
  
  filter(
    time <= tau
  ) %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax =
      max(CP_ngmL),
    
    Tmax_h =
      time[
        which.max(CP_ngmL)
      ],
    
    C24 =
      at_time(
        time,
        CP_ngmL,
        tau
      ),
    
    AUC0_24 =
      auc_trap(
        time,
        CP_ngmL
      ),
    
    .groups = "drop"
  )


fig1_summary




fig2_list <- lapply(
  doses_mg,
  function(d) {
    
    idata_typ <- tibble(
      ID = 1,
      HCT = HCT_typ
    )
    
    ev_md <- ev(
      time = 0,
      amt = d,
      cmt = 1,
      ii = tau,
      addl = n_dose - 1,
      ss = 1
    )
    
    mod_typ %>%
      
      ev(ev_md) %>%
      
      mrgsim(
        idata = idata_typ,
        end = t_end_md,
        delta = delta_md
      ) %>%
      
      as_tibble() %>%
      
      mutate(
        
        Dose =
          paste0(
            d,
            " mg"
          ),
        
        time_day =
          time / 24
      )
  }
)



fig2_out <- bind_rows(
  fig2_list
) %>%
  
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )



p2_siro <- ggplot(
  fig2_out,
  aes(
    time_day,
    CP_ngmL,
    color = Dose
  )
) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (days)",
    y = "Sirolimus concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Sirolimus once daily at steady state"
  )


p2_siro





fig2_summary <- fig2_out %>%
  
  filter(
    time >= last_dose,
    time <= last_dose + tau
  ) %>%
  
  mutate(
    t_rel =
      time - last_dose
  ) %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax_ss =
      max(CP_ngmL),
    
    Tmax_ss_h =
      t_rel[
        which.max(CP_ngmL)
      ],
    
    Ctrough_ss =
      at_time(
        t_rel,
        CP_ngmL,
        tau
      ),
    
    AUCtau_ss =
      auc_trap(
        t_rel,
        CP_ngmL
      ),
    
    .groups = "drop"
  )


fig2_summary




set.seed(123)


fig3_list <- lapply(
  doses_mg,
  function(d) {
    
    idata_pop <- tibble(
      ID = 1:N,
      HCT = HCT_typ
    )
    
    ev_sd <- ev(
      time = 0,
      amt = d,
      cmt = 1
    )
    
    mod_siro %>%
      
      ev(ev_sd) %>%
      
      mrgsim(
        idata = idata_pop,
        end = t_end_sd,
        delta = delta_sd
      ) %>%
      
      as_tibble() %>%
      
      mutate(
        
        Dose =
          paste0(
            d,
            " mg"
          ),
        
        time_day =
          time / 24
      )
  }
)



fig3_raw <- bind_rows(
  fig3_list
) %>%
  
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )




fig3_sum <- fig3_raw %>%
  
  group_by(
    Dose,
    time,
    time_day
  ) %>%
  
  summarise(
    
    CP_med =
      median(
        CP_ngmL
      ),
    
    CP_p05 =
      quantile(
        CP_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_ngmL,
        0.95
      ),
    
    .groups = "drop"
  )



p3_siro <- ggplot(
  fig3_sum,
  aes(
    time_day,
    CP_med,
    color = Dose,
    fill = Dose
  )
) +
  
  geom_ribbon(
    aes(
      ymin = CP_p05,
      ymax = CP_p95
    ),
    alpha = 0.25,
    colour = NA
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (days)",
    y = "Sirolimus concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Sirolimus single dose, population",
    subtitle = "Median with 5th–95th percentiles"
  )


p3_siro






fig3_ind <- fig3_raw %>%
  
  filter(
    time <= tau
  ) %>%
  
  arrange(
    Dose,
    ID,
    time
  ) %>%
  
  group_by(
    Dose,
    ID
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      time[
        which.max(
          CP_ngmL
        )
      ],
    
    C24 =
      at_time(
        time,
        CP_ngmL,
        tau
      ),
    
    AUC0_24 =
      auc_trap(
        time,
        CP_ngmL
      ),
    
    .groups = "drop"
  )



fig3_summary <- fig3_ind %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax_med =
      median(Cmax),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(Tmax_h),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    C24_med =
      median(C24),
    
    C24_p05 =
      quantile(
        C24,
        0.05
      ),
    
    C24_p95 =
      quantile(
        C24,
        0.95
      ),
    
    
    AUC0_24_med =
      median(AUC0_24),
    
    AUC0_24_p05 =
      quantile(
        AUC0_24,
        0.05
      ),
    
    AUC0_24_p95 =
      quantile(
        AUC0_24,
        0.95
      ),
    
    .groups = "drop"
  )


fig3_summary






set.seed(123)


fig4_list <- lapply(
  doses_mg,
  function(d) {
    
    idata_pop <- tibble(
      ID = 1:N,
      HCT = HCT_typ
    )
    
    ev_md <- ev(
      time = 0,
      amt = d,
      cmt = 1,
      ii = tau,
      addl = n_dose - 1,
      ss = 1
    )
    
    mod_siro %>%
      
      ev(ev_md) %>%
      
      mrgsim(
        idata = idata_pop,
        end = t_end_md,
        delta = delta_md
      ) %>%
      
      as_tibble() %>%
      
      mutate(
        
        Dose =
          paste0(
            d,
            " mg"
          ),
        
        time_day =
          time / 24
      )
  }
)



fig4_raw <- bind_rows(
  fig4_list
) %>%
  
  mutate(
    Dose = factor(
      Dose,
      levels = dose_levels
    )
  )




fig4_sum <- fig4_raw %>%
  
  group_by(
    Dose,
    time,
    time_day
  ) %>%
  
  summarise(
    
    CP_med =
      median(
        CP_ngmL
      ),
    
    CP_p05 =
      quantile(
        CP_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_ngmL,
        0.95
      ),
    
    .groups = "drop"
  )



p4_siro <- ggplot(
  fig4_sum,
  aes(
    time_day,
    CP_med,
    color = Dose,
    fill = Dose
  )
) +
  
  geom_ribbon(
    aes(
      ymin = CP_p05,
      ymax = CP_p95
    ),
    alpha = 0.25,
    colour = NA
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  theme_bw() +
  
  labs(
    x = "Time (days)",
    y = "Sirolimus concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Sirolimus once daily at steady state, population",
    subtitle = "Median with 5th–95th percentiles"
  )


p4_siro






fig4_ind <- fig4_raw %>%
  
  filter(
    time >= last_dose,
    time <= last_dose + tau
  ) %>%
  
  mutate(
    t_rel =
      time - last_dose
  ) %>%
  
  arrange(
    Dose,
    ID,
    t_rel
  ) %>%
  
  group_by(
    Dose,
    ID
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      t_rel[
        which.max(
          CP_ngmL
        )
      ],
    
    Ctrough =
      at_time(
        t_rel,
        CP_ngmL,
        tau
      ),
    
    AUCtau =
      auc_trap(
        t_rel,
        CP_ngmL
      ),
    
    .groups = "drop"
  )



fig4_summary <- fig4_ind %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax_med =
      median(Cmax),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(Tmax_h),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    Ctrough_med =
      median(Ctrough),
    
    Ctrough_p05 =
      quantile(
        Ctrough,
        0.05
      ),
    
    Ctrough_p95 =
      quantile(
        Ctrough,
        0.95
      ),
    
    
    AUCtau_med =
      median(AUCtau),
    
    AUCtau_p05 =
      quantile(
        AUCtau,
        0.05
      ),
    
    AUCtau_p95 =
      quantile(
        AUCtau,
        0.95
      ),
    
    .groups = "drop"
  )


fig4_summary