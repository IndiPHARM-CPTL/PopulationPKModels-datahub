library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

aliskiren_code <- '
$PROB
- Ref: Hong Y, Dingemanse J, Mager DE. Pharmacokinetic/pharmacodynamic modeling of renin biomarkers in subjects treated with the renin inhibitor aliskiren. Clin Pharmacol Ther. 2008;84(1):136-143. doi:10.1038/sj.clpt.6100495

$PARAM @annotated
KA        : 0.0748 : 1/h     Absorption rate constant
VC        : 176    : L       Apparent central volume Vc/F
VM1_UG_H  : 812    : ug/h    Michaelis-Menten elimination capacity
KM1       : 0.516  : ng/mL   Michaelis-Menten elimination constant
VM2_UG_H  : 87480  : ug/h    Michaelis-Menten distribution capacity
KM2       : 135    : ng/mL   Michaelis-Menten distribution constant
K21       : 0.00248: 1/h     Peripheral-to-central return rate constant

PROP_SD   : 0.263  : --      Proportional residual SD
USE_VAR   : 0      : --      0 = deterministic; 1 = pseudo-population variability

$CMT @annotated
DEPOT  : Oral absorption compartment
CENT   : Central compartment
PERIPH : Peripheral compartment

$OMEGA @diag @labels ETA_KA ETA_VC ETA_VM1 ETA_KM1 ETA_VM2 ETA_KM2 ETA_K21
0.00396 0.04730 0.09750 0.42700 0.01676 0.03550 0.01940

$SIGMA
1

$GLOBAL
double SCALE;

double KAi;
double VCi;
double VM1i;
double KM1i;
double VM2i;
double KM2i;
double K21i;

double CP_ODE;
double ELIM_MM;
double DIST_MM;

$MAIN
SCALE = 0.0;
if(USE_VAR > 0.5) SCALE = 1.0;

KAi   = KA              * exp(SCALE * ETA(1));
VCi   = VC              * exp(SCALE * ETA(2));
VM1i  = VM1_UG_H/1000.0 * exp(SCALE * ETA(3)); // mg/h
KM1i  = KM1             * exp(SCALE * ETA(4)); // ng/mL
VM2i  = VM2_UG_H/1000.0 * exp(SCALE * ETA(5)); // mg/h
KM2i  = KM2             * exp(SCALE * ETA(6)); // ng/mL
K21i  = K21             * exp(SCALE * ETA(7));

$ODE
CP_ODE = (CENT / VCi) * 1000.0; // ng/mL

ELIM_MM = VM1i * CP_ODE / (KM1i + CP_ODE);
DIST_MM = VM2i * CP_ODE / (KM2i + CP_ODE);

dxdt_DEPOT  = -KAi * DEPOT;

dxdt_CENT   =  KAi * DEPOT
             - ELIM_MM
             - DIST_MM
             + K21i * PERIPH;

dxdt_PERIPH =  DIST_MM
             - K21i * PERIPH;

$TABLE
double CP_mgL  = CENT / VCi;
double CP_ngmL = CP_mgL * 1000.0;
double DV_ngmL = CP_ngmL * exp(PROP_SD * EPS(1));

$CAPTURE
CP_mgL CP_ngmL DV_ngmL
KAi VCi VM1i KM1i VM2i KM2i K21i
ELIM_MM DIST_MM USE_VAR
'
mod <- mcode("aliskiren_pk_hong2008", aliskiren_code)

set.seed(123)

dose_mg <- c(150, 300)

N        <- 1000
tau_h    <- 24
n_doses  <- 10
addl_md  <- n_doses - 1

t_end_sd <- 24
t_end_md <- 240

delta_sd <- 0.1
delta_md <- 0.1

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- zero_re(mod) %>%
  param(USE_VAR = 0)

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:N)


fig1_list <- lapply(dose_mg, function(d) {
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = CP_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_out, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Aliskiren concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Aliskiren 150/300mg once-daily, single dose"
  )

fig1_summary <- fig1_out %>%
  group_by(Dose) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C24  = get_nearest(time, CP, 24),
    .groups = "drop"
  )


fig2_list <- lapply(dose_mg, function(d) {
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = CP_ngmL,
      Dose = paste0(d, " mg q24h x", n_doses)
    )
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_out, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Aliskiren concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Aliskiren 150/300mg once-daily multi-dose"
  )

fig2_summary <- fig2_out %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose) %>%
  summarise(
    Cmax_ss = max(CP, na.rm = TRUE),
    Tmax_ss = time[which.max(CP)] - (n_doses - 1) * tau_h,
    Ctrough = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )


fig3_list <- lapply(dose_mg, function(d) {
  ev_sd <- ev(time = 0, amt = d, cmt = "DEPOT")
  
  mod %>%
    param(USE_VAR = 1) %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(
      CP = CP_ngmL,
      Dose = paste0(d, " mg single dose")
    )
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Aliskiren concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Aliskiren 150/300mg once-daily, single dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C24  = get_nearest(time, CP, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C24_med = median(C24, na.rm = TRUE),
    C24_p05 = quantile(C24, 0.05, na.rm = TRUE),
    C24_p95 = quantile(C24, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


fig4_list <- lapply(dose_mg, function(d) {
  ev_md <- ev(
    time = 0,
    amt  = d,
    cmt  = "DEPOT",
    ii   = tau_h,
    addl = addl_md
  )
  
  mod %>%
    param(USE_VAR = 1) %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(
      CP = CP_ngmL,
      Dose = paste0(d, " mg q24h x", n_doses)
    )
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    C_med = median(CP, na.rm = TRUE),
    C_p05 = quantile(CP, 0.05, na.rm = TRUE),
    C_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Aliskiren concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Aliskiren 150/300mg once-daily, multi-dose, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= (n_doses - 1) * tau_h, time <= t_end_md) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_ss = max(CP, na.rm = TRUE),
    Tmax_ss = time[which.max(CP)] - (n_doses - 1) * tau_h,
    Ctrough = get_nearest(time, CP, t_end_md),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax_ss, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax_ss, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax_ss, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax_ss, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax_ss, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax_ss, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary

