library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

medroxyprogesterone_code <- '

$PROB
Depot Medroxyprogesterone Acetate population PK model

- Ref: Francis J, Mngqibisa R, McIlleron H, et al.
  A Semimechanistic Pharmacokinetic Model for Depot
  Medroxyprogesterone Acetate and Drug-Drug Interactions
  With Antiretroviral and Antituberculosis Treatment.
  Clin Pharmacol Ther. 2021;110(4):1057-1065.
  doi:10.1002/cpt.2324

$PARAM @annotated

CL        : 47.2   : L/h     Clearance at 62.5 kg
V         : 8910   : L       Volume at 62.5 kg

KA_DAY    : 0.578  : 1/day   First-order absorption rate
FFAST     : 0.24   : --      Fast absorption fraction

MTT_DAY   : 11.6   : day     Mean transit time for slow release
NTR       : 0.954  : --      Estimated number of transit compartments
KREL_DAY  : 0.0193 : 1/day   Final release rate constant

WTKG      : 62.5   : kg      Body weight
DDI       : 0      : --      DDI category

PROP_SD   : 0.177  : --      Proportional residual SD
ADD_SD    : 0.0187 : ng/mL   Additive residual SD, A5093/A5283 assays

$CMT @annotated
ABS     : Common absorption compartment (mg)
TR1     : Slow-release transit compartment 1 (mg)
TR2     : Slow-release transit compartment 2 (mg)
RELEASE : Final crystal-release compartment (mg)
CENT    : Central compartment (mg)


$OMEGA @labels ETA_CL ETA_FFAST ETA_MTT ETA_KREL

// CL BSV = 24.2% CV
0.056913

// Ffast BOV SD = 0.203 in logit space
0.041209

// MTT BOV = 45.5% CV
0.188159

// Krelease BOV = 76.9% CV
0.464590


$SIGMA @labels EPS_PROP EPS_ADD
1
1


$GLOBAL

double CLi;
double Vi;

double KAi;
double MTTi;
double KTRi;
double KRELi;

double FFASTi;
double FSLOWi;

double CL_FACTOR;
double KREL_FACTOR;


$MAIN
CL_FACTOR = 1.0;
KREL_FACTOR = 1.0;


if(DDI == 1) {
  CL_FACTOR = 0.842;
}


if(DDI == 2) {
  CL_FACTOR = 1.247;
}


if(DDI == 3) {
  CL_FACTOR = 0.713;
  KREL_FACTOR = 2.07;
}


if(DDI == 4) {
  CL_FACTOR = 1.524;
}


CLi =
  CL
  * pow(WTKG / 62.5, 0.75)
  * CL_FACTOR
  * exp(ETA(1));


Vi =
  V
  * pow(WTKG / 62.5, 1.0);

double LOGIT_FFAST =
  log(FFAST / (1.0 - FFAST))
  + ETA(2);


FFASTi =
  1.0 /
  (1.0 + exp(-LOGIT_FFAST));


FSLOWi =
  1.0 - FFASTi;


KAi =
  KA_DAY / 24.0;


MTTi =
  MTT_DAY
  * 24.0
  * exp(ETA(3));


KTRi =
  (NTR + 1.0) /
  MTTi;


KRELi =
  (KREL_DAY / 24.0)
  * KREL_FACTOR
  * exp(ETA(4));


F_ABS =
  FFASTi;

F_TR1 =
  FSLOWi;


$ODE

dxdt_ABS =
    KRELi * RELEASE
  - KAi * ABS;


dxdt_TR1 =
  -KTRi * TR1;


dxdt_TR2 =
    KTRi * TR1
  - KTRi * TR2;


dxdt_RELEASE =
    KTRi * TR2
  - KRELi * RELEASE;

dxdt_CENT =
    KAi * ABS
  - (CLi / Vi) * CENT;


$TABLE

// mg / L -> ng / mL
// 1 mg/L = 1000 ng/mL

double CP_ngmL =
  1000.0 * CENT / Vi;


// Combined proportional + additive residual error

double DV_PK =
    CP_ngmL
    * (1.0 + PROP_SD * EPS(1))
    + ADD_SD * EPS(2);


$CAPTURE

CP_ngmL DV_PK

CLi Vi
KAi MTTi KTRi KRELi

FFASTi FSLOWi

WTKG DDI

'
mod_mpa <- mcode(
  "medroxyprogesterone_acetate_pk",
  medroxyprogesterone_code
)


set.seed(123)

N <- 1000
doses_mg <- c(150)
dose_levels <- c("150 mg IM")
tau <- 12 * 7 * 24

# Five injections, as used in the publication simulations

n_dose <- 5

t_end_sd <- tau

t_end_md <- tau * n_dose

delta_sd <- 6
delta_md <- 12

last_dose <-
  (n_dose - 1) * tau




idata_typ <- tibble(
  ID = 1,
  WTKG = 62.5,
  DDI = 0
)




idata_pop <- tibble(
  ID = 1:N,
  WTKG = 62.5,
  DDI = 0
)


mod_typ <-
  zero_re(mod_mpa)


at_time <- function(
    time,
    value,
    target
) {
  
  value[
    which.min(
      abs(time - target)
    )
  ]
}


auc_trap <- function(
    time,
    conc
) {
  
  sum(
    diff(time) *
      (
        head(conc, -1) +
          tail(conc, -1)
      ) / 2
  )
}




fig1_list <-
  lapply(
    doses_mg,
    function(d) {
    
      
      
      ev_sd <- ev(
        
        time =
          c(0, 0),
        
        amt =
          c(d, d),
        
        cmt =
          c(1, 2)
        
      )
      
      
      mod_typ %>%
        ev(ev_sd) %>%
        mrgsim(
          
          idata =
            idata_typ,
          
          end =
            t_end_sd,
          
          delta =
            delta_sd
          
        ) %>%
        as_tibble() %>%
        mutate(
          
          Dose =
            paste0(
              d,
              " mg IM"
            ),
          
          time_wk =
            time /
            (7 * 24)
          
        )
      
    }
  )


fig1_out <-
  bind_rows(
    fig1_list
  ) %>%
  mutate(
    
    Dose =
      factor(
        Dose,
        levels =
          dose_levels
      )
    
  )


p1_mpa <- ggplot(
  
  fig1_out,
  
  aes(
    time_wk,
    CP_ngmL,
    color = Dose
  )
  
) +
  
  geom_line(
    linewidth = 1
  ) +
  
  geom_hline(
    
    yintercept =
      0.1,
    
    linetype =
      "dashed"
    
  ) +
  
  theme_bw() +
  
  labs(
    
    x =
      "Time (weeks)",
    
    y =
      "Medroxyprogesterone acetate concentration (ng/mL)",
    
    color =
      "Dose",
    
    title =
      "Figure 1. Depot medroxyprogesterone acetate single dose"
    
  )


p1_mpa


fig1_summary <-
  fig1_out %>%
  group_by(
    Dose
  ) %>%
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      time[
        which.max(
          CP_ngmL
        )
      ],
    
    Tmax_day =
      Tmax_h /
      24,
    
    C12wk =
      at_time(
        
        time,
        CP_ngmL,
        tau
        
      ),
    
    AUC0_12wk =
      auc_trap(
        
        time,
        CP_ngmL
        
      ),
    
    .groups =
      "drop"
    
  )


fig1_summary


fig2_list <-
  lapply(
    doses_mg,
    function(d) {
      
      
      ev_md <- ev(
        
        time =
          c(0, 0),
        
        amt =
          c(d, d),
        
        cmt =
          c(1, 2),
        
        ii =
          c(tau, tau),
        
        addl =
          c(
            n_dose - 1,
            n_dose - 1
          )
        
      )
      
      
      mod_typ %>%
        ev(ev_md) %>%
        mrgsim(
          
          idata =
            idata_typ,
          
          end =
            t_end_md,
          
          delta =
            delta_md
          
        ) %>%
        as_tibble() %>%
        mutate(
          
          Dose =
            paste0(
              d,
              " mg IM"
            ),
          
          time_wk =
            time /
            (7 * 24)
          
        )
      
    }
  )


fig2_out <-
  bind_rows(
    fig2_list
  ) %>%
  mutate(
    
    Dose =
      factor(
        Dose,
        levels =
          dose_levels
      )
    
  )


p2_mpa <- ggplot(
  
  fig2_out,
  
  aes(
    time_wk,
    CP_ngmL,
    color = Dose
  )
  
) +
  
  geom_line(
    linewidth = 1
  ) +
  
  geom_hline(
    
    yintercept =
      0.1,
    
    linetype =
      "dashed"
    
  ) +
  
  theme_bw() +
  
  labs(
    
    x =
      "Time (weeks)",
    
    y =
      "Medroxyprogesterone acetate concentration (ng/mL)",
    
    color =
      "Dose",
    
    title =
      "Figure 2. Depot medroxyprogesterone acetate every 12 weeks"
    
  )


p2_mpa


fig2_summary <-
  fig2_out %>%
  
  filter(
    
    time >=
      last_dose,
    
    time <=
      last_dose +
      tau
    
  ) %>%
  
  mutate(
    
    t_rel =
      time -
      last_dose
    
  ) %>%
  
  group_by(
    Dose
  ) %>%
  
  summarise(
    
    Cmax_last =
      max(
        CP_ngmL
      ),
    
    Tmax_last_h =
      t_rel[
        which.max(
          CP_ngmL
        )
      ],
    
    Ctrough_last =
      at_time(
        
        t_rel,
        CP_ngmL,
        tau
        
      ),
    
    AUCtau_last =
      auc_trap(
        
        t_rel,
        CP_ngmL
        
      ),
    
    .groups =
      "drop"
    
  )


fig2_summary




set.seed(123)


fig3_list <-
  lapply(
    doses_mg,
    function(d) {
      
      
      ev_sd <- ev(
        
        time =
          c(0, 0),
        
        amt =
          c(d, d),
        
        cmt =
          c(1, 2)
        
      )
      
      
      mod_mpa %>%
        ev(ev_sd) %>%
        mrgsim(
          
          idata =
            idata_pop,
          
          end =
            t_end_sd,
          
          delta =
            delta_sd
          
        ) %>%
        as_tibble() %>%
        mutate(
          
          Dose =
            paste0(
              d,
              " mg IM"
            ),
          
          time_wk =
            time /
            (7 * 24)
          
        )
      
    }
  )


fig3_raw <-
  bind_rows(
    fig3_list
  ) %>%
  mutate(
    
    Dose =
      factor(
        Dose,
        levels =
          dose_levels
      )
    
  )


fig3_sum <-
  fig3_raw %>%
  group_by(
    
    Dose,
    time,
    time_wk
    
  ) %>%
  summarise(
    
    CP_med =
      median(
        CP_ngmL
      ),
    
    CP_p05 =
      quantile(
        CP_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_ngmL,
        0.95
      ),
    
    .groups =
      "drop"
    
  )


p3_mpa <- ggplot(
  
  fig3_sum,
  
  aes(
    
    time_wk,
    CP_med,
    
    color =
      Dose,
    
    fill =
      Dose
    
  )
  
) +
  
  geom_ribbon(
    
    aes(
      
      ymin =
        CP_p05,
      
      ymax =
        CP_p95
      
    ),
    
    alpha =
      0.25,
    
    colour =
      NA
    
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  geom_hline(
    
    yintercept =
      0.1,
    
    linetype =
      "dashed"
    
  ) +
  
  theme_bw() +
  
  labs(
    
    x =
      "Time (weeks)",
    
    y =
      "Medroxyprogesterone acetate concentration (ng/mL)",
    
    color =
      "Dose",
    
    fill =
      "Dose",
    
    title =
      "Figure 3. Depot medroxyprogesterone acetate single dose, population",
    
    subtitle =
      "Median with 5th–95th percentiles"
    
  )


p3_mpa


fig3_ind <-
  fig3_raw %>%
  
  arrange(
    
    Dose,
    ID,
    time
    
  ) %>%
  
  group_by(
    
    Dose,
    ID
    
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      time[
        which.max(
          CP_ngmL
        )
      ],
    
    C12wk =
      at_time(
        
        time,
        CP_ngmL,
        tau
        
      ),
    
    AUC0_12wk =
      auc_trap(
        
        time,
        CP_ngmL
        
      ),
    
    .groups =
      "drop"
    
  )


fig3_summary <-
  fig3_ind %>%
  group_by(
    Dose
  ) %>%
  summarise(
    
    Cmax_med =
      median(
        Cmax
      ),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(
        Tmax_h
      ),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    C12wk_med =
      median(
        C12wk
      ),
    
    C12wk_p05 =
      quantile(
        C12wk,
        0.05
      ),
    
    C12wk_p95 =
      quantile(
        C12wk,
        0.95
      ),
    
    
    AUC0_12wk_med =
      median(
        AUC0_12wk
      ),
    
    AUC0_12wk_p05 =
      quantile(
        AUC0_12wk,
        0.05
      ),
    
    AUC0_12wk_p95 =
      quantile(
        AUC0_12wk,
        0.95
      ),
    
    .groups =
      "drop"
    
  )


fig3_summary





set.seed(123)


fig4_list <-
  lapply(
    doses_mg,
    function(d) {
      
      
      ev_md <- ev(
        
        time =
          c(0, 0),
        
        amt =
          c(d, d),
        
        cmt =
          c(1, 2),
        
        ii =
          c(tau, tau),
        
        addl =
          c(
            n_dose - 1,
            n_dose - 1
          )
        
      )
      
      
      mod_mpa %>%
        ev(ev_md) %>%
        mrgsim(
          
          idata =
            idata_pop,
          
          end =
            t_end_md,
          
          delta =
            delta_md
          
        ) %>%
        as_tibble() %>%
        mutate(
          
          Dose =
            paste0(
              d,
              " mg IM"
            ),
          
          time_wk =
            time /
            (7 * 24)
          
        )
      
    }
  )


fig4_raw <-
  bind_rows(
    fig4_list
  ) %>%
  mutate(
    
    Dose =
      factor(
        Dose,
        levels =
          dose_levels
      )
    
  )


fig4_sum <-
  fig4_raw %>%
  group_by(
    
    Dose,
    time,
    time_wk
    
  ) %>%
  summarise(
    
    CP_med =
      median(
        CP_ngmL
      ),
    
    CP_p05 =
      quantile(
        CP_ngmL,
        0.05
      ),
    
    CP_p95 =
      quantile(
        CP_ngmL,
        0.95
      ),
    
    .groups =
      "drop"
    
  )


p4_mpa <- ggplot(
  
  fig4_sum,
  
  aes(
    
    time_wk,
    CP_med,
    
    color =
      Dose,
    
    fill =
      Dose
    
  )
  
) +
  
  geom_ribbon(
    
    aes(
      
      ymin =
        CP_p05,
      
      ymax =
        CP_p95
      
    ),
    
    alpha =
      0.25,
    
    colour =
      NA
    
  ) +
  
  geom_line(
    linewidth = 1
  ) +
  
  geom_hline(
    
    yintercept =
      0.1,
    
    linetype =
      "dashed"
    
  ) +
  
  theme_bw() +
  
  labs(
    
    x =
      "Time (weeks)",
    
    y =
      "Medroxyprogesterone acetate concentration (ng/mL)",
    
    color =
      "Dose",
    
    fill =
      "Dose",
    
    title =
      "Figure 4. Depot medroxyprogesterone acetate every 12 weeks, population",
    
    subtitle =
      "Median with 5th–95th percentiles"
    
  )


p4_mpa


fig4_ind <-
  fig4_raw %>%
  
  filter(
    
    time >=
      last_dose,
    
    time <=
      last_dose +
      tau
    
  ) %>%
  
  mutate(
    
    t_rel =
      time -
      last_dose
    
  ) %>%
  
  arrange(
    
    Dose,
    ID,
    t_rel
    
  ) %>%
  
  group_by(
    
    Dose,
    ID
    
  ) %>%
  
  summarise(
    
    Cmax =
      max(
        CP_ngmL
      ),
    
    Tmax_h =
      t_rel[
        which.max(
          CP_ngmL
        )
      ],
    
    Ctrough =
      at_time(
        
        t_rel,
        CP_ngmL,
        tau
        
      ),
    
    AUCtau =
      auc_trap(
        
        t_rel,
        CP_ngmL
        
      ),
    
    .groups =
      "drop"
    
  )


fig4_summary <-
  fig4_ind %>%
  group_by(
    Dose
  ) %>%
  summarise(
    
    Cmax_med =
      median(
        Cmax
      ),
    
    Cmax_p05 =
      quantile(
        Cmax,
        0.05
      ),
    
    Cmax_p95 =
      quantile(
        Cmax,
        0.95
      ),
    
    
    Tmax_med_h =
      median(
        Tmax_h
      ),
    
    Tmax_p05_h =
      quantile(
        Tmax_h,
        0.05
      ),
    
    Tmax_p95_h =
      quantile(
        Tmax_h,
        0.95
      ),
    
    
    Ctrough_med =
      median(
        Ctrough
      ),
    
    Ctrough_p05 =
      quantile(
        Ctrough,
        0.05
      ),
    
    Ctrough_p95 =
      quantile(
        Ctrough,
        0.95
      ),
    
    
    AUCtau_med =
      median(
        AUCtau
      ),
    
    AUCtau_p05 =
      quantile(
        AUCtau,
        0.05
      ),
    
    AUCtau_p95 =
      quantile(
        AUCtau,
        0.95
      ),
    
    .groups =
      "drop"
    
  )


fig4_summary