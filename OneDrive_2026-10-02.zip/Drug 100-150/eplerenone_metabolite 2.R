library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

eplerenone_code <- '
$PROB
Eplerenone and SC-70303 PopPK model with nonlinear protein binding

- Ref: Mori Y, Chiba K, Takahashi H, Ogata H. A Population Approach to Eplerenone Pharmacokinetics and Saturable Protein Binding. Drug Metab Pharmacokinet. 2010;25(6):551-559.

$PARAM @annotated
KA     : 1.73    : 1/h    Absorption rate constant
CL2    : 12.4    : L/h    Eplerenone unbound clearance
VDU    : 148     : L      Eplerenone unbound volume
Q1     : 37.8    : L/h    Eplerenone-to-SC-70303 clearance
Q2     : 123     : L/h    SC-70303-to-eplerenone clearance
CL3    : 136     : L/h    SC-70303 clearance
VD3    : 11      : L      SC-70303 volume

NPT    : 0.00544 : mM     Protein-binding capacity
KD     : 0.00289 : mM     Dissociation constant
NS     : 0.14    : --     Nonspecific binding
MW_EPL : 414.5   : g/mol  Eplerenone molecular weight

$CMT @annotated
DEPOT    : Oral depot compartment
EPL_UNB  : Unbound eplerenone compartment
SC_TOTAL : SC-70303 compartment

$OMEGA @diag @labels ETA_KA ETA_CL2 ETA_VDU ETA_CL3 ETA_NPT ETA_NS
0.497 0.240 0.048 0.236 0.070 0.261

$MAIN
double KAi = KA * exp(ETA_KA);
double CL2i = CL2 * exp(ETA_CL2);
double VDUi = VDU * exp(ETA_VDU);
double CL3i = CL3 * exp(ETA_CL3);
double NPTi = NPT * exp(ETA_NPT);
double NSi = NS * exp(ETA_NS);

double K20i = CL2i / VDUi;
double K23i = Q1 / VDUi;
double K32i = Q2 / VD3;
double K30i = CL3i / VD3;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_EPL_UNB = KAi * DEPOT
               - K20i * EPL_UNB
               - K23i * EPL_UNB
               + K32i * SC_TOTAL;

dxdt_SC_TOTAL = K23i * EPL_UNB
                - K32i * SC_TOTAL
                - K30i * SC_TOTAL;

$TABLE
double C_EPL_UNB_mgL = EPL_UNB / VDUi;
double C_EPL_UNB_mM = C_EPL_UNB_mgL / MW_EPL;

double C_EPL_TOTAL_mM =
  (1.0 + NPTi / (KD + C_EPL_UNB_mM) + NSi) * C_EPL_UNB_mM;

double CP_EPL_ngmL = C_EPL_TOTAL_mM * MW_EPL * 1000.0;
double CP_SC_ngmL = (SC_TOTAL / VD3) * 1000.0;

$CAPTURE CP_EPL_ngmL CP_SC_ngmL
'

mod <- mcode("eplerenone_mori2010", eplerenone_code)

dose_mg <- c(100, 300, 1000)

N <- 1000
tau_h <- 24
n_doses <- 10
addl_md <- n_doses - 1

t_end_sd <- tau_h
t_end_md <- n_doses * tau_h

delta_sd <- 0.1
delta_md <- 0.25

last_dose_h <- (n_doses - 1) * tau_h

dose_levels_sd <- paste0(dose_mg, " mg single dose")
dose_levels_md <- paste0(dose_mg, " mg q24h x", n_doses)

get_nearest <- function(time, conc, target_time) {
  conc[which.min(abs(time - target_time))]
}

mod_typ <- mod %>%
  zero_re() %>%
  Req(CP_EPL_ngmL, CP_SC_ngmL)

mod_pop <- mod %>%
  Req(CP_EPL_ngmL, CP_SC_ngmL)

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:N)




fig1_out <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = "DEPOT")) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(
      ID,
      time,
      CP_EPL = pmax(CP_EPL_ngmL, 0),
      CP_SC = pmax(CP_SC_ngmL, 0),
      Dose = paste0(d, " mg single dose")
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig1_plot <- bind_rows(
  fig1_out %>%
    transmute(time, Dose, Analyte = "Eplerenone total", CP = CP_EPL),
  fig1_out %>%
    transmute(time, Dose, Analyte = "SC-70303", CP = CP_SC)
)

p1 <- ggplot(fig1_plot, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  facet_wrap(~Analyte, scales = "free_y") +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Eplerenone and SC-70303 single dose"
  )

fig1_summary <- bind_rows(
  fig1_out %>%
    group_by(Dose) %>%
    summarise(
      Cmax = max(CP_EPL, na.rm = TRUE),
      Tmax = time[which.max(CP_EPL)],
      C1 = get_nearest(time, CP_EPL, 1),
      C2 = get_nearest(time, CP_EPL, 2),
      C4 = get_nearest(time, CP_EPL, 4),
      C8 = get_nearest(time, CP_EPL, 8),
      C12 = get_nearest(time, CP_EPL, 12),
      Ctrough = get_nearest(time, CP_EPL, tau_h),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "Eplerenone total"),
  
  fig1_out %>%
    group_by(Dose) %>%
    summarise(
      Cmax = max(CP_SC, na.rm = TRUE),
      Tmax = time[which.max(CP_SC)],
      C1 = get_nearest(time, CP_SC, 1),
      C2 = get_nearest(time, CP_SC, 2),
      C4 = get_nearest(time, CP_SC, 4),
      C8 = get_nearest(time, CP_SC, 8),
      C12 = get_nearest(time, CP_SC, 12),
      Ctrough = get_nearest(time, CP_SC, tau_h),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "SC-70303")
) %>%
  select(Dose, Analyte, Cmax, Tmax, C1, C2, C4, C8, C12, Ctrough)


fig2_out <- lapply(dose_mg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(
      time = 0,
      amt = d,
      cmt = "DEPOT",
      ii = tau_h,
      addl = addl_md
    )) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(
      ID,
      time,
      CP_EPL = pmax(CP_EPL_ngmL, 0),
      CP_SC = pmax(CP_SC_ngmL, 0),
      Dose = paste0(d, " mg q24h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig2_plot <- bind_rows(
  fig2_out %>%
    transmute(time, Dose, Analyte = "Eplerenone total", CP = CP_EPL),
  fig2_out %>%
    transmute(time, Dose, Analyte = "SC-70303", CP = CP_SC)
)

p2 <- ggplot(fig2_plot, aes(time / 24, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  facet_wrap(~Analyte, scales = "free_y") +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Eplerenone and SC-70303 multidose"
  )

fig2_summary <- bind_rows(
  fig2_out %>%
    filter(time >= last_dose_h, time <= t_end_md) %>%
    group_by(Dose) %>%
    summarise(
      Cmax_final_interval = max(CP_EPL, na.rm = TRUE),
      Tmax_final_interval = time[which.max(CP_EPL)] - last_dose_h,
      C1_final_interval = get_nearest(time, CP_EPL, last_dose_h + 1),
      C2_final_interval = get_nearest(time, CP_EPL, last_dose_h + 2),
      C4_final_interval = get_nearest(time, CP_EPL, last_dose_h + 4),
      C8_final_interval = get_nearest(time, CP_EPL, last_dose_h + 8),
      C12_final_interval = get_nearest(time, CP_EPL, last_dose_h + 12),
      Ctrough_final_interval = get_nearest(time, CP_EPL, t_end_md),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "Eplerenone total"),
  
  fig2_out %>%
    filter(time >= last_dose_h, time <= t_end_md) %>%
    group_by(Dose) %>%
    summarise(
      Cmax_final_interval = max(CP_SC, na.rm = TRUE),
      Tmax_final_interval = time[which.max(CP_SC)] - last_dose_h,
      C1_final_interval = get_nearest(time, CP_SC, last_dose_h + 1),
      C2_final_interval = get_nearest(time, CP_SC, last_dose_h + 2),
      C4_final_interval = get_nearest(time, CP_SC, last_dose_h + 4),
      C8_final_interval = get_nearest(time, CP_SC, last_dose_h + 8),
      C12_final_interval = get_nearest(time, CP_SC, last_dose_h + 12),
      Ctrough_final_interval = get_nearest(time, CP_SC, t_end_md),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "SC-70303")
) %>%
  select(
    Dose,
    Analyte,
    Cmax_final_interval,
    Tmax_final_interval,
    C1_final_interval,
    C2_final_interval,
    C4_final_interval,
    C8_final_interval,
    C12_final_interval,
    Ctrough_final_interval
  )




fig3_raw <- lapply(dose_mg, function(d) {
  set.seed(123)
  
  mod_pop %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = "DEPOT")) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(
      ID,
      time,
      CP_EPL = pmax(CP_EPL_ngmL, 0),
      CP_SC = pmax(CP_SC_ngmL, 0),
      Dose = paste0(d, " mg single dose")
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- bind_rows(
  fig3_raw %>%
    group_by(Dose, time) %>%
    summarise(
      C_med = median(CP_EPL, na.rm = TRUE),
      C_p05 = quantile(CP_EPL, 0.05, na.rm = TRUE),
      C_p95 = quantile(CP_EPL, 0.95, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "Eplerenone total"),
  
  fig3_raw %>%
    group_by(Dose, time) %>%
    summarise(
      C_med = median(CP_SC, na.rm = TRUE),
      C_p05 = quantile(CP_SC, 0.05, na.rm = TRUE),
      C_p95 = quantile(CP_SC, 0.95, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "SC-70303")
)

p3 <- ggplot(fig3_sum, aes(time, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  facet_wrap(~Analyte, scales = "free_y") +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Eplerenone and SC-70303 single dose, population"
  )

fig3_ind <- bind_rows(
  fig3_raw %>%
    group_by(Dose, ID) %>%
    summarise(
      Cmax = max(CP_EPL, na.rm = TRUE),
      Tmax = time[which.max(CP_EPL)],
      C1 = get_nearest(time, CP_EPL, 1),
      C2 = get_nearest(time, CP_EPL, 2),
      C4 = get_nearest(time, CP_EPL, 4),
      C8 = get_nearest(time, CP_EPL, 8),
      C12 = get_nearest(time, CP_EPL, 12),
      Ctrough = get_nearest(time, CP_EPL, tau_h),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "Eplerenone total"),
  
  fig3_raw %>%
    group_by(Dose, ID) %>%
    summarise(
      Cmax = max(CP_SC, na.rm = TRUE),
      Tmax = time[which.max(CP_SC)],
      C1 = get_nearest(time, CP_SC, 1),
      C2 = get_nearest(time, CP_SC, 2),
      C4 = get_nearest(time, CP_SC, 4),
      C8 = get_nearest(time, CP_SC, 8),
      C12 = get_nearest(time, CP_SC, 12),
      Ctrough = get_nearest(time, CP_SC, tau_h),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "SC-70303")
)

fig3_summary <- fig3_ind %>%
  group_by(Dose, Analyte) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    
    C1_med = median(C1, na.rm = TRUE),
    C1_p05 = quantile(C1, 0.05, na.rm = TRUE),
    C1_p95 = quantile(C1, 0.95, na.rm = TRUE),
    
    C2_med = median(C2, na.rm = TRUE),
    C2_p05 = quantile(C2, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2, 0.95, na.rm = TRUE),
    
    C4_med = median(C4, na.rm = TRUE),
    C4_p05 = quantile(C4, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4, 0.95, na.rm = TRUE),
    
    C8_med = median(C8, na.rm = TRUE),
    C8_p05 = quantile(C8, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8, 0.95, na.rm = TRUE),
    
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )



fig4_raw <- lapply(dose_mg, function(d) {
  set.seed(123)
  
  mod_pop %>%
    idata_set(idata_pop) %>%
    ev(ev(
      time = 0,
      amt = d,
      cmt = "DEPOT",
      ii = tau_h,
      addl = addl_md
    )) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(
      ID,
      time,
      CP_EPL = pmax(CP_EPL_ngmL, 0),
      CP_SC = pmax(CP_SC_ngmL, 0),
      Dose = paste0(d, " mg q24h x", n_doses)
    )
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- bind_rows(
  fig4_raw %>%
    group_by(Dose, time) %>%
    summarise(
      C_med = median(CP_EPL, na.rm = TRUE),
      C_p05 = quantile(CP_EPL, 0.05, na.rm = TRUE),
      C_p95 = quantile(CP_EPL, 0.95, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "Eplerenone total"),
  
  fig4_raw %>%
    group_by(Dose, time) %>%
    summarise(
      C_med = median(CP_SC, na.rm = TRUE),
      C_p05 = quantile(CP_SC, 0.05, na.rm = TRUE),
      C_p95 = quantile(CP_SC, 0.95, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "SC-70303")
)

p4 <- ggplot(fig4_sum, aes(time / 24, C_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = C_p05, ymax = C_p95), alpha = 0.25, colour = NA) +
  geom_line(linewidth = 1.1) +
  facet_wrap(~Analyte, scales = "free_y") +
  theme_bw() +
  labs(
    x = "Time (days)",
    y = "Concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Eplerenone and SC-70303 multidose, population"
  )

fig4_ind <- bind_rows(
  fig4_raw %>%
    filter(time >= last_dose_h, time <= t_end_md) %>%
    group_by(Dose, ID) %>%
    summarise(
      Cmax_final_interval = max(CP_EPL, na.rm = TRUE),
      Tmax_final_interval = time[which.max(CP_EPL)] - last_dose_h,
      C1_final_interval = get_nearest(time, CP_EPL, last_dose_h + 1),
      C2_final_interval = get_nearest(time, CP_EPL, last_dose_h + 2),
      C4_final_interval = get_nearest(time, CP_EPL, last_dose_h + 4),
      C8_final_interval = get_nearest(time, CP_EPL, last_dose_h + 8),
      C12_final_interval = get_nearest(time, CP_EPL, last_dose_h + 12),
      Ctrough_final_interval = get_nearest(time, CP_EPL, t_end_md),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "Eplerenone total"),
  
  fig4_raw %>%
    filter(time >= last_dose_h, time <= t_end_md) %>%
    group_by(Dose, ID) %>%
    summarise(
      Cmax_final_interval = max(CP_SC, na.rm = TRUE),
      Tmax_final_interval = time[which.max(CP_SC)] - last_dose_h,
      C1_final_interval = get_nearest(time, CP_SC, last_dose_h + 1),
      C2_final_interval = get_nearest(time, CP_SC, last_dose_h + 2),
      C4_final_interval = get_nearest(time, CP_SC, last_dose_h + 4),
      C8_final_interval = get_nearest(time, CP_SC, last_dose_h + 8),
      C12_final_interval = get_nearest(time, CP_SC, last_dose_h + 12),
      Ctrough_final_interval = get_nearest(time, CP_SC, t_end_md),
      .groups = "drop"
    ) %>%
    mutate(Analyte = "SC-70303")
)

fig4_summary <- fig4_ind %>%
  group_by(Dose, Analyte) %>%
  summarise(
    Cmax_med = median(Cmax_final_interval, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax_final_interval, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax_final_interval, 0.95, na.rm = TRUE),
    
    Tmax_med = median(Tmax_final_interval, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax_final_interval, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax_final_interval, 0.95, na.rm = TRUE),
    
    C1_med = median(C1_final_interval, na.rm = TRUE),
    C1_p05 = quantile(C1_final_interval, 0.05, na.rm = TRUE),
    C1_p95 = quantile(C1_final_interval, 0.95, na.rm = TRUE),
    
    C2_med = median(C2_final_interval, na.rm = TRUE),
    C2_p05 = quantile(C2_final_interval, 0.05, na.rm = TRUE),
    C2_p95 = quantile(C2_final_interval, 0.95, na.rm = TRUE),
    
    C4_med = median(C4_final_interval, na.rm = TRUE),
    C4_p05 = quantile(C4_final_interval, 0.05, na.rm = TRUE),
    C4_p95 = quantile(C4_final_interval, 0.95, na.rm = TRUE),
    
    C8_med = median(C8_final_interval, na.rm = TRUE),
    C8_p05 = quantile(C8_final_interval, 0.05, na.rm = TRUE),
    C8_p95 = quantile(C8_final_interval, 0.95, na.rm = TRUE),
    
    C12_med = median(C12_final_interval, na.rm = TRUE),
    C12_p05 = quantile(C12_final_interval, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12_final_interval, 0.95, na.rm = TRUE),
    
    Ctrough_med = median(Ctrough_final_interval, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough_final_interval, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough_final_interval, 0.95, na.rm = TRUE),
    
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary