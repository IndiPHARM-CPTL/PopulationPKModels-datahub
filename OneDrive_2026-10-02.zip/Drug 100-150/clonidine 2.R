library(mrgsolve)
library(dplyr)
library(tibble)
library(ggplot2)

clonidine_code <- '
$PROB
Oral clonidine one-compartment PK model
- Ref: Anavekar SN, Howes LG, Jarrott B, Syrjanen M, Conway EL, Louis WJ. Pharmacokinetics and antihypertensive effects of low dose clonidine during chronic therapy. J Clin Pharmacol. 1989;29(4):321-326. doi:10.1002/j.1552-4604.1989.tb03335.x

$PARAM @annotated
KA   : 0.85 : 1/h  First-order absorption rate constant
CL   : 12.3 : L/h  Apparent oral clearance
VAPP : 268  : L    Apparent volume of distribution

$CMT
GUT CENT

$OMEGA @annotated
EKA   : 0.160 : IIV on KA
ECL   : 0.200 : IIV on CL
EVAPP : 0.250 : IIV on VAPP

$MAIN
double KAi = KA * exp(EKA);
double CLi = CL * exp(ECL);
double VAPPi = VAPP * exp(EVAPP);
double KELi = CLi / VAPPi;

$ODE
dxdt_GUT = -KAi * GUT;
dxdt_CENT = KAi * GUT - KELi * CENT;

$TABLE
double C_CLON_ngmL = CENT / VAPPi;

$CAPTURE C_CLON_ngmL
'

mod <- mcode("clonidine_anavekar_1989_1c", clonidine_code)

dose_mcg <- c(37.5, 75, 150)
n_pop <- 1000

tau_h <- 12
n_doses <- 10
addl_md <- n_doses - 1

t_end_sd <- 24
last_dose_h <- (n_doses - 1) * tau_h
final_interval_end_h <- last_dose_h + tau_h
t_end_md <- final_interval_end_h

delta_sd <- 0.05
delta_md <- 0.10

idata_typ <- tibble(ID = 1)
idata_pop <- tibble(ID = 1:n_pop)
mod_typ <- zero_re(mod)

dose_levels_sd <- paste0(dose_mcg, " mcg")
dose_levels_md <- paste0(dose_mcg, " mcg q12h x", n_doses)

get_nearest <- function(time, conc, target_time) conc[which.min(abs(time - target_time))]







fig1_raw <- lapply(dose_mcg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = 1)) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(ID, time, CP = pmax(C_CLON_ngmL, 0), Dose = paste0(d, " mcg"))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

p1 <- ggplot(fig1_raw, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time after oral dose (h)",
    y = "Plasma clonidine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Clonidine twice-daily single-dose"
  )

fig1_summary <- fig1_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_ng_mL = max(CP, na.rm = TRUE),
    Tmax_h = time[which.max(CP)],
    C24_ng_mL = get_nearest(time, CP, 24),
    .groups = "drop"
  )






fig2_raw <- lapply(dose_mcg, function(d) {
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev(time = 0, amt = d, cmt = 1, ii = tau_h, addl = addl_md)) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(ID, time, CP = pmax(C_CLON_ngmL, 0), Dose = paste0(d, " mcg q12h x", n_doses))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

p2 <- ggplot(fig2_raw, aes(time, CP, color = Dose)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Plasma clonidine concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Clonidine twice-daily multi-dose for 10 days"
  )

fig2_summary <- fig2_raw %>%
  filter(time >= last_dose_h, time <= final_interval_end_h) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax_ng_mL = max(CP, na.rm = TRUE),
    Tmax_h = time[which.max(CP)] - last_dose_h,
    Ctrough_ng_mL = get_nearest(time, CP, final_interval_end_h),
    .groups = "drop"
  )







fig3_raw <- lapply(dose_mcg, function(d) {
  set.seed(123)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = 1)) %>%
    mrgsim(end = t_end_sd, delta = delta_sd, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(ID, time, CP = pmax(C_CLON_ngmL, 0), Dose = paste0(d, " mcg"))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_sd))

fig3_sum <- fig3_raw %>%
  group_by(Dose, time) %>%
  summarise(
    CP_med = median(CP, na.rm = TRUE),
    CP_p05 = quantile(CP, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p3 <- ggplot(fig3_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time after oral dose (h)",
    y = "Plasma clonidine concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 3. Clonidine twice-daily single-dose, population"
  )

fig3_ind <- fig3_raw %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)],
    C12 = get_nearest(time, CP, 12),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    C12_med = median(C12, na.rm = TRUE),
    C12_p05 = quantile(C12, 0.05, na.rm = TRUE),
    C12_p95 = quantile(C12, 0.95, na.rm = TRUE),
    .groups = "drop"
  )







fig4_raw <- lapply(dose_mcg, function(d) {
  set.seed(123)
  
  mod %>%
    idata_set(idata_pop) %>%
    ev(ev(time = 0, amt = d, cmt = 1, ii = tau_h, addl = addl_md)) %>%
    mrgsim(end = t_end_md, delta = delta_md, obsonly = TRUE) %>%
    as_tibble() %>%
    transmute(ID, time, CP = pmax(C_CLON_ngmL, 0), Dose = paste0(d, " mcg q12h x", n_doses))
}) %>%
  bind_rows() %>%
  mutate(Dose = factor(Dose, levels = dose_levels_md))

fig4_sum <- fig4_raw %>%
  group_by(Dose, time) %>%
  summarise(
    CP_med = median(CP, na.rm = TRUE),
    CP_p05 = quantile(CP, 0.05, na.rm = TRUE),
    CP_p95 = quantile(CP, 0.95, na.rm = TRUE),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time, CP_med, color = Dose, fill = Dose)) +
  geom_ribbon(aes(ymin = CP_p05, ymax = CP_p95), alpha = 0.15, color = NA) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (h)",
    y = "Plasma clonidine concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Clonidine twice-daily multi-dose for 10 days, population"
  )

fig4_ind <- fig4_raw %>%
  filter(time >= last_dose_h, time <= final_interval_end_h) %>%
  group_by(Dose, ID) %>%
  summarise(
    Cmax = max(CP, na.rm = TRUE),
    Tmax = time[which.max(CP)] - last_dose_h,
    Ctrough = get_nearest(time, CP, final_interval_end_h),
    .groups = "drop"
  )

fig4_summary <- fig4_ind %>%
  group_by(Dose) %>%
  summarise(
    Cmax_med = median(Cmax, na.rm = TRUE),
    Cmax_p05 = quantile(Cmax, 0.05, na.rm = TRUE),
    Cmax_p95 = quantile(Cmax, 0.95, na.rm = TRUE),
    Tmax_med = median(Tmax, na.rm = TRUE),
    Tmax_p05 = quantile(Tmax, 0.05, na.rm = TRUE),
    Tmax_p95 = quantile(Tmax, 0.95, na.rm = TRUE),
    Ctrough_med = median(Ctrough, na.rm = TRUE),
    Ctrough_p05 = quantile(Ctrough, 0.05, na.rm = TRUE),
    Ctrough_p95 = quantile(Ctrough, 0.95, na.rm = TRUE),
    .groups = "drop"
  )


p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary