library(mrgsolve)
library(dplyr)
library(ggplot2)
library(tibble)

fludrocortisone_code <- '
$PROB
- Ref: Hamitouche N, Comets E, Ribot M, Alvarez JC,
  Bellissant E, Laviolle B. Population pharmacokinetic-
  pharmacodynamic model of oral fludrocortisone and
  intravenous hydrocortisone in healthy volunteers.
  AAPS J. 2017;19(3):727-735.
  doi:10.1208/s12248-016-0041-9

$PARAM @annotated
KA       : 0.43   : 1/h    First-order absorption rate constant
CL       : 40.8   : L/h    Apparent oral clearance
V        : 82.4   : L      Apparent volume of distribution
F1       : 1.00   : --     Relative oral bioavailability


$OMEGA @labels ETA_KA ETA_V ETA_CL_OCC
0.03
0.06
0.14

$SIGMA
0.34

$CMT
DEPOT CENT

$GLOBAL
double KAi, CLi, Vi;

$MAIN
KAi = KA * exp(ETA(1));
Vi  = V  * exp(ETA(2));
CLi = CL * exp(ETA(3));

F_DEPOT = F1;

$ODE
dxdt_DEPOT = -KAi * DEPOT;

dxdt_CENT = KAi * DEPOT
            - (CLi / Vi) * CENT;

$TABLE
double CP = (CENT / Vi) * 1000.0;
double DV = CP * (1.0 + EPS(1));

$CAPTURE CP
'
mod_flu <- mcode("fludrocortisone_popPK", fludrocortisone_code)


doses_mg <- c(0.05)
dose_levels <- paste0(doses_mg * 1000," mcg")
tau_h    <- 24
n_doses  <- 7
addl_md  <- n_doses - 1
t_end_sd <- 24
delta_sd <- 0.05
t_end_md <- 24*8
delta_md <- 0.05
last_dose_time_h   <- (n_doses - 1) * tau_h
last_trough_time_h <- n_doses * tau_h
mod_typ <- zero_re(mod_flu)
idata_typ <- tibble(ID = 1)

make_idata_pop <- function(N) {
  tibble(ID = seq_len(N))
}

at_time <- function(time, value, target) {
  value[which.min(abs(time - target))]
}

fig1_list <- lapply(doses_mg, function(d) {
  ev_sd <- ev(
    amt = d,
    cmt = 1,
    time = 0
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(group = paste0(d * 1000, " mcg"))
})

fig1_out <- bind_rows(fig1_list) %>%
  mutate(group = factor(group, levels = dose_levels))

p1 <- ggplot(fig1_out, aes(time, CP, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Fludrocortisone concentration (ng/mL)",
    color = "Dose",
    title = "Figure 1. Fludrocortisone single oral dose"
  )

fig1_summary <- fig1_out %>%
  group_by(group) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C2h = at_time(time, CP, 2),
    C4h = at_time(time, CP, 4),
    C6h = at_time(time, CP, 6),
    C8h = at_time(time, CP, 8),
    C12h = at_time(time, CP, 12),
    C24h = at_time(time, CP, 24),
    .groups = "drop"
  )


fig2_list <- lapply(doses_mg, function(d) {
  ev_md <- ev(
    amt = d,
    ii = tau_h,
    addl = addl_md,
    cmt = 1
  )
  
  mod_typ %>%
    idata_set(idata_typ) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(group = paste0(d * 1000, " mcg"))
})

fig2_out <- bind_rows(fig2_list) %>%
  mutate(group = factor(group, levels = dose_levels))

p2 <- ggplot(fig2_out, aes(time, CP, color = group)) +
  geom_line(linewidth = 1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Fludrocortisone concentration (ng/mL)",
    color = "Dose",
    title = "Figure 2. Fludrocortisone multi-dose"
    )


fig2_summary <- fig2_out %>%
  group_by(group) %>%
  summarise(
    Cmax_last = max(
      CP[
        time >= last_dose_time_h &
          time <= last_trough_time_h
      ]
    ),
    
    Tmax_last_h =
      time[
        time >= last_dose_time_h &
          time <= last_trough_time_h
      ][
        which.max(
          CP[
            time >= last_dose_time_h &
              time <= last_trough_time_h
          ]
        )
      ] -
      last_dose_time_h,
    
    Ctrough_6h = at_time(
      time,
      CP,
      last_trough_time_h
    ),
    
    C6h = at_time(time, CP, 6),
    C12h = at_time(time, CP, 12),
    C18h = at_time(time, CP, 18),
    C24h = at_time(time, CP, 24),
    
    .groups = "drop"
  )


N <- 1000

idata_pop <- make_idata_pop(N)

fig3_list <- lapply(doses_mg, function(d) {
  set.seed(123)
  
  ev_sd <- ev(
    amt = d,
    cmt = 1,
    time = 0
  )
  
  mod_flu %>%
    idata_set(idata_pop) %>%
    ev(ev_sd) %>%
    mrgsim(end = t_end_sd, delta = delta_sd) %>%
    as_tibble() %>%
    mutate(group = paste0(d * 1000, " mcg"))
})

fig3_raw <- bind_rows(fig3_list) %>%
  mutate(group = factor(group, levels = dose_levels))

fig3_sum <- fig3_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP),
    C_p05 = quantile(CP, 0.05),
    C_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p3 <- ggplot(
  fig3_sum,
  aes(time, C_med, color = group, fill = group)
) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Fludrocortisone concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = paste0(
      "Figure 3. Fludrocortisone single oral dose, ",
      "population"
    )
  )

fig3_ind <- fig3_raw %>%
  group_by(group, ID) %>%
  summarise(
    Cmax = max(CP),
    Tmax_h = time[which.max(CP)],
    C2h = at_time(time, CP, 2),
    C4h = at_time(time, CP, 4),
    C6h = at_time(time, CP, 6),
    C8h = at_time(time, CP, 8),
    C12h = at_time(time, CP, 12),
    C24h = at_time(time, CP, 24),
    .groups = "drop"
  )

fig3_summary <- fig3_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax),
    Cmax_p05 = quantile(Cmax, 0.05),
    Cmax_p95 = quantile(Cmax, 0.95),
    
    Tmax_med = median(Tmax_h),
    Tmax_p05 = quantile(Tmax_h, 0.05),
    Tmax_p95 = quantile(Tmax_h, 0.95),
    
    C2h_med = median(C2h),
    C2h_p05 = quantile(C2h, 0.05),
    C2h_p95 = quantile(C2h, 0.95),
    
    C4h_med = median(C4h),
    C4h_p05 = quantile(C4h, 0.05),
    C4h_p95 = quantile(C4h, 0.95),
    
    C6h_med = median(C6h),
    C6h_p05 = quantile(C6h, 0.05),
    C6h_p95 = quantile(C6h, 0.95),
    
    C8h_med = median(C8h),
    C8h_p05 = quantile(C8h, 0.05),
    C8h_p95 = quantile(C8h, 0.95),
    
    C12h_med = median(C12h),
    C12h_p05 = quantile(C12h, 0.05),
    C12h_p95 = quantile(C12h, 0.95),
    
    C24h_med = median(C24h),
    C24h_p05 = quantile(C24h, 0.05),
    C24h_p95 = quantile(C24h, 0.95),
    
    .groups = "drop"
  )


fig4_list <- lapply(doses_mg, function(d) {
  set.seed(123)
  
  ev_md <- ev(
    amt = d,
    ii = tau_h,
    addl = addl_md,
    cmt = 1
  )
  
  mod_flu %>%
    idata_set(idata_pop) %>%
    ev(ev_md) %>%
    mrgsim(end = t_end_md, delta = delta_md) %>%
    as_tibble() %>%
    mutate(group = paste0(d * 1000, " mcg"))
})

fig4_raw <- bind_rows(fig4_list) %>%
  mutate(group = factor(group, levels = dose_levels))

fig4_sum <- fig4_raw %>%
  group_by(group, time) %>%
  summarise(
    C_med = median(CP),
    C_p05 = quantile(CP, 0.05),
    C_p95 = quantile(CP, 0.95),
    .groups = "drop"
  )

p4 <- ggplot(fig4_sum, aes(time, C_med, color = group, fill = group)
) +
  geom_ribbon(
    aes(ymin = C_p05, ymax = C_p95),
    alpha = 0.25,
    colour = NA
  ) +
  geom_line(linewidth = 1.1) +
  theme_bw() +
  labs(
    x = "Time (hours)",
    y = "Fludrocortisone concentration (ng/mL)",
    color = "Dose",
    fill = "Dose",
    title = "Figure 4. Fludrocortisone multi-dose, population"
  )

fig4_samples <- fig4_raw %>%
  group_by(group, ID) %>%
  summarise(
    C6h = at_time(time, CP, 6),
    C12h = at_time(time, CP, 12),
    C18h = at_time(time, CP, 18),
    C24h = at_time(time, CP, 24),
    .groups = "drop"
  )

fig4_last_interval <- fig4_raw %>%
  filter(
    time >= last_dose_time_h,
    time <= last_trough_time_h
  ) %>%
  group_by(group, ID) %>%
  summarise(
    Cmax_last = max(CP),
    
    Tmax_last_h =
      time[which.max(CP)] -
      last_dose_time_h,
    
    Ctrough_6h = at_time(time, CP, last_trough_time_h),
    
    .groups = "drop"
  )

fig4_ind <- fig4_last_interval %>%
  left_join(
    fig4_samples,
    by = c("group", "ID")
  )

fig4_summary <- fig4_ind %>%
  group_by(group) %>%
  summarise(
    Cmax_med = median(Cmax_last),
    Cmax_p05 = quantile(Cmax_last, 0.05),
    Cmax_p95 = quantile(Cmax_last, 0.95),
    
    Tmax_med = median(Tmax_last_h),
    Tmax_p05 = quantile(Tmax_last_h, 0.05),
    Tmax_p95 = quantile(Tmax_last_h, 0.95),
    
    Ctrough_med = median(Ctrough_6h),
    Ctrough_p05 = quantile(Ctrough_6h, 0.05),
    Ctrough_p95 = quantile(Ctrough_6h, 0.95),
    
    C6h_med = median(C6h),
    C6h_p05 = quantile(C6h, 0.05),
    C6h_p95 = quantile(C6h, 0.95),
    
    C12h_med = median(C12h),
    C12h_p05 = quantile(C12h, 0.05),
    C12h_p95 = quantile(C12h, 0.95),
    
    C18h_med = median(C18h),
    C18h_p05 = quantile(C18h, 0.05),
    C18h_p95 = quantile(C18h, 0.95),
    
    C24h_med = median(C24h),
    C24h_p05 = quantile(C24h, 0.05),
    C24h_p95 = quantile(C24h, 0.95),
    
    .groups = "drop"
  )

p1
p2
p3
p4

fig1_summary
fig2_summary
fig3_summary
fig4_summary